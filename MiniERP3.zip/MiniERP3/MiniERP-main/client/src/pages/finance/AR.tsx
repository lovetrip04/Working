import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  PieChart,
  LineChart,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Download,
  Filter,
  Clock,
  DollarSign,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function AccountsReceivable() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Accounts Receivable (AR)</h1>
          <p className="text-sm text-muted-foreground">Manage customer invoices and payment collections</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            New Invoice
          </Button>
        </div>
      </div>

      {/* AR Navigation Tabs */}
      <Card>
        <Tabs defaultValue="overview" className="w-full">
          <div className="border-b px-4">
            <TabsList className="bg-transparent h-12 p-0 rounded-none">
              <TabsTrigger 
                value="overview" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="invoices" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Invoices
              </TabsTrigger>
              <TabsTrigger 
                value="aging" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Aging Analysis
              </TabsTrigger>
              <TabsTrigger 
                value="payments" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Payments
              </TabsTrigger>
              <TabsTrigger 
                value="collections" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Collections
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Overview Tab Content */}
          <TabsContent value="overview" className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Summary KPI Cards */}
              <ARCard 
                title="Total Receivables" 
                value="$482,917.32" 
                change={4.2} 
                isPositive={true}
                period="vs last month"
                icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
              />
              <ARCard 
                title="Average Collection Period" 
                value="32 days" 
                change={-2.5} 
                isPositive={true}
                period="vs last month"
                icon={<Clock className="h-4 w-4 text-muted-foreground" />}
              />
              <ARCard 
                title="Overdue Receivables" 
                value="$87,432.15" 
                change={1.7} 
                isPositive={false}
                period="vs last month"
                icon={<BarChart className="h-4 w-4 text-amber-500" />}
              />
            </div>
            
            {/* Aging Summary */}
            <div className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Aging Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                    Receivables Aging Chart
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Additional AR Widgets */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Top Customers by Outstanding Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <ARCustomer 
                      name="Acme Corporation"
                      balance="$78,500.00"
                      aging="15-30 days"
                      creditLimit="$100,000.00"
                    />
                    <ARCustomer 
                      name="TechNova Inc"
                      balance="$54,250.75"
                      aging="Current"
                      creditLimit="$150,000.00"
                    />
                    <ARCustomer 
                      name="Global Enterprises"
                      balance="$42,890.50"
                      aging="30-60 days"
                      creditLimit="$75,000.00"
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Collections Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <CollectionActivity 
                      customer="Acme Corporation"
                      activity="Payment reminder sent"
                      date="May 12, 2025"
                      status="Pending"
                    />
                    <CollectionActivity 
                      customer="Global Enterprises"
                      activity="Follow-up call scheduled"
                      date="May 15, 2025"
                      status="Scheduled"
                    />
                    <CollectionActivity 
                      customer="TechNova Inc"
                      activity="Partial payment received"
                      date="May 10, 2025"
                      status="Completed"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Other tabs content */}
          <TabsContent value="invoices" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Invoice management interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="aging" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Detailed aging analysis would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="payments" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Payment management interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="collections" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Collections management interface would appear here
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}

// Supporting components
type ARCardProps = {
  title: string;
  value: string;
  change: number;
  isPositive: boolean;
  period: string;
  icon: React.ReactNode;
};

function ARCard({ title, value, change, isPositive, period, icon }: ARCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center space-x-1 text-xs mt-1">
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          </span>
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? "+" : ""}{change}%
          </span>
          <span className="text-muted-foreground">{period}</span>
        </div>
      </CardContent>
    </Card>
  );
}

type ARCustomerProps = {
  name: string;
  balance: string;
  aging: string;
  creditLimit: string;
};

function ARCustomer({ name, balance, aging, creditLimit }: ARCustomerProps) {
  const isOverdue = aging !== "Current";
  
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{name}</div>
        <div className="text-xs text-muted-foreground">Credit limit: {creditLimit}</div>
      </div>
      <div className="text-right">
        <div className="font-medium">{balance}</div>
        <div className="text-xs">
          {isOverdue ? (
            <Badge variant="destructive" className="text-xs rounded-sm">{aging}</Badge>
          ) : (
            <Badge variant="outline" className="text-xs rounded-sm">{aging}</Badge>
          )}
        </div>
      </div>
    </div>
  );
}

type CollectionActivityProps = {
  customer: string;
  activity: string;
  date: string;
  status: string;
};

function CollectionActivity({ customer, activity, date, status }: CollectionActivityProps) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{customer}</div>
        <div className="text-xs text-muted-foreground">{activity}</div>
      </div>
      <div className="text-right">
        <div className="text-xs text-muted-foreground">{date}</div>
        <div className="text-xs">
          <Badge 
            variant={status === "Completed" ? "default" : status === "Pending" ? "secondary" : "outline"} 
            className={`text-xs rounded-sm ${status === "Completed" ? "bg-green-500" : status === "Pending" ? "bg-amber-500" : ""}`}
          >
            {status}
          </Badge>
        </div>
      </div>
    </div>
  );
}