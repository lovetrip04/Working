import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/apiClient";
import { Link } from "wouter";

// UI Components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialog } from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import { FileSpreadsheet, Edit, Trash2, RefreshCw, Plus, FileUp, Landmark, CreditCard, ArrowLeft } from "lucide-react";
import { toast } from "@/hooks/use-toast";

// Types for the data
interface CompanyCode {
  id: number;
  code: string;
  name: string;
}

interface ChartOfAccount {
  id: number;
  code: string;
  name: string;
  description?: string;
  accountType: string;
  accountSubtype?: string;
  accountGroup?: string;
  balanceSheetCategory?: string;
  incomeStatementCategory?: string;
  debitCredit?: string;
  isBalanceSheet: boolean;
  isIncomeStatement: boolean;
  isCashFlow: boolean;
  isTaxRelevant: boolean;
  isControlAccount: boolean;
  isReconciliationRequired: boolean;
  isActive: boolean;
  companyCodeId: number;
  parentAccountId?: number;
  // Relations
  companyCode?: CompanyCode;
}

// Validation schema for the form
const chartOfAccountFormSchema = z.object({
  code: z.string().min(3, "Code must be at least 3 characters").max(10, "Code must be at most 10 characters"),
  name: z.string().min(3, "Name must be at least 3 characters"),
  description: z.string().optional(),
  accountType: z.string().min(1, "Account type is required"),
  accountSubtype: z.string().optional(),
  accountGroup: z.string().optional(),
  balanceSheetCategory: z.string().optional(),
  incomeStatementCategory: z.string().optional(),
  debitCredit: z.string().optional(),
  isBalanceSheet: z.boolean().default(false),
  isIncomeStatement: z.boolean().default(false),
  isCashFlow: z.boolean().default(false),
  isTaxRelevant: z.boolean().default(false),
  isControlAccount: z.boolean().default(false),
  isReconciliationRequired: z.boolean().default(false),
  isActive: z.boolean().default(true),
  companyCodeId: z.coerce.number().min(1, "Company code is required"),
  parentAccountId: z.coerce.number().optional(),
});

export default function ChartOfAccounts() {
  // State management
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<ChartOfAccount | null>(null);
  const [deletingAccount, setDeletingAccount] = useState<ChartOfAccount | null>(null);

  // Forms
  const addForm = useForm<z.infer<typeof chartOfAccountFormSchema>>({
    resolver: zodResolver(chartOfAccountFormSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      accountType: "",
      accountSubtype: "",
      accountGroup: "",
      balanceSheetCategory: "",
      incomeStatementCategory: "",
      debitCredit: "debit",
      isBalanceSheet: false,
      isIncomeStatement: false,
      isCashFlow: false,
      isTaxRelevant: false,
      isControlAccount: false,
      isReconciliationRequired: false,
      isActive: true
    },
  });

  const editForm = useForm<z.infer<typeof chartOfAccountFormSchema>>({
    resolver: zodResolver(chartOfAccountFormSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      accountType: "",
      accountSubtype: "",
      accountGroup: "",
      balanceSheetCategory: "",
      incomeStatementCategory: "",
      debitCredit: "debit",
      isBalanceSheet: false,
      isIncomeStatement: false,
      isCashFlow: false,
      isTaxRelevant: false,
      isControlAccount: false,
      isReconciliationRequired: false,
      isActive: true
    },
  });

  // Fetch data
  const { data: accounts = [] as ChartOfAccount[], isLoading, error } = useQuery({
    queryKey: ['/api/master-data/chart-of-accounts'],
    retry: 1,
  });

  const { data: companyCodes = [] as CompanyCode[] } = useQuery({
    queryKey: ['/api/master-data/company-code'],
    retry: 1,
  });

  // Mutations
  const addAccountMutation = useMutation({
    mutationFn: (data: z.infer<typeof chartOfAccountFormSchema>) => 
      apiRequest('/api/master-data/chart-of-accounts', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/chart-of-accounts'] });
      setIsAddDialogOpen(false);
      addForm.reset();
      toast({
        title: "Account Added",
        description: "G/L Account has been successfully added to the chart of accounts.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add account. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateAccountMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: z.infer<typeof chartOfAccountFormSchema> }) => 
      apiRequest(`/api/master-data/chart-of-accounts/${id}`, 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/chart-of-accounts'] });
      setIsEditDialogOpen(false);
      setEditingAccount(null);
      toast({
        title: "Account Updated",
        description: "G/L Account has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update account. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/master-data/chart-of-accounts/${id}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/chart-of-accounts'] });
      setIsDeleteDialogOpen(false);
      setDeletingAccount(null);
      toast({
        title: "Account Deleted",
        description: "G/L Account has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete account. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Form submit handlers
  const handleAddSubmit = (data: z.infer<typeof chartOfAccountFormSchema>) => {
    addAccountMutation.mutate(data);
  };

  const handleEditSubmit = (data: z.infer<typeof chartOfAccountFormSchema>) => {
    if (!editingAccount) return;
    updateAccountMutation.mutate({ id: editingAccount.id, data });
  };

  const openEditDialog = (account: ChartOfAccount) => {
    setEditingAccount(account);
    editForm.reset({
      code: account.code,
      name: account.name,
      description: account.description || "",
      accountType: account.accountType,
      accountSubtype: account.accountSubtype || "",
      accountGroup: account.accountGroup || "",
      balanceSheetCategory: account.balanceSheetCategory || "",
      incomeStatementCategory: account.incomeStatementCategory || "",
      debitCredit: account.debitCredit || "debit",
      isBalanceSheet: account.isBalanceSheet,
      isIncomeStatement: account.isIncomeStatement,
      isCashFlow: account.isCashFlow,
      isTaxRelevant: account.isTaxRelevant,
      isControlAccount: account.isControlAccount,
      isReconciliationRequired: account.isReconciliationRequired,
      isActive: account.isActive,
      companyCodeId: account.companyCodeId,
      parentAccountId: account.parentAccountId,
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (account: ChartOfAccount) => {
    setDeletingAccount(account);
    setIsDeleteDialogOpen(true);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center mb-6">
          <Link href="/master-data" className="mr-4 p-2 rounded-md hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Chart of Accounts</h1>
            <p className="text-gray-600 mt-1">
              Manage financial accounts structure for accounting and reporting
            </p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
          >
            <FileUp className="h-4 w-4" />
            <span>Import</span>
          </Button>
          <Button 
            variant="default" 
            onClick={() => setIsAddDialogOpen(true)}
            className="flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add Account</span>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Accounts</TabsTrigger>
          <TabsTrigger value="assets">Assets</TabsTrigger>
          <TabsTrigger value="liabilities">Liabilities</TabsTrigger>
          <TabsTrigger value="equity">Equity</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <AccountsTable 
            accounts={accounts as ChartOfAccount[]}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="assets">
          <AccountsTable 
            accounts={(accounts as ChartOfAccount[]).filter(account => account.accountType === 'asset')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="liabilities">
          <AccountsTable 
            accounts={(accounts as ChartOfAccount[]).filter(account => account.accountType === 'liability')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="equity">
          <AccountsTable 
            accounts={(accounts as ChartOfAccount[]).filter(account => account.accountType === 'equity')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="revenue">
          <AccountsTable 
            accounts={(accounts as ChartOfAccount[]).filter(account => account.accountType === 'revenue')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="expenses">
          <AccountsTable 
            accounts={(accounts as ChartOfAccount[]).filter(account => account.accountType === 'expense')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
      </Tabs>

      {/* Add Account Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>Add New G/L Account</DialogTitle>
            <DialogDescription>
              Add a new account to the chart of accounts. This will be used for financial reporting and transactions.
            </DialogDescription>
          </DialogHeader>
          <Form {...addForm}>
            <form onSubmit={addForm.handleSubmit(handleAddSubmit)} className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={addForm.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Number</FormLabel>
                      <FormControl>
                        <Input placeholder="10001" {...field} />
                      </FormControl>
                      <FormDescription>
                        Unique identifier in the chart of accounts
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Cash in Bank" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="companyCodeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company Code</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value?.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Company Code" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {companyCodes.map((companyCode) => (
                            <SelectItem key={companyCode.id} value={companyCode.id.toString()}>
                              {companyCode.code} - {companyCode.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={addForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Detailed description of this account" 
                        className="resize-none" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={addForm.control}
                  name="accountType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Type</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select account type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="asset">Asset</SelectItem>
                          <SelectItem value="liability">Liability</SelectItem>
                          <SelectItem value="equity">Equity</SelectItem>
                          <SelectItem value="revenue">Revenue</SelectItem>
                          <SelectItem value="expense">Expense</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="accountSubtype"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Subtype</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select account subtype" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="current_asset">Current Asset</SelectItem>
                          <SelectItem value="non_current_asset">Non-Current Asset</SelectItem>
                          <SelectItem value="current_liability">Current Liability</SelectItem>
                          <SelectItem value="non_current_liability">Non-Current Liability</SelectItem>
                          <SelectItem value="owner_equity">Owner's Equity</SelectItem>
                          <SelectItem value="retained_earnings">Retained Earnings</SelectItem>
                          <SelectItem value="operating_revenue">Operating Revenue</SelectItem>
                          <SelectItem value="other_revenue">Other Revenue</SelectItem>
                          <SelectItem value="operating_expense">Operating Expense</SelectItem>
                          <SelectItem value="other_expense">Other Expense</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={addForm.control}
                  name="accountGroup"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Group</FormLabel>
                      <FormControl>
                        <Input placeholder="Cash and Cash Equivalents" {...field} />
                      </FormControl>
                      <FormDescription>
                        Grouping for financial reporting
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="debitCredit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Normal Balance</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Debit or credit" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="debit">Debit</SelectItem>
                          <SelectItem value="credit">Credit</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Normal balance side for this account
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={addForm.control}
                  name="balanceSheetCategory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Balance Sheet Category</FormLabel>
                      <FormControl>
                        <Input placeholder="Current Assets" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="incomeStatementCategory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Income Statement Category</FormLabel>
                      <FormControl>
                        <Input placeholder="Operating Expenses" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <FormField
                    control={addForm.control}
                    name="isBalanceSheet"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Balance Sheet Account</FormLabel>
                          <FormDescription>
                            Appears on balance sheet reports
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="isIncomeStatement"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Income Statement Account</FormLabel>
                          <FormDescription>
                            Appears on income statement reports
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="space-y-4">
                  <FormField
                    control={addForm.control}
                    name="isCashFlow"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Cash Flow Account</FormLabel>
                          <FormDescription>
                            Relevant for cash flow statement
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="isTaxRelevant"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Tax Relevant</FormLabel>
                          <FormDescription>
                            Used for tax calculations and reporting
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={addForm.control}
                  name="isControlAccount"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Control Account</FormLabel>
                        <FormDescription>
                          Summarizes subsidiary ledger entries
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={addForm.control}
                  name="isReconciliationRequired"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Reconciliation Required</FormLabel>
                        <FormDescription>
                          Regular reconciliation is necessary
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={addForm.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Account can be used in transactions
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={addAccountMutation.isPending}>
                  {addAccountMutation.isPending ? "Saving..." : "Save Account"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Account Dialog - Similar to Add with prefilled values */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>Edit G/L Account</DialogTitle>
            <DialogDescription>
              Update the selected account in the chart of accounts.
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-6">
              {/* Same form fields as Add dialog */}
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={updateAccountMutation.isPending}>
                  {updateAccountMutation.isPending ? "Updating..." : "Update Account"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the account "{deletingAccount?.name}" ({deletingAccount?.code}).
              This action cannot be undone and may impact financial reporting.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingAccount && deleteAccountMutation.mutate(deletingAccount.id)}
              disabled={deleteAccountMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteAccountMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// Accounts Table Component
function AccountsTable({
  accounts,
  isLoading,
  onEdit,
  onDelete
}: {
  accounts: ChartOfAccount[];
  isLoading: boolean;
  onEdit: (account: ChartOfAccount) => void;
  onDelete: (account: ChartOfAccount) => void;
}) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center items-center h-40">
            <div className="flex flex-col items-center">
              <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
              <p className="mt-2 text-gray-500">Loading accounts...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!accounts || accounts.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center items-center h-40">
            <div className="flex flex-col items-center">
              <FileSpreadsheet className="h-8 w-8 text-gray-400" />
              <p className="mt-2 text-gray-500">No accounts found</p>
              <p className="text-sm text-gray-400">Add an account to get started</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Account Number</TableHead>
              <TableHead>Account Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Category/Group</TableHead>
              <TableHead>Normal Balance</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {accounts.map((account) => (
              <TableRow key={account.id}>
                <TableCell className="font-medium">{account.code}</TableCell>
                <TableCell>{account.name}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="capitalize">
                    {account.accountType}
                  </Badge>
                </TableCell>
                <TableCell>{account.accountGroup || account.balanceSheetCategory || account.incomeStatementCategory || '-'}</TableCell>
                <TableCell className="capitalize">{account.debitCredit || '-'}</TableCell>
                <TableCell>
                  {account.isActive ? (
                    <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                      Inactive
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onEdit(account)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDelete(account)}
                      className="text-red-500 hover:text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}