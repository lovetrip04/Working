import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/apiClient";

// UI Components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialog } from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import { 
  Building, Edit, Trash2, RefreshCw, Plus, FileUp, Mail,
  Phone, DollarSign, MapPin, Globe, User, Filter, TruckIcon, StarIcon, ArrowLeft
} from "lucide-react";
import { Link } from "wouter";
import { toast } from "@/hooks/use-toast";

// Types for data
interface Vendor {
  id: number;
  code: string;
  name: string;
  type: string;
  description?: string;
  taxId?: string;
  industry?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
  region?: string;
  phone?: string;
  altPhone?: string;
  email?: string;
  website?: string;
  currency?: string;
  paymentTerms?: string;
  paymentMethod?: string;
  supplierType?: string;
  category?: string;
  orderFrequency?: string;
  minimumOrderValue?: number;
  evaluationScore?: number;
  leadTime?: number;
  purchasingGroupId?: number;
  status: string;
  blacklisted: boolean;
  blacklistReason?: string;
  notes?: string;
  tags?: string[];
  companyCodeId?: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface VendorContact {
  id: number;
  vendorId: number;
  firstName: string;
  lastName: string;
  position?: string;
  department?: string;
  email?: string;
  phone?: string;
  mobile?: string;
  isPrimary: boolean;
  isOrderContact: boolean;
  isPurchaseContact: boolean;
  isQualityContact: boolean;
  isAccountsContact: boolean;
  preferredLanguage?: string;
  notes?: string;
  isActive: boolean;
}

// Validation schema for vendor form
const vendorFormSchema = z.object({
  code: z.string().min(2, "Code must be at least 2 characters").max(10, "Code must be at most 10 characters"),
  name: z.string().min(3, "Name must be at least 3 characters"),
  type: z.string().min(1, "Vendor type is required"),
  description: z.string().optional(),
  taxId: z.string().optional(),
  industry: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  country: z.string().optional(),
  postalCode: z.string().optional(),
  region: z.string().optional(),
  phone: z.string().optional(),
  altPhone: z.string().optional(),
  email: z.string().email("Invalid email format").optional().or(z.literal("")),
  website: z.string().optional(),
  currency: z.string().optional(),
  paymentTerms: z.string().optional(),
  paymentMethod: z.string().optional(),
  supplierType: z.string().optional(),
  category: z.string().optional(),
  orderFrequency: z.string().optional(),
  minimumOrderValue: z.coerce.number().optional(),
  evaluationScore: z.coerce.number().min(0).max(100).optional(),
  leadTime: z.coerce.number().optional(),
  purchasingGroupId: z.coerce.number().optional(),
  status: z.string().default("active"),
  blacklisted: z.boolean().default(false),
  blacklistReason: z.string().optional(),
  notes: z.string().optional(),
  tags: z.array(z.string()).optional(),
  companyCodeId: z.coerce.number().optional(),
  isActive: z.boolean().default(true),
});

// Validation schema for vendor contact form
const contactFormSchema = z.object({
  firstName: z.string().min(2, "First name is required"),
  lastName: z.string().min(2, "Last name is required"),
  position: z.string().optional(),
  department: z.string().optional(),
  email: z.string().email("Invalid email format").optional().or(z.literal("")),
  phone: z.string().optional(),
  mobile: z.string().optional(),
  isPrimary: z.boolean().default(false),
  isOrderContact: z.boolean().default(false),
  isPurchaseContact: z.boolean().default(false),
  isQualityContact: z.boolean().default(false),
  isAccountsContact: z.boolean().default(false),
  preferredLanguage: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
});

export default function Vendor() {
  // State management
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isAddContactDialogOpen, setIsAddContactDialogOpen] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
  const [deletingVendor, setDeletingVendor] = useState<Vendor | null>(null);
  const [selectedVendorId, setSelectedVendorId] = useState<number | null>(null);
  const [viewingVendorDetails, setViewingVendorDetails] = useState<Vendor | null>(null);
  const [isVendorDetailsOpen, setIsVendorDetailsOpen] = useState(false);

  // Forms
  const addForm = useForm<z.infer<typeof vendorFormSchema>>({
    resolver: zodResolver(vendorFormSchema),
    defaultValues: {
      code: "",
      name: "",
      type: "supplier",
      description: "",
      status: "active",
      blacklisted: false,
      isActive: true,
    },
  });

  const editForm = useForm<z.infer<typeof vendorFormSchema>>({
    resolver: zodResolver(vendorFormSchema),
    defaultValues: {
      code: "",
      name: "",
      type: "supplier",
      description: "",
      status: "active",
      blacklisted: false,
      isActive: true,
    },
  });

  const contactForm = useForm<z.infer<typeof contactFormSchema>>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      position: "",
      department: "",
      email: "",
      phone: "",
      mobile: "",
      isPrimary: false,
      isOrderContact: false,
      isPurchaseContact: false,
      isQualityContact: false,
      isAccountsContact: false,
      preferredLanguage: "English",
      notes: "",
      isActive: true,
    },
  });

  // Fetch data
  const { data: vendors = [] as Vendor[], isLoading, error } = useQuery({
    queryKey: ['/api/master-data/vendor'],
    retry: 1,
  });

  const { data: contacts = [] as VendorContact[], isLoading: isLoadingContacts } = useQuery({
    queryKey: ['/api/master-data/vendor-contact', selectedVendorId],
    enabled: !!selectedVendorId,
    retry: 1,
  });

  // Mutations
  const addVendorMutation = useMutation({
    mutationFn: (data: z.infer<typeof vendorFormSchema>) => 
      apiRequest('/api/master-data/vendor', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/vendor'] });
      setIsAddDialogOpen(false);
      addForm.reset();
      toast({
        title: "Vendor Added",
        description: "Vendor has been successfully added.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add vendor. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateVendorMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: z.infer<typeof vendorFormSchema> }) => 
      apiRequest(`/api/master-data/vendor/${id}`, 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/vendor'] });
      setIsEditDialogOpen(false);
      setEditingVendor(null);
      toast({
        title: "Vendor Updated",
        description: "Vendor has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update vendor. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteVendorMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/master-data/vendor/${id}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/vendor'] });
      setIsDeleteDialogOpen(false);
      setDeletingVendor(null);
      toast({
        title: "Vendor Deleted",
        description: "Vendor has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete vendor. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addContactMutation = useMutation({
    mutationFn: (data: z.infer<typeof contactFormSchema>) => 
      apiRequest(`/api/master-data/vendor/${selectedVendorId}/contacts`, 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/vendor-contact', selectedVendorId] });
      setIsAddContactDialogOpen(false);
      contactForm.reset();
      toast({
        title: "Contact Added",
        description: "Contact has been successfully added.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add contact. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Form submit handlers
  const handleAddSubmit = (data: z.infer<typeof vendorFormSchema>) => {
    addVendorMutation.mutate(data);
  };

  const handleEditSubmit = (data: z.infer<typeof vendorFormSchema>) => {
    if (!editingVendor) return;
    updateVendorMutation.mutate({ id: editingVendor.id, data });
  };

  const handleAddContactSubmit = (data: z.infer<typeof contactFormSchema>) => {
    if (!selectedVendorId) return;
    addContactMutation.mutate(data);
  };

  const openEditDialog = (vendor: Vendor) => {
    setEditingVendor(vendor);
    editForm.reset({
      code: vendor.code,
      name: vendor.name,
      type: vendor.type,
      description: vendor.description || "",
      taxId: vendor.taxId || "",
      industry: vendor.industry || "",
      address: vendor.address || "",
      city: vendor.city || "",
      state: vendor.state || "",
      country: vendor.country || "",
      postalCode: vendor.postalCode || "",
      region: vendor.region || "",
      phone: vendor.phone || "",
      altPhone: vendor.altPhone || "",
      email: vendor.email || "",
      website: vendor.website || "",
      currency: vendor.currency || "",
      paymentTerms: vendor.paymentTerms || "",
      paymentMethod: vendor.paymentMethod || "",
      supplierType: vendor.supplierType || "",
      category: vendor.category || "",
      orderFrequency: vendor.orderFrequency || "",
      minimumOrderValue: vendor.minimumOrderValue,
      evaluationScore: vendor.evaluationScore,
      leadTime: vendor.leadTime,
      purchasingGroupId: vendor.purchasingGroupId,
      status: vendor.status,
      blacklisted: vendor.blacklisted,
      blacklistReason: vendor.blacklistReason || "",
      notes: vendor.notes || "",
      companyCodeId: vendor.companyCodeId,
      isActive: vendor.isActive,
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (vendor: Vendor) => {
    setDeletingVendor(vendor);
    setIsDeleteDialogOpen(true);
  };

  const openVendorDetails = (vendor: Vendor) => {
    setViewingVendorDetails(vendor);
    setSelectedVendorId(vendor.id);
    setIsVendorDetailsOpen(true);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Vendor Master</h1>
          <p className="text-gray-600 mt-1">
            Manage suppliers, contractors, and service providers
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
            onClick={() => {
              const csvContent = (vendors as Vendor[])?.map((vendor: Vendor) => ({
                Code: vendor.code,
                Name: vendor.name,
                Type: vendor.type,
                Industry: vendor.industry || '',
                City: vendor.city || '',
                Country: vendor.country || '',
                Phone: vendor.phone || '',
                Email: vendor.email || '',
                PaymentTerms: vendor.paymentTerms || '',
                Status: vendor.isActive ? 'Active' : 'Inactive'
              })) || [];
              
              const csvString = [
                Object.keys(csvContent[0] || {}).join(','),
                ...csvContent.map((row: any) => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'vendors.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            <FileUp className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
          >
            <FileUp className="h-4 w-4" />
            <span>Import</span>
          </Button>
          <Button 
            variant="default" 
            onClick={() => setIsAddDialogOpen(true)}
            className="flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add Vendor</span>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Vendors</TabsTrigger>
          <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
          <TabsTrigger value="contractors">Contractors</TabsTrigger>
          <TabsTrigger value="service">Service Providers</TabsTrigger>
          <TabsTrigger value="blacklisted">Blacklisted</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <VendorTable 
            vendors={vendors as Vendor[]}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            onViewDetails={openVendorDetails}
          />
        </TabsContent>
        
        <TabsContent value="suppliers">
          <VendorTable 
            vendors={(vendors as Vendor[]).filter(vendor => vendor.type === 'supplier')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            onViewDetails={openVendorDetails}
          />
        </TabsContent>
        
        <TabsContent value="contractors">
          <VendorTable 
            vendors={(vendors as Vendor[]).filter(vendor => vendor.type === 'contractor')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            onViewDetails={openVendorDetails}
          />
        </TabsContent>
        
        <TabsContent value="service">
          <VendorTable 
            vendors={(vendors as Vendor[]).filter(vendor => vendor.type === 'service_provider')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            onViewDetails={openVendorDetails}
          />
        </TabsContent>
        
        <TabsContent value="blacklisted">
          <VendorTable 
            vendors={(vendors as Vendor[]).filter(vendor => vendor.blacklisted)}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            onViewDetails={openVendorDetails}
          />
        </TabsContent>
      </Tabs>

      {/* Add Vendor Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[900px]">
          <DialogHeader>
            <DialogTitle>Add New Vendor</DialogTitle>
            <DialogDescription>
              Add a new vendor to the system. Fill in basic vendor information below.
            </DialogDescription>
          </DialogHeader>
          <Form {...addForm}>
            <form onSubmit={addForm.handleSubmit(handleAddSubmit)} className="space-y-6">
              <Tabs defaultValue="basic" className="w-full">
                <TabsList>
                  <TabsTrigger value="basic">Basic Info</TabsTrigger>
                  <TabsTrigger value="address">Address</TabsTrigger>
                  <TabsTrigger value="finance">Financial</TabsTrigger>
                  <TabsTrigger value="purchasing">Purchasing</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basic" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vendor Code</FormLabel>
                          <FormControl>
                            <Input placeholder="V10001" {...field} />
                          </FormControl>
                          <FormDescription>
                            Unique identifier for this vendor
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vendor Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Global Supply Co." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vendor Type</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="supplier">Material Supplier</SelectItem>
                              <SelectItem value="contractor">Contractor</SelectItem>
                              <SelectItem value="service_provider">Service Provider</SelectItem>
                              <SelectItem value="manufacturer">Manufacturer</SelectItem>
                              <SelectItem value="distributor">Distributor</SelectItem>
                              <SelectItem value="broker">Broker</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="inactive">Inactive</SelectItem>
                              <SelectItem value="onboarding">Onboarding</SelectItem>
                              <SelectItem value="qualified">Qualified</SelectItem>
                              <SelectItem value="under_review">Under Review</SelectItem>
                              <SelectItem value="blocked">Blocked</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="industry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Industry</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select industry" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="manufacturing">Manufacturing</SelectItem>
                              <SelectItem value="retail">Retail</SelectItem>
                              <SelectItem value="technology">Technology</SelectItem>
                              <SelectItem value="healthcare">Healthcare</SelectItem>
                              <SelectItem value="finance">Finance</SelectItem>
                              <SelectItem value="construction">Construction</SelectItem>
                              <SelectItem value="transportation">Transportation</SelectItem>
                              <SelectItem value="agriculture">Agriculture</SelectItem>
                              <SelectItem value="energy">Energy</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vendor Category</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="strategic">Strategic</SelectItem>
                              <SelectItem value="preferred">Preferred</SelectItem>
                              <SelectItem value="approved">Approved</SelectItem>
                              <SelectItem value="new">New</SelectItem>
                              <SelectItem value="one_time">One-Time</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input placeholder="+1 (555) 123-4567" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="contact@supplier.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={addForm.control}
                    name="taxId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tax ID / VAT Number</FormLabel>
                        <FormControl>
                          <Input placeholder="123456789" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="website"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Website</FormLabel>
                        <FormControl>
                          <Input placeholder="https://www.supplier.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Brief description of the vendor" 
                            className="resize-none" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>
                
                <TabsContent value="address" className="space-y-4 pt-4">
                  <FormField
                    control={addForm.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Street Address</FormLabel>
                        <FormControl>
                          <Input placeholder="123 Main St" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>City</FormLabel>
                          <FormControl>
                            <Input placeholder="Chicago" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="state"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>State/Province</FormLabel>
                          <FormControl>
                            <Input placeholder="IL" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="country"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Country</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select country" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="US">United States</SelectItem>
                              <SelectItem value="CA">Canada</SelectItem>
                              <SelectItem value="GB">United Kingdom</SelectItem>
                              <SelectItem value="DE">Germany</SelectItem>
                              <SelectItem value="FR">France</SelectItem>
                              <SelectItem value="JP">Japan</SelectItem>
                              <SelectItem value="CN">China</SelectItem>
                              <SelectItem value="IN">India</SelectItem>
                              <SelectItem value="MX">Mexico</SelectItem>
                              <SelectItem value="BR">Brazil</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="postalCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Postal/ZIP Code</FormLabel>
                          <FormControl>
                            <Input placeholder="60601" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={addForm.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Region</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select region" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="north_america">North America</SelectItem>
                            <SelectItem value="south_america">South America</SelectItem>
                            <SelectItem value="europe">Europe</SelectItem>
                            <SelectItem value="asia_pacific">Asia Pacific</SelectItem>
                            <SelectItem value="middle_east">Middle East</SelectItem>
                            <SelectItem value="africa">Africa</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>
                
                <TabsContent value="finance" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Currency</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select currency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="USD">USD - US Dollar</SelectItem>
                              <SelectItem value="EUR">EUR - Euro</SelectItem>
                              <SelectItem value="GBP">GBP - British Pound</SelectItem>
                              <SelectItem value="JPY">JPY - Japanese Yen</SelectItem>
                              <SelectItem value="CAD">CAD - Canadian Dollar</SelectItem>
                              <SelectItem value="AUD">AUD - Australian Dollar</SelectItem>
                              <SelectItem value="CNY">CNY - Chinese Yuan</SelectItem>
                              <SelectItem value="INR">INR - Indian Rupee</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="paymentTerms"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Terms</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select payment terms" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="net_30">Net 30</SelectItem>
                              <SelectItem value="net_45">Net 45</SelectItem>
                              <SelectItem value="net_60">Net 60</SelectItem>
                              <SelectItem value="due_on_receipt">Due on Receipt</SelectItem>
                              <SelectItem value="2_10_net_30">2% 10 Net 30</SelectItem>
                              <SelectItem value="cod">Cash on Delivery</SelectItem>
                              <SelectItem value="advance">Advance Payment</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Method</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select payment method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                              <SelectItem value="check">Check</SelectItem>
                              <SelectItem value="credit_card">Credit Card</SelectItem>
                              <SelectItem value="electronic_payment">Electronic Payment</SelectItem>
                              <SelectItem value="letter_of_credit">Letter of Credit</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="companyCodeId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Code</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select company code" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="1">1000 - Global HQ</SelectItem>
                              <SelectItem value="2">2000 - US Operations</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="purchasing" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="supplierType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Supplier Type</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select supplier type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="manufacturer">Manufacturer</SelectItem>
                              <SelectItem value="wholesaler">Wholesaler</SelectItem>
                              <SelectItem value="distributor">Distributor</SelectItem>
                              <SelectItem value="importer">Importer</SelectItem>
                              <SelectItem value="service">Service Provider</SelectItem>
                              <SelectItem value="contractor">Contractor</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="orderFrequency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Order Frequency</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select order frequency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="daily">Daily</SelectItem>
                              <SelectItem value="weekly">Weekly</SelectItem>
                              <SelectItem value="biweekly">Bi-Weekly</SelectItem>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="quarterly">Quarterly</SelectItem>
                              <SelectItem value="as_needed">As Needed</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="minimumOrderValue"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Minimum Order Value</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="500" {...field} />
                          </FormControl>
                          <FormDescription>
                            Minimum value required for orders
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="leadTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Lead Time (Days)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="14" {...field} />
                          </FormControl>
                          <FormDescription>
                            Average days from order to delivery
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={addForm.control}
                    name="evaluationScore"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Evaluation Score (0-100)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" max="100" placeholder="75" {...field} />
                        </FormControl>
                        <FormDescription>
                          Supplier performance rating
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="purchasingGroupId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Purchasing Group</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value?.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select purchasing group" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1">001 - Raw Materials</SelectItem>
                            <SelectItem value="2">002 - Packaging</SelectItem>
                            <SelectItem value="3">003 - MRO</SelectItem>
                            <SelectItem value="4">004 - Services</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>
                
                <TabsContent value="settings" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addForm.control}
                      name="blacklisted"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Blacklisted</FormLabel>
                            <FormDescription>
                              Prevent ordering from this vendor
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addForm.control}
                      name="blacklistReason"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Blacklist Reason</FormLabel>
                          <FormControl>
                            <Input placeholder="Reason for blacklisting" disabled={!addForm.watch("blacklisted")} {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={addForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Additional notes about this vendor" 
                            className="resize-none" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Active</FormLabel>
                          <FormDescription>
                            Enable for transactions and reporting
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </TabsContent>
              </Tabs>
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={addVendorMutation.isPending}>
                  {addVendorMutation.isPending ? "Saving..." : "Save Vendor"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Vendor Dialog - Similar to Add with prefilled values */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[900px]">
          <DialogHeader>
            <DialogTitle>Edit Vendor</DialogTitle>
            <DialogDescription>
              Update vendor information.
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-6">
              {/* Same form fields as Add dialog, with prefilled values */}
              <Tabs defaultValue="basic" className="w-full">
                {/* Same tabs content as Add dialog */}
              </Tabs>
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={updateVendorMutation.isPending}>
                  {updateVendorMutation.isPending ? "Updating..." : "Update Vendor"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the vendor "{deletingVendor?.name}" ({deletingVendor?.code}) and all associated data.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingVendor && deleteVendorMutation.mutate(deletingVendor.id)}
              disabled={deleteVendorMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteVendorMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Vendor Details Dialog */}
      <Dialog open={isVendorDetailsOpen} onOpenChange={setIsVendorDetailsOpen}>
        <DialogContent className="sm:max-w-[900px]">
          {viewingVendorDetails && (
            <>
              <DialogHeader>
                <DialogTitle>Vendor Details</DialogTitle>
                <DialogDescription>
                  Comprehensive information about {viewingVendorDetails.name}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="bg-gray-50 p-4 rounded-lg flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold">{viewingVendorDetails.name}</h3>
                    <div className="flex items-center mt-1">
                      <Badge variant="outline" className="mr-2">
                        {viewingVendorDetails.code}
                      </Badge>
                      <Badge 
                        variant={viewingVendorDetails.isActive ? "default" : "secondary"} 
                        className={viewingVendorDetails.isActive ? "bg-green-100 text-green-800" : ""}
                      >
                        {viewingVendorDetails.isActive ? "Active" : "Inactive"}
                      </Badge>
                      {viewingVendorDetails.blacklisted && (
                        <Badge variant="default" className="bg-red-100 text-red-800 ml-2">
                          Blacklisted
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-600 mt-2">{viewingVendorDetails.description}</p>
                  </div>
                  <div className="space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => openEditDialog(viewingVendorDetails)}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-red-600 border-red-200"
                      onClick={() => {
                        setIsVendorDetailsOpen(false);
                        openDeleteDialog(viewingVendorDetails);
                      }}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <Building className="h-4 w-4 mr-2" />
                        Basic Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <dl className="space-y-2">
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Type:</dt>
                          <dd className="text-sm text-gray-900 capitalize">{viewingVendorDetails.type?.replace("_", " ")}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Tax ID:</dt>
                          <dd className="text-sm text-gray-900">{viewingVendorDetails.taxId || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Industry:</dt>
                          <dd className="text-sm text-gray-900 capitalize">{viewingVendorDetails.industry?.replace("_", " ") || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Category:</dt>
                          <dd className="text-sm text-gray-900 capitalize">{viewingVendorDetails.category?.replace("_", " ") || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Status:</dt>
                          <dd className="text-sm text-gray-900 capitalize">{viewingVendorDetails.status?.replace("_", " ")}</dd>
                        </div>
                      </dl>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        Contact Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <dl className="space-y-2">
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Address:</dt>
                          <dd className="text-sm text-gray-900">{viewingVendorDetails.address || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">City/State:</dt>
                          <dd className="text-sm text-gray-900">
                            {viewingVendorDetails.city ? viewingVendorDetails.city + (viewingVendorDetails.state ? `, ${viewingVendorDetails.state}` : "") : "—"}
                          </dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Country:</dt>
                          <dd className="text-sm text-gray-900">{viewingVendorDetails.country || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Phone:</dt>
                          <dd className="text-sm text-gray-900">{viewingVendorDetails.phone || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Email:</dt>
                          <dd className="text-sm text-gray-900">{viewingVendorDetails.email || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Website:</dt>
                          <dd className="text-sm text-gray-900">{viewingVendorDetails.website || "—"}</dd>
                        </div>
                      </dl>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <DollarSign className="h-4 w-4 mr-2" />
                        Financial Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <dl className="space-y-2">
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Currency:</dt>
                          <dd className="text-sm text-gray-900">{viewingVendorDetails.currency || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Payment Terms:</dt>
                          <dd className="text-sm text-gray-900 capitalize">{viewingVendorDetails.paymentTerms?.replace("_", " ") || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Payment Method:</dt>
                          <dd className="text-sm text-gray-900 capitalize">{viewingVendorDetails.paymentMethod?.replace("_", " ") || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Min. Order Value:</dt>
                          <dd className="text-sm text-gray-900">
                            {viewingVendorDetails.minimumOrderValue ? 
                              `${viewingVendorDetails.currency || 'USD'} ${viewingVendorDetails.minimumOrderValue.toLocaleString()}` : 
                              "—"}
                          </dd>
                        </div>
                      </dl>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <TruckIcon className="h-4 w-4 mr-2" />
                        Purchasing Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <dl className="space-y-2">
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Supplier Type:</dt>
                          <dd className="text-sm text-gray-900 capitalize">{viewingVendorDetails.supplierType?.replace("_", " ") || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Lead Time:</dt>
                          <dd className="text-sm text-gray-900">
                            {viewingVendorDetails.leadTime ? `${viewingVendorDetails.leadTime} days` : "—"}
                          </dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Order Frequency:</dt>
                          <dd className="text-sm text-gray-900 capitalize">{viewingVendorDetails.orderFrequency?.replace("_", " ") || "—"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-sm font-medium text-gray-500">Evaluation Score:</dt>
                          <dd className="text-sm text-gray-900 flex items-center">
                            {viewingVendorDetails.evaluationScore ? (
                              <>
                                {viewingVendorDetails.evaluationScore}/100
                                <StarIcon className="h-3 w-3 ml-1 text-yellow-500" />
                              </>
                            ) : "—"}
                          </dd>
                        </div>
                      </dl>
                    </CardContent>
                  </Card>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Contact Persons</h3>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setIsAddContactDialogOpen(true)}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Contact
                    </Button>
                  </div>
                  
                  {isLoadingContacts ? (
                    <div className="flex justify-center items-center h-20">
                      <RefreshCw className="h-6 w-6 animate-spin text-gray-400" />
                      <p className="ml-2 text-gray-500">Loading contacts...</p>
                    </div>
                  ) : contacts && Array.isArray(contacts) && contacts.length > 0 ? (
                    <div className="border rounded-md">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Position</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Phone</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {contacts.map((contact: VendorContact) => (
                            <TableRow key={contact.id}>
                              <TableCell className="font-medium">
                                {contact.firstName} {contact.lastName}
                              </TableCell>
                              <TableCell>{contact.position || "—"}</TableCell>
                              <TableCell>{contact.email || "—"}</TableCell>
                              <TableCell>{contact.phone || contact.mobile || "—"}</TableCell>
                              <TableCell>
                                {contact.isPrimary && (
                                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 mr-1">
                                    Primary
                                  </Badge>
                                )}
                                {contact.isOrderContact && (
                                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 mr-1">
                                    Order
                                  </Badge>
                                )}
                              </TableCell>
                              <TableCell>
                                <div className="flex space-x-2">
                                  <Button variant="ghost" size="icon">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="text-red-600">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-32 border rounded-md bg-gray-50">
                      <User className="h-8 w-8 text-gray-300" />
                      <p className="mt-2 text-gray-500">No contacts added</p>
                      <p className="text-sm text-gray-400">Add contacts to manage specific points of communication</p>
                    </div>
                  )}
                </div>
                
                {viewingVendorDetails.notes && (
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Notes</h3>
                    <div className="p-4 bg-gray-50 rounded-md border">
                      <p className="text-gray-600">{viewingVendorDetails.notes}</p>
                    </div>
                  </div>
                )}
                
                {viewingVendorDetails.blacklisted && viewingVendorDetails.blacklistReason && (
                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-red-700">Blacklist Information</h3>
                    <div className="p-4 bg-red-50 rounded-md border border-red-200">
                      <p className="text-red-700">{viewingVendorDetails.blacklistReason}</p>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Contact Dialog */}
      <Dialog open={isAddContactDialogOpen} onOpenChange={setIsAddContactDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Add Contact Person</DialogTitle>
            <DialogDescription>
              Add a new contact for {viewingVendorDetails?.name}
            </DialogDescription>
          </DialogHeader>
          <Form {...contactForm}>
            <form onSubmit={contactForm.handleSubmit(handleAddContactSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={contactForm.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={contactForm.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Smith" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={contactForm.control}
                  name="position"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Position/Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Sales Manager" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={contactForm.control}
                  name="department"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Department</FormLabel>
                      <FormControl>
                        <Input placeholder="Sales" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={contactForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="john.smith@supplier.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={contactForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone</FormLabel>
                      <FormControl>
                        <Input placeholder="+1 (555) 123-4567" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={contactForm.control}
                name="mobile"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile Phone</FormLabel>
                    <FormControl>
                      <Input placeholder="+1 (555) 987-6543" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={contactForm.control}
                  name="isPrimary"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Primary Contact</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
                <FormField
                  control={contactForm.control}
                  name="isOrderContact"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Order Contact</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={contactForm.control}
                  name="isQualityContact"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Quality Contact</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
                <FormField
                  control={contactForm.control}
                  name="isAccountsContact"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Accounts Contact</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={contactForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Additional notes about this contact" 
                        className="resize-none" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddContactDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={addContactMutation.isPending}>
                  {addContactMutation.isPending ? "Saving..." : "Add Contact"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Vendor Table Component
function VendorTable({
  vendors,
  isLoading,
  onEdit,
  onDelete,
  onViewDetails
}: {
  vendors: Vendor[];
  isLoading: boolean;
  onEdit: (vendor: Vendor) => void;
  onDelete: (vendor: Vendor) => void;
  onViewDetails: (vendor: Vendor) => void;
}) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center items-center h-40">
            <div className="flex flex-col items-center">
              <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
              <p className="mt-2 text-gray-500">Loading vendors...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!vendors || vendors.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center items-center h-40">
            <div className="flex flex-col items-center">
              <Building className="h-8 w-8 text-gray-400" />
              <p className="mt-2 text-gray-500">No vendors found</p>
              <p className="text-sm text-gray-400">Add a vendor to get started</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {vendors.map((vendor) => (
              <TableRow key={vendor.id} className="cursor-pointer hover:bg-gray-50" onClick={() => onViewDetails(vendor)}>
                <TableCell className="font-medium">{vendor.code}</TableCell>
                <TableCell>{vendor.name}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="capitalize">
                    {vendor.type?.replace("_", " ")}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    {vendor.email && (
                      <div className="flex items-center text-sm">
                        <Mail className="h-3 w-3 mr-1 text-gray-400" />
                        <span className="truncate max-w-[120px]">{vendor.email}</span>
                      </div>
                    )}
                    {vendor.phone && (
                      <div className="flex items-center text-sm">
                        <Phone className="h-3 w-3 mr-1 text-gray-400" />
                        <span>{vendor.phone}</span>
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  {vendor.city ? 
                    `${vendor.city}${vendor.country ? `, ${vendor.country}` : ""}` : 
                    (vendor.country || "—")}
                </TableCell>
                <TableCell>
                  {vendor.blacklisted ? (
                    <Badge variant="default" className="bg-red-100 text-red-800 hover:bg-red-100">
                      Blacklisted
                    </Badge>
                  ) : vendor.isActive ? (
                    <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                      Inactive
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2" onClick={(e) => e.stopPropagation()}>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit(vendor);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(vendor);
                      }}
                      className="text-red-500 hover:text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}