import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Plus, RefreshCw, ArrowLeft, Edit, Trash2, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  account_number: z.string().min(1, "Account number is required"),
  account_name: z.string().min(1, "Account name is required"),
  account_type: z.string().min(1, "Account type is required"),
  account_group: z.string().min(1, "Account group is required"),
  chart_of_accounts_id: z.number().min(1, "Chart of accounts is required"),
  balance_sheet_account: z.boolean().default(false),
  pl_account: z.boolean().default(false),
  reconciliation_account: z.boolean().default(false),
  line_item_management: z.boolean().default(false),
  open_item_management: z.boolean().default(false),
  currency: z.string().optional(),
  description: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export default function GLAccounts() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      account_number: "",
      account_name: "",
      account_type: "",
      account_group: "",
      chart_of_accounts_id: 1,
      balance_sheet_account: false,
      pl_account: false,
      reconciliation_account: false,
      line_item_management: false,
      open_item_management: false,
      currency: "USD",
      description: "",
    },
  });

  const { data: glAccounts = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/master-data/gl-accounts"],
  });

  const { data: chartOfAccounts = [] } = useQuery({
    queryKey: ["/api/master-data/chart-of-accounts"],
  });

  const createMutation = useMutation({
    mutationFn: (data: FormData) => apiRequest("/api/master-data/gl-accounts", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/gl-accounts"] });
      setIsDialogOpen(false);
      form.reset();
      toast({ title: "Success", description: "GL account created successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to create GL account",
        variant: "destructive" 
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: FormData }) => 
      apiRequest(`/api/master-data/gl-accounts/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/gl-accounts"] });
      setIsDialogOpen(false);
      setEditingItem(null);
      form.reset();
      toast({ title: "Success", description: "GL account updated successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to update GL account",
        variant: "destructive" 
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/master-data/gl-accounts/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/gl-accounts"] });
      toast({ title: "Success", description: "GL account deleted successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to delete GL account",
        variant: "destructive" 
      });
    },
  });

  const onSubmit = (data: FormData) => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (item: any) => {
    setEditingItem(item);
    form.reset({
      account_number: item.account_number,
      account_name: item.account_name,
      account_type: item.account_type,
      account_group: item.account_group,
      chart_of_accounts_id: item.chart_of_accounts_id,
      balance_sheet_account: item.balance_sheet_account,
      pl_account: item.pl_account,
      reconciliation_account: item.reconciliation_account,
      line_item_management: item.line_item_management,
      open_item_management: item.open_item_management,
      currency: item.currency || "USD",
      description: item.description || "",
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this GL account?")) {
      deleteMutation.mutate(id);
    }
  };

  const openCreateDialog = () => {
    setEditingItem(null);
    form.reset();
    setIsDialogOpen(true);
  };

  const filteredAccounts = glAccounts.filter((account: any) =>
    account.account_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.account_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.account_type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getAccountTypeColor = (type: string) => {
    switch (type) {
      case 'ASSETS': return 'bg-blue-100 text-blue-800';
      case 'LIABILITIES': return 'bg-red-100 text-red-800';
      case 'EQUITY': return 'bg-green-100 text-green-800';
      case 'REVENUE': return 'bg-purple-100 text-purple-800';
      case 'EXPENSES': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => window.history.back()}
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back</span>
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">GL Accounts</h1>
            <p className="text-muted-foreground">General ledger accounts for financial postings</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={() => refetch()} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={openCreateDialog}>
                <Plus className="h-4 w-4 mr-2" />
                Add GL Account
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>
                  {editingItem ? "Edit GL Account" : "Create GL Account"}
                </DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="account_number"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Number *</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., 1000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="account_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Name *</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Cash and Cash Equivalents" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="account_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Type *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="ASSETS">Assets</SelectItem>
                              <SelectItem value="LIABILITIES">Liabilities</SelectItem>
                              <SelectItem value="EQUITY">Equity</SelectItem>
                              <SelectItem value="REVENUE">Revenue</SelectItem>
                              <SelectItem value="EXPENSES">Expenses</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="account_group"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Group *</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Current Assets" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Currency</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select currency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="USD">USD</SelectItem>
                              <SelectItem value="EUR">EUR</SelectItem>
                              <SelectItem value="GBP">GBP</SelectItem>
                              <SelectItem value="JPY">JPY</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="chart_of_accounts_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Chart of Accounts *</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select chart of accounts" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {chartOfAccounts.map((chart: any) => (
                              <SelectItem key={chart.id} value={chart.id.toString()}>
                                {chart.code} - {chart.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Additional description for this GL account"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <h4 className="text-sm font-medium">Account Properties</h4>
                      <div className="space-y-2">
                        <FormField
                          control={form.control}
                          name="balance_sheet_account"
                          render={({ field }) => (
                            <div className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={field.onChange}
                                className="rounded border-gray-300"
                              />
                              <label className="text-sm">Balance Sheet Account</label>
                            </div>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="pl_account"
                          render={({ field }) => (
                            <div className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={field.onChange}
                                className="rounded border-gray-300"
                              />
                              <label className="text-sm">P&L Account</label>
                            </div>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="reconciliation_account"
                          render={({ field }) => (
                            <div className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={field.onChange}
                                className="rounded border-gray-300"
                              />
                              <label className="text-sm">Reconciliation Account</label>
                            </div>
                          )}
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-sm font-medium">Management Options</h4>
                      <div className="space-y-2">
                        <FormField
                          control={form.control}
                          name="line_item_management"
                          render={({ field }) => (
                            <div className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={field.onChange}
                                className="rounded border-gray-300"
                              />
                              <label className="text-sm">Line Item Management</label>
                            </div>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="open_item_management"
                          render={({ field }) => (
                            <div className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={field.onChange}
                                className="rounded border-gray-300"
                              />
                              <label className="text-sm">Open Item Management</label>
                            </div>
                          )}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createMutation.isPending || updateMutation.isPending}
                    >
                      {editingItem ? "Update" : "Create"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search */}
      <div className="flex items-center space-x-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search accounts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Badge variant="secondary">{filteredAccounts.length} accounts</Badge>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAccounts.map((account: any) => (
            <Card key={account.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <BookOpen className="h-5 w-5 text-purple-600" />
                    <CardTitle className="text-lg">{account.account_number}</CardTitle>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(account)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(account.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <h3 className="font-medium text-sm">{account.account_name}</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="font-medium">Type:</span>
                    <Badge className={getAccountTypeColor(account.account_type)}>
                      {account.account_type}
                    </Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Group:</span>
                    <span className="text-xs">{account.account_group}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Currency:</span>
                    <span>{account.currency}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {account.balance_sheet_account && <Badge variant="outline" className="text-xs">BS</Badge>}
                    {account.pl_account && <Badge variant="outline" className="text-xs">P&L</Badge>}
                    {account.reconciliation_account && <Badge variant="outline" className="text-xs">Recon</Badge>}
                    {account.line_item_management && <Badge variant="outline" className="text-xs">Line Items</Badge>}
                    {account.open_item_management && <Badge variant="outline" className="text-xs">Open Items</Badge>}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {filteredAccounts.length === 0 && !isLoading && (
        <Card className="text-center py-12">
          <CardContent>
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No GL accounts found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm ? "No accounts match your search criteria." : "Create your first GL account to start managing your chart of accounts."}
            </p>
            <Button onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Add GL Account
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}