import { ArrowLeft, Briefcase, RefreshCw } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export interface Asset {
  id: string;
  name: string;
  description: string;
  category: string;
  acquisitionDate: string;
  acquisitionValue: number;
  currentValue: number;
  depreciationMethod: 'straight-line' | 'declining-balance' | 'units-of-production' | 'sum-of-years-digits';
  status: 'active' | 'inactive' | 'disposed';
  location: string;
}

const sampleAssets: Asset[] = [
  {
    id: "AST-1001",
    name: "CNC Machine #123",
    description: "CNC Milling Machine - Industrial Grade",
    category: "Manufacturing Equipment",
    acquisitionDate: "2021-06-15",
    acquisitionValue: 125000,
    currentValue: 105000,
    depreciationMethod: 'straight-line',
    status: 'active',
    location: "Plant 1 - Manufacturing Floor"
  },
  {
    id: "AST-1002",
    name: "Delivery Truck #A452",
    description: "Logistics Transport Vehicle - 5 Ton Capacity",
    category: "Vehicles",
    acquisitionDate: "2020-03-20",
    acquisitionValue: 78000,
    currentValue: 58500,
    depreciationMethod: 'declining-balance',
    status: 'active',
    location: "Fleet Garage"
  },
  {
    id: "AST-1003",
    name: "Office Building - Headquarters",
    description: "Main Corporate Office Building",
    category: "Real Estate",
    acquisitionDate: "2015-11-10",
    acquisitionValue: 2250000,
    currentValue: 2465000,
    depreciationMethod: 'straight-line',
    status: 'active',
    location: "Downtown Business District"
  },
  {
    id: "AST-1004",
    name: "Computer Servers - Rack #12",
    description: "IT Infrastructure Servers",
    category: "IT Equipment",
    acquisitionDate: "2022-01-15",
    acquisitionValue: 45000,
    currentValue: 40500,
    depreciationMethod: 'declining-balance',
    status: 'active',
    location: "Server Room - IT Department"
  },
  {
    id: "AST-1005",
    name: "Laboratory Equipment - Spectrometer",
    description: "High Precision Analysis Equipment",
    category: "Lab Equipment",
    acquisitionDate: "2021-08-30",
    acquisitionValue: 65000,
    currentValue: 58500,
    depreciationMethod: 'straight-line',
    status: 'active',
    location: "R&D Laboratory"
  },
  {
    id: "AST-1006",
    name: "Forklift #F23",
    description: "Warehouse Material Handling Equipment",
    category: "Warehouse Equipment",
    acquisitionDate: "2019-04-12",
    acquisitionValue: 32000,
    currentValue: 18000,
    depreciationMethod: 'units-of-production',
    status: 'active',
    location: "Warehouse A - Zone 3"
  },
  {
    id: "AST-1007",
    name: "Old Packaging Machine",
    description: "Discontinued Packaging Equipment",
    category: "Manufacturing Equipment",
    acquisitionDate: "2010-05-22",
    acquisitionValue: 85000,
    currentValue: 5000,
    depreciationMethod: 'straight-line',
    status: 'disposed',
    location: "Equipment Storage"
  }
];

const AssetMaster = () => {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Fetch data from API
  const fetchAssets = async () => {
    setIsLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      setAssets(sampleAssets);
      setIsLoading(false);
    } catch (error) {
      console.error("Error loading assets:", error);
      toast({
        title: "Error",
        description: "Failed to load assets data. Please try refreshing.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  // Refresh data handler
  const handleRefresh = () => {
    fetchAssets();
    toast({
      title: "Refreshing",
      description: "Asset master data is being refreshed",
    });
  };

  // Load data on component mount
  useEffect(() => {
    fetchAssets();
  }, []);

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'disposed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
  };

  const formatDepreciationMethod = (method: string) => {
    return method.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <Link href="/master-data" className="mr-4 p-2 rounded-md hover:bg-gray-100">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">Asset Master</h1>
          <p className="text-gray-600">Manage fixed assets and depreciation rules</p>
        </div>
      </div>

      {/* Banner indicating this is a placeholder */}
      <div className="mb-6 bg-blue-50 p-4 rounded-md border border-blue-200">
        <div className="flex items-center">
          <Briefcase className="h-5 w-5 text-blue-500 mr-2" />
          <span className="text-blue-800 font-medium">
            Asset Master module is under development. The data shown below is sample data for demonstration purposes.
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="mb-6 flex flex-col md:flex-row justify-between items-center gap-3 md:gap-0">
        <div className="flex space-x-2 w-full md:w-auto">
          <input 
            type="text" 
            placeholder="Search assets..." 
            className="border border-gray-300 rounded-md px-3 py-1.5 text-sm w-full md:w-64"
          />
          <button className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm">
            Search
          </button>
          <button 
            className="border border-gray-300 bg-white px-3 py-1.5 rounded-md text-sm flex items-center"
            onClick={handleRefresh}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
        <div className="flex space-x-2 w-full md:w-auto">
          <button 
            className="border border-gray-300 bg-white px-3 py-1.5 rounded-md text-sm flex items-center"
            onClick={() => {
              const csvContent = assets?.map((asset: Asset) => ({
                ID: asset.id,
                Name: asset.name,
                Description: asset.description,
                Category: asset.category,
                AcquisitionDate: asset.acquisitionDate,
                AcquisitionValue: asset.acquisitionValue,
                CurrentValue: asset.currentValue,
                DepreciationMethod: asset.depreciationMethod,
                Status: asset.status,
                Location: asset.location
              })) || [];
              
              const csvString = [
                Object.keys(csvContent[0] || {}).join(','),
                ...csvContent.map((row: any) => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'assets.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            Export
          </button>
          <button 
            className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm flex items-center w-full md:w-auto"
            onClick={() => {
              toast({
                title: "New Asset",
                description: "Asset creation form will open here",
              });
            }}
          >
            <span className="mr-1">+</span> New Asset
          </button>
        </div>
      </div>

      {/* Assets Table */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="flex flex-col items-center gap-2">
            <RefreshCw className="h-8 w-8 animate-spin text-blue-600" />
            <p>Loading asset data...</p>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-md shadow">
          <div className="max-h-[650px] overflow-y-auto overflow-x-auto" style={{ scrollbarWidth: 'thin' }}>
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50 sticky top-0 z-10">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acquisition Date
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acquisition Value
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Current Value
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Depreciation Method
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {assets.map(asset => (
                  <tr key={asset.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {asset.id}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      <div>
                        <div className="font-medium">{asset.name}</div>
                        <div className="text-xs text-gray-500">{asset.description}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {asset.category}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(asset.acquisitionDate)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatCurrency(asset.acquisitionValue)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatCurrency(asset.currentValue)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDepreciationMethod(asset.depreciationMethod)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded-full ${getStatusBadgeClass(asset.status)}`}>
                        {asset.status.charAt(0).toUpperCase() + asset.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button className="text-blue-600 hover:text-blue-800 mr-2">Edit</button>
                      <button className="text-red-600 hover:text-red-800">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 sm:px-6 flex items-center justify-between">
            <div className="flex-1 flex justify-between sm:hidden">
              <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                Previous
              </button>
              <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                Next
              </button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Showing <span className="font-medium">1</span> to <span className="font-medium">7</span> of{' '}
                  <span className="font-medium">7</span> results
                </p>
              </div>
              <div>
                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                  <button className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <span className="sr-only">Previous</span>
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </button>
                  <button aria-current="page" className="z-10 bg-blue-50 border-blue-500 text-blue-600 relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                    1
                  </button>
                  <button className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <span className="sr-only">Next</span>
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AssetMaster;