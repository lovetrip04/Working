import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Plus, Search, Edit, Trash2, X, FileUp, Download, Globe } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
// Import the company code excel import component
import CompanyCodeExcelImport from "../../components/master-data/CompanyCodeExcelImport";

// Define the Company Code type
type CompanyCode = {
  id: number;
  code: string;
  name: string;
  description: string | null;
  currency: string;
  country: string;
  taxId: string | null;
  fiscalYear: string;
  address: string | null;
  city: string | null;
  state: string | null;
  postalCode: string | null;
  phone: string | null;
  email: string | null;
  website: string | null;
  logoUrl: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

// List of currencies
const CURRENCIES = [
  "USD", "EUR", "JPY", "GBP", "AUD", "CAD", "CHF", "CNY", 
  "HKD", "NZD", "SEK", "KRW", "SGD", "NOK", "MXN", "INR"
];

// List of countries
const COUNTRIES = [
  "United States", "Canada", "United Kingdom", "Germany", "France", "Italy", "Spain", 
  "Japan", "China", "Australia", "India", "Brazil", "Mexico", "South Africa", "Russia"
];

// List of fiscal year options
const FISCAL_YEARS = [
  "Calendar Year (Jan-Dec)", 
  "Apr-Mar", 
  "Jul-Jun", 
  "Oct-Sep"
];

// Company Code Form Schema
const companyCodeSchema = z.object({
  code: z.string().min(2, "Code is required").max(10, "Code must be at most 10 characters"),
  name: z.string().min(1, "Name is required").max(100, "Name must be at most 100 characters"),
  description: z.string().optional(),
  currency: z.string().min(1, "Currency is required"),
  country: z.string().min(1, "Country is required"),
  taxId: z.string().optional(),
  fiscalYear: z.string().min(1, "Fiscal Year is required"),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  postalCode: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email("Invalid email format").optional().or(z.literal("")),
  website: z.string().url("Invalid website URL").optional().or(z.literal("")),
  logoUrl: z.string().optional(),
  isActive: z.boolean().default(true),
});

// Company Code Management Page
export default function CompanyCodePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [editingCompanyCode, setEditingCompanyCode] = useState<CompanyCode | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch company codes directly to avoid JSON parsing issues
  const [companyCodes, setCompanyCodes] = useState<CompanyCode[]>([]);
  const [filteredCompanyCodes, setFilteredCompanyCodes] = useState<CompanyCode[]>([]);
  const [companyCodesLoading, setCompanyCodesLoading] = useState(true);
  const [companyCodesError, setCompanyCodesError] = useState<Error | null>(null);
  
  // Fetch data on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch company codes
        setCompanyCodesLoading(true);
        const response = await fetch("/api/master-data/company-code", {
          headers: {
            'Accept': 'application/json'
          }
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          if (errorText.includes('<!DOCTYPE')) {
            throw new Error('Server returned HTML instead of JSON');
          }
          throw new Error(`API Error: ${response.status} ${response.statusText}`);
        }
        
        const data = await response.json();
        setCompanyCodes(data);
        setFilteredCompanyCodes(data);
        setCompanyCodesLoading(false);
      } catch (error) {
        console.error("Error fetching company codes:", error);
        setCompanyCodesError(error instanceof Error ? error : new Error('Failed to fetch company codes'));
        setCompanyCodesLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  // Filter company codes based on search query
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredCompanyCodes(companyCodes);
    } else {
      setFilteredCompanyCodes(
        companyCodes.filter(
          (companyCode) =>
            companyCode.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
            companyCode.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            companyCode.country.toLowerCase().includes(searchQuery.toLowerCase())
        )
      );
    }
  }, [searchQuery, companyCodes]);

  // Company code form setup
  const form = useForm<z.infer<typeof companyCodeSchema>>({
    resolver: zodResolver(companyCodeSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      currency: "USD",
      country: "United States",
      taxId: "",
      fiscalYear: "Calendar Year (Jan-Dec)",
      address: "",
      city: "",
      state: "",
      postalCode: "",
      phone: "",
      email: "",
      website: "",
      logoUrl: "",
      isActive: true,
    },
  });

  // Set form values when editing
  useEffect(() => {
    if (editingCompanyCode) {
      form.reset({
        code: editingCompanyCode.code,
        name: editingCompanyCode.name,
        description: editingCompanyCode.description || "",
        currency: editingCompanyCode.currency,
        country: editingCompanyCode.country,
        taxId: editingCompanyCode.taxId || "",
        fiscalYear: editingCompanyCode.fiscalYear,
        address: editingCompanyCode.address || "",
        city: editingCompanyCode.city || "",
        state: editingCompanyCode.state || "",
        postalCode: editingCompanyCode.postalCode || "",
        phone: editingCompanyCode.phone || "",
        email: editingCompanyCode.email || "",
        website: editingCompanyCode.website || "",
        logoUrl: editingCompanyCode.logoUrl || "",
        isActive: editingCompanyCode.isActive,
      });
    } else {
      form.reset({
        code: "",
        name: "",
        description: "",
        currency: "USD",
        country: "United States",
        taxId: "",
        fiscalYear: "Calendar Year (Jan-Dec)",
        address: "",
        city: "",
        state: "",
        postalCode: "",
        phone: "",
        email: "",
        website: "",
        logoUrl: "",
        isActive: true,
      });
    }
  }, [editingCompanyCode, form]);

  // Create company code mutation
  const createCompanyCodeMutation = useMutation({
    mutationFn: (companyCode: z.infer<typeof companyCodeSchema>) => {
      return apiRequest(`/api/master-data/company-code`, {
        method: "POST",
        body: JSON.stringify(companyCode)
      }).then(res => res.json());
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Company Code created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/company-code"] });
      setShowDialog(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create Company Code",
        variant: "destructive",
      });
    },
  });

  // Update company code mutation
  const updateCompanyCodeMutation = useMutation({
    mutationFn: (data: { id: number; companyCode: z.infer<typeof companyCodeSchema> }) => {
      return apiRequest(`/api/master-data/company-code/${data.id}`, {
        method: "PUT",
        body: JSON.stringify(data.companyCode),
      }).then(res => res.json());
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Company Code updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/company-code"] });
      setShowDialog(false);
      setEditingCompanyCode(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update Company Code",
        variant: "destructive",
      });
    },
  });

  // Delete company code mutation
  const deleteCompanyCodeMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest(`/api/master-data/company-code/${id}`, {
        method: "DELETE",
      }).then(res => res.json());
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Company Code deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/company-code"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete Company Code",
        variant: "destructive",
      });
    },
  });

  // Form submission
  const onSubmit = (values: z.infer<typeof companyCodeSchema>) => {
    if (editingCompanyCode) {
      updateCompanyCodeMutation.mutate({ id: editingCompanyCode.id, companyCode: values });
    } else {
      createCompanyCodeMutation.mutate(values);
    }
  };

  // Function to close the dialog and reset state
  const closeDialog = () => {
    setShowDialog(false);
    setEditingCompanyCode(null);
    form.reset();
  };

  // Function to handle editing a company code
  const handleEdit = (companyCode: CompanyCode) => {
    setEditingCompanyCode(companyCode);
    setShowDialog(true);
  };

  // Function to handle deleting a company code
  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this Company Code?")) {
      deleteCompanyCodeMutation.mutate(id);
    }
  };

  // Check for errors
  if (companyCodesError) {
    return (
      <div className="p-4">
        <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded-md">
          <h3 className="text-lg font-medium">Error</h3>
          <p>{(companyCodesError as Error).message || "An error occurred"}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Company Codes</h1>
          <p className="text-sm text-muted-foreground">
            Manage the legal entities in your organization
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowImportDialog(true)}>
            <FileUp className="mr-2 h-4 w-4" />
            Import from Excel
          </Button>
          <Button onClick={() => setShowDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Company Code
          </Button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search company codes..."
          className="pl-8"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Company Codes Table */}
      <Card>
        <CardHeader>
          <CardTitle>Company Codes</CardTitle>
          <CardDescription>
            All registered legal entities in your organization
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="max-h-[500px] overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-white z-10">
                  <TableRow>
                    <TableHead className="w-[100px]">Code</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden sm:table-cell">Country</TableHead>
                    <TableHead className="hidden md:table-cell">Currency</TableHead>
                    <TableHead className="hidden md:table-cell">Fiscal Year</TableHead>
                    <TableHead className="w-[100px] text-center">Status</TableHead>
                    <TableHead className="w-[100px] text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {companyCodesLoading ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24">
                        Loading...
                      </TableCell>
                    </TableRow>
                  ) : filteredCompanyCodes.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24">
                        No company codes found. {searchQuery ? "Try a different search." : "Create your first company code."}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredCompanyCodes.map((companyCode) => (
                      <TableRow key={companyCode.id}>
                        <TableCell className="font-medium">{companyCode.code}</TableCell>
                        <TableCell>{companyCode.name}</TableCell>
                        <TableCell className="hidden sm:table-cell">{companyCode.country}</TableCell>
                        <TableCell className="hidden md:table-cell">{companyCode.currency}</TableCell>
                        <TableCell className="hidden md:table-cell">{companyCode.fiscalYear}</TableCell>
                        <TableCell className="text-center">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                              companyCode.isActive
                                ? "bg-green-100 text-green-800"
                                : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {companyCode.isActive ? "Active" : "Inactive"}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(companyCode)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(companyCode.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Company Code Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>
              {editingCompanyCode ? "Edit Company Code" : "Create Company Code"}
            </DialogTitle>
            <DialogDescription>
              {editingCompanyCode
                ? "Update the company code details below"
                : "Add a new legal entity to your organization"}
            </DialogDescription>
          </DialogHeader>

          <div className="overflow-y-auto max-h-[calc(90vh-200px)] pr-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <Tabs defaultValue="basic" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="basic">Basic Information</TabsTrigger>
                    <TabsTrigger value="contact">Contact & Address</TabsTrigger>
                    <TabsTrigger value="additional">Additional Information</TabsTrigger>
                  </TabsList>
                  
                  {/* Basic Information Tab */}
                  <TabsContent value="basic" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="code"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Code*</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="E.g., US01" 
                                {...field} 
                                disabled={!!editingCompanyCode}
                              />
                            </FormControl>
                            <FormDescription>
                              Unique code for this legal entity (max 10 characters)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name*</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="E.g., ACME Corporation USA" 
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription>
                              Official legal name of the entity
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Brief description of this legal entity" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select country" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {COUNTRIES.map((country) => (
                                  <SelectItem key={country} value={country}>
                                    {country}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="currency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Currency*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select currency" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {CURRENCIES.map((currency) => (
                                  <SelectItem key={currency} value={currency}>
                                    {currency}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="fiscalYear"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Fiscal Year*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select fiscal year" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {FISCAL_YEARS.map((fiscalYear) => (
                                  <SelectItem key={fiscalYear} value={fiscalYear}>
                                    {fiscalYear}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="taxId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tax ID</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Tax identification number" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="isActive"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border rounded-md">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Active</FormLabel>
                            <FormDescription>
                              Is this company code active and available for use?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </TabsContent>

                  {/* Contact & Address Tab */}
                  <TabsContent value="contact" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Street address" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="City" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>State/Province</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="State or province" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="postalCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Postal Code</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Postal or ZIP code" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Phone number" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Email address" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </TabsContent>

                  {/* Additional Information Tab */}
                  <TabsContent value="additional" className="space-y-4">
                    <FormField
                      control={form.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Website</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://www.example.com" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormDescription>
                            Company website URL (must include http:// or https://)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="logoUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Logo URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="URL to company logo" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                </Tabs>

                <DialogFooter className="pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={closeDialog}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={createCompanyCodeMutation.isPending || updateCompanyCodeMutation.isPending}
                  >
                    {createCompanyCodeMutation.isPending || updateCompanyCodeMutation.isPending ? (
                      "Saving..."
                    ) : (
                      editingCompanyCode ? "Update Company Code" : "Create Company Code"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </div>
        </DialogContent>
      </Dialog>

      {/* Excel Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Import Company Codes from Excel</DialogTitle>
            <DialogDescription>
              Upload an Excel file with company code data to import in bulk
            </DialogDescription>
          </DialogHeader>
          {/* Import component will need to be properly implemented */}
          <div className="py-4">
            <p>Excel import functionality will be implemented here.</p>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowImportDialog(false)}
            >
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}