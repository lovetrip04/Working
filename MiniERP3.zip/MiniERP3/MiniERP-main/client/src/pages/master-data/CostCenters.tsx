import { ArrowLeft, DollarSign, RefreshCw } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export interface CostCenter {
  id: string;
  name: string;
  description: string;
  companyCode: string;
  manager: string;
  status: 'active' | 'inactive';
  type: 'production' | 'administration' | 'sales' | 'research';
}

const sampleCostCenters: CostCenter[] = [
  {
    id: "CC-1000",
    name: "Manufacturing",
    description: "Main production cost center",
    companyCode: "1000",
    manager: "Robert Johnson",
    status: 'active',
    type: 'production'
  },
  {
    id: "CC-2000",
    name: "Administration",
    description: "Administrative overhead",
    companyCode: "1000",
    manager: "Susan Miller",
    status: 'active',
    type: 'administration'
  },
  {
    id: "CC-3000",
    name: "Sales & Marketing",
    description: "Sales and marketing activities",
    companyCode: "1000",
    manager: "Michael Thompson",
    status: 'active',
    type: 'sales'
  },
  {
    id: "CC-4000",
    name: "Research Lab",
    description: "Product development and research",
    companyCode: "2000",
    manager: "Lisa Chen",
    status: 'active',
    type: 'research'
  },
  {
    id: "CC-5000",
    name: "IT Department",
    description: "Information technology support",
    companyCode: "1000",
    manager: "David Wilson",
    status: 'active',
    type: 'administration'
  },
  {
    id: "CC-6000",
    name: "East Sales Region",
    description: "Eastern sales territory",
    companyCode: "3000",
    manager: "Jennifer Lee",
    status: 'active',
    type: 'sales'
  },
  {
    id: "CC-7000",
    name: "West Sales Region",
    description: "Western sales territory",
    companyCode: "3000",
    manager: "Carlos Rodriguez",
    status: 'inactive',
    type: 'sales'
  }
];

const CostCenters = () => {
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Fetch data from API
  const fetchCostCenters = async () => {
    setIsLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      setCostCenters(sampleCostCenters);
      setIsLoading(false);
    } catch (error) {
      console.error("Error loading cost centers:", error);
      toast({
        title: "Error",
        description: "Failed to load cost centers data. Please try refreshing.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  // Refresh data handler
  const handleRefresh = () => {
    fetchCostCenters();
    toast({
      title: "Refreshing",
      description: "Cost centers data is being refreshed",
    });
  };

  // Load data on component mount
  useEffect(() => {
    fetchCostCenters();
  }, []);

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeBadgeClass = (type: string) => {
    switch (type) {
      case 'production':
        return 'bg-blue-100 text-blue-800';
      case 'administration':
        return 'bg-purple-100 text-purple-800';
      case 'sales':
        return 'bg-green-100 text-green-800';
      case 'research':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <Link href="/master-data" className="mr-4 p-2 rounded-md hover:bg-gray-100">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">Cost Centers</h1>
          <p className="text-gray-600">Manage organizational cost assignment units</p>
        </div>
      </div>

      {/* Banner indicating this is a placeholder */}
      <div className="mb-6 bg-blue-50 p-4 rounded-md border border-blue-200">
        <div className="flex items-center">
          <DollarSign className="h-5 w-5 text-blue-500 mr-2" />
          <span className="text-blue-800 font-medium">
            Cost Centers module is under development. The data shown below is sample data for demonstration purposes.
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="mb-6 flex flex-col md:flex-row justify-between items-center gap-3 md:gap-0">
        <div className="flex space-x-2 w-full md:w-auto">
          <input 
            type="text" 
            placeholder="Search cost centers..." 
            className="border border-gray-300 rounded-md px-3 py-1.5 text-sm w-full md:w-64"
          />
          <button className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm">
            Search
          </button>
          <button 
            className="border border-gray-300 bg-white px-3 py-1.5 rounded-md text-sm flex items-center"
            onClick={handleRefresh}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
        <div className="flex space-x-2 w-full md:w-auto">
          <button 
            className="border border-gray-300 bg-white px-3 py-1.5 rounded-md text-sm flex items-center"
            onClick={() => {
              const csvContent = costCenters?.map((center: CostCenter) => ({
                ID: center.id,
                Name: center.name,
                Description: center.description,
                CompanyCode: center.companyCode,
                Manager: center.manager,
                Status: center.status,
                Type: center.type
              })) || [];
              
              const csvString = [
                Object.keys(csvContent[0] || {}).join(','),
                ...csvContent.map((row: any) => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'cost-centers.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            Export
          </button>
          <button 
            className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm flex items-center w-full md:w-auto"
            onClick={() => {
              toast({
                title: "New Cost Center",
                description: "Cost Center creation form will open here",
              });
            }}
          >
            <span className="mr-1">+</span> New Cost Center
          </button>
        </div>
      </div>

      {/* Cost Centers Table */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="flex flex-col items-center gap-2">
            <RefreshCw className="h-8 w-8 animate-spin text-blue-600" />
            <p>Loading cost centers data...</p>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-md shadow">
          <div className="max-h-[650px] overflow-y-auto overflow-x-auto" style={{ scrollbarWidth: 'thin' }}>
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50 sticky top-0 z-10">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Company Code
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Manager
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {costCenters.map(costCenter => (
                  <tr key={costCenter.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {costCenter.id}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      {costCenter.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {costCenter.description}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {costCenter.companyCode}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {costCenter.manager}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded-full ${getTypeBadgeClass(costCenter.type)}`}>
                        {costCenter.type.charAt(0).toUpperCase() + costCenter.type.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded-full ${getStatusBadgeClass(costCenter.status)}`}>
                        {costCenter.status.charAt(0).toUpperCase() + costCenter.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button className="text-blue-600 hover:text-blue-800 mr-2">Edit</button>
                      <button className="text-red-600 hover:text-red-800">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 sm:px-6 flex items-center justify-between">
            <div className="flex-1 flex justify-between sm:hidden">
              <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                Previous
              </button>
              <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                Next
              </button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Showing <span className="font-medium">1</span> to <span className="font-medium">7</span> of{' '}
                  <span className="font-medium">7</span> results
                </p>
              </div>
              <div>
                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                  <button className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <span className="sr-only">Previous</span>
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </button>
                  <button aria-current="page" className="z-10 bg-blue-50 border-blue-500 text-blue-600 relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                    1
                  </button>
                  <button className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <span className="sr-only">Next</span>
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CostCenters;