import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Plus, Search, Edit, Trash2, X, FileUp, Download, Factory, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
// Import the plant excel import component
import PlantExcelImport from "../../components/master-data/PlantExcelImport";

// Define the Plant type
type Plant = {
  id: number;
  code: string;
  name: string;
  description: string | null;
  companyCodeId: number;
  companyCodeName?: string;
  type: string;
  category: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  country: string | null;
  postalCode: string | null;
  phone: string | null;
  email: string | null;
  manager: string | null;
  timezone: string | null;
  operatingHours: string | null;
  coordinates: string | null;
  status: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

// Define the Company Code type for selection
type CompanyCode = {
  id: number;
  code: string;
  name: string;
};

// List of plant types
const PLANT_TYPES = [
  "Manufacturing",
  "Distribution",
  "Warehouse",
  "Sales Office",
  "Service Center",
  "Research & Development",
  "Headquarters",
  "Regional Office",
  "Retail Store"
];

// List of countries
const COUNTRIES = [
  "United States", "Canada", "United Kingdom", "Germany", "France", "Italy", "Spain", 
  "Japan", "China", "Australia", "India", "Brazil", "Mexico", "South Africa", "Russia"
];

// List of timezones
const TIMEZONES = [
  "UTC-12:00", "UTC-11:00", "UTC-10:00", "UTC-09:00", "UTC-08:00", "UTC-07:00", 
  "UTC-06:00", "UTC-05:00", "UTC-04:00", "UTC-03:00", "UTC-02:00", "UTC-01:00", 
  "UTC+00:00", "UTC+01:00", "UTC+02:00", "UTC+03:00", "UTC+04:00", "UTC+05:00", 
  "UTC+06:00", "UTC+07:00", "UTC+08:00", "UTC+09:00", "UTC+10:00", "UTC+11:00", "UTC+12:00"
];

// Plant Form Schema
const plantSchema = z.object({
  code: z.string().min(2, "Code is required").max(10, "Code must be at most 10 characters"),
  name: z.string().min(1, "Name is required").max(100, "Name must be at most 100 characters"),
  description: z.string().optional(),
  companyCodeId: z.coerce.number().min(1, "Company Code is required"),
  type: z.string().min(1, "Plant Type is required"),
  category: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  country: z.string().optional(),
  postalCode: z.string().optional(),
  phone: z.string().optional(),
  email: z.union([z.string().email("Invalid email format"), z.literal("")]).optional(),
  manager: z.string().optional(),
  timezone: z.string().optional(),
  operatingHours: z.string().optional(),
  coordinates: z.string().optional(),
  status: z.string().default("active"),
  isActive: z.boolean().default(true),
});

// Plant Management Page
export default function PlantPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [editingPlant, setEditingPlant] = useState<Plant | null>(null);
  const [activeTab, setActiveTab] = useState("basic");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch plants using direct api call to handle JSON parsing correctly
  const [plants, setPlants] = useState<Plant[]>([]);
  const [filteredPlants, setFilteredPlants] = useState<Plant[]>([]);
  const [plantsLoading, setPlantsLoading] = useState(true);
  const [plantsError, setPlantsError] = useState<Error | null>(null);

  // Fetch company codes for dropdown selection
  const { data: companyCodes = [], isLoading: companyCodesLoading } = useQuery({
    queryKey: ['/api/master-data/company-code'],
    retry: 1,
  });

  // Fetch data on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch plants
        setPlantsLoading(true);
        const response = await fetch("/api/master-data/plant", {
          headers: {
            'Accept': 'application/json'
          }
        });
        
        if (!response.ok) {
          throw new Error(`API Error: ${response.status} ${response.statusText}`);
        }
        
        const data = await response.json();
        setPlants(data);
        setFilteredPlants(data);
        setPlantsLoading(false);
      } catch (error) {
        console.error("Error fetching plants:", error);
        setPlantsError(error instanceof Error ? error : new Error('Failed to fetch plants'));
        setPlantsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  // Filter plants based on search query
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredPlants(plants);
    } else {
      setFilteredPlants(
        plants.filter(
          (plant) =>
            plant.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
            plant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            (plant.type && plant.type.toLowerCase().includes(searchQuery.toLowerCase())) ||
            (plant.city && plant.city.toLowerCase().includes(searchQuery.toLowerCase())) ||
            (plant.country && plant.country.toLowerCase().includes(searchQuery.toLowerCase()))
        )
      );
    }
  }, [searchQuery, plants]);

  // Plant form setup
  const form = useForm<z.infer<typeof plantSchema>>({
    resolver: zodResolver(plantSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      companyCodeId: 0,
      type: "",
      category: "",
      address: "",
      city: "",
      state: "",
      country: "",
      postalCode: "",
      phone: "",
      email: "",
      manager: "",
      timezone: "",
      operatingHours: "",
      coordinates: "",
      status: "active",
      isActive: true,
    },
  });

  // Set form values when editing
  useEffect(() => {
    if (editingPlant) {
      form.reset({
        code: editingPlant.code,
        name: editingPlant.name,
        description: editingPlant.description || "",
        companyCodeId: editingPlant.companyCodeId,
        type: editingPlant.type,
        category: editingPlant.category || "",
        address: editingPlant.address || "",
        city: editingPlant.city || "",
        state: editingPlant.state || "",
        country: editingPlant.country || "",
        postalCode: editingPlant.postalCode || "",
        phone: editingPlant.phone || "",
        email: editingPlant.email || "",
        manager: editingPlant.manager || "",
        timezone: editingPlant.timezone || "",
        operatingHours: editingPlant.operatingHours || "",
        coordinates: editingPlant.coordinates || "",
        status: editingPlant.status,
        isActive: editingPlant.isActive,
      });
    } else {
      form.reset({
        code: "",
        name: "",
        description: "",
        companyCodeId: 0,
        type: "",
        category: "",
        address: "",
        city: "",
        state: "",
        country: "",
        postalCode: "",
        phone: "",
        email: "",
        manager: "",
        timezone: "",
        operatingHours: "",
        coordinates: "",
        status: "active",
        isActive: true,
      });
    }
  }, [editingPlant, form]);

  // Create plant mutation
  const createPlantMutation = useMutation({
    mutationFn: (plant: z.infer<typeof plantSchema>) => {
      return apiRequest(`/api/master-data/plant`, {
        method: "POST",
        body: JSON.stringify(plant)
      }).then(res => {
        if (!res.ok) {
          return res.json().then(err => {
            throw new Error(err.message || "Failed to create plant");
          });
        }
        return res.json();
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Plant created successfully",
      });
      // Refresh the plants list
      fetch("/api/master-data/plant", {
        headers: { 'Accept': 'application/json' }
      })
        .then(res => res.json())
        .then(data => {
          setPlants(data);
          setFilteredPlants(data);
        });
      setShowDialog(false);
      setActiveTab("basic");
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create Plant",
        variant: "destructive",
      });
    },
  });

  // Update plant mutation
  const updatePlantMutation = useMutation({
    mutationFn: (data: { id: number; plant: z.infer<typeof plantSchema> }) => {
      return apiRequest(`/api/master-data/plant/${data.id}`, {
        method: "PUT",
        body: JSON.stringify(data.plant),
      }).then(res => res.json());
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Plant updated successfully",
      });
      fetch("/api/master-data/plant", {
        headers: { 'Accept': 'application/json' }
      })
        .then(res => res.json())
        .then(data => {
          setPlants(data);
          setFilteredPlants(data);
        });
      setShowDialog(false);
      setEditingPlant(null);
      setActiveTab("basic");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update Plant",
        variant: "destructive",
      });
    },
  });

  // Delete plant mutation
  const deletePlantMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest(`/api/master-data/plant/${id}`, {
        method: "DELETE",
      }).then(res => res.json());
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Plant deleted successfully",
      });
      fetch("/api/master-data/plant", {
        headers: { 'Accept': 'application/json' }
      })
        .then(res => res.json())
        .then(data => {
          setPlants(data);
          setFilteredPlants(data);
        });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete Plant",
        variant: "destructive",
      });
    },
  });

  // Form submission
  const onSubmit = (values: z.infer<typeof plantSchema>) => {
    console.log("Form submitted with values:", values);
    
    // Convert code to uppercase to maintain consistency
    const updatedValues = {
      ...values,
      code: values.code.toUpperCase()
    };
    
    if (editingPlant) {
      updatePlantMutation.mutate({ id: editingPlant.id, plant: updatedValues });
    } else {
      createPlantMutation.mutate(updatedValues);
    }
  };

  // Function to close the dialog and reset state
  const closeDialog = () => {
    setShowDialog(false);
    setEditingPlant(null);
    setActiveTab("basic");
    form.reset();
  };

  // Function to handle editing a plant
  const handleEdit = (plant: Plant) => {
    setEditingPlant(plant);
    setShowDialog(true);
  };

  // Function to handle deleting a plant
  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this Plant?")) {
      deletePlantMutation.mutate(id);
    }
  };

  // Check for errors
  if (plantsError) {
    return (
      <div className="p-4">
        <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded-md">
          <h3 className="text-lg font-medium">Error</h3>
          <p>{(plantsError as Error).message || "An error occurred"}</p>
        </div>
      </div>
    );
  }

  // Find company code name by ID
  const getCompanyCodeName = (id: number) => {
    const companyCodesArray = Array.isArray(companyCodes) ? companyCodes : [];
    const companyCode = companyCodesArray.find((cc: any) => cc.id === id);
    return companyCode ? `${companyCode.code} - ${companyCode.name}` : "Unknown";
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center">
          <Link href="/master-data" className="mr-4 p-2 rounded-md hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Plants</h1>
            <p className="text-sm text-muted-foreground">
              Manage manufacturing sites, warehouses, and other facilities
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowImportDialog(true)}>
            <FileUp className="mr-2 h-4 w-4" />
            Import from Excel
          </Button>
          <Button onClick={() => setShowDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Plant
          </Button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search plants..."
          className="pl-8"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Plants Table */}
      <Card>
        <CardHeader>
          <CardTitle>Plants</CardTitle>
          <CardDescription>
            All manufacturing and distribution facilities in your organization
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="max-h-[500px] overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-white z-10">
                  <TableRow>
                    <TableHead className="w-[100px]">Code</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden md:table-cell">Company Code</TableHead>
                    <TableHead className="hidden sm:table-cell">Type</TableHead>
                    <TableHead className="hidden lg:table-cell">Location</TableHead>
                    <TableHead className="w-[100px] text-center">Status</TableHead>
                    <TableHead className="w-[100px] text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {plantsLoading ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24">
                        Loading...
                      </TableCell>
                    </TableRow>
                  ) : filteredPlants.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24">
                        No plants found. {searchQuery ? "Try a different search." : "Create your first plant."}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredPlants.map((plant) => (
                      <TableRow key={plant.id}>
                        <TableCell className="font-medium">{plant.code}</TableCell>
                        <TableCell>{plant.name}</TableCell>
                        <TableCell className="hidden md:table-cell">{getCompanyCodeName(plant.companyCodeId)}</TableCell>
                        <TableCell className="hidden sm:table-cell">{plant.type}</TableCell>
                        <TableCell className="hidden lg:table-cell">
                          {plant.city && plant.country ? `${plant.city}, ${plant.country}` : 
                           plant.city || plant.country || "N/A"}
                        </TableCell>
                        <TableCell className="text-center">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                              plant.isActive
                                ? "bg-green-100 text-green-800"
                                : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {plant.isActive ? "Active" : "Inactive"}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(plant)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(plant.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Plant Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>
              {editingPlant ? "Edit Plant" : "Create Plant"}
            </DialogTitle>
            <DialogDescription>
              {editingPlant
                ? "Update the plant details below"
                : "Add a new manufacturing site or warehouse to your organization"}
            </DialogDescription>
          </DialogHeader>

          <div className="overflow-y-auto max-h-[calc(90vh-170px)] pr-2 my-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-3 mb-4 sticky top-0 bg-background z-10">
                    <TabsTrigger value="basic">Basic Information</TabsTrigger>
                    <TabsTrigger value="contact">Contact & Address</TabsTrigger>
                    <TabsTrigger value="additional">Additional Information</TabsTrigger>
                  </TabsList>
                  
                  {/* Basic Information Tab */}
                  <TabsContent value="basic" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="code"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Code*</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="E.g., P001" 
                                {...field} 
                                disabled={!!editingPlant}
                              />
                            </FormControl>
                            <FormDescription>
                              Unique code for this plant (max 10 characters)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name*</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="E.g., Main Manufacturing Plant" 
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription>
                              Official name of the plant or facility
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Brief description of this plant" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="companyCodeId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company Code*</FormLabel>
                            <Select
                              onValueChange={(value) => field.onChange(parseInt(value))}
                              defaultValue={field.value ? field.value.toString() : undefined}
                              value={field.value ? field.value.toString() : undefined}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select company code" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {companyCodesLoading ? (
                                  <SelectItem value="loading" disabled>Loading...</SelectItem>
                                ) : (
                                  Array.isArray(companyCodes) && companyCodes.map((cc: any) => (
                                    <SelectItem key={cc.id} value={cc.id.toString()}>
                                      {cc.code} - {cc.name}
                                    </SelectItem>
                                  ))
                                )}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Company code this plant belongs to
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Plant Type*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select plant type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {PLANT_TYPES.map((type) => (
                                  <SelectItem key={type} value={type}>
                                    {type}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="isActive"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border rounded-md">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Active</FormLabel>
                            <FormDescription>
                              Is this plant active and available for use?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </TabsContent>

                  {/* Contact & Address Tab */}
                  <TabsContent value="contact" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Street address" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="City" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>State/Province</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="State or province" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select country" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {COUNTRIES.map((country) => (
                                  <SelectItem key={country} value={country}>
                                    {country}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="postalCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Postal Code</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Postal or ZIP code" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Phone number" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Email address" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormDescription>
                              Leave blank if no email address is available
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="manager"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Plant Manager</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Name of plant manager" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </TabsContent>

                  {/* Additional Information Tab */}
                  <TabsContent value="additional" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="timezone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Timezone</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select timezone" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {TIMEZONES.map((timezone) => (
                                  <SelectItem key={timezone} value={timezone}>
                                    {timezone}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="operatingHours"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Operating Hours</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="E.g., Mon-Fri: 8AM-5PM" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="coordinates"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>GPS Coordinates</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Latitude, Longitude (E.g., 40.7128, -74.0060)" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Plant Category</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Optional categorization" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormDescription>
                            Additional categorization for reporting purposes
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                </Tabs>

                <DialogFooter className="pt-4">
                  <div className="flex w-full justify-between">
                    <div>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={closeDialog}
                      >
                        Cancel
                      </Button>
                      
                      {activeTab !== "basic" && (
                        <Button
                          type="button"
                          variant="secondary"
                          onClick={() => {
                            if (activeTab === "contact") setActiveTab("basic");
                            if (activeTab === "additional") setActiveTab("contact");
                          }}
                          className="ml-2"
                        >
                          Previous
                        </Button>
                      )}
                    </div>
                    
                    <div>
                      {activeTab !== "additional" ? (
                        <Button 
                          type="button"
                          onClick={() => {
                            // Validate current tab before proceeding
                            if (activeTab === "basic") {
                              const basicFields = ["code", "name", "companyCodeId", "type"];
                              form.trigger(basicFields as any).then(isValid => {
                                if (isValid) setActiveTab("contact");
                              });
                            } else if (activeTab === "contact") {
                              // Validate email if it's not empty before proceeding
                              const email = form.getValues().email;
                              if (email && email.trim() !== "") {
                                form.trigger("email").then(isValid => {
                                  if (isValid) setActiveTab("additional");
                                });
                              } else {
                                setActiveTab("additional");
                              }
                            }
                          }}
                        >
                          Next
                        </Button>
                      ) : (
                        <Button 
                          type="button"
                          onClick={() => {
                            // Validate form before submitting
                            form.trigger().then(isValid => {
                              if (isValid) {
                                // Get form values
                                const values = form.getValues();
                                
                                // Pre-process values to handle empty email
                                const processedValues = {
                                  ...values,
                                  email: values.email === "" ? undefined : values.email
                                };
                                
                                // Submit the form
                                if (editingPlant) {
                                  updatePlantMutation.mutate({ id: editingPlant.id, plant: processedValues });
                                } else {
                                  createPlantMutation.mutate(processedValues);
                                }
                              }
                            });
                          }}
                          disabled={createPlantMutation.isPending || updatePlantMutation.isPending}
                        >
                          {createPlantMutation.isPending || updatePlantMutation.isPending ? (
                            "Saving..."
                          ) : (
                            editingPlant ? "Update Plant" : "Create Plant"
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                </DialogFooter>
              </form>
            </Form>
          </div>
        </DialogContent>
      </Dialog>

      {/* Excel Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Import Plants from Excel</DialogTitle>
            <DialogDescription>
              Upload an Excel file with plant data to import in bulk
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p>Excel import functionality will be implemented here.</p>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowImportDialog(false)}
            >
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}