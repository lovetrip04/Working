import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  X, 
  FileUp, 
  Download, 
  ShoppingCart,
  Copy,
  CreditCard,
  CheckCircle2,
  Truck
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

// Define the Sales Order Status type
type SalesOrderStatus = 
  | "Draft" 
  | "Confirmed" 
  | "In Process" 
  | "Shipped" 
  | "Delivered" 
  | "Invoiced" 
  | "Paid" 
  | "Cancelled";

// Define the Sales Order type
type SalesOrder = {
  id: number;
  orderNumber: string;
  customerCode: string;
  customerName: string;
  orderDate: string;
  deliveryDate: string | null;
  status: SalesOrderStatus;
  totalAmount: number;
  currency: string;
  salesOrg: string;
  distributionChannel: string;
  division: string;
  createdAt: string;
  updatedAt: string;
};

// Define the Sales Order Item type
type SalesOrderItem = {
  id: number;
  salesOrderId: number;
  lineNumber: number;
  productCode: string;
  productName: string;
  quantity: number;
  unit: string;
  price: number;
  discount: number;
  totalPrice: number;
  deliveryDate: string | null;
  status: string;
};

// Define the Customer type
type Customer = {
  id: number;
  code: string;
  name: string;
  address: string;
  city: string;
  country: string;
  email: string;
  phone: string;
};

// Define the Product type
type Product = {
  id: number;
  code: string;
  name: string;
  description: string;
  price: number;
  unit: string;
  category: string;
  stockQuantity: number;
};

// Define the Sales Organization type
type SalesOrg = {
  id: number;
  code: string;
  name: string;
  companyCode: string;
};

// Distribution Channels
const DISTRIBUTION_CHANNELS = [
  { code: "DI", name: "Direct Sales" },
  { code: "WH", name: "Wholesale" },
  { code: "RE", name: "Retail" },
  { code: "ON", name: "Online" },
];

// Divisions
const DIVISIONS = [
  { code: "FG", name: "Finished Goods" },
  { code: "SP", name: "Spare Parts" },
  { code: "SE", name: "Services" },
];

// Sales Order Header Schema
const salesOrderHeaderSchema = z.object({
  customerCode: z.string().min(1, "Customer is required"),
  orderDate: z.string().min(1, "Order date is required"),
  requestedDeliveryDate: z.string().optional(),
  salesOrg: z.string().min(1, "Sales organization is required"),
  distributionChannel: z.string().min(1, "Distribution channel is required"),
  division: z.string().min(1, "Division is required"),
  reference: z.string().optional(),
  incoterms: z.string().optional(),
  paymentTerms: z.string().optional(),
  currency: z.string().min(1, "Currency is required"),
  notes: z.string().optional(),
});

// Sales Order Item Schema
const salesOrderItemSchema = z.object({
  productCode: z.string().min(1, "Product is required"),
  quantity: z.coerce.number().min(0.01, "Quantity must be greater than 0"),
  price: z.coerce.number().min(0, "Price cannot be negative"),
  discount: z.coerce.number().min(0, "Discount cannot be negative").max(100, "Discount cannot exceed 100%"),
  requestedDeliveryDate: z.string().optional(),
  notes: z.string().optional(),
});

// Sales Order Item Array Schema
const salesOrderItemsSchema = z.array(salesOrderItemSchema).min(1, "At least one item is required");

// Sales Order Page Component
export default function SalesOrderPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [showItemDialog, setShowItemDialog] = useState(false);
  const [editingSalesOrder, setEditingSalesOrder] = useState<SalesOrder | null>(null);
  const [salesOrders, setSalesOrders] = useState<SalesOrder[]>([]);
  const [salesOrderItems, setSalesOrderItems] = useState<SalesOrderItem[]>([]);
  const [filteredSalesOrders, setFilteredSalesOrders] = useState<SalesOrder[]>([]);
  const [activeTab, setActiveTab] = useState("header");
  const [editingItemIndex, setEditingItemIndex] = useState<number | null>(null);
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isLoading, setIsLoading] = useState(true);
  const [isItemsLoading, setIsItemsLoading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Forms
  const headerForm = useForm<z.infer<typeof salesOrderHeaderSchema>>({
    resolver: zodResolver(salesOrderHeaderSchema),
    defaultValues: {
      customerCode: "",
      orderDate: new Date().toISOString().slice(0, 10),
      requestedDeliveryDate: "",
      salesOrg: "",
      distributionChannel: "DI",
      division: "FG",
      reference: "",
      incoterms: "",
      paymentTerms: "",
      currency: "USD",
      notes: "",
    },
  });

  const itemForm = useForm<z.infer<typeof salesOrderItemSchema>>({
    resolver: zodResolver(salesOrderItemSchema),
    defaultValues: {
      productCode: "",
      quantity: 1,
      price: 0,
      discount: 0,
      requestedDeliveryDate: "",
      notes: "",
    },
  });

  // Customers and Products data
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [salesOrgs, setSalesOrgs] = useState<SalesOrg[]>([]);
  
  // Current working order
  const [currentItems, setCurrentItems] = useState<z.infer<typeof salesOrderItemSchema>[]>([]);

  // Handle customer selection change
  const handleCustomerChange = (value: string) => {
    headerForm.setValue("customerCode", value);
    const selectedCustomer = customers.find(c => c.code === value);
    // You might want to update other fields based on customer defaults here
  };

  // Handle product selection change
  const handleProductChange = (value: string) => {
    itemForm.setValue("productCode", value);
    const selectedProduct = products.find(p => p.code === value);
    if (selectedProduct) {
      itemForm.setValue("price", selectedProduct.price);
      // You might want to set other product details as defaults
    }
  };

  // Calculate item total price
  const calculateItemTotal = () => {
    const quantity = itemForm.watch("quantity") || 0;
    const price = itemForm.watch("price") || 0;
    const discount = itemForm.watch("discount") || 0;
    return quantity * price * (1 - discount / 100);
  };

  // Fetch sales orders
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        // This would be a real API call in production
        // For now, let's use mock data
        const mockSalesOrders: SalesOrder[] = [
          {
            id: 1,
            orderNumber: "SO10001",
            customerCode: "CUST001",
            customerName: "ABC Company",
            orderDate: "2025-05-15",
            deliveryDate: "2025-05-25",
            status: "Confirmed",
            totalAmount: 5240.50,
            currency: "USD",
            salesOrg: "US01",
            distributionChannel: "DI",
            division: "FG",
            createdAt: "2025-05-15T10:30:00Z",
            updatedAt: "2025-05-15T10:30:00Z"
          },
          {
            id: 2,
            orderNumber: "SO10002",
            customerCode: "CUST002",
            customerName: "XYZ Corporation",
            orderDate: "2025-05-16",
            deliveryDate: "2025-05-26",
            status: "In Process",
            totalAmount: 3780.25,
            currency: "USD",
            salesOrg: "US01",
            distributionChannel: "WH",
            division: "FG",
            createdAt: "2025-05-16T11:45:00Z",
            updatedAt: "2025-05-16T14:20:00Z"
          },
          {
            id: 3,
            orderNumber: "SO10003",
            customerCode: "CUST003",
            customerName: "Global Enterprises",
            orderDate: "2025-05-17",
            deliveryDate: "2025-05-27",
            status: "Draft",
            totalAmount: 1250.75,
            currency: "EUR",
            salesOrg: "EU01",
            distributionChannel: "DI",
            division: "SE",
            createdAt: "2025-05-17T09:15:00Z",
            updatedAt: "2025-05-17T09:15:00Z"
          }
        ];
        
        setSalesOrders(mockSalesOrders);
        setFilteredSalesOrders(mockSalesOrders);

        // Mock customers data
        const mockCustomers: Customer[] = [
          {
            id: 1,
            code: "CUST001",
            name: "ABC Company",
            address: "123 Main St",
            city: "New York",
            country: "USA",
            email: "contact@abccompany.com",
            phone: "+1-555-123-4567"
          },
          {
            id: 2,
            code: "CUST002",
            name: "XYZ Corporation",
            address: "456 Business Ave",
            city: "Los Angeles",
            country: "USA",
            email: "info@xyzcorp.com",
            phone: "+1-555-987-6543"
          },
          {
            id: 3,
            code: "CUST003",
            name: "Global Enterprises",
            address: "789 International Blvd",
            city: "Berlin",
            country: "Germany",
            email: "contact@globalent.com",
            phone: "+49-30-12345678"
          }
        ];
        setCustomers(mockCustomers);

        // Mock products data
        const mockProducts: Product[] = [
          {
            id: 1,
            code: "P001",
            name: "Premium Widget",
            description: "High-quality widget for industrial use",
            price: 125.50,
            unit: "PC",
            category: "Widgets",
            stockQuantity: 150
          },
          {
            id: 2,
            code: "P002",
            name: "Standard Gadget",
            description: "Reliable gadget for everyday use",
            price: 75.25,
            unit: "PC",
            category: "Gadgets",
            stockQuantity: 200
          },
          {
            id: 3,
            code: "P003",
            name: "Economy Tool Set",
            description: "Affordable tool set for basic needs",
            price: 45.99,
            unit: "SET",
            category: "Tools",
            stockQuantity: 85
          }
        ];
        setProducts(mockProducts);

        // Mock sales organizations
        const mockSalesOrgs: SalesOrg[] = [
          {
            id: 1,
            code: "US01",
            name: "USA Sales",
            companyCode: "US01"
          },
          {
            id: 2,
            code: "EU01",
            name: "Europe Sales",
            companyCode: "EU01"
          }
        ];
        setSalesOrgs(mockSalesOrgs);

        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching sales orders:", error);
        toast({
          title: "Error",
          description: "Failed to load sales orders",
          variant: "destructive",
        });
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [toast]);

  // Filter sales orders based on search query and status filter
  useEffect(() => {
    let filtered = salesOrders;

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter(order => order.status === statusFilter);
    }

    // Apply search filter
    if (searchQuery.trim() !== "") {
      filtered = filtered.filter(
        order =>
          order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
          order.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          order.customerCode.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredSalesOrders(filtered);
  }, [searchQuery, statusFilter, salesOrders]);

  // Fetch sales order items when an order is selected
  useEffect(() => {
    const fetchOrderItems = async () => {
      if (!selectedOrderId) return;

      try {
        setIsItemsLoading(true);
        // This would be a real API call in production
        // For now, let's use mock data
        const mockItems: SalesOrderItem[] = [
          {
            id: 1,
            salesOrderId: 1,
            lineNumber: 1,
            productCode: "P001",
            productName: "Premium Widget",
            quantity: 25,
            unit: "PC",
            price: 125.50,
            discount: 5,
            totalPrice: 2980.63,
            deliveryDate: "2025-05-25",
            status: "Confirmed"
          },
          {
            id: 2,
            salesOrderId: 1,
            lineNumber: 2,
            productCode: "P002",
            productName: "Standard Gadget",
            quantity: 30,
            unit: "PC",
            price: 75.25,
            discount: 0,
            totalPrice: 2257.50,
            deliveryDate: "2025-05-25",
            status: "Confirmed"
          }
        ];
        
        setSalesOrderItems(mockItems);
        setIsItemsLoading(false);
      } catch (error) {
        console.error("Error fetching order items:", error);
        toast({
          title: "Error",
          description: "Failed to load order items",
          variant: "destructive",
        });
        setIsItemsLoading(false);
      }
    };

    if (selectedOrderId) {
      fetchOrderItems();
    }
  }, [selectedOrderId, toast]);

  // Handle sales order creation
  const handleCreateSalesOrder = async (data: z.infer<typeof salesOrderHeaderSchema>) => {
    // Validate that there are items
    if (currentItems.length === 0) {
      toast({
        title: "Error",
        description: "Sales order must have at least one item",
        variant: "destructive",
      });
      return;
    }

    // Create sales order with header and items
    try {
      // In a real application, this would be an API call
      console.log("Creating sales order:", {
        header: data,
        items: currentItems
      });

      toast({
        title: "Success",
        description: "Sales order created successfully",
      });

      // Reset form and current items
      headerForm.reset();
      setCurrentItems([]);
      setShowDialog(false);
    } catch (error) {
      console.error("Error creating sales order:", error);
      toast({
        title: "Error",
        description: "Failed to create sales order",
        variant: "destructive",
      });
    }
  };

  // Handle adding/editing an item to the current sales order
  const handleAddItem = (data: z.infer<typeof salesOrderItemSchema>) => {
    try {
      // Calculate total price
      const totalPrice = calculateItemTotal();
      
      if (editingItemIndex !== null) {
        // Edit existing item
        const updatedItems = [...currentItems];
        updatedItems[editingItemIndex] = {
          ...data,
          // Add any calculated fields here
        };
        setCurrentItems(updatedItems);
        setEditingItemIndex(null);
      } else {
        // Add new item
        setCurrentItems([...currentItems, {
          ...data,
          // Add any calculated fields here
        }]);
      }
      
      // Reset form and close dialog
      itemForm.reset({
        productCode: "",
        quantity: 1,
        price: 0,
        discount: 0,
        requestedDeliveryDate: "",
        notes: "",
      });
      setShowItemDialog(false);
      
      toast({
        title: "Success",
        description: editingItemIndex !== null 
          ? "Item updated successfully" 
          : "Item added successfully",
      });
    } catch (error) {
      console.error("Error adding/editing item:", error);
      toast({
        title: "Error",
        description: "Failed to add/edit item",
        variant: "destructive",
      });
    }
  };

  // Handle editing an existing item
  const handleEditItem = (index: number) => {
    const item = currentItems[index];
    itemForm.reset({
      productCode: item.productCode,
      quantity: item.quantity,
      price: item.price,
      discount: item.discount,
      requestedDeliveryDate: item.requestedDeliveryDate || "",
      notes: item.notes || "",
    });
    setEditingItemIndex(index);
    setShowItemDialog(true);
  };

  // Handle deleting an item
  const handleDeleteItem = (index: number) => {
    const updatedItems = [...currentItems];
    updatedItems.splice(index, 1);
    setCurrentItems(updatedItems);
    
    toast({
      title: "Success",
      description: "Item removed successfully",
    });
  };

  // Calculate total amount for current items
  const calculateTotal = () => {
    return currentItems.reduce((sum, item) => {
      const quantity = item.quantity || 0;
      const price = item.price || 0;
      const discount = item.discount || 0;
      return sum + (quantity * price * (1 - discount / 100));
    }, 0);
  };

  // Handle status changes for an order
  const handleStatusChange = async (orderId: number, newStatus: SalesOrderStatus) => {
    try {
      // In a real application, this would be an API call
      console.log("Changing status for order", orderId, "to", newStatus);
      
      // Update the local state
      const updatedOrders = salesOrders.map(order => 
        order.id === orderId ? { ...order, status: newStatus } : order
      );
      setSalesOrders(updatedOrders);
      setFilteredSalesOrders(updatedOrders);
      
      toast({
        title: "Success",
        description: `Order status updated to ${newStatus}`,
      });
    } catch (error) {
      console.error("Error updating order status:", error);
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      });
    }
  };

  // Function to get statusColor for badges
  const getStatusColor = (status: SalesOrderStatus) => {
    switch (status) {
      case "Draft": return "gray";
      case "Confirmed": return "blue";
      case "In Process": return "orange";
      case "Shipped": return "purple";
      case "Delivered": return "green";
      case "Invoiced": return "indigo";
      case "Paid": return "green";
      case "Cancelled": return "red";
      default: return "gray";
    }
  };

  // Generate a status badge with the correct color
  const StatusBadge = ({ status }: { status: SalesOrderStatus }) => {
    const colorMap: Record<string, string> = {
      "gray": "bg-gray-100 text-gray-800 hover:bg-gray-200",
      "blue": "bg-blue-100 text-blue-800 hover:bg-blue-200",
      "orange": "bg-orange-100 text-orange-800 hover:bg-orange-200",
      "purple": "bg-purple-100 text-purple-800 hover:bg-purple-200",
      "green": "bg-green-100 text-green-800 hover:bg-green-200",
      "indigo": "bg-indigo-100 text-indigo-800 hover:bg-indigo-200",
      "red": "bg-red-100 text-red-800 hover:bg-red-200",
    };
    
    const color = getStatusColor(status);
    const className = colorMap[color] || colorMap.gray;
    
    return <Badge className={className}>{status}</Badge>;
  };

  // Process steps for creating a sales order
  const handleNextStep = async () => {
    if (activeTab === "header") {
      const isValid = await headerForm.trigger();
      if (isValid) {
        setActiveTab("items");
      }
    } else if (activeTab === "items") {
      if (currentItems.length === 0) {
        toast({
          title: "Error",
          description: "You must add at least one item",
          variant: "destructive",
        });
        return;
      }
      setActiveTab("review");
    }
  };

  // Get the progress percentage
  const getProgressPercentage = () => {
    if (activeTab === "header") return 33;
    if (activeTab === "items") return 66;
    return 100;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Sales Orders</h1>
          <p className="text-sm text-muted-foreground">
            Manage customer orders and track their status
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => {
            setEditingSalesOrder(null);
            setCurrentItems([]);
            headerForm.reset();
            setActiveTab("header");
            setShowDialog(true);
          }}>
            <Plus className="mr-2 h-4 w-4" />
            New Sales Order
          </Button>
        </div>
      </div>

      {/* Search and Filter Section */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by order number, customer..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select
          value={statusFilter}
          onValueChange={setStatusFilter}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="Draft">Draft</SelectItem>
            <SelectItem value="Confirmed">Confirmed</SelectItem>
            <SelectItem value="In Process">In Process</SelectItem>
            <SelectItem value="Shipped">Shipped</SelectItem>
            <SelectItem value="Delivered">Delivered</SelectItem>
            <SelectItem value="Invoiced">Invoiced</SelectItem>
            <SelectItem value="Paid">Paid</SelectItem>
            <SelectItem value="Cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Sales Orders Table */}
      <Card>
        <CardHeader>
          <CardTitle>Sales Orders</CardTitle>
          <CardDescription>
            Manage and track all customer orders
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order Number</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead className="hidden md:table-cell">Order Date</TableHead>
                  <TableHead className="hidden md:table-cell">Delivery Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden lg:table-cell">Total</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center h-24">
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : filteredSalesOrders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center h-24">
                      No sales orders found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredSalesOrders.map((order) => (
                    <TableRow key={order.id} className={selectedOrderId === order.id ? "bg-muted/50" : ""}>
                      <TableCell className="font-medium">
                        <div className="cursor-pointer" onClick={() => setSelectedOrderId(order.id)}>
                          {order.orderNumber}
                        </div>
                      </TableCell>
                      <TableCell>{order.customerName}</TableCell>
                      <TableCell className="hidden md:table-cell">{new Date(order.orderDate).toLocaleDateString()}</TableCell>
                      <TableCell className="hidden md:table-cell">
                        {order.deliveryDate ? new Date(order.deliveryDate).toLocaleDateString() : "-"}
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={order.status} />
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        {order.totalAmount.toLocaleString(undefined, {
                          style: 'currency',
                          currency: order.currency,
                          minimumFractionDigits: 2
                        })}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end items-center gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              // Implement view/edit functionality
                              console.log("Edit order", order.id);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              // Implement copy functionality
                              console.log("Copy order", order.id);
                            }}
                          >
                            <Copy className="h-4 w-4" />
                            <span className="sr-only">Copy</span>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            disabled={order.status === "Cancelled"}
                            onClick={() => {
                              if (order.status === "Draft") {
                                handleStatusChange(order.id, "Confirmed");
                              } else if (order.status === "Confirmed") {
                                handleStatusChange(order.id, "In Process");
                              } else if (order.status === "In Process") {
                                handleStatusChange(order.id, "Shipped");
                              } else if (order.status === "Shipped") {
                                handleStatusChange(order.id, "Delivered");
                              } else if (order.status === "Delivered") {
                                handleStatusChange(order.id, "Invoiced");
                              } else if (order.status === "Invoiced") {
                                handleStatusChange(order.id, "Paid");
                              }
                            }}
                          >
                            <CheckCircle2 className="h-4 w-4" />
                            <span className="sr-only">Advance Status</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Selected Order Details */}
      {selectedOrderId && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>
                  Order Details: {filteredSalesOrders.find(o => o.id === selectedOrderId)?.orderNumber}
                </CardTitle>
                <CardDescription>
                  Customer: {filteredSalesOrders.find(o => o.id === selectedOrderId)?.customerName}
                </CardDescription>
              </div>
              <StatusBadge status={filteredSalesOrders.find(o => o.id === selectedOrderId)?.status || "Draft"} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Order details summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Order Information</h3>
                  <div className="mt-1 text-sm">
                    <p><span className="font-medium">Order Date:</span> {new Date(filteredSalesOrders.find(o => o.id === selectedOrderId)?.orderDate || "").toLocaleDateString()}</p>
                    <p><span className="font-medium">Delivery Date:</span> {filteredSalesOrders.find(o => o.id === selectedOrderId)?.deliveryDate ? new Date(filteredSalesOrders.find(o => o.id === selectedOrderId)?.deliveryDate || "").toLocaleDateString() : "Not specified"}</p>
                    <p><span className="font-medium">Sales Org:</span> {filteredSalesOrders.find(o => o.id === selectedOrderId)?.salesOrg}</p>
                    <p><span className="font-medium">Distribution Channel:</span> {filteredSalesOrders.find(o => o.id === selectedOrderId)?.distributionChannel}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Customer Information</h3>
                  <div className="mt-1 text-sm">
                    <p><span className="font-medium">Customer Code:</span> {filteredSalesOrders.find(o => o.id === selectedOrderId)?.customerCode}</p>
                    <p><span className="font-medium">Customer Name:</span> {filteredSalesOrders.find(o => o.id === selectedOrderId)?.customerName}</p>
                    <p><span className="font-medium">Address:</span> {customers.find(c => c.code === filteredSalesOrders.find(o => o.id === selectedOrderId)?.customerCode)?.address}</p>
                    <p><span className="font-medium">City/Country:</span> {customers.find(c => c.code === filteredSalesOrders.find(o => o.id === selectedOrderId)?.customerCode)?.city}, {customers.find(c => c.code === filteredSalesOrders.find(o => o.id === selectedOrderId)?.customerCode)?.country}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Financial Information</h3>
                  <div className="mt-1 text-sm">
                    <p><span className="font-medium">Total Amount:</span> {filteredSalesOrders.find(o => o.id === selectedOrderId)?.totalAmount.toLocaleString(undefined, { style: 'currency', currency: filteredSalesOrders.find(o => o.id === selectedOrderId)?.currency || "USD" })}</p>
                    <p><span className="font-medium">Currency:</span> {filteredSalesOrders.find(o => o.id === selectedOrderId)?.currency}</p>
                  </div>
                </div>
              </div>

              {/* Order items table */}
              <div>
                <h3 className="text-sm font-medium mb-2">Order Items</h3>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Line</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Unit</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Discount</TableHead>
                        <TableHead>Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isItemsLoading ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center h-24">
                            Loading items...
                          </TableCell>
                        </TableRow>
                      ) : salesOrderItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center h-24">
                            No items found for this order
                          </TableCell>
                        </TableRow>
                      ) : (
                        salesOrderItems.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>{item.lineNumber}</TableCell>
                            <TableCell>
                              <div>
                                <p className="font-medium">{item.productName}</p>
                                <p className="text-xs text-muted-foreground">{item.productCode}</p>
                              </div>
                            </TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>{item.unit}</TableCell>
                            <TableCell>
                              {item.price.toLocaleString(undefined, {
                                style: 'currency',
                                currency: filteredSalesOrders.find(o => o.id === selectedOrderId)?.currency || "USD"
                              })}
                            </TableCell>
                            <TableCell>{item.discount}%</TableCell>
                            <TableCell>
                              {item.totalPrice.toLocaleString(undefined, {
                                style: 'currency',
                                currency: filteredSalesOrders.find(o => o.id === selectedOrderId)?.currency || "USD"
                              })}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-wrap gap-2 justify-end">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    // Implement print functionality
                    console.log("Print order", selectedOrderId);
                  }}
                >
                  Print
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => {
                    // Implement export functionality
                    console.log("Export order", selectedOrderId);
                  }}
                >
                  Export
                </Button>
                {filteredSalesOrders.find(o => o.id === selectedOrderId)?.status === "Delivered" && (
                  <Button 
                    onClick={() => {
                      // Create invoice from order
                      handleStatusChange(selectedOrderId, "Invoiced");
                      toast({
                        title: "Success",
                        description: "Invoice created successfully",
                      });
                    }}
                  >
                    <CreditCard className="mr-2 h-4 w-4" />
                    Create Invoice
                  </Button>
                )}
                {filteredSalesOrders.find(o => o.id === selectedOrderId)?.status === "Confirmed" && (
                  <Button 
                    onClick={() => {
                      // Create delivery for order
                      handleStatusChange(selectedOrderId, "In Process");
                      toast({
                        title: "Success",
                        description: "Order moved to processing",
                      });
                    }}
                  >
                    <Truck className="mr-2 h-4 w-4" />
                    Process Order
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create/Edit Sales Order Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>
              {editingSalesOrder ? "Edit Sales Order" : "Create New Sales Order"}
            </DialogTitle>
            <DialogDescription>
              Fill in the order details and add items to create a new sales order.
            </DialogDescription>
          </DialogHeader>

          {/* Progress indicator */}
          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
            <div 
              className="bg-blue-600 h-2.5 rounded-full" 
              style={{ width: `${getProgressPercentage()}%` }}
            ></div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="header">Order Header</TabsTrigger>
              <TabsTrigger value="items">Order Items</TabsTrigger>
              <TabsTrigger value="review">Review & Create</TabsTrigger>
            </TabsList>
            
            {/* Header Tab */}
            <TabsContent value="header">
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={headerForm.control}
                    name="customerCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Customer</FormLabel>
                        <Select
                          onValueChange={handleCustomerChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select customer" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {customers.map((customer) => (
                              <SelectItem key={customer.id} value={customer.code}>
                                {customer.code} - {customer.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="orderDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Order Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="requestedDeliveryDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Requested Delivery Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="salesOrg"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sales Organization</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select sales org" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {salesOrgs.map((org) => (
                              <SelectItem key={org.id} value={org.code}>
                                {org.code} - {org.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="distributionChannel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Distribution Channel</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select distribution channel" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {DISTRIBUTION_CHANNELS.map((channel) => (
                              <SelectItem key={channel.code} value={channel.code}>
                                {channel.code} - {channel.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="division"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Division</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select division" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {DIVISIONS.map((division) => (
                              <SelectItem key={division.code} value={division.code}>
                                {division.code} - {division.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="currency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Currency</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select currency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="USD">USD - US Dollar</SelectItem>
                            <SelectItem value="EUR">EUR - Euro</SelectItem>
                            <SelectItem value="GBP">GBP - British Pound</SelectItem>
                            <SelectItem value="JPY">JPY - Japanese Yen</SelectItem>
                            <SelectItem value="CNY">CNY - Chinese Yuan</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="reference"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reference Number</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Customer's reference number" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={headerForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <textarea
                          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Any special instructions or notes for this order"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </form>
            </TabsContent>
            
            {/* Items Tab */}
            <TabsContent value="items">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Order Items</h3>
                  <Button
                    onClick={() => {
                      setEditingItemIndex(null);
                      itemForm.reset({
                        productCode: "",
                        quantity: 1,
                        price: 0,
                        discount: 0,
                        requestedDeliveryDate: "",
                        notes: "",
                      });
                      setShowItemDialog(true);
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Item
                  </Button>
                </div>
                
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Discount</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currentItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center h-24">
                            No items added. Click "Add Item" to add products to this order.
                          </TableCell>
                        </TableRow>
                      ) : (
                        currentItems.map((item, index) => {
                          // Find product details
                          const product = products.find(p => p.code === item.productCode);
                          // Calculate total
                          const total = (item.quantity || 0) * (item.price || 0) * (1 - (item.discount || 0) / 100);
                          
                          return (
                            <TableRow key={index}>
                              <TableCell>
                                <div>
                                  <p className="font-medium">{product?.name || item.productCode}</p>
                                  <p className="text-xs text-muted-foreground">{item.productCode}</p>
                                </div>
                              </TableCell>
                              <TableCell>{item.quantity} {product?.unit}</TableCell>
                              <TableCell>
                                {item.price.toLocaleString(undefined, {
                                  style: 'currency',
                                  currency: headerForm.watch("currency") || "USD"
                                })}
                              </TableCell>
                              <TableCell>{item.discount}%</TableCell>
                              <TableCell>
                                {total.toLocaleString(undefined, {
                                  style: 'currency',
                                  currency: headerForm.watch("currency") || "USD"
                                })}
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleEditItem(index)}
                                  >
                                    <Edit className="h-4 w-4" />
                                    <span className="sr-only">Edit</span>
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDeleteItem(index)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                    <span className="sr-only">Delete</span>
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
                
                {currentItems.length > 0 && (
                  <div className="flex justify-end">
                    <div className="bg-muted p-4 rounded-md w-48">
                      <div className="flex justify-between mb-2">
                        <span className="font-medium">Total:</span>
                        <span>
                          {calculateTotal().toLocaleString(undefined, {
                            style: 'currency',
                            currency: headerForm.watch("currency") || "USD"
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
            
            {/* Review Tab */}
            <TabsContent value="review">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Order Summary</h3>
                  <div className="bg-muted p-4 rounded-md">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium mb-1">Customer</h4>
                        <p className="text-sm">
                          {customers.find(c => c.code === headerForm.watch("customerCode"))?.name || "-"}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {headerForm.watch("customerCode")}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-1">Order Details</h4>
                        <p className="text-sm">
                          Date: {headerForm.watch("orderDate") || "-"}
                        </p>
                        <p className="text-sm">
                          Delivery: {headerForm.watch("requestedDeliveryDate") || "Not specified"}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-1">Sales Area</h4>
                        <p className="text-sm">
                          {salesOrgs.find(o => o.code === headerForm.watch("salesOrg"))?.name || "-"}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {DISTRIBUTION_CHANNELS.find(d => d.code === headerForm.watch("distributionChannel"))?.name || "-"} / 
                          {DIVISIONS.find(d => d.code === headerForm.watch("division"))?.name || "-"}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-1">Additional Info</h4>
                        <p className="text-sm">
                          Currency: {headerForm.watch("currency") || "USD"}
                        </p>
                        <p className="text-sm">
                          Reference: {headerForm.watch("reference") || "None"}
                        </p>
                      </div>
                    </div>
                    {headerForm.watch("notes") && (
                      <div className="mt-4">
                        <h4 className="text-sm font-medium mb-1">Notes</h4>
                        <p className="text-sm">{headerForm.watch("notes")}</p>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">Items ({currentItems.length})</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Product</TableHead>
                          <TableHead>Quantity</TableHead>
                          <TableHead>Price</TableHead>
                          <TableHead>Discount</TableHead>
                          <TableHead>Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {currentItems.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center h-24">
                              No items added.
                            </TableCell>
                          </TableRow>
                        ) : (
                          currentItems.map((item, index) => {
                            // Find product details
                            const product = products.find(p => p.code === item.productCode);
                            // Calculate total
                            const total = (item.quantity || 0) * (item.price || 0) * (1 - (item.discount || 0) / 100);
                            
                            return (
                              <TableRow key={index}>
                                <TableCell>
                                  <div>
                                    <p className="font-medium">{product?.name || item.productCode}</p>
                                    <p className="text-xs text-muted-foreground">{item.productCode}</p>
                                  </div>
                                </TableCell>
                                <TableCell>{item.quantity} {product?.unit}</TableCell>
                                <TableCell>
                                  {item.price.toLocaleString(undefined, {
                                    style: 'currency',
                                    currency: headerForm.watch("currency") || "USD"
                                  })}
                                </TableCell>
                                <TableCell>{item.discount}%</TableCell>
                                <TableCell>
                                  {total.toLocaleString(undefined, {
                                    style: 'currency',
                                    currency: headerForm.watch("currency") || "USD"
                                  })}
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                  
                  {currentItems.length > 0 && (
                    <div className="flex justify-end mt-4">
                      <div className="bg-muted p-4 rounded-md w-48">
                        <div className="flex justify-between mb-2">
                          <span className="font-medium">Total:</span>
                          <span>
                            {calculateTotal().toLocaleString(undefined, {
                              style: 'currency',
                              currency: headerForm.watch("currency") || "USD"
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <DialogFooter>
            <div className="flex w-full justify-between">
              <div>
                {activeTab !== "header" && (
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => {
                      if (activeTab === "items") setActiveTab("header");
                      if (activeTab === "review") setActiveTab("items");
                    }}
                  >
                    Back
                  </Button>
                )}
              </div>
              <div className="flex gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowDialog(false);
                    setActiveTab("header");
                  }}
                >
                  Cancel
                </Button>
                {activeTab !== "review" ? (
                  <Button 
                    type="button"
                    onClick={handleNextStep}
                  >
                    Next
                  </Button>
                ) : (
                  <Button 
                    type="button"
                    onClick={() => handleCreateSalesOrder(headerForm.getValues())}
                  >
                    Create Sales Order
                  </Button>
                )}
              </div>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Item Dialog */}
      <Dialog open={showItemDialog} onOpenChange={setShowItemDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingItemIndex !== null ? "Edit Item" : "Add Item"}
            </DialogTitle>
            <DialogDescription>
              {editingItemIndex !== null 
                ? "Update the item details" 
                : "Add a product to the sales order"}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={itemForm.handleSubmit(handleAddItem)} className="space-y-4">
            <FormField
              control={itemForm.control}
              name="productCode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Product</FormLabel>
                  <Select
                    onValueChange={handleProductChange}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select product" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {products.map((product) => (
                        <SelectItem key={product.id} value={product.code}>
                          {product.code} - {product.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={itemForm.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0.01" 
                        step="0.01"
                        {...field}
                        onChange={(e) => {
                          field.onChange(parseFloat(e.target.value) || 0);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={itemForm.control}
                name="price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        step="0.01"
                        {...field}
                        onChange={(e) => {
                          field.onChange(parseFloat(e.target.value) || 0);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={itemForm.control}
                name="discount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Discount %</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        max="100" 
                        step="0.01"
                        {...field}
                        onChange={(e) => {
                          field.onChange(parseFloat(e.target.value) || 0);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={itemForm.control}
                name="requestedDeliveryDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Delivery Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="bg-muted p-3 rounded-md">
              <div className="flex justify-between">
                <span className="font-medium">Total:</span>
                <span>
                  {calculateItemTotal().toLocaleString(undefined, {
                    style: 'currency',
                    currency: headerForm.watch("currency") || "USD"
                  })}
                </span>
              </div>
            </div>

            <FormField
              control={itemForm.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <textarea
                      className="flex min-h-[60px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Any notes for this item"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowItemDialog(false)}>
                Cancel
              </Button>
              <Button type="submit">
                {editingItemIndex !== null ? "Update Item" : "Add Item"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}