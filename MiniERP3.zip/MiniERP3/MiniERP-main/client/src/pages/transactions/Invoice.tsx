import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  CreditCard, 
  FileText, 
  DollarSign,
  Printer,
  Send,
  CheckCircle,
  CalendarDays,
  Filter
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

// Invoice Status Type
type InvoiceStatus = 
  | "Draft" 
  | "Issued" 
  | "Sent" 
  | "Partly Paid" 
  | "Paid" 
  | "Overdue" 
  | "Cancelled";

// Invoice Type
type Invoice = {
  id: number;
  invoiceNumber: string;
  salesOrderNumber: string | null;
  customerCode: string;
  customerName: string;
  billingAddress: string;
  issueDate: string;
  dueDate: string;
  status: InvoiceStatus;
  totalAmount: number;
  paidAmount: number;
  currency: string;
  paymentTerms: string;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
};

// Invoice Item Type
type InvoiceItem = {
  id: number;
  invoiceId: number;
  lineNumber: number;
  description: string;
  quantity: number;
  unit: string;
  price: number;
  discount: number;
  taxRate: number;
  totalPrice: number;
};

// Customer Type
type Customer = {
  id: number;
  code: string;
  name: string;
  address: string;
  city: string;
  country: string;
  email: string;
  phone: string;
};

// Sales Order Reference Type
type SalesOrderReference = {
  id: number;
  orderNumber: string;
  customerCode: string;
  customerName: string;
  orderDate: string;
  totalAmount: number;
  status: string;
};

// Payment Terms
const PAYMENT_TERMS = [
  { code: "NET30", name: "Net 30 days" },
  { code: "NET15", name: "Net 15 days" },
  { code: "NET7", name: "Net 7 days" },
  { code: "COD", name: "Cash on Delivery" },
  { code: "EOM", name: "End of Month" },
  { code: "CIA", name: "Cash in Advance" }
];

// Invoice Header Schema
const invoiceHeaderSchema = z.object({
  customerCode: z.string().min(1, "Customer is required"),
  salesOrderNumber: z.string().optional(),
  issueDate: z.string().min(1, "Issue date is required"),
  dueDate: z.string().min(1, "Due date is required"),
  paymentTerms: z.string().min(1, "Payment terms are required"),
  billingAddress: z.string().min(1, "Billing address is required"),
  currency: z.string().min(1, "Currency is required"),
  notes: z.string().optional(),
});

// Invoice Item Schema
const invoiceItemSchema = z.object({
  description: z.string().min(1, "Description is required"),
  quantity: z.coerce.number().min(0.01, "Quantity must be greater than 0"),
  unit: z.string().min(1, "Unit is required"),
  price: z.coerce.number().min(0, "Price cannot be negative"),
  discount: z.coerce.number().min(0, "Discount cannot be negative").max(100, "Discount cannot exceed 100%"),
  taxRate: z.coerce.number().min(0, "Tax rate cannot be negative"),
});

// Invoice Page Component
export default function InvoicePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [showItemDialog, setShowItemDialog] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [filteredInvoices, setFilteredInvoices] = useState<Invoice[]>([]);
  const [activeTab, setActiveTab] = useState("header");
  const [editingItemIndex, setEditingItemIndex] = useState<number | null>(null);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isLoading, setIsLoading] = useState(true);
  const [isItemsLoading, setIsItemsLoading] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Forms
  const headerForm = useForm<z.infer<typeof invoiceHeaderSchema>>({
    resolver: zodResolver(invoiceHeaderSchema),
    defaultValues: {
      customerCode: "",
      salesOrderNumber: "",
      issueDate: new Date().toISOString().slice(0, 10),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10), // 30 days from now
      paymentTerms: "NET30",
      billingAddress: "",
      currency: "USD",
      notes: "",
    },
  });

  const itemForm = useForm<z.infer<typeof invoiceItemSchema>>({
    resolver: zodResolver(invoiceItemSchema),
    defaultValues: {
      description: "",
      quantity: 1,
      unit: "PC",
      price: 0,
      discount: 0,
      taxRate: 0,
    },
  });

  // Customers and Sales Orders data
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [salesOrders, setSalesOrders] = useState<SalesOrderReference[]>([]);
  
  // Current working invoice items
  const [currentItems, setCurrentItems] = useState<z.infer<typeof invoiceItemSchema>[]>([]);

  // Handle customer selection change
  const handleCustomerChange = (value: string) => {
    headerForm.setValue("customerCode", value);
    const selectedCustomer = customers.find(c => c.code === value);
    if (selectedCustomer) {
      headerForm.setValue("billingAddress", `${selectedCustomer.address}, ${selectedCustomer.city}, ${selectedCustomer.country}`);
    }
  };

  // Handle sales order selection
  const handleSalesOrderChange = (value: string) => {
    headerForm.setValue("salesOrderNumber", value);
    
    // Find the selected sales order
    const selectedOrder = salesOrders.find(o => o.orderNumber === value);
    if (selectedOrder) {
      // Auto-populate customer and other fields
      headerForm.setValue("customerCode", selectedOrder.customerCode);
      const selectedCustomer = customers.find(c => c.code === selectedOrder.customerCode);
      if (selectedCustomer) {
        headerForm.setValue("billingAddress", `${selectedCustomer.address}, ${selectedCustomer.city}, ${selectedCustomer.country}`);
      }
      
      // Fetch order items and convert to invoice items
      fetchSalesOrderItems(selectedOrder.id);
    }
  };

  // Function to fetch sales order items and convert to invoice items
  const fetchSalesOrderItems = async (orderId: number) => {
    try {
      // In real app, this would be an API call
      // For now, let's use mock data
      const mockOrderItems = [
        {
          id: 1,
          salesOrderId: 1,
          lineNumber: 1,
          productCode: "P001",
          productName: "Premium Widget",
          quantity: 25,
          unit: "PC",
          price: 125.50,
          discount: 5,
          totalPrice: 2980.63,
        },
        {
          id: 2,
          salesOrderId: 1,
          lineNumber: 2,
          productCode: "P002",
          productName: "Standard Gadget",
          quantity: 30,
          unit: "PC",
          price: 75.25,
          discount: 0,
          totalPrice: 2257.50,
        }
      ];
      
      // Convert sales order items to invoice items
      const invoiceItems = mockOrderItems.map(item => ({
        description: `${item.productCode} - ${item.productName}`,
        quantity: item.quantity,
        unit: item.unit,
        price: item.price,
        discount: item.discount,
        taxRate: 0, // Default tax rate
      }));
      
      setCurrentItems(invoiceItems);
      
    } catch (error) {
      console.error("Error fetching sales order items:", error);
      toast({
        title: "Error",
        description: "Failed to load sales order items",
        variant: "destructive",
      });
    }
  };

  // Calculate item total price
  const calculateItemTotal = (item: z.infer<typeof invoiceItemSchema>) => {
    const subtotal = item.quantity * item.price * (1 - item.discount / 100);
    const tax = subtotal * (item.taxRate / 100);
    return subtotal + tax;
  };

  // Fetch invoices
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        // This would be a real API call in production
        // For now, let's use mock data
        const mockInvoices: Invoice[] = [
          {
            id: 1,
            invoiceNumber: "INV-2025-001",
            salesOrderNumber: "SO10001",
            customerCode: "CUST001",
            customerName: "ABC Company",
            billingAddress: "123 Main St, New York, USA",
            issueDate: "2025-05-16",
            dueDate: "2025-06-15",
            status: "Issued",
            totalAmount: 5240.50,
            paidAmount: 0,
            currency: "USD",
            paymentTerms: "NET30",
            notes: null,
            createdAt: "2025-05-16T10:30:00Z",
            updatedAt: "2025-05-16T10:30:00Z"
          },
          {
            id: 2,
            invoiceNumber: "INV-2025-002",
            salesOrderNumber: "SO10002",
            customerCode: "CUST002",
            customerName: "XYZ Corporation",
            billingAddress: "456 Business Ave, Los Angeles, USA",
            issueDate: "2025-05-17",
            dueDate: "2025-06-01",
            status: "Partly Paid",
            totalAmount: 3780.25,
            paidAmount: 2000.00,
            currency: "USD",
            paymentTerms: "NET15",
            notes: "Partial payment received on May 20, 2025",
            createdAt: "2025-05-17T11:45:00Z",
            updatedAt: "2025-05-20T14:20:00Z"
          },
          {
            id: 3,
            invoiceNumber: "INV-2025-003",
            salesOrderNumber: "SO10003",
            customerCode: "CUST003",
            customerName: "Global Enterprises",
            billingAddress: "789 International Blvd, Berlin, Germany",
            issueDate: "2025-05-18",
            dueDate: "2025-06-17",
            status: "Paid",
            totalAmount: 1250.75,
            paidAmount: 1250.75,
            currency: "EUR",
            paymentTerms: "NET30",
            notes: "Payment received in full on May 25, 2025",
            createdAt: "2025-05-18T09:15:00Z",
            updatedAt: "2025-05-25T10:45:00Z"
          }
        ];
        
        setInvoices(mockInvoices);
        setFilteredInvoices(mockInvoices);

        // Mock customers data
        const mockCustomers: Customer[] = [
          {
            id: 1,
            code: "CUST001",
            name: "ABC Company",
            address: "123 Main St",
            city: "New York",
            country: "USA",
            email: "contact@abccompany.com",
            phone: "+1-555-123-4567"
          },
          {
            id: 2,
            code: "CUST002",
            name: "XYZ Corporation",
            address: "456 Business Ave",
            city: "Los Angeles",
            country: "USA",
            email: "info@xyzcorp.com",
            phone: "+1-555-987-6543"
          },
          {
            id: 3,
            code: "CUST003",
            name: "Global Enterprises",
            address: "789 International Blvd",
            city: "Berlin",
            country: "Germany",
            email: "contact@globalent.com",
            phone: "+49-30-12345678"
          }
        ];
        setCustomers(mockCustomers);

        // Mock sales orders data
        const mockSalesOrders: SalesOrderReference[] = [
          {
            id: 1,
            orderNumber: "SO10001",
            customerCode: "CUST001",
            customerName: "ABC Company",
            orderDate: "2025-05-15",
            totalAmount: 5240.50,
            status: "Delivered"
          },
          {
            id: 2,
            orderNumber: "SO10002",
            customerCode: "CUST002",
            customerName: "XYZ Corporation",
            orderDate: "2025-05-16",
            totalAmount: 3780.25,
            status: "Delivered"
          },
          {
            id: 3,
            orderNumber: "SO10003",
            customerCode: "CUST003",
            customerName: "Global Enterprises",
            orderDate: "2025-05-17",
            totalAmount: 1250.75,
            status: "Delivered"
          }
        ];
        setSalesOrders(mockSalesOrders);

        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching invoices:", error);
        toast({
          title: "Error",
          description: "Failed to load invoices",
          variant: "destructive",
        });
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [toast]);

  // Filter invoices based on search query and status filter
  useEffect(() => {
    let filtered = invoices;

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter(invoice => invoice.status === statusFilter);
    }

    // Apply search filter
    if (searchQuery.trim() !== "") {
      filtered = filtered.filter(
        invoice =>
          invoice.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
          invoice.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          invoice.customerCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (invoice.salesOrderNumber && invoice.salesOrderNumber.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    setFilteredInvoices(filtered);
  }, [searchQuery, statusFilter, invoices]);

  // Fetch invoice items when an invoice is selected
  useEffect(() => {
    const fetchInvoiceItems = async () => {
      if (!selectedInvoiceId) return;

      try {
        setIsItemsLoading(true);
        // This would be a real API call in production
        // For now, let's use mock data
        const mockItems: InvoiceItem[] = [
          {
            id: 1,
            invoiceId: 1,
            lineNumber: 1,
            description: "P001 - Premium Widget",
            quantity: 25,
            unit: "PC",
            price: 125.50,
            discount: 5,
            taxRate: 10,
            totalPrice: 3278.69,
          },
          {
            id: 2,
            invoiceId: 1,
            lineNumber: 2,
            description: "P002 - Standard Gadget",
            quantity: 30,
            unit: "PC",
            price: 75.25,
            discount: 0,
            taxRate: 10,
            totalPrice: 2483.25,
          }
        ];
        
        setInvoiceItems(mockItems);
        setIsItemsLoading(false);
      } catch (error) {
        console.error("Error fetching invoice items:", error);
        toast({
          title: "Error",
          description: "Failed to load invoice items",
          variant: "destructive",
        });
        setIsItemsLoading(false);
      }
    };

    if (selectedInvoiceId) {
      fetchInvoiceItems();
    }
  }, [selectedInvoiceId, toast]);

  // Handle invoice creation
  const handleCreateInvoice = async (data: z.infer<typeof invoiceHeaderSchema>) => {
    // Validate that there are items
    if (currentItems.length === 0) {
      toast({
        title: "Error",
        description: "Invoice must have at least one item",
        variant: "destructive",
      });
      return;
    }

    // Create invoice with header and items
    try {
      // In a real application, this would be an API call
      console.log("Creating invoice:", {
        header: data,
        items: currentItems
      });

      toast({
        title: "Success",
        description: "Invoice created successfully",
      });

      // Reset form and current items
      headerForm.reset();
      setCurrentItems([]);
      setShowDialog(false);
    } catch (error) {
      console.error("Error creating invoice:", error);
      toast({
        title: "Error",
        description: "Failed to create invoice",
        variant: "destructive",
      });
    }
  };

  // Handle adding/editing an item to the current invoice
  const handleAddItem = (data: z.infer<typeof invoiceItemSchema>) => {
    try {
      // Calculate total price with tax
      const total = calculateItemTotal(data);
      
      if (editingItemIndex !== null) {
        // Edit existing item
        const updatedItems = [...currentItems];
        updatedItems[editingItemIndex] = data;
        setCurrentItems(updatedItems);
        setEditingItemIndex(null);
      } else {
        // Add new item
        setCurrentItems([...currentItems, data]);
      }
      
      // Reset form and close dialog
      itemForm.reset({
        description: "",
        quantity: 1,
        unit: "PC",
        price: 0,
        discount: 0,
        taxRate: 0,
      });
      setShowItemDialog(false);
      
      toast({
        title: "Success",
        description: editingItemIndex !== null 
          ? "Item updated successfully" 
          : "Item added successfully",
      });
    } catch (error) {
      console.error("Error adding/editing item:", error);
      toast({
        title: "Error",
        description: "Failed to add/edit item",
        variant: "destructive",
      });
    }
  };

  // Handle editing an existing item
  const handleEditItem = (index: number) => {
    const item = currentItems[index];
    itemForm.reset(item);
    setEditingItemIndex(index);
    setShowItemDialog(true);
  };

  // Handle deleting an item
  const handleDeleteItem = (index: number) => {
    const updatedItems = [...currentItems];
    updatedItems.splice(index, 1);
    setCurrentItems(updatedItems);
    
    toast({
      title: "Success",
      description: "Item removed successfully",
    });
  };

  // Calculate subtotal for current items (before tax)
  const calculateSubtotal = () => {
    return currentItems.reduce((sum, item) => {
      const quantity = item.quantity || 0;
      const price = item.price || 0;
      const discount = item.discount || 0;
      return sum + (quantity * price * (1 - discount / 100));
    }, 0);
  };

  // Calculate tax total for current items
  const calculateTaxTotal = () => {
    return currentItems.reduce((sum, item) => {
      const quantity = item.quantity || 0;
      const price = item.price || 0;
      const discount = item.discount || 0;
      const taxRate = item.taxRate || 0;
      const subtotal = quantity * price * (1 - discount / 100);
      return sum + (subtotal * taxRate / 100);
    }, 0);
  };

  // Calculate total for current items (including tax)
  const calculateTotal = () => {
    return calculateSubtotal() + calculateTaxTotal();
  };

  // Handle status changes for an invoice
  const handleStatusChange = async (invoiceId: number, newStatus: InvoiceStatus) => {
    try {
      // In a real application, this would be an API call
      console.log("Changing status for invoice", invoiceId, "to", newStatus);
      
      // Update the local state
      const updatedInvoices = invoices.map(invoice => 
        invoice.id === invoiceId ? { ...invoice, status: newStatus } : invoice
      );
      setInvoices(updatedInvoices);
      setFilteredInvoices(updatedInvoices);
      
      toast({
        title: "Success",
        description: `Invoice status updated to ${newStatus}`,
      });
    } catch (error) {
      console.error("Error updating invoice status:", error);
      toast({
        title: "Error",
        description: "Failed to update invoice status",
        variant: "destructive",
      });
    }
  };

  // Handle payment recording
  const handleRecordPayment = async (invoiceId: number, amount: number) => {
    try {
      // Find the invoice
      const invoice = invoices.find(inv => inv.id === invoiceId);
      if (!invoice) {
        throw new Error("Invoice not found");
      }
      
      // Validate payment amount
      if (amount <= 0) {
        throw new Error("Payment amount must be greater than zero");
      }
      
      if (amount > (invoice.totalAmount - invoice.paidAmount)) {
        throw new Error("Payment amount cannot exceed the remaining balance");
      }
      
      // In a real application, this would be an API call
      console.log("Recording payment for invoice", invoiceId, "amount:", amount);
      
      // Update the invoice in local state
      const newPaidAmount = invoice.paidAmount + amount;
      let newStatus: InvoiceStatus = invoice.status;
      
      if (newPaidAmount >= invoice.totalAmount) {
        newStatus = "Paid";
      } else if (newPaidAmount > 0) {
        newStatus = "Partly Paid";
      }
      
      const updatedInvoices = invoices.map(inv => 
        inv.id === invoiceId 
          ? { 
              ...inv, 
              paidAmount: newPaidAmount, 
              status: newStatus,
              notes: inv.notes 
                ? `${inv.notes}; Payment of ${amount.toLocaleString(undefined, { style: 'currency', currency: inv.currency })} received on ${new Date().toLocaleDateString()}`
                : `Payment of ${amount.toLocaleString(undefined, { style: 'currency', currency: inv.currency })} received on ${new Date().toLocaleDateString()}`
            } 
          : inv
      );
      
      setInvoices(updatedInvoices);
      setFilteredInvoices(updatedInvoices);
      setPaymentAmount(0);
      setShowPaymentDialog(false);
      
      toast({
        title: "Success",
        description: `Payment of ${amount.toLocaleString(undefined, { style: 'currency', currency: invoice.currency })} recorded`,
      });
    } catch (error) {
      console.error("Error recording payment:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to record payment",
        variant: "destructive",
      });
    }
  };

  // Function to get statusColor for badges
  const getStatusColor = (status: InvoiceStatus) => {
    switch (status) {
      case "Draft": return "gray";
      case "Issued": return "blue";
      case "Sent": return "purple";
      case "Partly Paid": return "orange";
      case "Paid": return "green";
      case "Overdue": return "red";
      case "Cancelled": return "gray";
      default: return "gray";
    }
  };

  // Generate a status badge with the correct color
  const StatusBadge = ({ status }: { status: InvoiceStatus }) => {
    const colorMap: Record<string, string> = {
      "gray": "bg-gray-100 text-gray-800 hover:bg-gray-200",
      "blue": "bg-blue-100 text-blue-800 hover:bg-blue-200",
      "purple": "bg-purple-100 text-purple-800 hover:bg-purple-200",
      "orange": "bg-orange-100 text-orange-800 hover:bg-orange-200",
      "green": "bg-green-100 text-green-800 hover:bg-green-200",
      "red": "bg-red-100 text-red-800 hover:bg-red-200",
    };
    
    const color = getStatusColor(status);
    const className = colorMap[color] || colorMap.gray;
    
    return <Badge className={className}>{status}</Badge>;
  };

  // Process steps for creating an invoice
  const handleNextStep = async () => {
    if (activeTab === "header") {
      const isValid = await headerForm.trigger();
      if (isValid) {
        setActiveTab("items");
      }
    } else if (activeTab === "items") {
      if (currentItems.length === 0) {
        toast({
          title: "Error",
          description: "You must add at least one item",
          variant: "destructive",
        });
        return;
      }
      setActiveTab("review");
    }
  };

  // Get the progress percentage
  const getProgressPercentage = () => {
    if (activeTab === "header") return 33;
    if (activeTab === "items") return 66;
    return 100;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Invoices</h1>
          <p className="text-sm text-muted-foreground">
            Manage customer invoices and payments
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => {
            setEditingInvoice(null);
            setCurrentItems([]);
            headerForm.reset();
            setActiveTab("header");
            setShowDialog(true);
          }}>
            <Plus className="mr-2 h-4 w-4" />
            New Invoice
          </Button>
        </div>
      </div>

      {/* Search and Filter Section */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by invoice number, customer..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select
          value={statusFilter}
          onValueChange={setStatusFilter}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="Draft">Draft</SelectItem>
            <SelectItem value="Issued">Issued</SelectItem>
            <SelectItem value="Sent">Sent</SelectItem>
            <SelectItem value="Partly Paid">Partly Paid</SelectItem>
            <SelectItem value="Paid">Paid</SelectItem>
            <SelectItem value="Overdue">Overdue</SelectItem>
            <SelectItem value="Cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Invoices Table */}
      <Card>
        <CardHeader>
          <CardTitle>Invoices</CardTitle>
          <CardDescription>
            Manage and track all customer invoices
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice Number</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead className="hidden md:table-cell">Issue Date</TableHead>
                  <TableHead className="hidden md:table-cell">Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden lg:table-cell">Amount</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center h-24">
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : filteredInvoices.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center h-24">
                      No invoices found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInvoices.map((invoice) => (
                    <TableRow key={invoice.id} className={selectedInvoiceId === invoice.id ? "bg-muted/50" : ""}>
                      <TableCell className="font-medium">
                        <div className="cursor-pointer" onClick={() => setSelectedInvoiceId(invoice.id)}>
                          {invoice.invoiceNumber}
                        </div>
                      </TableCell>
                      <TableCell>{invoice.customerName}</TableCell>
                      <TableCell className="hidden md:table-cell">{new Date(invoice.issueDate).toLocaleDateString()}</TableCell>
                      <TableCell className="hidden md:table-cell">{new Date(invoice.dueDate).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <StatusBadge status={invoice.status} />
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        {invoice.totalAmount.toLocaleString(undefined, {
                          style: 'currency',
                          currency: invoice.currency,
                          minimumFractionDigits: 2
                        })}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end items-center gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              // Implement view/edit functionality
                              console.log("Edit invoice", invoice.id);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              // Implement print functionality
                              console.log("Print invoice", invoice.id);
                            }}
                          >
                            <Printer className="h-4 w-4" />
                            <span className="sr-only">Print</span>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            disabled={invoice.status === "Paid" || invoice.status === "Cancelled"}
                            onClick={() => {
                              setSelectedInvoiceId(invoice.id);
                              setPaymentAmount(invoice.totalAmount - invoice.paidAmount);
                              setShowPaymentDialog(true);
                            }}
                          >
                            <DollarSign className="h-4 w-4" />
                            <span className="sr-only">Record Payment</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Selected Invoice Details */}
      {selectedInvoiceId && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>
                  Invoice: {filteredInvoices.find(i => i.id === selectedInvoiceId)?.invoiceNumber}
                </CardTitle>
                <CardDescription>
                  Customer: {filteredInvoices.find(i => i.id === selectedInvoiceId)?.customerName}
                </CardDescription>
              </div>
              <StatusBadge status={filteredInvoices.find(i => i.id === selectedInvoiceId)?.status || "Draft"} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Invoice details summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Invoice Information</h3>
                  <div className="mt-1 text-sm">
                    <p><span className="font-medium">Invoice Date:</span> {new Date(filteredInvoices.find(i => i.id === selectedInvoiceId)?.issueDate || "").toLocaleDateString()}</p>
                    <p><span className="font-medium">Due Date:</span> {new Date(filteredInvoices.find(i => i.id === selectedInvoiceId)?.dueDate || "").toLocaleDateString()}</p>
                    <p><span className="font-medium">Payment Terms:</span> {filteredInvoices.find(i => i.id === selectedInvoiceId)?.paymentTerms}</p>
                    <p><span className="font-medium">Sales Order:</span> {filteredInvoices.find(i => i.id === selectedInvoiceId)?.salesOrderNumber || "N/A"}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Customer Information</h3>
                  <div className="mt-1 text-sm">
                    <p><span className="font-medium">Customer Code:</span> {filteredInvoices.find(i => i.id === selectedInvoiceId)?.customerCode}</p>
                    <p><span className="font-medium">Customer Name:</span> {filteredInvoices.find(i => i.id === selectedInvoiceId)?.customerName}</p>
                    <p><span className="font-medium">Billing Address:</span> {filteredInvoices.find(i => i.id === selectedInvoiceId)?.billingAddress}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Financial Information</h3>
                  <div className="mt-1 text-sm">
                    <p>
                      <span className="font-medium">Total Amount:</span> {
                        filteredInvoices.find(i => i.id === selectedInvoiceId)?.totalAmount.toLocaleString(undefined, { 
                          style: 'currency', 
                          currency: filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency || "USD" 
                        })
                      }
                    </p>
                    <p>
                      <span className="font-medium">Paid Amount:</span> {
                        filteredInvoices.find(i => i.id === selectedInvoiceId)?.paidAmount.toLocaleString(undefined, { 
                          style: 'currency', 
                          currency: filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency || "USD" 
                        })
                      }
                    </p>
                    <p>
                      <span className="font-medium">Balance Due:</span> {
                        ((filteredInvoices.find(i => i.id === selectedInvoiceId)?.totalAmount || 0) - 
                        (filteredInvoices.find(i => i.id === selectedInvoiceId)?.paidAmount || 0)).toLocaleString(undefined, { 
                          style: 'currency', 
                          currency: filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency || "USD" 
                        })
                      }
                    </p>
                    <p><span className="font-medium">Currency:</span> {filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency}</p>
                  </div>
                </div>
              </div>
              
              {/* Invoice notes */}
              {filteredInvoices.find(i => i.id === selectedInvoiceId)?.notes && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Notes</h3>
                  <p className="text-sm">{filteredInvoices.find(i => i.id === selectedInvoiceId)?.notes}</p>
                </div>
              )}

              {/* Invoice items table */}
              <div>
                <h3 className="text-sm font-medium mb-2">Invoice Items</h3>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Line</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Unit</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Discount</TableHead>
                        <TableHead>Tax Rate</TableHead>
                        <TableHead>Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isItemsLoading ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center h-24">
                            Loading items...
                          </TableCell>
                        </TableRow>
                      ) : invoiceItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center h-24">
                            No items found for this invoice
                          </TableCell>
                        </TableRow>
                      ) : (
                        invoiceItems.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>{item.lineNumber}</TableCell>
                            <TableCell>{item.description}</TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>{item.unit}</TableCell>
                            <TableCell>
                              {item.price.toLocaleString(undefined, {
                                style: 'currency',
                                currency: filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency || "USD"
                              })}
                            </TableCell>
                            <TableCell>{item.discount}%</TableCell>
                            <TableCell>{item.taxRate}%</TableCell>
                            <TableCell>
                              {item.totalPrice.toLocaleString(undefined, {
                                style: 'currency',
                                currency: filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency || "USD"
                              })}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-wrap gap-2 justify-end">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    // Implement print functionality
                    console.log("Print invoice", selectedInvoiceId);
                  }}
                >
                  <Printer className="mr-2 h-4 w-4" />
                  Print
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => {
                    // Implement email functionality
                    console.log("Email invoice", selectedInvoiceId);
                    // Update status to Sent
                    const invoice = filteredInvoices.find(i => i.id === selectedInvoiceId);
                    if (invoice && invoice.status === "Issued") {
                      handleStatusChange(selectedInvoiceId, "Sent");
                    }
                    toast({
                      title: "Success",
                      description: "Invoice sent to customer",
                    });
                  }}
                >
                  <Send className="mr-2 h-4 w-4" />
                  Send to Customer
                </Button>
                {filteredInvoices.find(i => i.id === selectedInvoiceId)?.status !== "Paid" && 
                 filteredInvoices.find(i => i.id === selectedInvoiceId)?.status !== "Cancelled" && (
                  <Button 
                    onClick={() => {
                      setPaymentAmount(
                        (filteredInvoices.find(i => i.id === selectedInvoiceId)?.totalAmount || 0) - 
                        (filteredInvoices.find(i => i.id === selectedInvoiceId)?.paidAmount || 0)
                      );
                      setShowPaymentDialog(true);
                    }}
                  >
                    <DollarSign className="mr-2 h-4 w-4" />
                    Record Payment
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create/Edit Invoice Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>
              {editingInvoice ? "Edit Invoice" : "Create New Invoice"}
            </DialogTitle>
            <DialogDescription>
              Fill in the invoice details and add items to create a new invoice.
            </DialogDescription>
          </DialogHeader>

          {/* Progress indicator */}
          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
            <div 
              className="bg-blue-600 h-2.5 rounded-full" 
              style={{ width: `${getProgressPercentage()}%` }}
            ></div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="header">Invoice Header</TabsTrigger>
              <TabsTrigger value="items">Invoice Items</TabsTrigger>
              <TabsTrigger value="review">Review & Create</TabsTrigger>
            </TabsList>
            
            {/* Header Tab */}
            <TabsContent value="header">
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={headerForm.control}
                    name="salesOrderNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sales Order Reference (Optional)</FormLabel>
                        <Select
                          onValueChange={handleSalesOrderChange}
                          value={field.value || ""}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select sales order" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">No Sales Order Reference</SelectItem>
                            {salesOrders
                              .filter(order => order.status === "Delivered")
                              .map((order) => (
                                <SelectItem key={order.id} value={order.orderNumber}>
                                  {order.orderNumber} - {order.customerName}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Auto-populate invoice from a delivered sales order
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="customerCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Customer</FormLabel>
                        <Select
                          onValueChange={handleCustomerChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select customer" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {customers.map((customer) => (
                              <SelectItem key={customer.id} value={customer.code}>
                                {customer.code} - {customer.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="billingAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Billing Address</FormLabel>
                        <FormControl>
                          <textarea
                            className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            placeholder="Enter billing address"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={headerForm.control}
                      name="issueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Issue Date</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={headerForm.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Due Date</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={headerForm.control}
                    name="paymentTerms"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Payment Terms</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select payment terms" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {PAYMENT_TERMS.map((term) => (
                              <SelectItem key={term.code} value={term.code}>
                                {term.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={headerForm.control}
                    name="currency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Currency</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select currency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="USD">USD - US Dollar</SelectItem>
                            <SelectItem value="EUR">EUR - Euro</SelectItem>
                            <SelectItem value="GBP">GBP - British Pound</SelectItem>
                            <SelectItem value="JPY">JPY - Japanese Yen</SelectItem>
                            <SelectItem value="CNY">CNY - Chinese Yuan</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={headerForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <textarea
                          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Any special instructions or notes for this invoice"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </form>
            </TabsContent>
            
            {/* Items Tab */}
            <TabsContent value="items">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Invoice Items</h3>
                  <Button
                    onClick={() => {
                      setEditingItemIndex(null);
                      itemForm.reset({
                        description: "",
                        quantity: 1,
                        unit: "PC",
                        price: 0,
                        discount: 0,
                        taxRate: 0,
                      });
                      setShowItemDialog(true);
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Item
                  </Button>
                </div>
                
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Description</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Unit</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Discount</TableHead>
                        <TableHead>Tax Rate</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currentItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center h-24">
                            No items added. Click "Add Item" to add items to this invoice.
                          </TableCell>
                        </TableRow>
                      ) : (
                        currentItems.map((item, index) => {
                          // Calculate total
                          const subtotal = item.quantity * item.price * (1 - item.discount / 100);
                          const tax = subtotal * (item.taxRate / 100);
                          const total = subtotal + tax;
                          
                          return (
                            <TableRow key={index}>
                              <TableCell>{item.description}</TableCell>
                              <TableCell>{item.quantity}</TableCell>
                              <TableCell>{item.unit}</TableCell>
                              <TableCell>
                                {item.price.toLocaleString(undefined, {
                                  style: 'currency',
                                  currency: headerForm.watch("currency") || "USD"
                                })}
                              </TableCell>
                              <TableCell>{item.discount}%</TableCell>
                              <TableCell>{item.taxRate}%</TableCell>
                              <TableCell>
                                {total.toLocaleString(undefined, {
                                  style: 'currency',
                                  currency: headerForm.watch("currency") || "USD"
                                })}
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleEditItem(index)}
                                  >
                                    <Edit className="h-4 w-4" />
                                    <span className="sr-only">Edit</span>
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDeleteItem(index)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                    <span className="sr-only">Delete</span>
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
                
                {currentItems.length > 0 && (
                  <div className="flex justify-end">
                    <div className="bg-muted p-4 rounded-md w-64">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Subtotal:</span>
                          <span>
                            {calculateSubtotal().toLocaleString(undefined, {
                              style: 'currency',
                              currency: headerForm.watch("currency") || "USD"
                            })}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Tax:</span>
                          <span>
                            {calculateTaxTotal().toLocaleString(undefined, {
                              style: 'currency',
                              currency: headerForm.watch("currency") || "USD"
                            })}
                          </span>
                        </div>
                        <Separator />
                        <div className="flex justify-between font-medium">
                          <span>Total:</span>
                          <span>
                            {calculateTotal().toLocaleString(undefined, {
                              style: 'currency',
                              currency: headerForm.watch("currency") || "USD"
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
            
            {/* Review Tab */}
            <TabsContent value="review">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Invoice Summary</h3>
                  <div className="bg-muted p-4 rounded-md">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium mb-1">Customer</h4>
                        <p className="text-sm">
                          {customers.find(c => c.code === headerForm.watch("customerCode"))?.name || "-"}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {headerForm.watch("customerCode")}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-1">Invoice Details</h4>
                        <p className="text-sm">
                          Issue Date: {headerForm.watch("issueDate") || "-"}
                        </p>
                        <p className="text-sm">
                          Due Date: {headerForm.watch("dueDate") || "-"}
                        </p>
                        <p className="text-sm">
                          Payment Terms: {PAYMENT_TERMS.find(t => t.code === headerForm.watch("paymentTerms"))?.name || "-"}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-1">Billing Address</h4>
                        <p className="text-sm whitespace-pre-line">
                          {headerForm.watch("billingAddress") || "-"}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-1">Additional Info</h4>
                        <p className="text-sm">
                          Currency: {headerForm.watch("currency") || "USD"}
                        </p>
                        <p className="text-sm">
                          Sales Order: {headerForm.watch("salesOrderNumber") || "None"}
                        </p>
                      </div>
                    </div>
                    {headerForm.watch("notes") && (
                      <div className="mt-4">
                        <h4 className="text-sm font-medium mb-1">Notes</h4>
                        <p className="text-sm">{headerForm.watch("notes")}</p>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">Items ({currentItems.length})</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Description</TableHead>
                          <TableHead>Quantity</TableHead>
                          <TableHead>Unit</TableHead>
                          <TableHead>Price</TableHead>
                          <TableHead>Discount</TableHead>
                          <TableHead>Tax Rate</TableHead>
                          <TableHead>Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {currentItems.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center h-24">
                              No items added.
                            </TableCell>
                          </TableRow>
                        ) : (
                          currentItems.map((item, index) => {
                            // Calculate total
                            const subtotal = item.quantity * item.price * (1 - item.discount / 100);
                            const tax = subtotal * (item.taxRate / 100);
                            const total = subtotal + tax;
                            
                            return (
                              <TableRow key={index}>
                                <TableCell>{item.description}</TableCell>
                                <TableCell>{item.quantity} {item.unit}</TableCell>
                                <TableCell>
                                  {item.price.toLocaleString(undefined, {
                                    style: 'currency',
                                    currency: headerForm.watch("currency") || "USD"
                                  })}
                                </TableCell>
                                <TableCell>{item.discount}%</TableCell>
                                <TableCell>{item.taxRate}%</TableCell>
                                <TableCell>
                                  {total.toLocaleString(undefined, {
                                    style: 'currency',
                                    currency: headerForm.watch("currency") || "USD"
                                  })}
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                  
                  {currentItems.length > 0 && (
                    <div className="flex justify-end mt-4">
                      <div className="bg-muted p-4 rounded-md w-64">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span>Subtotal:</span>
                            <span>
                              {calculateSubtotal().toLocaleString(undefined, {
                                style: 'currency',
                                currency: headerForm.watch("currency") || "USD"
                              })}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Tax:</span>
                            <span>
                              {calculateTaxTotal().toLocaleString(undefined, {
                                style: 'currency',
                                currency: headerForm.watch("currency") || "USD"
                              })}
                            </span>
                          </div>
                          <Separator />
                          <div className="flex justify-between font-medium">
                            <span>Total:</span>
                            <span>
                              {calculateTotal().toLocaleString(undefined, {
                                style: 'currency',
                                currency: headerForm.watch("currency") || "USD"
                              })}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <DialogFooter>
            <div className="flex w-full justify-between">
              <div>
                {activeTab !== "header" && (
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => {
                      if (activeTab === "items") setActiveTab("header");
                      if (activeTab === "review") setActiveTab("items");
                    }}
                  >
                    Back
                  </Button>
                )}
              </div>
              <div className="flex gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowDialog(false);
                    setActiveTab("header");
                  }}
                >
                  Cancel
                </Button>
                {activeTab !== "review" ? (
                  <Button 
                    type="button"
                    onClick={handleNextStep}
                  >
                    Next
                  </Button>
                ) : (
                  <Button 
                    type="button"
                    onClick={() => handleCreateInvoice(headerForm.getValues())}
                  >
                    Create Invoice
                  </Button>
                )}
              </div>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Item Dialog */}
      <Dialog open={showItemDialog} onOpenChange={setShowItemDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingItemIndex !== null ? "Edit Item" : "Add Item"}
            </DialogTitle>
            <DialogDescription>
              {editingItemIndex !== null 
                ? "Update the item details" 
                : "Add an item to the invoice"}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={itemForm.handleSubmit(handleAddItem)} className="space-y-4">
            <FormField
              control={itemForm.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Item description" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={itemForm.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0.01" 
                        step="0.01"
                        {...field}
                        onChange={(e) => {
                          field.onChange(parseFloat(e.target.value) || 0);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={itemForm.control}
                name="unit"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select unit" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="PC">PC - Piece</SelectItem>
                        <SelectItem value="HR">HR - Hour</SelectItem>
                        <SelectItem value="KG">KG - Kilogram</SelectItem>
                        <SelectItem value="M">M - Meter</SelectItem>
                        <SelectItem value="SET">SET - Set</SelectItem>
                        <SelectItem value="BOX">BOX - Box</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={itemForm.control}
                name="price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit Price</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        step="0.01"
                        {...field}
                        onChange={(e) => {
                          field.onChange(parseFloat(e.target.value) || 0);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={itemForm.control}
                name="discount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Discount %</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        max="100" 
                        step="0.01"
                        {...field}
                        onChange={(e) => {
                          field.onChange(parseFloat(e.target.value) || 0);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={itemForm.control}
              name="taxRate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tax Rate %</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(parseFloat(value))}
                    value={field.value.toString()}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select tax rate" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="0">0% - No Tax</SelectItem>
                      <SelectItem value="5">5% - Reduced Rate</SelectItem>
                      <SelectItem value="10">10% - Standard Rate</SelectItem>
                      <SelectItem value="15">15% - Higher Rate</SelectItem>
                      <SelectItem value="20">20% - Premium Rate</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="bg-muted p-3 rounded-md">
              <div className="flex justify-between">
                <span className="font-medium">Subtotal:</span>
                <span>
                  {((itemForm.watch("quantity") || 0) * 
                   (itemForm.watch("price") || 0) * 
                   (1 - (itemForm.watch("discount") || 0) / 100)).toLocaleString(undefined, {
                    style: 'currency',
                    currency: headerForm.watch("currency") || "USD"
                  })}
                </span>
              </div>
              <div className="flex justify-between mt-1">
                <span className="font-medium">Tax:</span>
                <span>
                  {((itemForm.watch("quantity") || 0) * 
                   (itemForm.watch("price") || 0) * 
                   (1 - (itemForm.watch("discount") || 0) / 100) *
                   (itemForm.watch("taxRate") || 0) / 100).toLocaleString(undefined, {
                    style: 'currency',
                    currency: headerForm.watch("currency") || "USD"
                  })}
                </span>
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-medium">
                <span>Total:</span>
                <span>
                  {((itemForm.watch("quantity") || 0) * 
                   (itemForm.watch("price") || 0) * 
                   (1 - (itemForm.watch("discount") || 0) / 100) *
                   (1 + (itemForm.watch("taxRate") || 0) / 100)).toLocaleString(undefined, {
                    style: 'currency',
                    currency: headerForm.watch("currency") || "USD"
                  })}
                </span>
              </div>
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowItemDialog(false)}>
                Cancel
              </Button>
              <Button type="submit">
                {editingItemIndex !== null ? "Update Item" : "Add Item"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Record Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Record Payment</DialogTitle>
            <DialogDescription>
              Record a payment for invoice {filteredInvoices.find(i => i.id === selectedInvoiceId)?.invoiceNumber}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="font-medium">Total Amount:</span>
                <span>
                  {filteredInvoices.find(i => i.id === selectedInvoiceId)?.totalAmount.toLocaleString(undefined, { 
                    style: 'currency', 
                    currency: filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency || "USD" 
                  })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Paid to Date:</span>
                <span>
                  {filteredInvoices.find(i => i.id === selectedInvoiceId)?.paidAmount.toLocaleString(undefined, { 
                    style: 'currency', 
                    currency: filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency || "USD" 
                  })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Balance Due:</span>
                <span>
                  {((filteredInvoices.find(i => i.id === selectedInvoiceId)?.totalAmount || 0) - 
                  (filteredInvoices.find(i => i.id === selectedInvoiceId)?.paidAmount || 0)).toLocaleString(undefined, { 
                    style: 'currency', 
                    currency: filteredInvoices.find(i => i.id === selectedInvoiceId)?.currency || "USD" 
                  })}
                </span>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <label htmlFor="payment-amount" className="text-sm font-medium">
                Payment Amount
              </label>
              <div className="relative">
                <DollarSign className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="payment-amount"
                  type="number"
                  className="pl-8"
                  min="0.01"
                  step="0.01"
                  max={(filteredInvoices.find(i => i.id === selectedInvoiceId)?.totalAmount || 0) - 
                        (filteredInvoices.find(i => i.id === selectedInvoiceId)?.paidAmount || 0)}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                />
              </div>
              <label htmlFor="payment-date" className="text-sm font-medium">
                Payment Date
              </label>
              <div className="relative">
                <CalendarDays className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="payment-date"
                  type="date"
                  className="pl-8"
                  defaultValue={new Date().toISOString().slice(0, 10)}
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setShowPaymentDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              type="button"
              onClick={() => {
                if (selectedInvoiceId) {
                  handleRecordPayment(selectedInvoiceId, paymentAmount);
                }
              }}
              disabled={!paymentAmount || paymentAmount <= 0}
            >
              Record Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}