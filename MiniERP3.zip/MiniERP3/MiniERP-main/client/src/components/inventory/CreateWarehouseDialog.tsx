import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

interface Plant {
  id: number;
  name: string;
  code: string;
}

interface CreateWarehouseDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateWarehouseDialog({ isOpen, onClose }: CreateWarehouseDialogProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { data: plants } = useQuery<Plant[]>({
    queryKey: ['/api/master-data/plants'],
    enabled: isOpen, // Only fetch when dialog is open
  });
  
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    description: "",
    plant_id: "",
    is_active: true
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const resetForm = () => {
    setFormData({
      code: "",
      name: "",
      description: "",
      plant_id: "",
      is_active: true
    });
  };

  useEffect(() => {
    if (!isOpen) {
      resetForm();
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.plant_id) {
      toast({
        title: "Error",
        description: "Please select a plant",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await apiRequest('/api/inventory/warehouses', {
        method: 'POST',
        body: JSON.stringify({
          ...formData,
          plant_id: parseInt(formData.plant_id)
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      // Invalidate query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/warehouses'] });
      
      toast({
        title: "Warehouse Created",
        description: `${formData.name} has been added as a new storage location.`,
      });
      
      resetForm();
      onClose();
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create warehouse. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add Storage Location</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="code">Location Code *</Label>
                <Input
                  id="code"
                  name="code"
                  placeholder="e.g., WH01"
                  value={formData.code}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">Location Name *</Label>
                <Input
                  id="name"
                  name="name"
                  placeholder="e.g., Main Warehouse"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                name="description"
                placeholder="Describe the purpose or location of this storage area"
                value={formData.description}
                onChange={handleInputChange}
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="plant_id">Plant *</Label>
              <Select 
                value={formData.plant_id} 
                onValueChange={(value) => handleSelectChange("plant_id", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select plant" />
                </SelectTrigger>
                <SelectContent>
                  {plants && plants.length > 0 ? (
                    plants.map(plant => (
                      <SelectItem key={plant.id} value={plant.id.toString()}>
                        {plant.name} ({plant.code})
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="" disabled>
                      No plants available - Please add plants first
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({ ...prev, is_active: checked }))
                }
              />
              <Label htmlFor="is_active">Active</Label>
            </div>
          </div>
          
          <DialogFooter className="mt-6">
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Creating..." : "Create Location"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}