import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, Download, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function WorkCentersContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [showNewWorkCenterForm, setShowNewWorkCenterForm] = useState(false);
  const [newWorkCenter, setNewWorkCenter] = useState({
    code: "",
    name: "",
    description: "",
    capacity: "",
    capacity_uom: "",
    responsible: ""
  });
  
  // Sample data for work centers
  const workCenters = [
    {
      id: 1,
      code: "WC001",
      name: "Assembly Line 1",
      description: "Main assembly line for smartphones",
      capacity: 100,
      capacity_uom: "units/day",
      status: "Active",
      responsible: "John Smith"
    },
    {
      id: 2,
      code: "WC002",
      name: "Testing Station",
      description: "Quality assurance and testing",
      capacity: 150,
      capacity_uom: "units/day",
      status: "Active",
      responsible: "Sarah Johnson"
    },
    {
      id: 3,
      code: "WC003",
      name: "Packaging Line",
      description: "Product packaging and preparation for shipping",
      capacity: 200,
      capacity_uom: "units/day",
      status: "Active",
      responsible: "Robert Brown"
    },
    {
      id: 4,
      code: "WC004",
      name: "Circuit Board Assembly",
      description: "Electronic components assembly",
      capacity: 80,
      capacity_uom: "units/day",
      status: "Maintenance",
      responsible: "Michael Lee"
    }
  ];

  const filteredWorkCenters = workCenters.filter(wc => {
    const matchesSearch = wc.code.toLowerCase().includes(searchTerm.toLowerCase()) || 
      wc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      wc.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      wc.responsible.toLowerCase().includes(searchTerm.toLowerCase()) ||
      wc.status.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || wc.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return <Badge className="bg-green-500 text-white">Active</Badge>;
      case 'maintenance':
        return <Badge className="bg-yellow-500 text-white">Maintenance</Badge>;
      case 'inactive':
        return <Badge variant="outline">Inactive</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search work centers..." 
            className="pl-8 rounded-md border border-input bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant={showFilters ? "default" : "outline"}
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              const csvContent = filteredWorkCenters.map(wc => ({
                Code: wc.code,
                Name: wc.name,
                Description: wc.description,
                Capacity: `${wc.capacity} ${wc.capacity_uom}`,
                Responsible: wc.responsible,
                Status: wc.status
              }));
              
              const csvString = [
                Object.keys(csvContent[0]).join(','),
                ...csvContent.map(row => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'work-centers.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Dialog open={showNewWorkCenterForm} onOpenChange={setShowNewWorkCenterForm}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                New Work Center
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Work Center</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="code">Work Center Code</Label>
                  <Input
                    id="code"
                    value={newWorkCenter.code}
                    onChange={(e) => setNewWorkCenter({...newWorkCenter, code: e.target.value})}
                    placeholder="Enter work center code"
                  />
                </div>
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={newWorkCenter.name}
                    onChange={(e) => setNewWorkCenter({...newWorkCenter, name: e.target.value})}
                    placeholder="Enter work center name"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={newWorkCenter.description}
                    onChange={(e) => setNewWorkCenter({...newWorkCenter, description: e.target.value})}
                    placeholder="Enter description"
                  />
                </div>
                <div>
                  <Label htmlFor="capacity">Capacity</Label>
                  <Input
                    id="capacity"
                    type="number"
                    value={newWorkCenter.capacity}
                    onChange={(e) => setNewWorkCenter({...newWorkCenter, capacity: e.target.value})}
                    placeholder="Enter capacity"
                  />
                </div>
                <div>
                  <Label htmlFor="capacity_uom">Capacity Unit</Label>
                  <Input
                    id="capacity_uom"
                    value={newWorkCenter.capacity_uom}
                    onChange={(e) => setNewWorkCenter({...newWorkCenter, capacity_uom: e.target.value})}
                    placeholder="Enter capacity unit (e.g., units/day)"
                  />
                </div>
                <div>
                  <Label htmlFor="responsible">Responsible Person</Label>
                  <Input
                    id="responsible"
                    value={newWorkCenter.responsible}
                    onChange={(e) => setNewWorkCenter({...newWorkCenter, responsible: e.target.value})}
                    placeholder="Enter responsible person"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowNewWorkCenterForm(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => {
                    console.log('Creating work center:', newWorkCenter);
                    setShowNewWorkCenterForm(false);
                    setNewWorkCenter({code: "", name: "", description: "", capacity: "", capacity_uom: "", responsible: ""});
                  }}>
                    Create Work Center
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Filter Panel */}
      {showFilters && (
        <Card>
          <CardHeader>
            <CardTitle>Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="status-filter">Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setStatusFilter("all");
                    setSearchTerm("");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Work Centers Table */}
      <Card>
        <CardHeader>
          <CardTitle>Work Centers</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredWorkCenters.length > 0 ? (
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Capacity</TableHead>
                    <TableHead>Responsible</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredWorkCenters.map((wc) => (
                    <TableRow key={wc.id}>
                      <TableCell className="font-medium">{wc.code}</TableCell>
                      <TableCell>{wc.name}</TableCell>
                      <TableCell>{wc.description}</TableCell>
                      <TableCell>{wc.capacity} {wc.capacity_uom}</TableCell>
                      <TableCell>{wc.responsible}</TableCell>
                      <TableCell>{getStatusBadge(wc.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No work centers match your search.' : 'No work centers found.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}