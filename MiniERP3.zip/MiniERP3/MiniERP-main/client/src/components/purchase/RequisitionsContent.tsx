import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, Download, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function RequisitionsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  
  // Sample data for requisitions
  const requisitions = [
    {
      id: 1,
      req_number: "REQ-2025-1001",
      requester: "John Smith",
      department: "Engineering",
      req_date: new Date(2025, 0, 15).toISOString(),
      status: "Pending Approval",
      priority: "High"
    },
    {
      id: 2,
      req_number: "REQ-2025-1002",
      requester: "Sarah Johnson",
      department: "Operations",
      req_date: new Date(2025, 0, 17).toISOString(),
      status: "Approved",
      priority: "Medium"
    },
    {
      id: 3,
      req_number: "REQ-2025-1003",
      requester: "Robert Brown",
      department: "Marketing",
      req_date: new Date(2025, 0, 19).toISOString(),
      status: "Converted to PO",
      priority: "Low"
    }
  ];

  const filteredRequisitions = requisitions.filter(req => 
    req.req_number.toLowerCase().includes(searchTerm.toLowerCase()) || 
    req.requester.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending approval':
        return <Badge className="bg-yellow-500 text-white">Pending Approval</Badge>;
      case 'approved':
        return <Badge className="bg-blue-500 text-white">Approved</Badge>;
      case 'converted to po':
        return <Badge className="bg-green-500 text-white">Converted to PO</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return <Badge className="bg-red-500 text-white">High</Badge>;
      case 'medium':
        return <Badge className="bg-orange-500 text-white">Medium</Badge>;
      case 'low':
        return <Badge className="bg-green-500 text-white">Low</Badge>;
      default:
        return <Badge variant="outline">{priority}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search requisitions..." 
            className="pl-8 rounded-md border border-input bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              console.log('Filter requisitions clicked');
              // Add filter functionality
            }}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              console.log('Export requisitions clicked');
              // Add export functionality
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button 
            size="sm"
            onClick={() => {
              console.log('New requisition clicked');
              // Add new requisition functionality
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            New Requisition
          </Button>
        </div>
      </div>
      
      {/* Requisitions Table */}
      <Card>
        <CardHeader>
          <CardTitle>Purchase Requisitions</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredRequisitions.length > 0 ? (
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Requisition Number</TableHead>
                    <TableHead>Requester</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRequisitions.map((req) => (
                    <TableRow key={req.id}>
                      <TableCell className="font-medium">{req.req_number}</TableCell>
                      <TableCell>{req.requester}</TableCell>
                      <TableCell>{req.department}</TableCell>
                      <TableCell>{formatDate(req.req_date)}</TableCell>
                      <TableCell>{getPriorityBadge(req.priority)}</TableCell>
                      <TableCell>{getStatusBadge(req.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No requisitions match your search.' : 'No requisitions found.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}