-- Database Sequences Export
-- Generated: 2025-06-05T15:16:22.413Z
-- Sequences: 113

-- Sequence: categories_id_seq
CREATE SEQUENCE IF NOT EXISTS "categories_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"categories_id_seq"', 1, true);

-- Sequence: customers_id_seq
CREATE SEQUENCE IF NOT EXISTS "customers_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"customers_id_seq"', 22, true);

-- Sequence: expenses_id_seq
CREATE SEQUENCE IF NOT EXISTS "expenses_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"expenses_id_seq"', 18, true);

-- Sequence: invoices_id_seq
CREATE SEQUENCE IF NOT EXISTS "invoices_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"invoices_id_seq"', 10, true);

-- Sequence: order_items_id_seq
CREATE SEQUENCE IF NOT EXISTS "order_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"order_items_id_seq"', 131, true);

-- Sequence: orders_id_seq
CREATE SEQUENCE IF NOT EXISTS "orders_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"orders_id_seq"', 52, true);

-- Sequence: products_id_seq
CREATE SEQUENCE IF NOT EXISTS "products_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"products_id_seq"', 20, true);

-- Sequence: stock_movements_id_seq
CREATE SEQUENCE IF NOT EXISTS "stock_movements_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"stock_movements_id_seq"', 28, true);

-- Sequence: users_id_seq
CREATE SEQUENCE IF NOT EXISTS "users_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"users_id_seq"', 1, true);

-- Sequence: uom_id_seq
CREATE SEQUENCE IF NOT EXISTS "uom_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"uom_id_seq"', 14, true);

-- Sequence: uom_conversions_id_seq
CREATE SEQUENCE IF NOT EXISTS "uom_conversions_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"uom_conversions_id_seq"', 6, true);

-- Sequence: plants_id_seq
CREATE SEQUENCE IF NOT EXISTS "plants_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"plants_id_seq"', 37, true);

-- Sequence: storage_locations_id_seq
CREATE SEQUENCE IF NOT EXISTS "storage_locations_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"storage_locations_id_seq"', 52, true);

-- Sequence: currencies_id_seq
CREATE SEQUENCE IF NOT EXISTS "currencies_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"currencies_id_seq"', 5, true);

-- Sequence: purchase_organizations_id_seq
CREATE SEQUENCE IF NOT EXISTS "purchase_organizations_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"purchase_organizations_id_seq"', 36, true);

-- Sequence: credit_control_areas_id_seq
CREATE SEQUENCE IF NOT EXISTS "credit_control_areas_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"credit_control_areas_id_seq"', 5, true);

-- Sequence: tax_codes_id_seq
CREATE SEQUENCE IF NOT EXISTS "tax_codes_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"tax_codes_id_seq"', 18, true);

-- Sequence: customer_contacts_id_seq
CREATE SEQUENCE IF NOT EXISTS "customer_contacts_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"customer_contacts_id_seq"', 12, true);

-- Sequence: vendors_id_seq
CREATE SEQUENCE IF NOT EXISTS "vendors_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"vendors_id_seq"', 25, true);

-- Sequence: vendor_contacts_id_seq
CREATE SEQUENCE IF NOT EXISTS "vendor_contacts_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"vendor_contacts_id_seq"', 10, true);

-- Sequence: erp_customers_id_seq
CREATE SEQUENCE IF NOT EXISTS "erp_customers_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"erp_customers_id_seq"', 10, true);

-- Sequence: erp_customer_contacts_id_seq
CREATE SEQUENCE IF NOT EXISTS "erp_customer_contacts_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"erp_customer_contacts_id_seq"', 10, true);

-- Sequence: erp_vendors_id_seq
CREATE SEQUENCE IF NOT EXISTS "erp_vendors_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"erp_vendors_id_seq"', 12, true);

-- Sequence: erp_vendor_contacts_id_seq
CREATE SEQUENCE IF NOT EXISTS "erp_vendor_contacts_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"erp_vendor_contacts_id_seq"', 12, true);

-- Sequence: sales_organizations_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_organizations_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_organizations_id_seq"', 31, true);

-- Sequence: fiscal_periods_id_seq
CREATE SEQUENCE IF NOT EXISTS "fiscal_periods_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"fiscal_periods_id_seq"', 12, true);

-- Sequence: purchase_groups_id_seq
CREATE SEQUENCE IF NOT EXISTS "purchase_groups_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"purchase_groups_id_seq"', 12, true);

-- Sequence: supply_types_id_seq
CREATE SEQUENCE IF NOT EXISTS "supply_types_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"supply_types_id_seq"', 11, true);

-- Sequence: asset_master_id_seq
CREATE SEQUENCE IF NOT EXISTS "asset_master_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"asset_master_id_seq"', 15, true);

-- Sequence: environment_config_id_seq
CREATE SEQUENCE IF NOT EXISTS "environment_config_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"environment_config_id_seq"', null, true);

-- Sequence: units_of_measure_id_seq
CREATE SEQUENCE IF NOT EXISTS "units_of_measure_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"units_of_measure_id_seq"', 30, true);

-- Sequence: material_categories_id_seq
CREATE SEQUENCE IF NOT EXISTS "material_categories_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"material_categories_id_seq"', 11, true);

-- Sequence: materials_id_seq
CREATE SEQUENCE IF NOT EXISTS "materials_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"materials_id_seq"', 34, true);

-- Sequence: approval_levels_id_seq
CREATE SEQUENCE IF NOT EXISTS "approval_levels_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"approval_levels_id_seq"', 11, true);

-- Sequence: regions_id_seq
CREATE SEQUENCE IF NOT EXISTS "regions_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"regions_id_seq"', 4, true);

-- Sequence: countries_id_seq
CREATE SEQUENCE IF NOT EXISTS "countries_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"countries_id_seq"', 12, true);

-- Sequence: bill_of_materials_id_seq
CREATE SEQUENCE IF NOT EXISTS "bill_of_materials_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"bill_of_materials_id_seq"', 8, true);

-- Sequence: bom_items_id_seq
CREATE SEQUENCE IF NOT EXISTS "bom_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"bom_items_id_seq"', 18, true);

-- Sequence: work_centers_id_seq
CREATE SEQUENCE IF NOT EXISTS "work_centers_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"work_centers_id_seq"', 28, true);

-- Sequence: cost_allocations_id_seq
CREATE SEQUENCE IF NOT EXISTS "cost_allocations_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"cost_allocations_id_seq"', null, true);

-- Sequence: employees_id_seq
CREATE SEQUENCE IF NOT EXISTS "employees_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"employees_id_seq"', 12, true);

-- Sequence: leads_id_seq
CREATE SEQUENCE IF NOT EXISTS "leads_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"leads_id_seq"', 24, true);

-- Sequence: opportunities_id_seq
CREATE SEQUENCE IF NOT EXISTS "opportunities_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"opportunities_id_seq"', 17, true);

-- Sequence: quotes_id_seq
CREATE SEQUENCE IF NOT EXISTS "quotes_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"quotes_id_seq"', 7, true);

-- Sequence: quote_items_id_seq
CREATE SEQUENCE IF NOT EXISTS "quote_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"quote_items_id_seq"', 10, true);

-- Sequence: quote_approvals_id_seq
CREATE SEQUENCE IF NOT EXISTS "quote_approvals_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"quote_approvals_id_seq"', 16, true);

-- Sequence: sales_orders_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_orders_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_orders_id_seq"', 11, true);

-- Sequence: sales_order_items_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_order_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_order_items_id_seq"', 16, true);

-- Sequence: sales_quotes_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_quotes_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_quotes_id_seq"', 5, true);

-- Sequence: sales_quote_items_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_quote_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_quote_items_id_seq"', 12, true);

-- Sequence: sales_invoices_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_invoices_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_invoices_id_seq"', 5, true);

-- Sequence: sales_invoice_items_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_invoice_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_invoice_items_id_seq"', 9, true);

-- Sequence: sales_returns_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_returns_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_returns_id_seq"', 4, true);

-- Sequence: sales_return_items_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_return_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_return_items_id_seq"', 7, true);

-- Sequence: sales_customers_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_customers_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_customers_id_seq"', 7, true);

-- Sequence: sales_customer_contacts_id_seq
CREATE SEQUENCE IF NOT EXISTS "sales_customer_contacts_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"sales_customer_contacts_id_seq"', 11, true);

-- Sequence: dashboard_configs_id_seq
CREATE SEQUENCE IF NOT EXISTS "dashboard_configs_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"dashboard_configs_id_seq"', 29, true);

-- Sequence: transport_requests_id_seq
CREATE SEQUENCE IF NOT EXISTS "transport_requests_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"transport_requests_id_seq"', 5, true);

-- Sequence: transport_objects_id_seq
CREATE SEQUENCE IF NOT EXISTS "transport_objects_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"transport_objects_id_seq"', 12, true);

-- Sequence: transport_logs_id_seq
CREATE SEQUENCE IF NOT EXISTS "transport_logs_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"transport_logs_id_seq"', 9, true);

-- Sequence: transport_number_ranges_id_seq
CREATE SEQUENCE IF NOT EXISTS "transport_number_ranges_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"transport_number_ranges_id_seq"', 1266, true);

-- Sequence: purchase_orders_id_seq
CREATE SEQUENCE IF NOT EXISTS "purchase_orders_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"purchase_orders_id_seq"', 5, true);

-- Sequence: purchase_order_items_id_seq
CREATE SEQUENCE IF NOT EXISTS "purchase_order_items_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"purchase_order_items_id_seq"', null, true);

-- Sequence: production_orders_id_seq
CREATE SEQUENCE IF NOT EXISTS "production_orders_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"production_orders_id_seq"', 5, true);

-- Sequence: general_ledger_accounts_id_seq
CREATE SEQUENCE IF NOT EXISTS "general_ledger_accounts_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"general_ledger_accounts_id_seq"', null, true);

-- Sequence: journal_entries_id_seq
CREATE SEQUENCE IF NOT EXISTS "journal_entries_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"journal_entries_id_seq"', 5, true);

-- Sequence: employee_master_id_seq
CREATE SEQUENCE IF NOT EXISTS "employee_master_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"employee_master_id_seq"', null, true);

-- Sequence: inventory_transactions_id_seq
CREATE SEQUENCE IF NOT EXISTS "inventory_transactions_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"inventory_transactions_id_seq"', null, true);

-- Sequence: batch_master_id_seq
CREATE SEQUENCE IF NOT EXISTS "batch_master_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"batch_master_id_seq"', null, true);

-- Sequence: warehouse_bins_id_seq
CREATE SEQUENCE IF NOT EXISTS "warehouse_bins_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"warehouse_bins_id_seq"', null, true);

-- Sequence: cost_centers_id_seq
CREATE SEQUENCE IF NOT EXISTS "cost_centers_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"cost_centers_id_seq"', 24, true);

-- Sequence: profit_centers_id_seq
CREATE SEQUENCE IF NOT EXISTS "profit_centers_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"profit_centers_id_seq"', 20, true);

-- Sequence: activity_types_id_seq
CREATE SEQUENCE IF NOT EXISTS "activity_types_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"activity_types_id_seq"', 5, true);

-- Sequence: cost_center_planning_id_seq
CREATE SEQUENCE IF NOT EXISTS "cost_center_planning_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"cost_center_planning_id_seq"', 138, true);

-- Sequence: cost_center_actuals_id_seq
CREATE SEQUENCE IF NOT EXISTS "cost_center_actuals_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"cost_center_actuals_id_seq"', 135, true);

-- Sequence: internal_orders_id_seq
CREATE SEQUENCE IF NOT EXISTS "internal_orders_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"internal_orders_id_seq"', null, true);

-- Sequence: copa_actuals_id_seq
CREATE SEQUENCE IF NOT EXISTS "copa_actuals_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"copa_actuals_id_seq"', null, true);

-- Sequence: variance_analysis_id_seq
CREATE SEQUENCE IF NOT EXISTS "variance_analysis_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"variance_analysis_id_seq"', null, true);

-- Sequence: accounts_payable_id_seq
CREATE SEQUENCE IF NOT EXISTS "accounts_payable_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"accounts_payable_id_seq"', 20, true);

-- Sequence: accounts_receivable_id_seq
CREATE SEQUENCE IF NOT EXISTS "accounts_receivable_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"accounts_receivable_id_seq"', 25, true);

-- Sequence: gl_accounts_id_seq
CREATE SEQUENCE IF NOT EXISTS "gl_accounts_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"gl_accounts_id_seq"', 35, true);

-- Sequence: company_code_chart_assignments_id_seq
CREATE SEQUENCE IF NOT EXISTS "company_code_chart_assignments_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"company_code_chart_assignments_id_seq"', 1, true);

-- Sequence: ai_agent_configs_id_seq
CREATE SEQUENCE IF NOT EXISTS "ai_agent_configs_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"ai_agent_configs_id_seq"', 7, true);

-- Sequence: ai_chat_sessions_id_seq
CREATE SEQUENCE IF NOT EXISTS "ai_chat_sessions_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"ai_chat_sessions_id_seq"', null, true);

-- Sequence: ai_chat_messages_id_seq
CREATE SEQUENCE IF NOT EXISTS "ai_chat_messages_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"ai_chat_messages_id_seq"', null, true);

-- Sequence: ai_agent_analytics_id_seq
CREATE SEQUENCE IF NOT EXISTS "ai_agent_analytics_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"ai_agent_analytics_id_seq"', null, true);

-- Sequence: ai_data_analysis_sessions_id_seq
CREATE SEQUENCE IF NOT EXISTS "ai_data_analysis_sessions_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"ai_data_analysis_sessions_id_seq"', null, true);

-- Sequence: ai_agent_health_id_seq
CREATE SEQUENCE IF NOT EXISTS "ai_agent_health_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"ai_agent_health_id_seq"', null, true);

-- Sequence: api_keys_id_seq
CREATE SEQUENCE IF NOT EXISTS "api_keys_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"api_keys_id_seq"', 2, true);

-- Sequence: custom_reports_id_seq
CREATE SEQUENCE IF NOT EXISTS "custom_reports_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"custom_reports_id_seq"', 5, true);

-- Sequence: reports_id_seq
CREATE SEQUENCE IF NOT EXISTS "reports_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"reports_id_seq"', 5, true);

-- Sequence: companies_id_seq
CREATE SEQUENCE IF NOT EXISTS "companies_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"companies_id_seq"', 1, true);

-- Sequence: company_codes_id_seq
CREATE SEQUENCE IF NOT EXISTS "company_codes_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"company_codes_id_seq"', 20, true);

-- Sequence: chart_of_accounts_id_seq
CREATE SEQUENCE IF NOT EXISTS "chart_of_accounts_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"chart_of_accounts_id_seq"', null, true);

-- Sequence: fiscal_year_variants_id_seq
CREATE SEQUENCE IF NOT EXISTS "fiscal_year_variants_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"fiscal_year_variants_id_seq"', null, true);

-- Sequence: account_groups_id_seq
CREATE SEQUENCE IF NOT EXISTS "account_groups_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"account_groups_id_seq"', null, true);

-- Sequence: system_error_logs_id_seq
CREATE SEQUENCE IF NOT EXISTS "system_error_logs_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"system_error_logs_id_seq"', 20, true);

-- Sequence: change_document_headers_id_seq
CREATE SEQUENCE IF NOT EXISTS "change_document_headers_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"change_document_headers_id_seq"', null, true);

-- Sequence: change_document_positions_id_seq
CREATE SEQUENCE IF NOT EXISTS "change_document_positions_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"change_document_positions_id_seq"', null, true);

-- Sequence: change_document_relations_id_seq
CREATE SEQUENCE IF NOT EXISTS "change_document_relations_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"change_document_relations_id_seq"', null, true);

-- Sequence: change_document_approvals_id_seq
CREATE SEQUENCE IF NOT EXISTS "change_document_approvals_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"change_document_approvals_id_seq"', null, true);

-- Sequence: change_document_attachments_id_seq
CREATE SEQUENCE IF NOT EXISTS "change_document_attachments_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"change_document_attachments_id_seq"', null, true);

-- Sequence: change_document_analytics_id_seq
CREATE SEQUENCE IF NOT EXISTS "change_document_analytics_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"change_document_analytics_id_seq"', 5, true);

-- Sequence: change_document_number_seq
CREATE SEQUENCE IF NOT EXISTS "change_document_number_seq"
    START WITH 1000000
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"change_document_number_seq"', 1000000, true);

-- Sequence: comprehensive_issues_log_id_seq
CREATE SEQUENCE IF NOT EXISTS "comprehensive_issues_log_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"comprehensive_issues_log_id_seq"', 137, true);

-- Sequence: ai_agent_interventions_id_seq
CREATE SEQUENCE IF NOT EXISTS "ai_agent_interventions_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"ai_agent_interventions_id_seq"', null, true);

-- Sequence: issue_resolutions_id_seq
CREATE SEQUENCE IF NOT EXISTS "issue_resolutions_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"issue_resolutions_id_seq"', null, true);

-- Sequence: issue_patterns_id_seq
CREATE SEQUENCE IF NOT EXISTS "issue_patterns_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"issue_patterns_id_seq"', 5, true);

-- Sequence: module_health_status_id_seq
CREATE SEQUENCE IF NOT EXISTS "module_health_status_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"module_health_status_id_seq"', 146, true);

-- Sequence: issue_analytics_summary_id_seq
CREATE SEQUENCE IF NOT EXISTS "issue_analytics_summary_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"issue_analytics_summary_id_seq"', 1, true);

-- Sequence: ai_agent_performance_id_seq
CREATE SEQUENCE IF NOT EXISTS "ai_agent_performance_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 9223372036854775807
    CACHE 1;
SELECT setval('"ai_agent_performance_id_seq"', 9, true);

-- Sequence: purchase_requests_id_seq
CREATE SEQUENCE IF NOT EXISTS "purchase_requests_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"purchase_requests_id_seq"', null, true);

-- Sequence: production_work_orders_id_seq
CREATE SEQUENCE IF NOT EXISTS "production_work_orders_id_seq"
    START WITH 1
    INCREMENT BY 1
    MIN VALUE 1
    MAX VALUE 2147483647
    CACHE 1;
SELECT setval('"production_work_orders_id_seq"', null, true);

