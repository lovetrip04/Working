# MallyERP - Complete Enterprise Resource Planning System

## Overview
MallyERP is a comprehensive, AI-powered Enterprise Resource Planning system designed for modern manufacturing businesses. The system integrates all critical business processes with intelligent automation and zero-error data integrity guarantees.

## System Architecture

### Frontend (React + TypeScript)
- **Framework**: React 18 with TypeScript for type safety
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: Comprehensive component library with responsive design

### Backend (Node.js + Express)
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM
- **API**: RESTful API with comprehensive endpoint coverage
- **Authentication**: Passport.js with session-based authentication
- **Security**: Enterprise-grade security implementations

### Database (PostgreSQL)
- **Tables**: 112 comprehensive tables covering all ERP modules
- **Audit Trail**: LOGHDR/LOGITEMS standard implementation
- **Change Tracking**: Complete field-level change tracking
- **Data Integrity**: Zero-error guarantees with comprehensive validation

### AI Integration (OpenAI)
- **Agents**: 9 specialized AI agents for different modules
- **Capabilities**: Automatic error resolution and process optimization
- **Coverage**: All major business processes with intelligent assistance

## Core Modules

### 1. Master Data Management
- Company codes, plants, storage locations
- Material master with comprehensive attributes
- Customer and vendor master data
- Chart of accounts and financial structures

### 2. Sales Management
- Lead and opportunity management
- Quote generation and approval workflows
- Sales order processing
- Customer relationship management

### 3. Inventory Management
- Stock management and tracking
- Warehouse operations
- Material movements and valuations
- Inventory optimization

### 4. Purchase Management
- Purchase requisition and order processing
- Vendor management and evaluation
- Procurement workflows
- Cost optimization

### 5. Production Management
- Production planning and scheduling
- Work center management
- Bill of materials (BOM) management
- Quality control integration

### 6. Financial Management
- General ledger accounting
- Accounts payable and receivable
- Financial reporting and analysis
- Cash flow management

### 7. Controlling
- Cost center accounting
- Profit center analysis
- Internal order management
- Management reporting

## AI-Powered Features

### Module-Specific Agents
1. **Master Data Specialist**: Data validation and hierarchy management
2. **Sales Operations Expert**: Opportunity conversion and order optimization
3. **Inventory Control Specialist**: Stock optimization and movement tracking
4. **Procurement Specialist**: Vendor evaluation and cost analysis
5. **Manufacturing Operations Expert**: Production optimization and quality control
6. **Financial Operations Expert**: Account reconciliation and financial analysis
7. **Management Accounting Specialist**: Cost allocation and profitability analysis

### Data Integrity Agents
8. **Data Integrity Guardian**: Cross-module validation and constraint management
9. **Auto-Recovery Agent**: System monitoring and automatic issue resolution

## Change Management System

### LOGHDR/LOGITEMS Standard
- **Change Document Headers**: Main change document tracking
- **Change Document Positions**: Field-level change details
- **Automatic Numbering**: CHG0001000000 format with sequential numbering
- **Business Context**: Process-aware change tracking
- **Approval Integration**: Workflow integration for critical changes

## Technical Specifications

### Performance
- Optimized database queries with indexing
- Efficient API endpoints with proper caching
- Responsive frontend with lazy loading
- Real-time updates with WebSocket integration

### Security
- Role-based access control
- Session management with secure cookies
- Input validation and sanitization
- Audit trails for all operations

### Scalability
- Modular architecture for easy expansion
- Database optimization for large datasets
- Microservice-ready architecture
- Cloud deployment capabilities

## Deployment

### Requirements
- Node.js 18+
- PostgreSQL 14+
- OpenAI API access
- Modern web browser

### Environment Setup
```bash
# Install dependencies
npm install

# Set environment variables
DATABASE_URL=your_postgresql_url
OPENAI_API_KEY=your_openai_key

# Initialize database
npm run db:push

# Start development server
npm run dev
```

### Production Deployment
The system is production-ready with:
- Comprehensive error handling
- Performance monitoring
- Automatic backup systems
- Zero-downtime deployment capabilities

## Data Import/Export

### Schema Import
```bash
psql -d your_database < database-schema-complete.sql
```

### Data Import
```bash
psql -d your_database < database-data-complete.sql
```

## Support and Maintenance

### Monitoring
- Real-time system health monitoring
- Automated error detection and resolution
- Performance metrics and analytics
- User activity tracking

### Backup and Recovery
- Automated daily backups
- Point-in-time recovery capabilities
- Data integrity verification
- Disaster recovery procedures

## License
MIT License - See LICENSE file for details

## Contributing
Please read CONTRIBUTING.md for contribution guidelines and code standards.
