# MallyERP Source Code Structure

## Project Architecture

### Frontend Structure (React + TypeScript)
```
client/
├── src/
│   ├── components/          # Reusable UI components
│   │   ├── ui/             # shadcn/ui components
│   │   ├── dashboard/      # Dashboard widgets
│   │   ├── forms/          # Form components
│   │   └── layout/         # Layout components
│   ├── pages/              # Route components
│   │   ├── MasterData/     # Master data pages
│   │   ├── Sales/          # Sales module pages
│   │   ├── Inventory/      # Inventory pages
│   │   ├── Purchase/       # Purchase pages
│   │   ├── Production/     # Production pages
│   │   ├── Finance/        # Finance pages
│   │   └── Controlling/    # Controlling pages
│   ├── hooks/              # Custom React hooks
│   ├── lib/                # Utility libraries
│   └── App.tsx             # Main application component
```

### Backend Structure (Node.js + Express)
```
server/
├── routes/                 # API route handlers
│   ├── master-data/       # Master data APIs
│   ├── sales/             # Sales module APIs
│   ├── inventory/         # Inventory APIs
│   ├── purchase/          # Purchase APIs
│   ├── production/        # Production APIs
│   ├── finance/           # Finance APIs
│   ├── controlling/       # Controlling APIs
│   └── aiAgentRoutes.js   # AI agent APIs
├── middleware/            # Express middleware
├── utils/                 # Utility functions
└── index.ts              # Server entry point
```

### Database Structure
```
database/
├── migrations/            # Database migration scripts
├── seeds/                # Sample data scripts
└── schema/               # Schema definitions
```

## AI System Implementation

### AI Agent Files Included
1. **server/routes/aiAgentRoutes.js** - Core AI agent endpoints
2. **server/utils/aiAgents.js** - AI agent class implementations
3. **client/src/components/AIAssistant.tsx** - Frontend AI interface
4. **client/src/hooks/useAI.ts** - AI integration hooks

### AI Database Tables (Included in schema export)
- ai_agents
- ai_agent_logs
- ai_agent_master_data_logs
- ai_agent_sales_logs
- ai_agent_inventory_logs
- ai_agent_purchase_logs
- ai_agent_production_logs
- ai_agent_finance_logs
- ai_agent_controlling_logs
- ai_agent_data_integrity_logs
- ai_agent_auto_recovery_logs

## Help System Implementation

### Help Documentation Files
1. **client/src/components/HelpSystem.tsx** - Interactive help component
2. **client/src/pages/Help.tsx** - Help page component
3. **public/help/** - Static help files
4. **github-export/HELP-DOCUMENTATION.md** - Complete help guide

### Help Features
- Context-sensitive help
- Search functionality
- Video tutorials (embedded)
- Interactive walkthroughs
- FAQ system
- Troubleshooting guides

## Key Components Included

### Master Data Management
- **Files**: client/src/pages/MasterData/*.tsx
- **APIs**: server/routes/master-data/*.ts
- **Features**: Company codes, plants, materials, customers, vendors

### Sales Module
- **Files**: client/src/pages/Sales/*.tsx
- **APIs**: server/routes/salesModuleRoutes.js
- **Features**: Leads, opportunities, quotes, orders

### Inventory Management
- **Files**: client/src/pages/Inventory/*.tsx
- **APIs**: server/routes/inventoryRoutes.js
- **Features**: Stock management, movements, tracking

### Purchase Management
- **Files**: client/src/pages/Purchase/*.tsx
- **APIs**: server/routes/purchaseRoutes.js
- **Features**: Purchase orders, vendor management

### Production Management
- **Files**: client/src/pages/Production/*.tsx
- **APIs**: server/routes/productionRoutes.js
- **Features**: Work centers, BOMs, production orders

### Financial Management
- **Files**: client/src/pages/Finance/*.tsx
- **APIs**: server/routes/financeRoutes.js
- **Features**: GL accounts, journal entries

### Controlling Module
- **Files**: client/src/pages/Controlling/*.tsx
- **APIs**: server/routes/controllingRoutes.js
- **Features**: Cost centers, profit centers

## AI Integration Points

### Frontend AI Components
```typescript
// AI Assistant Component
import { AIAssistant } from '@/components/AIAssistant';

// Usage in any component
<AIAssistant 
  module="sales" 
  context={currentData}
  onSuggestion={handleAISuggestion}
/>
```

### Backend AI Integration
```javascript
// AI Agent Usage Example
const aiAgent = new SalesAgent();
const analysis = await aiAgent.analyze(leadData);
const suggestions = await aiAgent.getSuggestions(opportunityData);
```

### Real-time AI Monitoring
- WebSocket connections for real-time AI updates
- Event-driven AI agent triggers
- Automatic error detection and resolution
- Performance monitoring and optimization

## Configuration Files

### Environment Configuration
```
.env.example              # Environment template
.env                     # Local environment (not in git)
```

### Build Configuration
```
package.json             # Dependencies and scripts
tsconfig.json           # TypeScript configuration
vite.config.ts          # Vite build configuration
tailwind.config.ts      # Tailwind CSS configuration
```

### Database Configuration
```
drizzle.config.ts       # Database ORM configuration
```

## API Documentation

### Complete API Endpoints
- All CRUD operations for each module
- AI agent integration endpoints
- Real-time update endpoints
- File upload and export endpoints
- Authentication and authorization

### API Response Formats
- Standardized JSON responses
- Error handling with proper status codes
- Pagination for list endpoints
- Search and filtering capabilities

## Testing Structure

### Test Files Included
```
tests/
├── unit/               # Unit tests
├── integration/        # Integration tests
├── e2e/               # End-to-end tests
└── ai/                # AI agent tests
```

### Test Coverage
- Component testing with React Testing Library
- API endpoint testing
- Database operation testing
- AI agent functionality testing

## Deployment Assets

### Docker Configuration
```
Dockerfile             # Container configuration
docker-compose.yml     # Multi-service setup
```

### CI/CD Configuration
```
.github/workflows/     # GitHub Actions workflows
```

### Production Configuration
```
nginx.conf            # Nginx configuration
ecosystem.config.js   # PM2 configuration
```

## Security Implementation

### Authentication System
- Passport.js integration
- Session management
- Role-based access control
- API key management

### Data Protection
- Input validation and sanitization
- SQL injection prevention
- XSS protection
- CSRF protection

## Performance Optimization

### Frontend Optimization
- Code splitting and lazy loading
- Component memoization
- Virtual scrolling for large lists
- Image optimization

### Backend Optimization
- Database query optimization
- Connection pooling
- Caching strategies
- Rate limiting

## Monitoring and Logging

### Application Monitoring
- Error tracking and reporting
- Performance metrics
- User activity logging
- AI agent performance monitoring

### System Health
- Database health checks
- API response time monitoring
- Memory and CPU usage tracking
- Automated alerting

---

*All source code, AI components, help documentation, and deployment assets are included in this GitHub export for complete system reproduction.*