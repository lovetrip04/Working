-- Create custom_reports table for the advanced reports module
CREATE TABLE IF NOT EXISTS custom_reports (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    sql_query TEXT NOT NULL,
    chart_config JSONB DEFAULT '{}',
    parameters JSONB DEFAULT '[]',
    category VARCHAR(100) DEFAULT 'custom',
    is_shared BOOLEAN DEFAULT false,
    created_by VARCHAR(100) DEFAULT 'system',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_custom_reports_category ON custom_reports(category);
CREATE INDEX IF NOT EXISTS idx_custom_reports_created_by ON custom_reports(created_by);
CREATE INDEX IF NOT EXISTS idx_custom_reports_name ON custom_reports(name);

-- Insert sample reports
INSERT INTO custom_reports (name, description, sql_query, chart_config, category) VALUES
('Sales by Month', 'Monthly sales revenue analysis', 
 'SELECT DATE_TRUNC(''month'', order_date) as month, SUM(total_amount) as revenue FROM sales_orders WHERE order_date >= NOW() - INTERVAL ''12 months'' GROUP BY month ORDER BY month', 
 '{"type": "line", "title": "Sales Revenue by Month", "xLabel": "Month", "yLabel": "Revenue"}', 
 'sales'),

('Top Customers by Revenue', 'Customers with highest revenue contribution', 
 'SELECT c.name as customer_name, SUM(so.total_amount) as total_revenue FROM customers c JOIN sales_orders so ON c.id = so.customer_id GROUP BY c.id, c.name ORDER BY total_revenue DESC LIMIT 10', 
 '{"type": "bar", "title": "Top 10 Customers by Revenue", "xLabel": "Customer", "yLabel": "Revenue"}', 
 'sales'),

('Inventory Levels by Category', 'Current inventory levels grouped by material category', 
 'SELECT cat.name as category, SUM(inv.quantity) as total_quantity FROM inventory inv JOIN materials m ON inv.material_id = m.id JOIN categories cat ON m.category_id = cat.id GROUP BY cat.id, cat.name ORDER BY total_quantity DESC', 
 '{"type": "pie", "title": "Inventory Distribution by Category"}', 
 'inventory'),

('Cost Center Expenses', 'Expenses by cost center for current year', 
 'SELECT cc.name as cost_center, SUM(e.amount) as total_expenses FROM cost_centers cc LEFT JOIN expenses e ON cc.id = e.cost_center_id WHERE EXTRACT(YEAR FROM e.expense_date) = EXTRACT(YEAR FROM NOW()) GROUP BY cc.id, cc.name ORDER BY total_expenses DESC', 
 '{"type": "column", "title": "Expenses by Cost Center", "xLabel": "Cost Center", "yLabel": "Amount"}', 
 'finance'),

('Purchase Orders by Vendor', 'Purchase order volumes by vendor', 
 'SELECT v.name as vendor_name, COUNT(po.id) as order_count, SUM(po.total_amount) as total_amount FROM vendors v JOIN purchase_orders po ON v.id = po.vendor_id GROUP BY v.id, v.name ORDER BY total_amount DESC LIMIT 15', 
 '{"type": "stacked_bar", "title": "Purchase Orders by Vendor", "xLabel": "Vendor", "yLabel": "Count/Amount"}', 
 'purchase');

-- Update timestamp trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_custom_reports_updated_at 
    BEFORE UPDATE ON custom_reports 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();