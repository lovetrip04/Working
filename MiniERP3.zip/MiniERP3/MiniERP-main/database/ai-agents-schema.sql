-- AI Agents Database Schema
-- This file contains all table definitions for storing AI agent information

-- AI Agent Configurations Table
CREATE TABLE IF NOT EXISTS ai_agent_configs (
    id SERIAL PRIMARY KEY,
    module_type VARCHAR(50) UNIQUE NOT NULL,
    module_name VARCHAR(100) NOT NULL,
    agent_name VARCHAR(100) NOT NULL,
    role_description TEXT NOT NULL,
    system_prompt TEXT NOT NULL,
    expertise_areas JSONB NOT NULL,
    capabilities JSONB NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- AI Agent Chat Sessions Table
CREATE TABLE IF NOT EXISTS ai_chat_sessions (
    id SERIAL PRIMARY KEY,
    session_id UUID UNIQUE DEFAULT gen_random_uuid(),
    module_type VARCHAR(50) NOT NULL,
    user_id INTEGER,
    user_role VARCHAR(50),
    context_data JSONB,
    session_start TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    session_end TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    FOREIGN KEY (module_type) REFERENCES ai_agent_configs(module_type)
);

-- AI Agent Chat Messages Table
CREATE TABLE IF NOT EXISTS ai_chat_messages (
    id SERIAL PRIMARY KEY,
    session_id UUID NOT NULL,
    message_type VARCHAR(20) NOT NULL CHECK (message_type IN ('user', 'agent')),
    content TEXT NOT NULL,
    agent_name VARCHAR(100),
    context_data JSONB,
    api_response_time INTEGER, -- in milliseconds
    tokens_used INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES ai_chat_sessions(session_id) ON DELETE CASCADE
);

-- AI Agent Analytics Table
CREATE TABLE IF NOT EXISTS ai_agent_analytics (
    id SERIAL PRIMARY KEY,
    module_type VARCHAR(50) NOT NULL,
    date DATE DEFAULT CURRENT_DATE,
    total_queries INTEGER DEFAULT 0,
    successful_queries INTEGER DEFAULT 0,
    failed_queries INTEGER DEFAULT 0,
    avg_response_time DECIMAL(10,2),
    total_tokens_used INTEGER DEFAULT 0,
    unique_users INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (module_type) REFERENCES ai_agent_configs(module_type),
    UNIQUE(module_type, date)
);

-- AI Agent Data Analysis Sessions Table
CREATE TABLE IF NOT EXISTS ai_data_analysis_sessions (
    id SERIAL PRIMARY KEY,
    session_id UUID UNIQUE DEFAULT gen_random_uuid(),
    module_type VARCHAR(50) NOT NULL,
    analysis_type VARCHAR(50) NOT NULL,
    input_data JSONB NOT NULL,
    analysis_result TEXT,
    insights JSONB,
    recommendations JSONB,
    user_id INTEGER,
    processing_time INTEGER, -- in milliseconds
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE,
    FOREIGN KEY (module_type) REFERENCES ai_agent_configs(module_type)
);

-- AI Agent System Health Table
CREATE TABLE IF NOT EXISTS ai_agent_health (
    id SERIAL PRIMARY KEY,
    check_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    openai_status VARCHAR(20) NOT NULL,
    api_key_status VARCHAR(20) NOT NULL,
    total_agents INTEGER NOT NULL,
    active_agents INTEGER NOT NULL,
    response_time INTEGER, -- in milliseconds
    error_details JSONB
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_ai_chat_sessions_module_type ON ai_chat_sessions(module_type);
CREATE INDEX IF NOT EXISTS idx_ai_chat_sessions_user_id ON ai_chat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_chat_messages_session_id ON ai_chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_ai_chat_messages_created_at ON ai_chat_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_ai_agent_analytics_module_date ON ai_agent_analytics(module_type, date);
CREATE INDEX IF NOT EXISTS idx_ai_data_analysis_module_type ON ai_data_analysis_sessions(module_type);
CREATE INDEX IF NOT EXISTS idx_ai_agent_health_timestamp ON ai_agent_health(check_timestamp);

-- Comments for documentation
COMMENT ON TABLE ai_agent_configs IS 'Stores configuration and metadata for each AI agent module';
COMMENT ON TABLE ai_chat_sessions IS 'Tracks individual chat sessions with AI agents';
COMMENT ON TABLE ai_chat_messages IS 'Stores all messages exchanged between users and AI agents';
COMMENT ON TABLE ai_agent_analytics IS 'Daily analytics and metrics for AI agent usage';
COMMENT ON TABLE ai_data_analysis_sessions IS 'Records of data analysis requests and results';
COMMENT ON TABLE ai_agent_health IS 'System health monitoring for AI agent infrastructure';