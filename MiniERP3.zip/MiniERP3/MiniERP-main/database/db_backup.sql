--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: approval_status; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.approval_status AS ENUM (
    'draft',
    'pending_approval',
    'approved',
    'rejected',
    'superseded'
);


ALTER TYPE public.approval_status OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: approval_levels; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.approval_levels (
    id integer NOT NULL,
    level integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    value_limit numeric(15,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.approval_levels OWNER TO neondb_owner;

--
-- Name: approval_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.approval_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.approval_levels_id_seq OWNER TO neondb_owner;

--
-- Name: approval_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.approval_levels_id_seq OWNED BY public.approval_levels.id;


--
-- Name: asset_master; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.asset_master (
    id integer NOT NULL,
    asset_number character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    asset_class character varying(50),
    acquisition_date date,
    acquisition_cost numeric(15,2),
    current_value numeric(15,2),
    depreciation_method character varying(50),
    useful_life_years integer,
    company_code_id integer,
    cost_center_id integer,
    location character varying(100),
    status character varying(20),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.asset_master OWNER TO neondb_owner;

--
-- Name: asset_master_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.asset_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.asset_master_id_seq OWNER TO neondb_owner;

--
-- Name: asset_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.asset_master_id_seq OWNED BY public.asset_master.id;


--
-- Name: bill_of_materials; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.bill_of_materials (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    material_id integer NOT NULL,
    description text,
    version character varying(10) DEFAULT '1.0'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bill_of_materials OWNER TO neondb_owner;

--
-- Name: bill_of_materials_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.bill_of_materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bill_of_materials_id_seq OWNER TO neondb_owner;

--
-- Name: bill_of_materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.bill_of_materials_id_seq OWNED BY public.bill_of_materials.id;


--
-- Name: bom_items; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.bom_items (
    id integer NOT NULL,
    bom_id integer NOT NULL,
    material_id integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    unit_cost numeric(15,2),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bom_items OWNER TO neondb_owner;

--
-- Name: bom_items_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.bom_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bom_items_id_seq OWNER TO neondb_owner;

--
-- Name: bom_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.bom_items_id_seq OWNED BY public.bom_items.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.categories OWNER TO neondb_owner;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO neondb_owner;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    account_type character varying(30) NOT NULL,
    account_subtype character varying(50),
    account_group character varying(50),
    balance_sheet_category character varying(50),
    income_statement_category character varying(50),
    debit_credit character varying(10),
    is_balance_sheet boolean DEFAULT true,
    is_income_statement boolean DEFAULT false,
    is_cash_flow boolean DEFAULT false,
    is_tax_relevant boolean DEFAULT false,
    is_control_account boolean DEFAULT false,
    is_reconciliation_required boolean DEFAULT false,
    is_active boolean DEFAULT true,
    company_code_id integer NOT NULL,
    parent_account_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    notes text
);


ALTER TABLE public.chart_of_accounts OWNER TO neondb_owner;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chart_of_accounts_id_seq OWNER TO neondb_owner;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;


--
-- Name: company_codes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.company_codes (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    currency text NOT NULL,
    country text NOT NULL,
    tax_id text,
    fiscal_year text NOT NULL,
    address text,
    city text,
    state text,
    postal_code text,
    phone text,
    email text,
    website text,
    logo_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    notes text
);


ALTER TABLE public.company_codes OWNER TO neondb_owner;

--
-- Name: company_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.company_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_codes_id_seq OWNER TO neondb_owner;

--
-- Name: company_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.company_codes_id_seq OWNED BY public.company_codes.id;


--
-- Name: cost_centers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.cost_centers (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    company_code_id integer,
    description text,
    manager character varying(100),
    department character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cost_centers OWNER TO neondb_owner;

--
-- Name: cost_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.cost_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cost_centers_id_seq OWNER TO neondb_owner;

--
-- Name: cost_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.cost_centers_id_seq OWNED BY public.cost_centers.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    code character varying(2) NOT NULL,
    name character varying(100) NOT NULL,
    region_id integer,
    currency_code character varying(3),
    language_code character varying(5),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.countries OWNER TO neondb_owner;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.countries_id_seq OWNER TO neondb_owner;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: credit_control_areas; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.credit_control_areas (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    company_code_id integer NOT NULL,
    credit_checking_group character varying(50),
    credit_period integer DEFAULT 30,
    grace_percentage numeric DEFAULT 10,
    blocking_reason character varying(100),
    review_frequency character varying(20) DEFAULT 'monthly'::character varying,
    currency character varying(3) DEFAULT 'USD'::character varying,
    credit_approver character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    is_active boolean DEFAULT true,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer
);


ALTER TABLE public.credit_control_areas OWNER TO neondb_owner;

--
-- Name: credit_control_areas_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.credit_control_areas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_control_areas_id_seq OWNER TO neondb_owner;

--
-- Name: credit_control_areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.credit_control_areas_id_seq OWNED BY public.credit_control_areas.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.currencies (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    symbol text NOT NULL,
    decimal_places text NOT NULL,
    conversion_rate text NOT NULL,
    base_currency boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    notes text
);


ALTER TABLE public.currencies OWNER TO neondb_owner;

--
-- Name: currencies_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.currencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.currencies_id_seq OWNER TO neondb_owner;

--
-- Name: currencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.currencies_id_seq OWNED BY public.currencies.id;


--
-- Name: customer_contacts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.customer_contacts (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    "position" character varying(100),
    department character varying(100),
    email character varying(100),
    phone character varying(30),
    mobile character varying(30),
    is_primary boolean DEFAULT false,
    is_billing boolean DEFAULT false,
    is_shipping boolean DEFAULT false,
    is_technical boolean DEFAULT false,
    is_marketing boolean DEFAULT false,
    preferred_language character varying(50) DEFAULT 'English'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer
);


ALTER TABLE public.customer_contacts OWNER TO neondb_owner;

--
-- Name: customer_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.customer_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_contacts_id_seq OWNER TO neondb_owner;

--
-- Name: customer_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.customer_contacts_id_seq OWNED BY public.customer_contacts.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    address text NOT NULL,
    notes text,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.customers OWNER TO neondb_owner;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO neondb_owner;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    employee_id character varying(20) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(100),
    phone character varying(20),
    department character varying(100),
    "position" character varying(100),
    company_code_id integer,
    cost_center_id integer,
    join_date date,
    manager_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.employees OWNER TO neondb_owner;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO neondb_owner;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: erp_customer_contacts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.erp_customer_contacts (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    "position" character varying(100),
    department character varying(100),
    email character varying(100),
    phone character varying(30),
    mobile character varying(30),
    is_primary boolean DEFAULT false,
    is_billing boolean DEFAULT false,
    is_shipping boolean DEFAULT false,
    is_technical boolean DEFAULT false,
    is_marketing boolean DEFAULT false,
    preferred_language character varying(50) DEFAULT 'English'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer
);


ALTER TABLE public.erp_customer_contacts OWNER TO neondb_owner;

--
-- Name: erp_customer_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.erp_customer_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.erp_customer_contacts_id_seq OWNER TO neondb_owner;

--
-- Name: erp_customer_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.erp_customer_contacts_id_seq OWNED BY public.erp_customer_contacts.id;


--
-- Name: erp_customers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.erp_customers (
    id integer NOT NULL,
    customer_code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    tax_id character varying(50),
    industry character varying(50),
    segment character varying(50),
    address text,
    city character varying(100),
    state character varying(50),
    country character varying(50),
    postal_code character varying(20),
    region character varying(50),
    phone character varying(30),
    alt_phone character varying(30),
    email character varying(100),
    website character varying(255),
    currency character varying(10),
    payment_terms character varying(50),
    payment_method character varying(50),
    credit_limit numeric,
    credit_rating character varying(10),
    discount_group character varying(50),
    price_group character varying(50),
    incoterms character varying(20),
    shipping_method character varying(50),
    delivery_terms character varying(100),
    delivery_route character varying(100),
    sales_rep_id integer,
    parent_customer_id integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    is_b2b boolean DEFAULT true,
    is_b2c boolean DEFAULT false,
    is_vip boolean DEFAULT false,
    notes text,
    tags text[],
    company_code_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.erp_customers OWNER TO neondb_owner;

--
-- Name: erp_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.erp_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.erp_customers_id_seq OWNER TO neondb_owner;

--
-- Name: erp_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.erp_customers_id_seq OWNED BY public.erp_customers.id;


--
-- Name: erp_vendor_contacts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.erp_vendor_contacts (
    id integer NOT NULL,
    vendor_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    "position" character varying(100),
    department character varying(100),
    email character varying(100),
    phone character varying(30),
    mobile character varying(30),
    is_primary boolean DEFAULT false,
    is_order_contact boolean DEFAULT false,
    is_purchase_contact boolean DEFAULT false,
    is_quality_contact boolean DEFAULT false,
    is_accounts_contact boolean DEFAULT false,
    preferred_language character varying(50) DEFAULT 'English'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer
);


ALTER TABLE public.erp_vendor_contacts OWNER TO neondb_owner;

--
-- Name: erp_vendor_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.erp_vendor_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.erp_vendor_contacts_id_seq OWNER TO neondb_owner;

--
-- Name: erp_vendor_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.erp_vendor_contacts_id_seq OWNED BY public.erp_vendor_contacts.id;


--
-- Name: erp_vendors; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.erp_vendors (
    id integer NOT NULL,
    vendor_code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    tax_id character varying(50),
    industry character varying(50),
    address text,
    city character varying(100),
    state character varying(50),
    country character varying(50),
    postal_code character varying(20),
    region character varying(50),
    phone character varying(30),
    alt_phone character varying(30),
    email character varying(100),
    website character varying(255),
    currency character varying(10),
    payment_terms character varying(50),
    payment_method character varying(50),
    supplier_type character varying(50),
    category character varying(50),
    order_frequency character varying(50),
    minimum_order_value numeric,
    evaluation_score numeric,
    lead_time integer,
    purchasing_group_id integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    blacklisted boolean DEFAULT false,
    blacklist_reason text,
    notes text,
    tags text[],
    company_code_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.erp_vendors OWNER TO neondb_owner;

--
-- Name: erp_vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.erp_vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.erp_vendors_id_seq OWNER TO neondb_owner;

--
-- Name: erp_vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.erp_vendors_id_seq OWNED BY public.erp_vendors.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    amount double precision NOT NULL,
    category text NOT NULL,
    description text NOT NULL,
    payment_method text NOT NULL,
    reference text,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.expenses OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO neondb_owner;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: fiscal_periods; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.fiscal_periods (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    version integer DEFAULT 1,
    year integer NOT NULL,
    period integer NOT NULL,
    name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status character varying(50) DEFAULT 'Open'::character varying,
    company_code_id integer
);


ALTER TABLE public.fiscal_periods OWNER TO neondb_owner;

--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.fiscal_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fiscal_periods_id_seq OWNER TO neondb_owner;

--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.fiscal_periods_id_seq OWNED BY public.fiscal_periods.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    invoice_number text NOT NULL,
    order_id integer,
    issue_date timestamp without time zone DEFAULT now() NOT NULL,
    due_date timestamp without time zone NOT NULL,
    amount double precision NOT NULL,
    status text DEFAULT 'Due'::text NOT NULL,
    paid_date timestamp without time zone,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoices OWNER TO neondb_owner;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoices_id_seq OWNER TO neondb_owner;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: material_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.material_categories (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    parent_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.material_categories OWNER TO neondb_owner;

--
-- Name: material_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.material_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.material_categories_id_seq OWNER TO neondb_owner;

--
-- Name: material_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.material_categories_id_seq OWNED BY public.material_categories.id;


--
-- Name: materials; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.materials (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    long_description text,
    type character varying(50) NOT NULL,
    uom_id integer NOT NULL,
    category_id integer,
    weight numeric,
    weight_uom_id integer,
    dimensions jsonb,
    base_unit_price numeric,
    cost numeric,
    min_order_qty numeric,
    order_multiple numeric,
    procurement_type character varying(20),
    min_stock numeric DEFAULT 0,
    max_stock numeric,
    reorder_point numeric,
    lead_time integer,
    shelf_life integer,
    lot_size character varying(20),
    mrp_type character varying(30),
    planning_policy character varying(30),
    is_active boolean DEFAULT true,
    is_sellable boolean DEFAULT false,
    is_purchasable boolean DEFAULT false,
    is_manufactured boolean DEFAULT false,
    is_stockable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.materials OWNER TO neondb_owner;

--
-- Name: materials_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.materials_id_seq OWNER TO neondb_owner;

--
-- Name: materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.materials_id_seq OWNED BY public.materials.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer,
    product_id integer,
    quantity integer NOT NULL,
    unit_price double precision NOT NULL,
    total double precision NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.order_items OWNER TO neondb_owner;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO neondb_owner;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    order_number text NOT NULL,
    customer_id integer,
    date timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'Processing'::text NOT NULL,
    total double precision NOT NULL,
    notes text,
    shipping_address text,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.orders OWNER TO neondb_owner;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO neondb_owner;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: plants; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.plants (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    company_code_id integer NOT NULL,
    type text NOT NULL,
    category text,
    address text,
    city text,
    state text,
    country text,
    postal_code text,
    phone text,
    email text,
    manager text,
    timezone text,
    operating_hours text,
    coordinates text,
    status text DEFAULT 'active'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    notes text
);


ALTER TABLE public.plants OWNER TO neondb_owner;

--
-- Name: plants_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.plants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plants_id_seq OWNER TO neondb_owner;

--
-- Name: plants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.plants_id_seq OWNED BY public.plants.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    description text,
    price double precision NOT NULL,
    cost double precision NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    min_stock integer DEFAULT 10 NOT NULL,
    category_id integer,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.products OWNER TO neondb_owner;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO neondb_owner;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: profit_centers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.profit_centers (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    company_code_id integer,
    description text,
    manager character varying(100),
    segment character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.profit_centers OWNER TO neondb_owner;

--
-- Name: profit_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.profit_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.profit_centers_id_seq OWNER TO neondb_owner;

--
-- Name: profit_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.profit_centers_id_seq OWNED BY public.profit_centers.id;


--
-- Name: purchase_groups; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.purchase_groups (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by text,
    updated_by text,
    version integer DEFAULT 1 NOT NULL,
    valid_from timestamp without time zone DEFAULT now() NOT NULL,
    valid_to timestamp without time zone
);


ALTER TABLE public.purchase_groups OWNER TO neondb_owner;

--
-- Name: purchase_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.purchase_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_groups_id_seq OWNER TO neondb_owner;

--
-- Name: purchase_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.purchase_groups_id_seq OWNED BY public.purchase_groups.id;


--
-- Name: purchase_organizations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.purchase_organizations (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    company_code_id integer NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying,
    purchasing_manager character varying(100),
    email character varying(100),
    phone character varying(50),
    address text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1,
    valid_from date DEFAULT CURRENT_DATE,
    valid_to date,
    purchasing_group text,
    supply_type text,
    approval_level text,
    city text,
    state text,
    country text,
    postal_code text,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    manager text
);


ALTER TABLE public.purchase_organizations OWNER TO neondb_owner;

--
-- Name: purchase_organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.purchase_organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_organizations_id_seq OWNER TO neondb_owner;

--
-- Name: purchase_organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.purchase_organizations_id_seq OWNED BY public.purchase_organizations.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.regions (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.regions OWNER TO neondb_owner;

--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.regions_id_seq OWNER TO neondb_owner;

--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: sales_organizations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sales_organizations (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    company_code_id integer NOT NULL,
    currency text DEFAULT 'USD'::text,
    region text,
    distribution_channel text,
    industry text,
    address text,
    city text,
    state text,
    country text,
    postal_code text,
    phone text,
    email text,
    manager text,
    status text DEFAULT 'active'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.sales_organizations OWNER TO neondb_owner;

--
-- Name: sales_organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.sales_organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_organizations_id_seq OWNER TO neondb_owner;

--
-- Name: sales_organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.sales_organizations_id_seq OWNED BY public.sales_organizations.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    product_id integer,
    type text NOT NULL,
    quantity integer NOT NULL,
    reason text NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stock_movements OWNER TO neondb_owner;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO neondb_owner;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.storage_locations (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    plant_id integer NOT NULL,
    type text NOT NULL,
    is_mrp_relevant boolean DEFAULT true NOT NULL,
    is_negative_stock_allowed boolean DEFAULT false NOT NULL,
    is_goods_receipt_relevant boolean DEFAULT true NOT NULL,
    is_goods_issue_relevant boolean DEFAULT true NOT NULL,
    is_interim_storage boolean DEFAULT false NOT NULL,
    is_transit_storage boolean DEFAULT false NOT NULL,
    is_restricted_use boolean DEFAULT false NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    notes text
);


ALTER TABLE public.storage_locations OWNER TO neondb_owner;

--
-- Name: storage_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.storage_locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.storage_locations_id_seq OWNER TO neondb_owner;

--
-- Name: storage_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.storage_locations_id_seq OWNED BY public.storage_locations.id;


--
-- Name: supply_types; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.supply_types (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by text,
    updated_by text,
    version integer DEFAULT 1 NOT NULL,
    valid_from timestamp without time zone DEFAULT now() NOT NULL,
    valid_to timestamp without time zone
);


ALTER TABLE public.supply_types OWNER TO neondb_owner;

--
-- Name: supply_types_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.supply_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supply_types_id_seq OWNER TO neondb_owner;

--
-- Name: supply_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.supply_types_id_seq OWNED BY public.supply_types.id;


--
-- Name: tax_codes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tax_codes (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(2) NOT NULL,
    tax_type character varying(20) NOT NULL,
    percentage numeric(5,2) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tax_codes OWNER TO neondb_owner;

--
-- Name: tax_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tax_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tax_codes_id_seq OWNER TO neondb_owner;

--
-- Name: tax_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tax_codes_id_seq OWNED BY public.tax_codes.id;


--
-- Name: units_of_measure; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.units_of_measure (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    dimension character varying(50),
    conversion_factor numeric(15,5) DEFAULT 1.0,
    base_uom_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    version integer DEFAULT 1
);


ALTER TABLE public.units_of_measure OWNER TO neondb_owner;

--
-- Name: units_of_measure_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.units_of_measure_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.units_of_measure_id_seq OWNER TO neondb_owner;

--
-- Name: units_of_measure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.units_of_measure_id_seq OWNED BY public.units_of_measure.id;


--
-- Name: uom; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.uom (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    is_base boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text
);


ALTER TABLE public.uom OWNER TO neondb_owner;

--
-- Name: uom_conversions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.uom_conversions (
    id integer NOT NULL,
    from_uom_id integer NOT NULL,
    to_uom_id integer NOT NULL,
    conversion_factor numeric NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text
);


ALTER TABLE public.uom_conversions OWNER TO neondb_owner;

--
-- Name: uom_conversions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.uom_conversions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.uom_conversions_id_seq OWNER TO neondb_owner;

--
-- Name: uom_conversions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.uom_conversions_id_seq OWNED BY public.uom_conversions.id;


--
-- Name: uom_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.uom_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.uom_id_seq OWNER TO neondb_owner;

--
-- Name: uom_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.uom_id_seq OWNED BY public.uom.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vendor_contacts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.vendor_contacts (
    id integer NOT NULL,
    vendor_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    "position" character varying(100),
    department character varying(100),
    email character varying(100),
    phone character varying(30),
    mobile character varying(30),
    is_primary boolean DEFAULT false,
    is_order_contact boolean DEFAULT false,
    is_purchase_contact boolean DEFAULT false,
    is_quality_contact boolean DEFAULT false,
    is_accounts_contact boolean DEFAULT false,
    preferred_language character varying(50) DEFAULT 'English'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer
);


ALTER TABLE public.vendor_contacts OWNER TO neondb_owner;

--
-- Name: vendor_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.vendor_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vendor_contacts_id_seq OWNER TO neondb_owner;

--
-- Name: vendor_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.vendor_contacts_id_seq OWNED BY public.vendor_contacts.id;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.vendors (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    tax_id character varying(50),
    industry character varying(50),
    address text,
    city character varying(100),
    state character varying(50),
    country character varying(50),
    postal_code character varying(20),
    region character varying(50),
    phone character varying(30),
    alt_phone character varying(30),
    email character varying(100),
    website character varying(255),
    currency character varying(10),
    payment_terms character varying(50),
    payment_method character varying(50),
    supplier_type character varying(50),
    category character varying(50),
    order_frequency character varying(50),
    minimum_order_value numeric,
    evaluation_score numeric,
    lead_time integer,
    purchasing_group_id integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    blacklisted boolean DEFAULT false,
    blacklist_reason text,
    notes text,
    tags text[],
    company_code_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.vendors OWNER TO neondb_owner;

--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vendors_id_seq OWNER TO neondb_owner;

--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: work_centers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.work_centers (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    plant_id integer,
    description text,
    capacity numeric(10,2),
    capacity_unit character varying(20),
    cost_rate numeric(15,2),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying
);


ALTER TABLE public.work_centers OWNER TO neondb_owner;

--
-- Name: work_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.work_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.work_centers_id_seq OWNER TO neondb_owner;

--
-- Name: work_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.work_centers_id_seq OWNED BY public.work_centers.id;


--
-- Name: approval_levels id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.approval_levels ALTER COLUMN id SET DEFAULT nextval('public.approval_levels_id_seq'::regclass);


--
-- Name: asset_master id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.asset_master ALTER COLUMN id SET DEFAULT nextval('public.asset_master_id_seq'::regclass);


--
-- Name: bill_of_materials id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bill_of_materials ALTER COLUMN id SET DEFAULT nextval('public.bill_of_materials_id_seq'::regclass);


--
-- Name: bom_items id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bom_items ALTER COLUMN id SET DEFAULT nextval('public.bom_items_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: chart_of_accounts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);


--
-- Name: company_codes id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.company_codes ALTER COLUMN id SET DEFAULT nextval('public.company_codes_id_seq'::regclass);


--
-- Name: cost_centers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cost_centers ALTER COLUMN id SET DEFAULT nextval('public.cost_centers_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: credit_control_areas id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_control_areas ALTER COLUMN id SET DEFAULT nextval('public.credit_control_areas_id_seq'::regclass);


--
-- Name: currencies id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.currencies ALTER COLUMN id SET DEFAULT nextval('public.currencies_id_seq'::regclass);


--
-- Name: customer_contacts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customer_contacts ALTER COLUMN id SET DEFAULT nextval('public.customer_contacts_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: erp_customer_contacts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_customer_contacts ALTER COLUMN id SET DEFAULT nextval('public.erp_customer_contacts_id_seq'::regclass);


--
-- Name: erp_customers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_customers ALTER COLUMN id SET DEFAULT nextval('public.erp_customers_id_seq'::regclass);


--
-- Name: erp_vendor_contacts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_vendor_contacts ALTER COLUMN id SET DEFAULT nextval('public.erp_vendor_contacts_id_seq'::regclass);


--
-- Name: erp_vendors id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_vendors ALTER COLUMN id SET DEFAULT nextval('public.erp_vendors_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: fiscal_periods id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.fiscal_periods ALTER COLUMN id SET DEFAULT nextval('public.fiscal_periods_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: material_categories id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.material_categories ALTER COLUMN id SET DEFAULT nextval('public.material_categories_id_seq'::regclass);


--
-- Name: materials id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.materials ALTER COLUMN id SET DEFAULT nextval('public.materials_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: plants id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plants ALTER COLUMN id SET DEFAULT nextval('public.plants_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: profit_centers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.profit_centers ALTER COLUMN id SET DEFAULT nextval('public.profit_centers_id_seq'::regclass);


--
-- Name: purchase_groups id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_groups ALTER COLUMN id SET DEFAULT nextval('public.purchase_groups_id_seq'::regclass);


--
-- Name: purchase_organizations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_organizations ALTER COLUMN id SET DEFAULT nextval('public.purchase_organizations_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: sales_organizations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales_organizations ALTER COLUMN id SET DEFAULT nextval('public.sales_organizations_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: storage_locations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.storage_locations ALTER COLUMN id SET DEFAULT nextval('public.storage_locations_id_seq'::regclass);


--
-- Name: supply_types id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.supply_types ALTER COLUMN id SET DEFAULT nextval('public.supply_types_id_seq'::regclass);


--
-- Name: tax_codes id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tax_codes ALTER COLUMN id SET DEFAULT nextval('public.tax_codes_id_seq'::regclass);


--
-- Name: units_of_measure id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.units_of_measure ALTER COLUMN id SET DEFAULT nextval('public.units_of_measure_id_seq'::regclass);


--
-- Name: uom id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.uom ALTER COLUMN id SET DEFAULT nextval('public.uom_id_seq'::regclass);


--
-- Name: uom_conversions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.uom_conversions ALTER COLUMN id SET DEFAULT nextval('public.uom_conversions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vendor_contacts id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vendor_contacts ALTER COLUMN id SET DEFAULT nextval('public.vendor_contacts_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Name: work_centers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.work_centers ALTER COLUMN id SET DEFAULT nextval('public.work_centers_id_seq'::regclass);


--
-- Data for Name: approval_levels; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.approval_levels (id, level, name, description, value_limit, created_at, updated_at) FROM stdin;
1	1	Team Lead	First level approval - up to $5,000	5000.00	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924
2	2	Department Manager	Second level approval - up to $25,000	25000.00	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924
3	3	Director	Third level approval - up to $100,000	100000.00	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924
4	4	VP	Fourth level approval - up to $500,000	500000.00	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924
5	5	CFO	Fifth level approval - unlimited	\N	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924
6	1	Solutions		500.00	2025-05-21 01:42:12.929446	2025-05-21 01:42:12.929446
7	1	Team Lead Approval	First level approval for small purchases	1000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801
8	2	Manager Approval	Second level approval for medium purchases	10000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801
9	3	Director Approval	Third level approval for large purchases	50000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801
10	4	Executive Approval	Fourth level approval for very large purchases	250000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801
11	5	Board Approval	Highest level approval for major expenditures	1000000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801
\.


--
-- Data for Name: asset_master; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.asset_master (id, asset_number, name, description, asset_class, acquisition_date, acquisition_cost, current_value, depreciation_method, useful_life_years, company_code_id, cost_center_id, location, status, is_active, created_at, updated_at) FROM stdin;
1	A10001	CNC Machine - Haas VF-2	Vertical machining center	MACHINERY	2019-03-15	85000.00	65000.00	STRAIGHT_LINE	10	1	\N	Plant NY - Building A	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858
2	A10002	Forklift - Toyota 8FGCU25	Material handling equipment	EQUIPMENT	2019-05-01	28000.00	21000.00	STRAIGHT_LINE	7	1	\N	Plant NY - Warehouse	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858
3	A10003	Injection Molding Machine - Engel	Plastic injection molding	MACHINERY	2019-08-15	120000.00	96000.00	STRAIGHT_LINE	12	1	\N	Plant NY - Building B	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858
4	A10004	Server System - Dell PowerEdge	Data center servers	IT_EQUIPMENT	2020-01-10	45000.00	27000.00	ACCELERATED	5	1	\N	NY Headquarters - Server Room	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858
5	A10005	Office Building - NY HQ	Main office building	REAL_ESTATE	2015-11-30	3500000.00	3200000.00	STRAIGHT_LINE	40	1	\N	Manhattan, NY	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858
6	CN01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	10	9	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215
7	DE01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	9	5	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215
8	IN01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	6	14	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215
9	GA01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	7	15	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215
10	UK01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	11	6	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215
11	TEST02-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	4	8	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308
12	DE01-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	9	5	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308
13	CA01-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	5	13	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308
14	US01-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	1	1	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308
15	EU01-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	2	10	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308
\.


--
-- Data for Name: bill_of_materials; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.bill_of_materials (id, code, name, material_id, description, version, is_active, created_at, updated_at) FROM stdin;
1	BOM-FG-3001	BOM for Smart Thermostat	9	Bill of Materials for Smart Thermostat	1.0	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
2	BOM-FG-3002	BOM for Industrial Control Panel	10	Bill of Materials for Industrial Control Panel	1.0	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
3	BOM-FG-3003	BOM for LED Light Fixture	11	Bill of Materials for LED Light Fixture	1.0	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
4	BOM-PM-4001	BOM for Cardboard Box - Small	14	Bill of materials for manufacturing Cardboard Box - Small	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118
5	BOM-FG-3004	BOM for Wireless Router	12	Bill of materials for manufacturing Wireless Router	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118
6	BOM-SF-2003	BOM for Injection Molded Housing	8	Bill of materials for manufacturing Injection Molded Housing	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118
7	BOM-FG-3005	BOM for Electric Motor	13	Bill of materials for manufacturing Electric Motor	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118
8	BOM-SF-2001	BOM for Aluminum Frame	6	Bill of materials for manufacturing Aluminum Frame	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118
\.


--
-- Data for Name: bom_items; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.bom_items (id, bom_id, material_id, quantity, unit_cost, is_active, created_at, updated_at) FROM stdin;
1	1	1	5.850	24.95	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
2	2	1	13.890	12.59	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
3	3	1	10.720	12.07	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
4	1	2	11.780	38.61	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
5	2	2	14.810	58.75	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
6	3	2	5.700	36.81	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
7	1	3	11.460	12.73	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
8	2	3	5.100	36.66	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983
9	1	4	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
10	1	5	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
11	1	6	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
12	1	7	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
13	1	8	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
14	1	10	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
15	1	11	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
16	1	12	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
17	1	13	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
18	1	14	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.categories (id, name, description, user_id, created_at, updated_at) FROM stdin;
1	General	General category for materials	\N	2025-05-20 14:35:23.847433	2025-05-20 14:35:23.847433
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.chart_of_accounts (id, code, name, description, account_type, account_subtype, account_group, balance_sheet_category, income_statement_category, debit_credit, is_balance_sheet, is_income_statement, is_cash_flow, is_tax_relevant, is_control_account, is_reconciliation_required, is_active, company_code_id, parent_account_id, created_at, updated_at, created_by, updated_by, version, notes) FROM stdin;
1	10000	ASSETS	Parent account for all assets	asset	\N	Assets	Assets	\N	debit	t	f	f	f	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
2	10100	Cash and Cash Equivalents	Liquid assets	asset	current_asset	Cash	Current Assets	\N	debit	t	f	t	f	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
3	10101	Cash on Hand	Physical cash	asset	current_asset	Cash	Current Assets	\N	debit	t	f	t	f	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
4	10102	Bank Account - Operations	Main operating account	asset	current_asset	Cash	Current Assets	\N	debit	t	f	t	f	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
5	10200	Accounts Receivable	Amounts owed by customers	asset	current_asset	Receivables	Current Assets	\N	debit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
6	10300	Inventory	Inventory control account	asset	current_asset	Inventory	Current Assets	\N	debit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
7	10301	Raw Materials Inventory	Raw materials in stock	asset	current_asset	Inventory	Current Assets	\N	debit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
8	10302	Work in Process Inventory	Partially completed goods	asset	current_asset	Inventory	Current Assets	\N	debit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
9	10303	Finished Goods Inventory	Completed products ready for sale	asset	current_asset	Inventory	Current Assets	\N	debit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
10	10400	Fixed Assets	Long-term tangible assets	asset	non_current_asset	Fixed Assets	Non-Current Assets	\N	debit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
11	10401	Machinery and Equipment	Production equipment	asset	non_current_asset	Fixed Assets	Non-Current Assets	\N	debit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
12	10402	Buildings	Company-owned buildings	asset	non_current_asset	Fixed Assets	Non-Current Assets	\N	debit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
13	10403	Accumulated Depreciation	Accumulated depreciation of fixed assets	asset	non_current_asset	Fixed Assets	Non-Current Assets	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
14	20000	LIABILITIES	Parent account for all liabilities	liability	\N	Liabilities	Liabilities	\N	credit	t	f	f	f	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
15	20100	Accounts Payable	Amounts owed to suppliers	liability	current_liability	Payables	Current Liabilities	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
16	20200	Accrued Expenses	Expenses incurred but not yet paid	liability	current_liability	Accruals	Current Liabilities	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
17	20300	Short-term Loans	Loans due within one year	liability	current_liability	Loans	Current Liabilities	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
18	20400	Long-term Loans	Loans due beyond one year	liability	non_current_liability	Loans	Non-Current Liabilities	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
19	20500	Deferred Revenue	Payments received for goods/services not yet provided	liability	current_liability	Deferred	Current Liabilities	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
20	30000	EQUITY	Parent account for all equity	equity	\N	Equity	Equity	\N	credit	t	f	f	f	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
21	30100	Share Capital	Capital from shareholders	equity	owner_equity	Capital	Equity	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
22	30200	Retained Earnings	Accumulated earnings	equity	retained_earnings	Earnings	Equity	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
23	30300	Current Year Earnings	Current year profit/loss	equity	retained_earnings	Earnings	Equity	\N	credit	t	f	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
24	40000	REVENUE	Parent account for all revenue	revenue	\N	Revenue	\N	Revenue	credit	f	t	f	f	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
25	40100	Sales Revenue - Products	Revenue from product sales	revenue	operating_revenue	Sales	\N	Operating Revenue	credit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
26	40200	Sales Revenue - Services	Revenue from service delivery	revenue	operating_revenue	Sales	\N	Operating Revenue	credit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
27	40300	Other Revenue	Miscellaneous revenue sources	revenue	other_revenue	Other	\N	Other Revenue	credit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
28	50000	EXPENSES	Parent account for all expenses	expense	\N	Expenses	\N	Expenses	debit	f	t	f	f	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
29	50100	Cost of Goods Sold	Direct costs of products sold	expense	operating_expense	COGS	\N	Cost of Sales	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
30	50101	Raw Materials Consumed	Cost of raw materials used in production	expense	operating_expense	COGS	\N	Cost of Sales	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
31	50102	Direct Labor	Cost of direct production labor	expense	operating_expense	COGS	\N	Cost of Sales	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
32	50103	Manufacturing Overhead	Indirect production costs	expense	operating_expense	COGS	\N	Cost of Sales	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
33	50200	Selling Expenses	Costs related to sales activities	expense	operating_expense	Selling	\N	Operating Expenses	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
34	50300	Administrative Expenses	General business operation costs	expense	operating_expense	Admin	\N	Operating Expenses	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
35	50400	Research and Development	R&D expenses	expense	operating_expense	R&D	\N	Operating Expenses	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
36	50500	Finance Costs	Interest and other financial expenses	expense	other_expense	Finance	\N	Other Expenses	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
37	50600	Depreciation Expense	Depreciation of fixed assets	expense	operating_expense	Depreciation	\N	Operating Expenses	debit	f	t	f	t	f	f	t	2	\N	2025-05-17 15:12:41.573183	2025-05-17 15:12:41.573183	\N	\N	1	\N
\.


--
-- Data for Name: company_codes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.company_codes (id, code, name, description, currency, country, tax_id, fiscal_year, address, city, state, postal_code, phone, email, website, logo_url, is_active, created_at, created_by, updated_at, updated_by, version, notes) FROM stdin;
1	US01	ACME Corporation USA	\N	USD	United States	\N	Calendar Year (Jan-Dec)	\N	\N	\N	\N	\N	\N	\N	\N	t	2025-05-17 13:43:44.835584	\N	2025-05-17 13:43:44.835584	\N	1	\N
2	EU01	ACME Europe GmbH	\N	EUR	Germany	\N	Calendar Year (Jan-Dec)	\N	\N	\N	\N	\N	\N	\N	\N	t	2025-05-17 13:43:44.835584	\N	2025-05-17 13:43:44.835584	\N	1	\N
4	TEST02	Test Company 2	\N	USD	United States	\N	Calendar Year (Jan-Dec)	\N	\N	\N	\N	\N	\N	https://example.com	\N	t	2025-05-18 00:40:52.466	\N	2025-05-18 00:40:52.466	\N	1	\N
5	CA01	CMIS Association	CMIS Canada	CAD	Canada		Calendar Year (Jan-Dec)						\N	\N	\N	t	2025-05-18 01:05:01.453	\N	2025-05-18 01:05:01.453	\N	1	\N
7	GA01	Germany		EUR	Germany		Calendar Year (Jan-Dec)						\N	\N	\N	t	2025-05-19 21:59:41.861	\N	2025-05-19 22:00:29.936	\N	1	\N
6	IN01	India Company Code	India Company Code	INR	United States		Calendar Year (Jan-Dec)	Gandhi Road	Bangalore				\N	\N	\N	t	2025-05-19 21:48:54.52	\N	2025-05-19 22:31:18.93	\N	1	\N
3	TEST01	Mexico Company		MXN	Mexico		Calendar Year (Jan-Dec)						\N	\N	\N	t	2025-05-18 00:35:00.714	\N	2025-05-19 22:50:46.093	\N	1	\N
9	DE01	Germany Operations	European manufacturing hub	EUR	Germany	\N	2025	\N	\N	\N	\N	\N	\N	\N	\N	t	2025-05-20 03:55:35.337909	\N	2025-05-20 03:55:35.337909	\N	1	\N
10	CN01	China Operations	Asian production facility	CNY	China	\N	2025	\N	\N	\N	\N	\N	\N	\N	\N	t	2025-05-20 03:55:35.337909	\N	2025-05-20 03:55:35.337909	\N	1	\N
11	UK01	United Kingdom Branch	UK sales and distribution	GBP	United Kingdom	\N	2025	\N	\N	\N	\N	\N	\N	\N	\N	t	2025-05-20 03:55:35.337909	\N	2025-05-20 03:55:35.337909	\N	1	\N
\.


--
-- Data for Name: cost_centers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.cost_centers (id, code, name, company_code_id, description, manager, department, is_active, created_at, updated_at) FROM stdin;
1	CC-PROD-US	US Production	1	Production costs for US facilities	James Wilson	Manufacturing	t	2025-05-20 22:10:10.463336	2025-05-20 22:10:10.463336
2	CC-LOGI-US	US Logistics	1	Logistics costs for US operations	Mary Johnson	Logistics	t	2025-05-20 22:10:10.463336	2025-05-20 22:10:10.463336
3	CC-SALE-US	US Sales	1	Sales costs for US market	Robert Brown	Sales	t	2025-05-20 22:10:10.463336	2025-05-20 22:10:10.463336
4	CC-ADMI-US	US Administration	1	Administrative costs for US operations	Sarah Davis	Administration	t	2025-05-20 22:10:10.463336	2025-05-20 22:10:10.463336
5	CC-PROD-DE	Germany Production	9	Production costs for German facilities	Hans Mueller	Manufacturing	t	2025-05-20 22:10:10.463336	2025-05-20 22:10:10.463336
6	UK01-PROD	Production - United Kingdom Branch	11	Production cost center for United Kingdom Branch	John Smith	Production	t	2025-05-21 14:57:51.67185	2025-05-21 14:57:51.67185
7	TEST01-PROD	Production - Mexico Company	3	Production cost center for Mexico Company	John Smith	Production	t	2025-05-21 14:57:51.67185	2025-05-21 14:57:51.67185
8	TEST02-PROD	Production - Test Company 2	4	Production cost center for Test Company 2	John Smith	Production	t	2025-05-21 14:57:51.67185	2025-05-21 14:57:51.67185
9	CN01-PROD	Production - China Operations	10	Production cost center for China Operations	John Smith	Production	t	2025-05-21 14:57:51.67185	2025-05-21 14:57:51.67185
10	EU01-PROD	Production - ACME Europe GmbH	2	Production cost center for ACME Europe GmbH	John Smith	Production	t	2025-05-21 14:57:51.67185	2025-05-21 14:57:51.67185
11	UK01-SALES	Sales - United Kingdom Branch	11	Sales cost center for United Kingdom Branch	Jessica Williams	Sales	t	2025-05-21 14:57:59.20959	2025-05-21 14:57:59.20959
12	DE01-SALES	Sales - Germany Operations	9	Sales cost center for Germany Operations	Jessica Williams	Sales	t	2025-05-21 14:57:59.20959	2025-05-21 14:57:59.20959
13	CA01-SALES	Sales - CMIS Association	5	Sales cost center for CMIS Association	Jessica Williams	Sales	t	2025-05-21 14:57:59.20959	2025-05-21 14:57:59.20959
14	IN01-SALES	Sales - India Company Code	6	Sales cost center for India Company Code	Jessica Williams	Sales	t	2025-05-21 14:57:59.20959	2025-05-21 14:57:59.20959
15	GA01-SALES	Sales - Germany	7	Sales cost center for Germany	Jessica Williams	Sales	t	2025-05-21 14:57:59.20959	2025-05-21 14:57:59.20959
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.countries (id, code, name, region_id, currency_code, language_code, is_active, created_at, updated_at) FROM stdin;
1	MX	Mexico	1	MXN	es-MX	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
2	CA	Canada	1	CAD	en-CA	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
3	US	United States	1	USD	en-US	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
4	AR	Argentina	2	ARS	es-AR	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
5	BR	Brazil	2	BRL	pt-BR	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
6	FR	France	3	EUR	fr-FR	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
7	DE	Germany	3	EUR	de-DE	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
8	GB	United Kingdom	3	GBP	en-GB	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
9	AU	Australia	4	AUD	en-AU	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
10	IN	India	4	INR	en-IN	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
11	CN	China	4	CNY	zh-CN	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
12	JP	Japan	4	JPY	ja-JP	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
\.


--
-- Data for Name: credit_control_areas; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.credit_control_areas (id, code, name, description, company_code_id, credit_checking_group, credit_period, grace_percentage, blocking_reason, review_frequency, currency, credit_approver, status, is_active, notes, created_at, updated_at, created_by, updated_by) FROM stdin;
1	CC001	North America Credit	Credit control for North American customers	2	medium_risk	30	15	\N	monthly	USD	Michael Brown	active	t	\N	2025-05-17 14:59:22.779157	2025-05-17 14:59:22.779157	\N	\N
2	CC002	EMEA Credit	Credit control for European, Middle Eastern, and African customers	2	high_risk	45	10	\N	monthly	EUR	Emma Schmidt	active	t	\N	2025-05-17 14:59:22.779157	2025-05-17 14:59:22.779157	\N	\N
3	CC003	APAC Credit	Credit control for Asia-Pacific customers	2	low_risk	60	5	\N	monthly	USD	James Wong	active	t	\N	2025-05-17 14:59:22.779157	2025-05-17 14:59:22.779157	\N	\N
4	CC004	Strategic Customers	Strategic Customers - Credit control for VIP customers	1	VIP	60	15	\N	monthly	USD	\N	active	t	\N	2025-05-20 04:52:27.962894	2025-05-20 04:52:27.962894	\N	\N
5	CC005	UK Credit Management	UK Credit Management - Credit control for standard customers	11	standard	30	5	\N	monthly	GBP	\N	active	t	\N	2025-05-20 04:52:28.006898	2025-05-20 04:52:28.006898	\N	\N
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.currencies (id, code, name, symbol, decimal_places, conversion_rate, base_currency, is_active, created_at, updated_at, notes) FROM stdin;
1	USD	US Dollar	$	2	1.0	t	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N
2	EUR	Euro	€	2	1.08	f	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N
3	GBP	British Pound	£	2	1.27	f	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N
4	JPY	Japanese Yen	¥	0	0.0067	f	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N
5	CNY	Chinese Yuan	¥	2	0.138	f	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N
\.


--
-- Data for Name: customer_contacts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.customer_contacts (id, customer_id, first_name, last_name, "position", department, email, phone, mobile, is_primary, is_billing, is_shipping, is_technical, is_marketing, preferred_language, notes, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.customers (id, name, email, phone, address, notes, user_id, created_at, updated_at) FROM stdin;
1	Acme Corporation	orders@acme.example.com	+1-212-555-0123	123 Main Street, New York, NY 10001	Key account - has special pricing agreement	\N	2025-05-20 18:17:22.106429	2025-05-20 18:17:22.106429
2	Global Enterprises	procurement@globalent.example.com	+1-312-555-0456	456 Park Avenue, Chicago, IL 60601	High volume customer	\N	2025-05-20 18:17:22.140573	2025-05-20 18:17:22.140573
3	European Distributors Ltd	orders@eurodist.example.com	+44-20-7123-4567	1 Oxford Street, London, W1D 1BS	European distribution partner	\N	2025-05-20 18:17:22.160991	2025-05-20 18:17:22.160991
4	Tech Solutions GmbH	einkauf@techsolutions.example.de	+49-30-1234-5678	Hauptstraße 1, Berlin, 10115	German tech industry client	\N	2025-05-20 18:17:22.179183	2025-05-20 18:17:22.179183
5	Japan Manufacturing Co.	orders@japanmfg.example.jp	+81-3-1234-5678	1-1 Marunouchi, Tokyo, 100-0005	Japanese manufacturing partner	\N	2025-05-20 18:17:22.197684	2025-05-20 18:17:22.197684
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.employees (id, employee_id, first_name, last_name, email, phone, department, "position", company_code_id, cost_center_id, join_date, manager_id, is_active, created_at, updated_at) FROM stdin;
1	E1001	John	Smith	john.smith@minierp.com	212-555-1234	Executive	CEO	1	\N	2018-01-15	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641
2	E1002	Sarah	Johnson	sarah.johnson@minierp.com	212-555-2345	Finance	CFO	1	\N	2018-02-01	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641
3	E1003	Michael	Williams	michael.williams@minierp.com	212-555-3456	Operations	COO	1	\N	2018-03-15	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641
4	E1004	David	Brown	david.brown@minierp.com	212-555-4567	Manufacturing	VP Manufacturing	1	\N	2018-06-01	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641
5	E1005	Jennifer	Davis	jennifer.davis@minierp.com	212-555-5678	Sales	VP Sales	1	\N	2018-07-15	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641
8	US01-EMP2769	Emma	Johnson	emma.johnson1@example.com	+1-555-987-8217	Sales	Sales Manager	1	3	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057
9	EU01-EMP9748	Emma	Johnson	emma.johnson2@example.com	+1-555-987-8928	Sales	Sales Manager	2	\N	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057
10	TEST02-EMP9857	Emma	Johnson	emma.johnson4@example.com	+1-555-987-1855	Sales	Sales Manager	4	\N	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057
11	CA01-EMP8109	Emma	Johnson	emma.johnson5@example.com	+1-555-987-5968	Sales	Sales Manager	5	13	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057
12	GA01-EMP6705	Emma	Johnson	emma.johnson7@example.com	+1-555-987-5673	Sales	Sales Manager	7	15	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057
\.


--
-- Data for Name: erp_customer_contacts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.erp_customer_contacts (id, customer_id, first_name, last_name, "position", department, email, phone, mobile, is_primary, is_billing, is_shipping, is_technical, is_marketing, preferred_language, notes, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
1	1	James	Wilson	Purchasing Manager	Procurement	james.wilson@acmecorp.com	+1-312-555-1235	\N	t	f	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
2	1	Sarah	Johnson	Accounts Payable Manager	Finance	sarah.johnson@acmecorp.com	+1-312-555-1236	\N	f	t	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
3	1	Robert	Davis	Logistics Coordinator	Operations	robert.davis@acmecorp.com	+1-312-555-1237	\N	f	f	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
4	2	Michael	Brown	Director of Merchandising	Purchasing	michael.brown@globalretail.com	+1-212-555-2346	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
5	2	Emily	Taylor	Supply Chain Manager	Operations	emily.taylor@globalretail.com	+1-212-555-2347	\N	f	f	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
6	3	David	Martinez	Head of Procurement	Administration	david.martinez@cityhospital.org	+1-617-555-3457	\N	t	t	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
7	4	Lisa	Anderson	Operations Director	Operations	lisa.anderson@techinnovate.com	+1-415-555-4568	\N	t	t	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
8	6	Thomas	Washington	Procurement Officer	Acquisitions	thomas.washington@gov.agency.gov	+1-202-555-6790	\N	t	f	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
9	6	Jennifer	Adams	Financial Officer	Finance	jennifer.adams@gov.agency.gov	+1-202-555-6791	\N	f	t	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
10	7	Klaus	Schmidt	International Sales Director	Sales	klaus.schmidt@eurodist.eu	+49-30-555-7891	\N	t	t	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N
\.


--
-- Data for Name: erp_customers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.erp_customers (id, customer_code, name, type, description, tax_id, industry, segment, address, city, state, country, postal_code, region, phone, alt_phone, email, website, currency, payment_terms, payment_method, credit_limit, credit_rating, discount_group, price_group, incoterms, shipping_method, delivery_terms, delivery_route, sales_rep_id, parent_customer_id, status, is_b2b, is_b2c, is_vip, notes, tags, company_code_id, is_active, created_at, updated_at, created_by, updated_by, version) FROM stdin;
1	C1001	Acme Corporation	corporate	Large manufacturing client	123-45-6789	manufacturing	enterprise	123 Main Street	Chicago	IL	US	60601	\N	+1-312-555-1234	\N	contact@acmecorp.com	\N	USD	net_30	\N	50000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	t	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
2	C1002	Global Retailers	corporate	International retail chain	987-65-4321	retail	key_account	456 Market Ave	New York	NY	US	10001	\N	+1-212-555-2345	\N	orders@globalretail.com	\N	USD	net_45	\N	100000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	t	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
3	C1003	City Hospital	corporate	Regional medical center	456-78-9012	healthcare	mid_market	789 Health Blvd	Boston	MA	US	02110	\N	+1-617-555-3456	\N	procurement@cityhospital.org	\N	USD	net_60	\N	75000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
4	C1004	Tech Innovations	corporate	Technology startup	789-01-2345	technology	small_business	321 Tech Park	San Francisco	CA	US	94105	\N	+1-415-555-4567	\N	orders@techinnovate.com	\N	USD	net_30	\N	25000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
5	C1005	John Smith	individual	Regular customer	\N	\N	consumer	555 Residential St	Los Angeles	CA	US	90001	\N	+1-213-555-5678	\N	john.smith@email.com	\N	USD	prepaid	\N	1000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	t	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
6	C1006	Government Agency	government	Federal procurement office	GOV-123456	government	enterprise	1 Federal Plaza	Washington	DC	US	20001	\N	+1-202-555-6789	\N	procurement@gov.agency.gov	\N	USD	net_60	\N	500000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
7	C1007	European Distributors	corporate	European distribution partner	EU-8765432	distribution	strategic	10 International Blvd	Berlin	\N	DE	10115	\N	+49-30-555-7890	\N	orders@eurodist.eu	\N	EUR	net_45	\N	200000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	t	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
8	C1008	Education Foundation	non_profit	Educational institution	TAX-EXEMPT-123	education	mid_market	200 Learning Way	Atlanta	GA	US	30301	\N	+1-404-555-8901	\N	purchases@edufoundation.org	\N	USD	net_30	\N	30000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
9	C1009	Local Restaurant	corporate	Small business customer	BUS-987654	food_service	small_business	75 Culinary Lane	Miami	FL	US	33101	\N	+1-305-555-9012	\N	orders@localrestaurant.com	\N	USD	cod	\N	5000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
10	C1010	Industrial Supplies	corporate	Industrial equipment supplier	IND-456789	industrial	mid_market	800 Factory Road	Detroit	MI	US	48201	\N	+1-313-555-0123	\N	sales@industrialsupplies.com	\N	USD	net_30	\N	150000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1
\.


--
-- Data for Name: erp_vendor_contacts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.erp_vendor_contacts (id, vendor_id, first_name, last_name, "position", department, email, phone, mobile, is_primary, is_order_contact, is_purchase_contact, is_quality_contact, is_accounts_contact, preferred_language, notes, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
1	1	Richard	Steel	Sales Director	Sales	richard.steel@primesteelsupply.com	+1-412-555-1112	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
2	1	Patricia	Miller	Accounts Manager	Finance	patricia.miller@primesteelsupply.com	+1-412-555-1113	\N	f	f	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
3	2	Edward	Johnson	VP of Sales	Sales	edward.johnson@qualityelectronics.com	+1-408-555-2223	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
4	2	Michelle	Lee	Customer Relations	Customer Service	michelle.lee@qualityelectronics.com	+1-408-555-2224	\N	f	f	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
5	3	Carlos	Rodriguez	Operations Manager	Operations	carlos.rodriguez@globallogistics.com	+1-562-555-3334	\N	t	t	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
6	4	Stephanie	Clark	Sales Representative	Sales	stephanie.clark@advancedmaterials.com	+1-919-555-4445	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
7	4	Mark	Williams	Technical Support	Engineering	mark.williams@advancedmaterials.com	+1-919-555-4446	\N	f	f	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
8	5	Gregory	Phillips	Owner	Management	gregory.phillips@precisionengineering.com	+1-513-555-5556	\N	t	t	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
9	8	Mei	Chen	Export Manager	International Sales	mei.chen@asianmanufacturing.com	+86-755-5558889	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
10	8	Jian	Zhang	Quality Control Manager	Quality	jian.zhang@asianmanufacturing.com	+86-755-5558890	\N	f	f	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
11	12	Brian	Davis	Account Executive	Sales	brian.davis@softwaresolutions.com	+1-206-555-2223	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
12	12	Amanda	Wilson	Support Manager	Technical Support	amanda.wilson@softwaresolutions.com	+1-206-555-2224	\N	f	f	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N
\.


--
-- Data for Name: erp_vendors; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.erp_vendors (id, vendor_code, name, type, description, tax_id, industry, address, city, state, country, postal_code, region, phone, alt_phone, email, website, currency, payment_terms, payment_method, supplier_type, category, order_frequency, minimum_order_value, evaluation_score, lead_time, purchasing_group_id, status, blacklisted, blacklist_reason, notes, tags, company_code_id, is_active, created_at, updated_at, created_by, updated_by, version) FROM stdin;
1	V1001	Prime Steel Supply	supplier	Steel and metal supplier	PS-12345	manufacturing	100 Industrial Road	Pittsburgh	PA	US	15222	\N	+1-412-555-1111	\N	orders@primesteelsupply.com	\N	USD	net_30	\N	manufacturer	strategic	\N	\N	92	14	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
2	V1002	Quality Electronics	supplier	Electronic components supplier	QE-67890	electronics	200 Tech Avenue	San Jose	CA	US	95110	\N	+1-408-555-2222	\N	sales@qualityelectronics.com	\N	USD	net_45	\N	distributor	preferred	\N	\N	88	21	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
3	V1003	Global Logistics	service_provider	International shipping and logistics	GL-34567	transportation	300 Harbor Blvd	Long Beach	CA	US	90802	\N	+1-562-555-3333	\N	operations@globallogistics.com	\N	USD	net_30	\N	service	approved	\N	\N	95	7	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
4	V1004	Advanced Materials	supplier	Specialized manufacturing materials	AM-89012	chemicals	400 Research Parkway	Raleigh	NC	US	27601	\N	+1-919-555-4444	\N	orders@advancedmaterials.com	\N	USD	net_60	\N	manufacturer	strategic	\N	\N	90	28	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
5	V1005	Precision Engineering	contractor	Custom tooling and machining services	PE-45678	manufacturing	500 Precision Way	Cincinnati	OH	US	45202	\N	+1-513-555-5555	\N	info@precisionengineering.com	\N	USD	net_30	\N	service	preferred	\N	\N	87	35	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
6	V1006	Packaging Solutions	supplier	Industrial packaging materials	PS-90123	packaging	600 Box Street	Memphis	TN	US	38101	\N	+1-901-555-6666	\N	sales@packagingsolutions.com	\N	USD	net_30	\N	manufacturer	approved	\N	\N	83	10	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
7	V1007	Machinery Maintenance	service_provider	Equipment maintenance and repair	MM-56789	services	700 Service Road	Cleveland	OH	US	44101	\N	+1-216-555-7777	\N	service@machinerymaintenance.com	\N	USD	net_15	\N	service	approved	\N	\N	79	3	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
8	V1008	Asian Manufacturing	supplier	Overseas manufacturing partner	AM-901234	manufacturing	800 Export Zone	Shenzhen	\N	CN	518000	\N	+86-755-5558888	\N	exports@asianmanufacturing.com	\N	USD	letter_of_credit	\N	manufacturer	strategic	\N	\N	85	45	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
9	V1009	Office Supplies Co	supplier	General office and facility supplies	OSC-12345	retail	900 Retail Row	Chicago	IL	US	60602	\N	+1-312-555-9999	\N	orders@officesupplies.com	\N	USD	net_30	\N	distributor	approved	\N	\N	82	5	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
10	V1010	Unreliable Vendor	supplier	Problematic supplier with quality issues	UV-99999	manufacturing	1000 Problem Street	Phoenix	AZ	US	85001	\N	+1-602-555-0000	\N	orders@unreliablevendor.com	\N	USD	advance	\N	manufacturer	one_time	\N	\N	30	60	\N	inactive	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
11	V1011	Blacklisted Supply	supplier	Blacklisted due to contract violations	BS-00000	manufacturing	1100 Violation Road	Denver	CO	US	80201	\N	+1-303-555-1111	\N	info@blacklistedsupply.com	\N	USD	cod	\N	manufacturer	one_time	\N	\N	10	90	\N	blocked	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
12	V1012	Software Solutions	service_provider	Software and IT services provider	SS-12345	technology	1200 Code Boulevard	Seattle	WA	US	98101	\N	+1-206-555-2222	\N	services@softwaresolutions.com	\N	USD	net_30	\N	service	strategic	\N	\N	91	14	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.expenses (id, date, amount, category, description, payment_method, reference, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fiscal_periods; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.fiscal_periods (id, created_at, updated_at, version, year, period, name, start_date, end_date, status, company_code_id) FROM stdin;
1	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	1	2025-01	2025-01-01	2025-01-31	CLOSED	1
2	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	2	2025-02	2025-02-01	2025-02-28	CLOSED	1
3	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	3	2025-03	2025-03-01	2025-03-31	CLOSED	1
4	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	4	2025-04	2025-04-01	2025-04-30	CLOSED	1
5	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	5	2025-05	2025-05-01	2025-05-31	CLOSED	1
6	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	6	2025-06	2025-06-01	2025-06-30	OPEN	1
7	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	7	2025-07	2025-07-01	2025-07-31	OPEN	1
8	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	8	2025-08	2025-08-01	2025-08-31	OPEN	1
9	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	9	2025-09	2025-09-01	2025-09-30	OPEN	1
10	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	10	2025-10	2025-10-01	2025-10-31	OPEN	1
11	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	11	2025-11	2025-11-01	2025-11-30	OPEN	1
12	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	12	2025-12	2025-12-01	2025-12-31	OPEN	1
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.invoices (id, invoice_number, order_id, issue_date, due_date, amount, status, paid_date, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: material_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.material_categories (id, code, name, description, parent_id, created_at, updated_at) FROM stdin;
1	RM	Raw Materials	Base materials used in production	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374
2	FG	Finished Goods	Products ready for sale	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374
3	SFG	Semi-finished	Intermediate products	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374
4	SPRT	Spare Parts	Components for maintenance and repair	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374
5	PKG	Packaging	Materials used for packaging products	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374
6	CONS	Consumables	Materials consumed during production	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374
7	RM-MET	Metals	Metal raw materials	1	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947
8	RM-PLST	Plastics	Plastic raw materials	1	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947
9	FG-ELEC	Electronics	Electronic finished products	2	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947
10	FG-TOOL	Tools	Hand and power tools	2	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947
11	PKG-BOX	Boxes	Cardboard and corrugated boxes	5	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947
\.


--
-- Data for Name: materials; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.materials (id, code, name, description, long_description, type, uom_id, category_id, weight, weight_uom_id, dimensions, base_unit_price, cost, min_order_qty, order_multiple, procurement_type, min_stock, max_stock, reorder_point, lead_time, shelf_life, lot_size, mrp_type, planning_policy, is_active, is_sellable, is_purchasable, is_manufactured, is_stockable, created_at, updated_at, created_by, updated_by, version) FROM stdin;
1	RM-1001	Aluminum Sheet	High-grade aluminum sheet for industrial use	\N	RAW	1	1	1	1	{"width": "1000mm", "height": "2mm", "length": "1000mm"}	7.5	5.25	10	5	external	20	100	30	7	0	EX	reorder_point	standard	t	t	t	f	t	2025-05-20 14:36:38.689364	2025-05-20 14:36:38.689364	\N	\N	1
2	RM-1002	Steel Rod	Carbon steel rod for structural applications	\N	RAW	1	1	2.5	1	{"length": "2m", "diameter": "20mm"}	8.75	6.5	10	5	external	15	80	20	5	0	EX	reorder_point	standard	t	t	t	f	t	2025-05-20 14:36:38.705246	2025-05-20 14:36:38.705246	\N	\N	1
3	RM-1003	Plastic Granulate	ABS plastic granulate for injection molding	\N	RAW	1	1	1	1	{"bulk": true}	3.25	2.1	25	25	external	50	300	75	10	730	EX	reorder_point	lot_for_lot	t	f	t	f	t	2025-05-20 14:36:38.720782	2025-05-20 14:36:38.720782	\N	\N	1
4	RM-1004	Copper Wire	Industrial grade copper wire	\N	RAW	4	1	0.05	1	{"diameter": "2mm"}	6.5	4.2	100	50	external	200	1000	300	15	0	EX	reorder_point	standard	t	f	t	f	t	2025-05-20 14:36:38.735852	2025-05-20 14:36:38.735852	\N	\N	1
5	RM-1005	Cotton Fabric	Premium cotton fabric for textile manufacturing	\N	RAW	5	1	0.2	1	{"width": "1.5m"}	4.25	3	50	10	external	100	500	150	12	365	EX	reorder_point	standard	t	f	t	f	t	2025-05-20 14:36:38.750003	2025-05-20 14:36:38.750003	\N	\N	1
6	SF-2001	Aluminum Frame	Partially assembled aluminum frame	\N	SEMI	10	1	3.2	1	{"width": "0.8m", "height": "0.1m", "length": "1.2m"}	35	22.5	5	5	in-house	10	50	15	3	0	EX	make_to_stock	lot_for_lot	t	f	f	t	t	2025-05-20 14:36:38.765285	2025-05-20 14:36:38.765285	\N	\N	1
7	SF-2002	PCB Assembly	Partially assembled printed circuit board	\N	SEMI	10	1	0.15	1	{"width": "80mm", "height": "2mm", "length": "120mm"}	28.5	18	10	5	in-house	20	100	30	5	365	EX	make_to_stock	lot_for_lot	t	f	f	t	t	2025-05-20 14:36:38.779297	2025-05-20 14:36:38.779297	\N	\N	1
8	SF-2003	Injection Molded Housing	Plastic housing for electronic devices	\N	SEMI	10	1	0.45	1	{"width": "150mm", "height": "50mm", "length": "200mm"}	12.75	8.5	25	25	in-house	50	250	75	2	0	EX	make_to_stock	lot_for_lot	t	f	f	t	t	2025-05-20 14:36:38.794055	2025-05-20 14:36:38.794055	\N	\N	1
9	FG-3001	Smart Thermostat	IoT-enabled smart thermostat for home automation	\N	FINI	10	1	0.85	1	{"width": "80mm", "height": "35mm", "length": "120mm"}	85	45	1	1	in-house	10	50	15	7	730	EX	make_to_stock	lot_for_lot	t	t	f	t	t	2025-05-20 14:36:38.808153	2025-05-20 14:36:38.808153	\N	\N	1
10	FG-3002	Industrial Control Panel	Advanced control panel for manufacturing equipment	\N	FINI	10	1	12.5	1	{"width": "450mm", "height": "200mm", "length": "600mm"}	1250	750	1	1	in-house	2	10	3	15	1825	EX	make_to_order	lot_for_lot	t	t	f	t	t	2025-05-20 14:36:38.822432	2025-05-20 14:36:38.822432	\N	\N	1
11	FG-3003	LED Light Fixture	Energy-efficient LED ceiling light fixture	\N	FINI	10	1	1.8	1	{"width": "300mm", "height": "100mm", "length": "300mm"}	65	38	1	1	in-house	15	75	25	5	1825	EX	make_to_stock	lot_for_lot	t	t	f	t	t	2025-05-20 14:36:38.83712	2025-05-20 14:36:38.83712	\N	\N	1
12	FG-3004	Wireless Router	High-speed wireless router for home and office	\N	FINI	10	1	0.9	1	{"width": "180mm", "height": "40mm", "length": "230mm"}	120	75	1	1	external	20	100	30	7	1095	EX	make_to_stock	standard	t	t	t	f	t	2025-05-20 14:36:38.851882	2025-05-20 14:36:38.851882	\N	\N	1
13	FG-3005	Electric Motor	Industrial electric motor for manufacturing equipment	\N	FINI	10	1	35	1	{"width": "250mm", "height": "250mm", "length": "350mm"}	890	650	1	1	external	3	15	5	21	3650	EX	make_to_order	standard	t	t	t	f	t	2025-05-20 14:36:38.866115	2025-05-20 14:36:38.866115	\N	\N	1
14	PM-4001	Cardboard Box - Small	Corrugated cardboard box for shipping small items	\N	PACK	10	1	0.15	1	{"width": "200mm", "height": "200mm", "length": "200mm"}	1.25	0.85	100	100	external	250	1000	350	3	365	EX	reorder_point	lot_for_lot	t	f	t	f	t	2025-05-20 14:36:38.885914	2025-05-20 14:36:38.885914	\N	\N	1
16	CHEM-001	Industrial Cleaning Solution	Multi-purpose industrial cleaning solution	\N	RAW	1	1	\N	\N	\N	25.5	15.75	\N	\N	\N	10	50	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-05-20 16:14:07.491142	2025-05-20 16:14:07.491142	\N	\N	1
17	TOOL-001	Precision Measurement Tool	High-accuracy digital measurement tool	\N	FINI	1	1	\N	\N	\N	199.99	125	\N	\N	\N	2	10	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-05-20 16:14:07.580166	2025-05-20 16:14:07.580166	\N	\N	1
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.order_items (id, order_id, product_id, quantity, unit_price, total, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.orders (id, order_number, customer_id, date, status, total, notes, shipping_address, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plants; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.plants (id, code, name, description, company_code_id, type, category, address, city, state, country, postal_code, phone, email, manager, timezone, operating_hours, coordinates, status, is_active, created_at, created_by, updated_at, updated_by, version, notes) FROM stdin;
1	P001	Main Factory	\N	1	Manufacturing	Production	\N	Chicago	\N	United States	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-17 13:44:11.172767	\N	2025-05-17 13:44:11.172767	\N	1	\N
2	W001	East Coast Warehouse	\N	1	Warehouse	Storage	\N	Newark	\N	United States	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-17 13:44:11.172767	\N	2025-05-17 13:44:11.172767	\N	1	\N
3	P002	European Production	\N	2	Manufacturing	Production	\N	Munich	\N	Germany	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-17 13:44:11.172767	\N	2025-05-17 13:44:11.172767	\N	1	\N
4	p001	plant South East		1	Warehouse								\N					active	t	2025-05-19 22:58:38.372	\N	2025-05-19 22:58:38.372	\N	1	\N
5	P003	Berlin Production	Berlin Production - manufacturing facility	2	manufacturing	production	Fabrikstraße 25, Berlin, 10115	\N	\N	Germany	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.251247	\N	2025-05-20 04:52:26.251247	\N	1	\N
6	P004	Shanghai Facility	Shanghai Facility - manufacturing facility	10	manufacturing	production	100 Industrial Zone, Shanghai, 200000	\N	\N	China	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.305857	\N	2025-05-20 04:52:26.305857	\N	1	\N
7	W002	European Warehouse	European Warehouse - warehouse facility	2	warehouse	distribution	Logistikweg 10, Hamburg, 20095	\N	\N	Germany	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.370563	\N	2025-05-20 04:52:26.370563	\N	1	\N
8	W003	Asian Distribution Hub	Asian Distribution Hub - warehouse facility	10	warehouse	distribution	200 Export Center, Shenzhen, 518000	\N	\N	China	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.417674	\N	2025-05-20 04:52:26.417674	\N	1	\N
9	W004	UK Warehouse	UK Warehouse - warehouse facility	11	warehouse	distribution	15 Logistics Way, Manchester, M1 1AA	\N	\N	United Kingdom	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.461796	\N	2025-05-20 04:52:26.461796	\N	1	\N
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.products (id, name, sku, description, price, cost, stock, min_stock, category_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: profit_centers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.profit_centers (id, code, name, company_code_id, description, manager, segment, is_active, created_at, updated_at) FROM stdin;
1	PC-MOTO-US	Motors - US	1	Motor product line in US	Daniel Smith	Motors	t	2025-05-20 22:10:19.040007	2025-05-20 22:10:19.040007
2	PC-CONT-US	Controls - US	1	Control systems in US	Emily Johnson	Controls	t	2025-05-20 22:10:19.040007	2025-05-20 22:10:19.040007
3	PC-PUMP-US	Pumps - US	1	Pump product line in US	Michael Davis	Pumps	t	2025-05-20 22:10:19.040007	2025-05-20 22:10:19.040007
4	PC-SERV-US	Services - US	1	Service offerings in US	Jennifer Wilson	Services	t	2025-05-20 22:10:19.040007	2025-05-20 22:10:19.040007
5	PC-MOTO-DE	Motors - Germany	9	Motor product line in Germany	Klaus Weber	Motors	t	2025-05-20 22:10:19.040007	2025-05-20 22:10:19.040007
6	CA01-EAST	Eastern Region - CMIS Association	5	Eastern region profit center for CMIS Association	Robert Johnson	Eastern	t	2025-05-21 14:58:18.864556	2025-05-21 14:58:18.864556
7	CN01-EAST	Eastern Region - China Operations	10	Eastern region profit center for China Operations	Robert Johnson	Eastern	t	2025-05-21 14:58:18.864556	2025-05-21 14:58:18.864556
8	DE01-EAST	Eastern Region - Germany Operations	9	Eastern region profit center for Germany Operations	Robert Johnson	Eastern	t	2025-05-21 14:58:18.864556	2025-05-21 14:58:18.864556
9	EU01-EAST	Eastern Region - ACME Europe GmbH	2	Eastern region profit center for ACME Europe GmbH	Robert Johnson	Eastern	t	2025-05-21 14:58:18.864556	2025-05-21 14:58:18.864556
10	IN01-EAST	Eastern Region - India Company Code	6	Eastern region profit center for India Company Code	Robert Johnson	Eastern	t	2025-05-21 14:58:18.864556	2025-05-21 14:58:18.864556
11	GA01-WEST	Western Region - Germany	7	Western region profit center for Germany	Patricia Davis	Western	t	2025-05-21 14:58:27.160646	2025-05-21 14:58:27.160646
12	IN01-WEST	Western Region - India Company Code	6	Western region profit center for India Company Code	Patricia Davis	Western	t	2025-05-21 14:58:27.160646	2025-05-21 14:58:27.160646
13	TEST01-WEST	Western Region - Mexico Company	3	Western region profit center for Mexico Company	Patricia Davis	Western	t	2025-05-21 14:58:27.160646	2025-05-21 14:58:27.160646
14	UK01-WEST	Western Region - United Kingdom Branch	11	Western region profit center for United Kingdom Branch	Patricia Davis	Western	t	2025-05-21 14:58:27.160646	2025-05-21 14:58:27.160646
15	DE01-WEST	Western Region - Germany Operations	9	Western region profit center for Germany Operations	Patricia Davis	Western	t	2025-05-21 14:58:27.160646	2025-05-21 14:58:27.160646
\.


--
-- Data for Name: purchase_groups; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.purchase_groups (id, code, name, description, is_active, created_at, updated_at, created_by, updated_by, version, valid_from, valid_to) FROM stdin;
1	MECH	Mechanical Parts	Procurement group for mechanical components and parts	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N
2	ELEC	Electrical Components	Procurement group for electrical components and supplies	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N
3	RAW	Raw Materials	Basic raw materials used in manufacturing processes	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N
4	PACK	Packaging Materials	Materials used for packaging finished products	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N
5	TOOL	Tools & Equipment	Tools and equipment for maintenance and operations	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N
6	PG001	Raw Materials	Purchasing group for raw materials procurement	t	2025-05-20 04:52:27.386821	2025-05-20 04:52:27.386821	\N	\N	1	2025-05-20 04:52:27.386821	\N
7	PG002	Production Equipment	Purchasing group for manufacturing equipment	t	2025-05-20 04:52:27.427776	2025-05-20 04:52:27.427776	\N	\N	1	2025-05-20 04:52:27.427776	\N
8	PG003	Office Supplies	Purchasing group for office and administrative supplies	t	2025-05-20 04:52:27.459234	2025-05-20 04:52:27.459234	\N	\N	1	2025-05-20 04:52:27.459234	\N
9	PG004	IT Hardware	Purchasing group for computers and IT equipment	t	2025-05-20 04:52:27.490428	2025-05-20 04:52:27.490428	\N	\N	1	2025-05-20 04:52:27.490428	\N
10	PG005	Packaging Materials	Purchasing group for packaging supplies	t	2025-05-20 04:52:27.526279	2025-05-20 04:52:27.526279	\N	\N	1	2025-05-20 04:52:27.526279	\N
11	PG006	Services	Purchasing group for third-party services	t	2025-05-20 04:52:27.560699	2025-05-20 04:52:27.560699	\N	\N	1	2025-05-20 04:52:27.560699	\N
12	PG007	Maintenance	Purchasing group for maintenance supplies and services	t	2025-05-20 04:52:27.592969	2025-05-20 04:52:27.592969	\N	\N	1	2025-05-20 04:52:27.592969	\N
\.


--
-- Data for Name: purchase_organizations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.purchase_organizations (id, code, name, description, company_code_id, currency, purchasing_manager, email, phone, address, is_active, created_at, updated_at, created_by, updated_by, version, valid_from, valid_to, purchasing_group, supply_type, approval_level, city, state, country, postal_code, status, notes, manager) FROM stdin;
9	PO01	US Raw Materials Procurement	Purchases raw materials for US manufacturing	1	USD	\N	\N	\N	\N	t	2025-05-20 05:01:13.627938	2025-05-20 05:01:13.627938	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	USA	\N	active	\N	\N
10	PO02	US MRO Procurement	Purchases maintenance supplies for US operations	1	USD	\N	\N	\N	\N	t	2025-05-20 05:01:13.677542	2025-05-20 05:01:13.677542	\N	\N	1	2025-05-20	\N	indirect	maintenance	\N	\N	\N	USA	\N	active	\N	\N
11	PO03	European Raw Materials	Purchases raw materials for European manufacturing	2	EUR	\N	\N	\N	\N	t	2025-05-20 05:01:13.705442	2025-05-20 05:01:13.705442	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	Germany	\N	active	\N	\N
12	PO04	European Services	Purchases services for European operations	2	EUR	\N	\N	\N	\N	t	2025-05-20 05:01:13.730688	2025-05-20 05:01:13.730688	\N	\N	1	2025-05-20	\N	indirect	services	\N	\N	\N	Germany	\N	active	\N	\N
13	PO05	Asia Pacific Procurement	Handles all purchasing activities in APAC region	10	CNY	\N	\N	\N	\N	t	2025-05-20 05:01:13.754219	2025-05-20 05:01:13.754219	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	China	\N	active	\N	\N
14	PO06	Global Capital Purchases	Handles all major capital expenditures globally	1	USD	\N	\N	\N	\N	t	2025-05-20 05:01:13.782274	2025-05-20 05:01:13.782274	\N	\N	1	2025-05-20	\N	capital	equipment	\N	\N	\N	USA	\N	active	\N	\N
15	PO07	UK Procurement	Manages all procurement for UK operations	11	GBP	\N	\N	\N	\N	t	2025-05-20 05:01:13.801961	2025-05-20 05:01:13.801961	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	United Kingdom	\N	active	\N	\N
16	PO08	Canada Procurement	Handles all purchasing for Canadian operations	5	CAD	\N	\N	\N	\N	t	2025-05-20 05:01:13.825862	2025-05-20 05:01:13.825862	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	Canada	\N	active	\N	\N
17	NA01	North America Procurement	\N	1	USD	\N	\N	\N	\N	t	2025-05-20 21:43:20.089848	2025-05-20 21:43:20.089848	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N
18	EU01	European Procurement	\N	9	EUR	\N	\N	\N	\N	t	2025-05-20 21:43:20.111292	2025-05-20 21:43:20.111292	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N
19	UK01	UK Procurement	\N	11	GBP	\N	\N	\N	\N	t	2025-05-20 21:43:20.128029	2025-05-20 21:43:20.128029	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N
22	IN01	India Purchasing	\N	6	INR	\N	\N	\N	\N	t	2025-05-20 21:43:20.460685	2025-05-20 21:43:20.460685	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N
24	GLOB	Global Procurement	\N	1	USD	\N	\N	\N	\N	t	2025-05-20 21:43:20.621543	2025-05-20 21:43:20.621543	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.regions (id, code, name, description, is_active, created_at, updated_at) FROM stdin;
1	NA	North America	United States, Canada, and Mexico	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
2	SA	South America	South American countries	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
3	EMEA	Europe, Middle East, and Africa	Europe, Middle East, and Africa regions	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
4	APAC	Asia Pacific	Asia, Australia, and Pacific Islands	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169
\.


--
-- Data for Name: sales_organizations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sales_organizations (id, code, name, description, company_code_id, currency, region, distribution_channel, industry, address, city, state, country, postal_code, phone, email, manager, status, is_active, notes, created_at, created_by, updated_at, updated_by, version) FROM stdin;
8	SO01	US Consumer Retail	Manages US retail consumer sales	1	USD	North America	retail	consumer	\N	\N	\N	USA	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.871186+00	\N	2025-05-20 05:01:13.871186+00	\N	1
9	SO02	US B2B Sales	Handles direct business-to-business sales in US	1	USD	North America	direct	industrial	\N	\N	\N	USA	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.903811+00	\N	2025-05-20 05:01:13.903811+00	\N	1
10	SO03	US eCommerce	Manages all online sales channels in US	1	USD	North America	online	consumer	\N	\N	\N	USA	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.923177+00	\N	2025-05-20 05:01:13.923177+00	\N	1
11	SO04	European Retail	Manages European retail sales operations	2	EUR	EMEA	retail	consumer	\N	\N	\N	Germany	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.949517+00	\N	2025-05-20 05:01:13.949517+00	\N	1
12	SO05	European Wholesale	Handles wholesale distribution in Europe	2	EUR	EMEA	wholesale	industrial	\N	\N	\N	Germany	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.967276+00	\N	2025-05-20 05:01:13.967276+00	\N	1
13	SO06	China Retail	Manages retail sales operations in China	10	CNY	APAC	retail	consumer	\N	\N	\N	China	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.98566+00	\N	2025-05-20 05:01:13.98566+00	\N	1
14	SO07	APAC Distribution	Handles distribution across Asia Pacific region	10	CNY	APAC	wholesale	mixed	\N	\N	\N	China	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:14.008718+00	\N	2025-05-20 05:01:14.008718+00	\N	1
15	SO08	UK Consumer Sales	Manages retail consumer sales in UK	11	GBP	EMEA	retail	consumer	\N	\N	\N	United Kingdom	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:14.03034+00	\N	2025-05-20 05:01:14.03034+00	\N	1
16	SO09	Canada Sales	Handles all sales operations in Canada	5	CAD	North America	mixed	mixed	\N	\N	\N	Canada	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:14.049053+00	\N	2025-05-20 05:01:14.049053+00	\N	1
17	US01	US East Sales	\N	1	USD	\N	\N	\N	\N	\N	\N	US	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.29688+00	\N	2025-05-20 21:43:19.29688+00	\N	1
19	CA01	Canada Sales	\N	5	CAD	\N	\N	\N	\N	\N	\N	CA	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.477648+00	\N	2025-05-20 21:43:19.477648+00	\N	1
20	UK01	UK Sales Division	\N	11	GBP	\N	\N	\N	\N	\N	\N	GB	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.499825+00	\N	2025-05-20 21:43:19.499825+00	\N	1
21	EU01	European Sales	\N	9	EUR	\N	\N	\N	\N	\N	\N	EU	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.51623+00	\N	2025-05-20 21:43:19.51623+00	\N	1
24	IN01	India Sales Division	\N	6	INR	\N	\N	\N	\N	\N	\N	IN	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.889334+00	\N	2025-05-20 21:43:19.889334+00	\N	1
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.stock_movements (id, product_id, type, quantity, reason, date, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.storage_locations (id, code, name, description, plant_id, type, is_mrp_relevant, is_negative_stock_allowed, is_goods_receipt_relevant, is_goods_issue_relevant, is_interim_storage, is_transit_storage, is_restricted_use, status, is_active, created_at, created_by, updated_at, updated_by, version, notes) FROM stdin;
13	SL001	Raw Materials Warehouse	Primary storage for raw materials in main factory	1	raw_material	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.094952	\N	2025-05-20 05:01:14.094952	\N	1	\N
14	SL002	Work-in-Progress	Temporary storage for work-in-progress items	1	wip	t	f	f	f	f	f	f	active	t	2025-05-20 05:01:14.125555	\N	2025-05-20 05:01:14.125555	\N	1	\N
15	SL003	Finished Goods	Storage for completed products ready for shipping	1	finished_goods	t	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.149165	\N	2025-05-20 05:01:14.149165	\N	1	\N
16	SL004	Quality Control Area	Area for quality inspection and testing	1	quality_control	f	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.170727	\N	2025-05-20 05:01:14.170727	\N	1	\N
17	SL005	Components Storage	Storage for assembly components and parts	3	components	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.195182	\N	2025-05-20 05:01:14.195182	\N	1	\N
18	SL006	Assembly WIP	Work-in-progress area for assembly operations	3	wip	t	f	f	f	f	f	f	active	t	2025-05-20 05:01:14.215786	\N	2025-05-20 05:01:14.215786	\N	1	\N
19	SL007	Berlin Raw Materials	Raw material storage for Berlin plant	5	raw_material	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.233335	\N	2025-05-20 05:01:14.233335	\N	1	\N
20	SL008	Berlin Finished Goods	Finished product storage for Berlin plant	5	finished_goods	t	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.250899	\N	2025-05-20 05:01:14.250899	\N	1	\N
21	SL009	Shanghai Materials	Raw material storage for Shanghai facility	6	raw_material	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.273873	\N	2025-05-20 05:01:14.273873	\N	1	\N
22	SL010	Shanghai Finished Goods	Finished product storage for Shanghai facility	6	finished_goods	t	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.293642	\N	2025-05-20 05:01:14.293642	\N	1	\N
23	SL011	US Distribution - Zone A	High-volume products distribution area	2	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.314699	\N	2025-05-20 05:01:14.314699	\N	1	\N
24	SL012	US Distribution - Zone B	Specialty products distribution area	2	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.339057	\N	2025-05-20 05:01:14.339057	\N	1	\N
25	SL013	European Warehouse - General	General storage area for European warehouse	7	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.365961	\N	2025-05-20 05:01:14.365961	\N	1	\N
26	SL014	European Warehouse - Cold Storage	Temperature-controlled storage area	7	special_handling	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.386335	\N	2025-05-20 05:01:14.386335	\N	1	\N
27	SL015	Asia Distribution - General	General storage area for Asian distribution hub	8	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.408615	\N	2025-05-20 05:01:14.408615	\N	1	\N
28	SL016	UK Warehouse - Main	Main storage area for UK warehouse	9	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.426302	\N	2025-05-20 05:01:14.426302	\N	1	\N
29	SL017	Hazardous Materials	Special storage for hazardous materials	1	hazardous	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.444301	\N	2025-05-20 05:01:14.444301	\N	1	\N
30	SL018	Returns Processing	Area for processing customer returns	2	returns	f	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.465474	\N	2025-05-20 05:01:14.465474	\N	1	\N
31	SL019	Maintenance Supplies	Storage for maintenance tools and supplies	1	maintenance	f	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.484431	\N	2025-05-20 05:01:14.484431	\N	1	\N
32	SL020	Packaging Materials	Storage for packaging materials and supplies	1	packaging	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.506819	\N	2025-05-20 05:01:14.506819	\N	1	\N
\.


--
-- Data for Name: supply_types; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.supply_types (id, code, name, description, is_active, created_at, updated_at, created_by, updated_by, version, valid_from, valid_to) FROM stdin;
1	DIR	Direct Materials	Materials directly used in manufacturing products	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N
2	IND	Indirect Materials	Materials indirectly used in manufacturing	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N
3	SERV	Services	Service-related procurement	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N
4	CAPEX	Capital Expenditure	Large equipment and capital investments	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N
5	MRO	Maintenance & Repair	Maintenance, repair, and operations supplies	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N
6	ST001	Direct Materials	Materials directly used in manufacturing	t	2025-05-20 04:52:27.64864	2025-05-20 04:52:27.64864	\N	\N	1	2025-05-20 04:52:27.64864	\N
7	ST002	Indirect Materials	Materials not directly used in manufacturing	t	2025-05-20 04:52:27.683957	2025-05-20 04:52:27.683957	\N	\N	1	2025-05-20 04:52:27.683957	\N
8	ST003	Capital Equipment	Long-term assets and equipment	t	2025-05-20 04:52:27.71506	2025-05-20 04:52:27.71506	\N	\N	1	2025-05-20 04:52:27.71506	\N
9	ST004	Services	External services and contracted work	t	2025-05-20 04:52:27.75151	2025-05-20 04:52:27.75151	\N	\N	1	2025-05-20 04:52:27.75151	\N
10	ST005	Trading Goods	Finished goods purchased for resale	t	2025-05-20 04:52:27.788036	2025-05-20 04:52:27.788036	\N	\N	1	2025-05-20 04:52:27.788036	\N
11	ST006	MRO Supplies	Maintenance, repair, and operations supplies	t	2025-05-20 04:52:27.83183	2025-05-20 04:52:27.83183	\N	\N	1	2025-05-20 04:52:27.83183	\N
\.


--
-- Data for Name: tax_codes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tax_codes (id, code, name, country, tax_type, percentage, description, is_active, created_at, updated_at) FROM stdin;
1	US-EX	US Exempt	US	SALES	0.00	Tax exempt sales in US	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264
2	US-STD	US Standard	US	SALES	6.00	Standard US sales tax	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264
3	US-NY	New York	US	SALES	8.88	New York City sales tax	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264
4	DE-STD	Germany Standard	DE	VAT	19.00	Standard German VAT	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264
5	DE-RED	Germany Reduced	DE	VAT	7.00	Reduced German VAT	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264
6	UK-STD	UK Standard	GB	VAT	20.00	Standard UK VAT	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264
7	JP-STD	Japan Standard	JP	CONSUMPTION	10.00	Standard Japanese consumption tax	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264
10	US-RED	US Reduced Tax	US	SALES	2.50	United States reduced sales tax rate	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
11	US-EXE	US Tax Exempt	US	EXEMPT	0.00	United States tax exempt status	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
12	CA-GST	Canada GST	CA	SALES	5.00	Canada Goods and Services Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
13	CA-HST	Canada HST	CA	SALES	13.00	Canada Harmonized Sales Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
14	UK-VAT	UK Standard VAT	UK	VAT	20.00	United Kingdom standard Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
15	UK-RED	UK Reduced VAT	UK	VAT	5.00	United Kingdom reduced Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
16	UK-ZER	UK Zero VAT	UK	VAT	0.00	United Kingdom zero-rated Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
17	EU-STD	EU Standard VAT	EU	VAT	21.00	European Union standard Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
18	EU-RED	EU Reduced VAT	EU	VAT	10.00	European Union reduced Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326
\.


--
-- Data for Name: units_of_measure; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.units_of_measure (id, code, name, description, is_active, dimension, conversion_factor, base_uom_id, created_at, updated_at, version) FROM stdin;
21	BOX	Box	Standard shipping box	t	Count	1.00000	1	2025-05-20 14:35:23.427158	2025-05-20 14:35:23.427158	1
22	PK	Pack	Standard package unit	t	Count	1.00000	1	2025-05-20 14:35:23.450134	2025-05-20 14:35:23.450134	1
23	CS	Case	Standard shipping case	t	Count	1.00000	1	2025-05-20 14:35:23.469472	2025-05-20 14:35:23.469472	1
24	PAL	Pallet	Standard shipping pallet	t	Count	1.00000	1	2025-05-20 14:35:23.487324	2025-05-20 14:35:23.487324	1
25	BDL	Bundle	Bundled items	t	Count	1.00000	1	2025-05-20 14:35:23.504645	2025-05-20 14:35:23.504645	1
26	ROL	Roll	Material in roll form	t	Count	1.00000	1	2025-05-20 14:35:23.523414	2025-05-20 14:35:23.523414	1
1	EA	Each	Individual units/pieces	t	Count	1.00000	\N	2025-05-20 14:35:22.9723	2025-05-20 14:35:22.9723	1
2	KG	Kilogram	Standard weight measure	t	Weight	1.00000	\N	2025-05-20 14:35:22.993509	2025-05-20 14:35:22.993509	1
3	L	Liter	Standard volume measure	t	Volume	1.00000	\N	2025-05-20 14:35:23.012083	2025-05-20 14:35:23.012083	1
4	M	Meter	Standard length measure	t	Length	1.00000	\N	2025-05-20 14:35:23.031217	2025-05-20 14:35:23.031217	1
5	M2	Square Meter	Standard area measure	t	Area	1.00000	\N	2025-05-20 14:35:23.051068	2025-05-20 14:35:23.051068	1
6	M3	Cubic Meter	Standard cubic measure	t	Volume	1.00000	\N	2025-05-20 14:35:23.091756	2025-05-20 14:35:23.091756	1
7	HR	Hour	Time duration in hours	t	Time	1.00000	\N	2025-05-20 14:35:23.126854	2025-05-20 14:35:23.126854	1
8	DZ	Dozen	12 pieces	t	Count	12.00000	1	2025-05-20 14:35:23.149004	2025-05-20 14:35:23.149004	1
18	LB	Pound	Imperial weight unit	t	Weight	0.45359	2	2025-05-20 14:35:23.360131	2025-05-20 14:35:23.360131	1
19	OZ	Ounce	Imperial weight unit	t	Weight	0.02835	2	2025-05-20 14:35:23.380406	2025-05-20 14:35:23.380406	1
9	G	Gram	1/1000 of a kilogram	t	Weight	0.00100	2	2025-05-20 14:35:23.167923	2025-05-20 14:35:23.167923	1
10	TON	Metric Ton	1000 kilograms	t	Weight	1000.00000	2	2025-05-20 14:35:23.188929	2025-05-20 14:35:23.188929	1
20	GAL	Gallon	Imperial volume unit	t	Volume	3.78541	3	2025-05-20 14:35:23.407112	2025-05-20 14:35:23.407112	1
11	ML	Milliliter	1/1000 of a liter	t	Volume	0.00100	3	2025-05-20 14:35:23.211278	2025-05-20 14:35:23.211278	1
14	KM	Kilometer	1000 meters	t	Length	1000.00000	4	2025-05-20 14:35:23.278287	2025-05-20 14:35:23.278287	1
15	FT	Feet	Imperial length unit	t	Length	0.30480	4	2025-05-20 14:35:23.296244	2025-05-20 14:35:23.296244	1
16	IN	Inch	Imperial length unit	t	Length	0.02540	4	2025-05-20 14:35:23.318598	2025-05-20 14:35:23.318598	1
17	YD	Yard	Imperial length unit	t	Length	0.91440	4	2025-05-20 14:35:23.338962	2025-05-20 14:35:23.338962	1
12	CM	Centimeter	1/100 of a meter	t	Length	0.01000	4	2025-05-20 14:35:23.240106	2025-05-20 14:35:23.240106	1
13	MM	Millimeter	1/1000 of a meter	t	Length	0.00100	4	2025-05-20 14:35:23.260301	2025-05-20 14:35:23.260301	1
27	MIN	Minute	Time duration in minutes	t	Time	0.01667	7	2025-05-20 14:35:23.542799	2025-05-20 14:35:23.542799	1
28	DAY	Day	Time duration in days	t	Time	24.00000	7	2025-05-20 14:35:23.562736	2025-05-20 14:35:23.562736	1
29	WK	Week	Time duration in weeks	t	Time	168.00000	7	2025-05-20 14:35:23.581007	2025-05-20 14:35:23.581007	1
30	MO	Month	Time duration in months	t	Time	730.00000	7	2025-05-20 14:35:23.601732	2025-05-20 14:35:23.601732	1
\.


--
-- Data for Name: uom; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.uom (id, code, name, description, category, is_base, created_at, created_by, updated_at, updated_by, version, is_active, notes) FROM stdin;
1	KG	Kilogram	\N	weight	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
2	G	Gram	\N	weight	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
3	LB	Pound	\N	weight	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
4	M	Meter	\N	length	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
5	CM	Centimeter	\N	length	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
6	INCH	Inch	\N	length	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
7	L	Liter	\N	volume	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
8	ML	Milliliter	\N	volume	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
9	GAL	Gallon	\N	volume	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
10	EA	Each	\N	unit	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
11	PCS	Pieces	\N	unit	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
12	BOX	Box	\N	package	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N
13	Oz	OZ	OZ	Weight	f	2025-05-17 12:34:16.642	1	2025-05-17 12:34:16.642	1	1	t	\N
14	PC	Piece	Standard Piece	Count	t	2025-05-20 16:12:26.384342	\N	2025-05-20 16:12:26.384342	\N	1	t	\N
\.


--
-- Data for Name: uom_conversions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.uom_conversions (id, from_uom_id, to_uom_id, conversion_factor, created_at, created_by, updated_at, updated_by, version, is_active, notes) FROM stdin;
1	1	2	1000	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N
2	1	3	2.20462	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N
3	4	5	100	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N
4	4	6	39.3701	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N
5	7	8	1000	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N
6	7	9	0.264172	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, username, password, name, email, role, created_at, updated_at) FROM stdin;
1	admin	admin123	Administrator	admin@example.com	admin	2025-05-17 05:55:13.089835	2025-05-17 05:55:13.089835
\.


--
-- Data for Name: vendor_contacts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.vendor_contacts (id, vendor_id, first_name, last_name, "position", department, email, phone, mobile, is_primary, is_order_contact, is_purchase_contact, is_quality_contact, is_accounts_contact, preferred_language, notes, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.vendors (id, code, name, type, description, tax_id, industry, address, city, state, country, postal_code, region, phone, alt_phone, email, website, currency, payment_terms, payment_method, supplier_type, category, order_frequency, minimum_order_value, evaluation_score, lead_time, purchasing_group_id, status, blacklisted, blacklist_reason, notes, tags, company_code_id, is_active, created_at, updated_at, created_by, updated_by, version) FROM stdin;
1	VEND001	Global Raw Materials Inc	SUPPLIER	\N	123-45-6789	\N	100 Supplier Road, Chicago, IL 60601	\N	\N	US	\N	\N	+1-312-555-1234	\N	sales@grm.example.com	\N	\N	NET30	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	Primary raw material supplier	\N	\N	t	2025-05-20 18:17:22.279989	2025-05-20 18:17:22.279989	\N	\N	1
2	VEND002	European Components GmbH	MANUFACTURER	\N	DE123456789	\N	Industrieweg 10, Munich, 80331	\N	\N	DE	\N	\N	+49-89-1234-5678	\N	orders@eurocomponents.example.de	\N	\N	NET45	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	European electronics components supplier	\N	\N	t	2025-05-20 18:17:22.301591	2025-05-20 18:17:22.301591	\N	\N	1
3	VEND003	Asian Electronics Ltd	MANUFACTURER	\N	SG987654321	\N	1 Electronics Way, Singapore, 618989	\N	\N	SG	\N	\N	+65-6789-1234	\N	sales@asianelec.example.sg	\N	\N	NET30	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	Electronics components supplier	\N	\N	t	2025-05-20 18:17:22.320725	2025-05-20 18:17:22.320725	\N	\N	1
4	VEND004	Quality Packaging Ltd	SUPPLIER	\N	GB123456789	\N	10 Packaging Street, Manchester, M1 1AA	\N	\N	GB	\N	\N	+44-161-123-4567	\N	sales@qualitypack.example.uk	\N	\N	NET30	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	Packaging materials supplier	\N	\N	t	2025-05-20 18:17:22.341416	2025-05-20 18:17:22.341416	\N	\N	1
5	VEND005	Japan Precision Tools	MANUFACTURER	\N	JP1234567890	\N	2-1 Industrial Area, Osaka, 530-0001	\N	\N	JP	\N	\N	+81-6-1234-5678	\N	export@jpt.example.jp	\N	\N	NET15	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	Precision tools manufacturer	\N	\N	t	2025-05-20 18:17:22.360311	2025-05-20 18:17:22.360311	\N	\N	1
\.


--
-- Data for Name: work_centers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.work_centers (id, code, name, plant_id, description, capacity, capacity_unit, cost_rate, is_active, created_at, updated_at, status) FROM stdin;
1	WC-ASM-01	Primary Assembly Line	1	Main assembly line for final product assembly with automated stations	120.00	units/day	65.75	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active
2	WC-ASM-02	Secondary Assembly	1	Manual assembly operations for complex components	85.00	units/day	48.50	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active
3	WC-SUBASM	Sub-Assembly Station	2	Pre-assembly of component groups before main assembly	200.00	units/day	42.25	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active
4	WC-MCH-01	CNC Machining Center	2	Precision CNC machining for critical components	65.00	units/day	78.50	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active
5	WC-MCH-02	Milling Station	3	Multi-axis milling operations for complex geometries	40.00	units/day	82.75	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active
6	WC-QC-01	Quality Inspection	1	Manual and automated quality inspection station	180.00	units/day	45.25	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active
7	WC-PKG-01	Packaging Line	1	Automated packaging system for finished products	200.00	units/day	38.75	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active
8	WC-WELD-01	Robotic Welding	4	Automated welding cells for consistent high-quality joints	60.00	units/day	72.25	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active
9	WC-LASER	Laser Cutting Station	5	Precision laser cutting for sheet materials	70.00	units/day	92.50	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	maintenance
10	WC-3DPRINT	Additive Manufacturing	6	3D printing facility for prototypes and small production runs	30.00	units/day	105.75	f	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	inactive
11	WC-W001A	Assembly Line - East Coast Warehouse	2	Main assembly line for East Coast Warehouse	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE
12	WC-p001A	Assembly Line - plant South East	4	Main assembly line for plant South East	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE
13	WC-P004A	Assembly Line - Shanghai Facility	6	Main assembly line for Shanghai Facility	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE
14	WC-P003A	Assembly Line - Berlin Production	5	Main assembly line for Berlin Production	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE
15	WC-P001A	Assembly Line - Main Factory	1	Main assembly line for Main Factory	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE
16	WC-W003P	Packaging - Asian Distribution Hub	8	Packaging workstation for Asian Distribution Hub	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE
17	WC-P004P	Packaging - Shanghai Facility	6	Packaging workstation for Shanghai Facility	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE
18	WC-p001P	Packaging - plant South East	4	Packaging workstation for plant South East	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE
19	WC-W004P	Packaging - UK Warehouse	9	Packaging workstation for UK Warehouse	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE
20	WC-W001P	Packaging - East Coast Warehouse	2	Packaging workstation for East Coast Warehouse	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE
\.


--
-- Name: approval_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.approval_levels_id_seq', 11, true);


--
-- Name: asset_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.asset_master_id_seq', 15, true);


--
-- Name: bill_of_materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.bill_of_materials_id_seq', 8, true);


--
-- Name: bom_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.bom_items_id_seq', 18, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, true);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 37, true);


--
-- Name: company_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.company_codes_id_seq', 16, true);


--
-- Name: cost_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.cost_centers_id_seq', 15, true);


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.countries_id_seq', 12, true);


--
-- Name: credit_control_areas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.credit_control_areas_id_seq', 5, true);


--
-- Name: currencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.currencies_id_seq', 5, true);


--
-- Name: customer_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.customer_contacts_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.customers_id_seq', 5, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.employees_id_seq', 12, true);


--
-- Name: erp_customer_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.erp_customer_contacts_id_seq', 10, true);


--
-- Name: erp_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.erp_customers_id_seq', 10, true);


--
-- Name: erp_vendor_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.erp_vendor_contacts_id_seq', 12, true);


--
-- Name: erp_vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.erp_vendors_id_seq', 12, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, false);


--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.fiscal_periods_id_seq', 12, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: material_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.material_categories_id_seq', 11, true);


--
-- Name: materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.materials_id_seq', 17, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: plants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.plants_id_seq', 9, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: profit_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.profit_centers_id_seq', 15, true);


--
-- Name: purchase_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.purchase_groups_id_seq', 12, true);


--
-- Name: purchase_organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.purchase_organizations_id_seq', 24, true);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.regions_id_seq', 4, true);


--
-- Name: sales_organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.sales_organizations_id_seq', 25, true);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 1, false);


--
-- Name: storage_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.storage_locations_id_seq', 52, true);


--
-- Name: supply_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.supply_types_id_seq', 11, true);


--
-- Name: tax_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tax_codes_id_seq', 18, true);


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.units_of_measure_id_seq', 30, true);


--
-- Name: uom_conversions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.uom_conversions_id_seq', 6, true);


--
-- Name: uom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.uom_id_seq', 14, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: vendor_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.vendor_contacts_id_seq', 1, false);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.vendors_id_seq', 5, true);


--
-- Name: work_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.work_centers_id_seq', 20, true);


--
-- Name: approval_levels approval_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.approval_levels
    ADD CONSTRAINT approval_levels_pkey PRIMARY KEY (id);


--
-- Name: asset_master asset_master_asset_number_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.asset_master
    ADD CONSTRAINT asset_master_asset_number_key UNIQUE (asset_number);


--
-- Name: asset_master asset_master_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.asset_master
    ADD CONSTRAINT asset_master_pkey PRIMARY KEY (id);


--
-- Name: bill_of_materials bill_of_materials_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bill_of_materials
    ADD CONSTRAINT bill_of_materials_code_key UNIQUE (code);


--
-- Name: bill_of_materials bill_of_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bill_of_materials
    ADD CONSTRAINT bill_of_materials_pkey PRIMARY KEY (id);


--
-- Name: bom_items bom_items_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bom_items
    ADD CONSTRAINT bom_items_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_unique UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_code_key UNIQUE (code);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: company_codes company_code_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.company_codes
    ADD CONSTRAINT company_code_unique UNIQUE (code);


--
-- Name: company_codes company_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.company_codes
    ADD CONSTRAINT company_codes_code_key UNIQUE (code);


--
-- Name: company_codes company_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.company_codes
    ADD CONSTRAINT company_codes_pkey PRIMARY KEY (id);


--
-- Name: cost_centers cost_centers_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_code_key UNIQUE (code);


--
-- Name: cost_centers cost_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_pkey PRIMARY KEY (id);


--
-- Name: countries countries_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_code_key UNIQUE (code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: credit_control_areas credit_control_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_control_areas
    ADD CONSTRAINT credit_control_areas_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_code_key UNIQUE (code);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: customer_contacts customer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customer_contacts
    ADD CONSTRAINT customer_contacts_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- Name: employees employees_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_employee_id_key UNIQUE (employee_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: erp_customer_contacts erp_customer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_customer_contacts
    ADD CONSTRAINT erp_customer_contacts_pkey PRIMARY KEY (id);


--
-- Name: erp_customers erp_customers_customer_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_customers
    ADD CONSTRAINT erp_customers_customer_code_key UNIQUE (customer_code);


--
-- Name: erp_customers erp_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_customers
    ADD CONSTRAINT erp_customers_pkey PRIMARY KEY (id);


--
-- Name: erp_vendor_contacts erp_vendor_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_vendor_contacts
    ADD CONSTRAINT erp_vendor_contacts_pkey PRIMARY KEY (id);


--
-- Name: erp_vendors erp_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_vendors
    ADD CONSTRAINT erp_vendors_pkey PRIMARY KEY (id);


--
-- Name: erp_vendors erp_vendors_vendor_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_vendors
    ADD CONSTRAINT erp_vendors_vendor_code_key UNIQUE (vendor_code);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: fiscal_periods fiscal_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_pkey PRIMARY KEY (id);


--
-- Name: fiscal_periods fiscal_periods_year_period_company_code_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_year_period_company_code_id_key UNIQUE (year, period, company_code_id);


--
-- Name: invoices invoices_invoice_number_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_unique UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: material_categories material_categories_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.material_categories
    ADD CONSTRAINT material_categories_code_key UNIQUE (code);


--
-- Name: material_categories material_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.material_categories
    ADD CONSTRAINT material_categories_pkey PRIMARY KEY (id);


--
-- Name: materials materials_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_code_key UNIQUE (code);


--
-- Name: materials materials_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_number_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_unique UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: plants plants_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plants
    ADD CONSTRAINT plants_code_key UNIQUE (code);


--
-- Name: plants plants_code_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plants
    ADD CONSTRAINT plants_code_unique UNIQUE (code);


--
-- Name: plants plants_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plants
    ADD CONSTRAINT plants_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_unique UNIQUE (sku);


--
-- Name: profit_centers profit_centers_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.profit_centers
    ADD CONSTRAINT profit_centers_code_key UNIQUE (code);


--
-- Name: profit_centers profit_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.profit_centers
    ADD CONSTRAINT profit_centers_pkey PRIMARY KEY (id);


--
-- Name: purchase_groups purchase_groups_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_groups
    ADD CONSTRAINT purchase_groups_code_key UNIQUE (code);


--
-- Name: purchase_groups purchase_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_groups
    ADD CONSTRAINT purchase_groups_pkey PRIMARY KEY (id);


--
-- Name: purchase_organizations purchase_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_organizations
    ADD CONSTRAINT purchase_organizations_pkey PRIMARY KEY (id);


--
-- Name: regions regions_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_code_key UNIQUE (code);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: sales_organizations sales_organizations_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales_organizations
    ADD CONSTRAINT sales_organizations_code_key UNIQUE (code);


--
-- Name: sales_organizations sales_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales_organizations
    ADD CONSTRAINT sales_organizations_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_code_key UNIQUE (code);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: supply_types supply_types_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.supply_types
    ADD CONSTRAINT supply_types_code_key UNIQUE (code);


--
-- Name: supply_types supply_types_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.supply_types
    ADD CONSTRAINT supply_types_pkey PRIMARY KEY (id);


--
-- Name: tax_codes tax_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tax_codes
    ADD CONSTRAINT tax_codes_code_key UNIQUE (code);


--
-- Name: tax_codes tax_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tax_codes
    ADD CONSTRAINT tax_codes_pkey PRIMARY KEY (id);


--
-- Name: units_of_measure units_of_measure_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_code_key UNIQUE (code);


--
-- Name: units_of_measure units_of_measure_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_pkey PRIMARY KEY (id);


--
-- Name: uom uom_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.uom
    ADD CONSTRAINT uom_code_key UNIQUE (code);


--
-- Name: uom_conversions uom_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.uom_conversions
    ADD CONSTRAINT uom_conversions_pkey PRIMARY KEY (id);


--
-- Name: uom uom_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.uom
    ADD CONSTRAINT uom_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: vendor_contacts vendor_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vendor_contacts
    ADD CONSTRAINT vendor_contacts_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_code_key UNIQUE (code);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: work_centers work_centers_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.work_centers
    ADD CONSTRAINT work_centers_code_key UNIQUE (code);


--
-- Name: work_centers work_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.work_centers
    ADD CONSTRAINT work_centers_pkey PRIMARY KEY (id);


--
-- Name: bom_items bom_items_bom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bom_items
    ADD CONSTRAINT bom_items_bom_id_fkey FOREIGN KEY (bom_id) REFERENCES public.bill_of_materials(id);


--
-- Name: categories categories_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: countries countries_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id);


--
-- Name: customers customers_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: employees employees_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.employees(id);


--
-- Name: expenses expenses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: fiscal_periods fiscal_periods_company_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_company_code_id_fkey FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: chart_of_accounts fk_company_code_chart; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT fk_company_code_chart FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: erp_customers fk_company_code_erp_customer; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_customers
    ADD CONSTRAINT fk_company_code_erp_customer FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: erp_vendors fk_company_code_erp_vendor; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_vendors
    ADD CONSTRAINT fk_company_code_erp_vendor FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: vendors fk_company_code_vendor; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT fk_company_code_vendor FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: credit_control_areas fk_credit_control_company_code; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.credit_control_areas
    ADD CONSTRAINT fk_credit_control_company_code FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: customer_contacts fk_customer; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customer_contacts
    ADD CONSTRAINT fk_customer FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: erp_customer_contacts fk_erp_customer; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_customer_contacts
    ADD CONSTRAINT fk_erp_customer FOREIGN KEY (customer_id) REFERENCES public.erp_customers(id) ON DELETE CASCADE;


--
-- Name: erp_vendor_contacts fk_erp_vendor; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_vendor_contacts
    ADD CONSTRAINT fk_erp_vendor FOREIGN KEY (vendor_id) REFERENCES public.erp_vendors(id) ON DELETE CASCADE;


--
-- Name: chart_of_accounts fk_parent_account; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT fk_parent_account FOREIGN KEY (parent_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: erp_customers fk_parent_erp_customer; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.erp_customers
    ADD CONSTRAINT fk_parent_erp_customer FOREIGN KEY (parent_customer_id) REFERENCES public.erp_customers(id);


--
-- Name: purchase_organizations fk_purchase_org_company_code; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_organizations
    ADD CONSTRAINT fk_purchase_org_company_code FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: materials fk_uom; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT fk_uom FOREIGN KEY (uom_id) REFERENCES public.uom(id);


--
-- Name: vendor_contacts fk_vendor; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vendor_contacts
    ADD CONSTRAINT fk_vendor FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: invoices invoices_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: material_categories material_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.material_categories
    ADD CONSTRAINT material_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.material_categories(id);


--
-- Name: order_items order_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_items order_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders orders_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: plants plants_company_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plants
    ADD CONSTRAINT plants_company_code_id_fkey FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: products products_category_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: products products_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sales_organizations sales_organizations_company_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales_organizations
    ADD CONSTRAINT sales_organizations_company_code_id_fkey FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: stock_movements stock_movements_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_movements stock_movements_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_locations storage_locations_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: units_of_measure units_of_measure_base_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_base_uom_id_fkey FOREIGN KEY (base_uom_id) REFERENCES public.units_of_measure(id);


--
-- Name: uom_conversions uom_conversions_from_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.uom_conversions
    ADD CONSTRAINT uom_conversions_from_uom_id_fkey FOREIGN KEY (from_uom_id) REFERENCES public.uom(id);


--
-- Name: uom_conversions uom_conversions_to_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.uom_conversions
    ADD CONSTRAINT uom_conversions_to_uom_id_fkey FOREIGN KEY (to_uom_id) REFERENCES public.uom(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

