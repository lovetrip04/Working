import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/apiClient";

// UI Components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialog } from "@/components/ui/alert-dialog";
import { PlusCircle, Edit, Trash2, ArrowUpDown, Download, Upload, RefreshCw, Map } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";

// Types for the data
interface Plant {
  id: number;
  code: string;
  name: string;
}

interface StorageLocation {
  id: number;
  code: string;
  name: string;
  description?: string;
  plantId: number;
  type: string;
  isMrpRelevant: boolean;
  isNegativeStockAllowed: boolean;
  isGoodsReceiptRelevant: boolean;
  isGoodsIssueRelevant: boolean;
  isInterimStorage: boolean;
  isTransitStorage: boolean;
  isRestrictedUse: boolean;
  status: string;
  isActive: boolean;
  notes?: string;
  plant?: Plant;
}

// Validation schema for the form
const storageLocationFormSchema = z.object({
  code: z.string().min(2, "Code must be at least 2 characters").max(10, "Code must be at most 10 characters"),
  name: z.string().min(3, "Name must be at least 3 characters"),
  description: z.string().optional(),
  plantId: z.coerce.number().min(1, "Plant is required"),
  type: z.string().min(1, "Type is required"),
  isMrpRelevant: z.boolean().default(true),
  isNegativeStockAllowed: z.boolean().default(false),
  isGoodsReceiptRelevant: z.boolean().default(true),
  isGoodsIssueRelevant: z.boolean().default(true),
  isInterimStorage: z.boolean().default(false),
  isTransitStorage: z.boolean().default(false),
  isRestrictedUse: z.boolean().default(false),
  status: z.string().default("active"),
  isActive: z.boolean().default(true),
  notes: z.string().optional(),
});

// StorageLocation Table Component
interface StorageLocationTableProps {
  storageLocations: StorageLocation[];
  isLoading: boolean;
  onEdit: (storageLocation: StorageLocation) => void;
  onDelete: (storageLocation: StorageLocation) => void;
}

function StorageLocationTable({ storageLocations, isLoading, onEdit, onDelete }: StorageLocationTableProps) {
  return (
    <Card>
      <CardContent className="p-0">
        <div className="border rounded-md">
          <div className="relative max-h-[600px] overflow-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-white z-10">
                <TableRow>
                  <TableHead className="w-[100px]">Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Plant</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="w-[120px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : storageLocations.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      No storage locations found.
                    </TableCell>
                  </TableRow>
                ) : (
                  storageLocations.map((location) => (
                    <TableRow key={location.id}>
                      <TableCell className="font-medium">{location.code}</TableCell>
                      <TableCell>{location.name}</TableCell>
                      <TableCell>{location.plant ? `${location.plant.code} - ${location.plant.name}` : location.plantId}</TableCell>
                      <TableCell>
                        {location.type === 'raw_material' ? 'Raw Material' : 
                         location.type === 'finished_goods' ? 'Finished Goods' : 
                         location.type}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant={location.status === 'active' ? 'default' : 'secondary'}>
                          {location.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onEdit(location)}
                          className="h-8 w-8"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onDelete(location)}
                          className="h-8 w-8 text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function StorageLocation() {
  // State management
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingStorageLocation, setEditingStorageLocation] = useState<StorageLocation | null>(null);
  const [deletingStorageLocation, setDeletingStorageLocation] = useState<StorageLocation | null>(null);
  const [activeTab, setActiveTab] = useState("basic");

  // Forms
  const addForm = useForm<z.infer<typeof storageLocationFormSchema>>({
    resolver: zodResolver(storageLocationFormSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      type: "raw_material",
      isMrpRelevant: true,
      isNegativeStockAllowed: false,
      isGoodsReceiptRelevant: true,
      isGoodsIssueRelevant: true,
      isInterimStorage: false,
      isTransitStorage: false,
      isRestrictedUse: false,
      status: "active",
      isActive: true,
      notes: "",
    },
  });

  const editForm = useForm<z.infer<typeof storageLocationFormSchema>>({
    resolver: zodResolver(storageLocationFormSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      type: "raw_material",
      isMrpRelevant: true,
      isNegativeStockAllowed: false,
      isGoodsReceiptRelevant: true,
      isGoodsIssueRelevant: true,
      isInterimStorage: false,
      isTransitStorage: false,
      isRestrictedUse: false,
      status: "active",
      isActive: true,
      notes: "",
    },
  });

  // Fetch data
  const { data: storageLocations = [] as StorageLocation[], isLoading, error, refetch: refetchStorageLocations } = useQuery({
    queryKey: ['/api/master-data/storage-location'],
    retry: 1,
  });

  const { data: plants = [] as Plant[] } = useQuery({
    queryKey: ['/api/master-data/plant'],
    retry: 1,
  });

  // Mutations
  const addStorageLocationMutation = useMutation({
    mutationFn: (data: z.infer<typeof storageLocationFormSchema>) => 
      apiRequest('/api/master-data/storage-location', 'POST', data),
    onSuccess: () => {
      // Force immediate refetch to update the table
      refetchStorageLocations();
      
      // Clean up the form state
      setIsAddDialogOpen(false);
      setActiveTab("basic"); // Reset tab when closed
      addForm.reset();
      
      toast({
        title: "Storage Location Added",
        description: "Storage location has been successfully added.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add storage location. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateStorageLocationMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: z.infer<typeof storageLocationFormSchema> }) => 
      apiRequest(`/api/master-data/storage-location/${id}`, 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/storage-location'] });
      setIsEditDialogOpen(false);
      setActiveTab("basic"); // Reset tab when closed
      setEditingStorageLocation(null);
      toast({
        title: "Storage Location Updated",
        description: "Storage location has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update storage location. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteStorageLocationMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/master-data/storage-location/${id}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/storage-location'] });
      setIsDeleteDialogOpen(false);
      setDeletingStorageLocation(null);
      toast({
        title: "Storage Location Deleted",
        description: "Storage location has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete storage location. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Form submit handlers
  const handleAddSubmit = (data: z.infer<typeof storageLocationFormSchema>) => {
    // Check for validation errors
    const formErrors = addForm.formState.errors;
    if (Object.keys(formErrors).length > 0) {
      // Collect all error messages
      const errorMessages = Object.entries(formErrors)
        .map(([field, error]) => {
          const fieldName = field.charAt(0).toUpperCase() + field.slice(1);
          return `${fieldName}: ${error.message}`;
        })
        .join("\n");

      // Display error toast with all validation errors
      toast({
        title: "Validation Error",
        description: "Please fix the following errors:\n" + errorMessages,
        variant: "destructive",
      });
      
      // Highlight the tab with errors
      if (formErrors.code || formErrors.name || formErrors.plantId || formErrors.type) {
        setActiveTab("basic");
      } else if (formErrors.isMrpRelevant || formErrors.isNegativeStockAllowed || 
                formErrors.isGoodsReceiptRelevant || formErrors.isGoodsIssueRelevant) {
        setActiveTab("settings");
      } else {
        setActiveTab("additional");
      }
      
      return;
    }
    
    // If validation passes, submit the data
    addStorageLocationMutation.mutate(data);
  };

  const handleEditSubmit = (data: z.infer<typeof storageLocationFormSchema>) => {
    if (!editingStorageLocation) return;
    
    // Check for validation errors
    const formErrors = editForm.formState.errors;
    if (Object.keys(formErrors).length > 0) {
      // Collect all error messages
      const errorMessages = Object.entries(formErrors)
        .map(([field, error]) => {
          const fieldName = field.charAt(0).toUpperCase() + field.slice(1);
          return `${fieldName}: ${error.message}`;
        })
        .join("\n");

      // Display error toast with all validation errors
      toast({
        title: "Validation Error",
        description: "Please fix the following errors:\n" + errorMessages,
        variant: "destructive",
      });
      
      // Highlight the tab with errors
      if (formErrors.code || formErrors.name || formErrors.plantId || formErrors.type) {
        setActiveTab("basic");
      } else if (formErrors.isMrpRelevant || formErrors.isNegativeStockAllowed || 
                formErrors.isGoodsReceiptRelevant || formErrors.isGoodsIssueRelevant) {
        setActiveTab("settings");
      } else {
        setActiveTab("additional");
      }
      
      return;
    }
    
    updateStorageLocationMutation.mutate({ id: editingStorageLocation.id, data });
  };

  const openEditDialog = (storageLocation: StorageLocation) => {
    setEditingStorageLocation(storageLocation);
    setActiveTab("basic"); // Reset to first tab
    editForm.reset({
      code: storageLocation.code,
      name: storageLocation.name,
      description: storageLocation.description || "",
      plantId: storageLocation.plantId,
      type: storageLocation.type,
      isMrpRelevant: storageLocation.isMrpRelevant,
      isNegativeStockAllowed: storageLocation.isNegativeStockAllowed,
      isGoodsReceiptRelevant: storageLocation.isGoodsReceiptRelevant,
      isGoodsIssueRelevant: storageLocation.isGoodsIssueRelevant,
      isInterimStorage: storageLocation.isInterimStorage,
      isTransitStorage: storageLocation.isTransitStorage,
      isRestrictedUse: storageLocation.isRestrictedUse,
      status: storageLocation.status,
      isActive: storageLocation.isActive,
      notes: storageLocation.notes || "",
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (storageLocation: StorageLocation) => {
    setDeletingStorageLocation(storageLocation);
    setIsDeleteDialogOpen(true);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Storage Location Management</h1>
          <p className="text-gray-600 mt-1">
            Manage storage locations within plants for inventory organization
          </p>
        </div>
        <Button 
          variant="default" 
          onClick={() => setIsAddDialogOpen(true)}
          className="space-x-2"
        >
          <PlusCircle className="h-4 w-4" />
          <span>Add Storage Location</span>
        </Button>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Locations</TabsTrigger>
          <TabsTrigger value="raw-material">Raw Materials</TabsTrigger>
          <TabsTrigger value="finished-goods">Finished Goods</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <StorageLocationTable 
            storageLocations={storageLocations}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="raw-material">
          <StorageLocationTable 
            storageLocations={storageLocations.filter(loc => loc.type === 'raw_material')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="finished-goods">
          <StorageLocationTable 
            storageLocations={storageLocations.filter(loc => loc.type === 'finished_goods')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
      </Tabs>

      {/* Add Storage Location Dialog */}
      <Dialog 
        open={isAddDialogOpen} 
        onOpenChange={(open) => {
          setIsAddDialogOpen(open);
          if (!open) setActiveTab("basic");
        }}
      >
        <DialogContent className="sm:max-w-[800px] max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Add New Storage Location</DialogTitle>
            <DialogDescription>
              Enter storage location details to track inventory within a plant.
            </DialogDescription>
          </DialogHeader>
          
          <div className="overflow-y-auto max-h-[calc(90vh-180px)] pr-2 my-2">
            <Form {...addForm}>
              <form className="space-y-6">
                
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="mb-4 grid w-full grid-cols-3">
                    <TabsTrigger value="basic">Basic Info</TabsTrigger>
                    <TabsTrigger value="settings">Settings</TabsTrigger>
                    <TabsTrigger value="additional">Additional Info</TabsTrigger>
                  </TabsList>
                  
                  {/* Basic Info Tab */}
                  <TabsContent value="basic" className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={addForm.control}
                        name="code"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Storage Location Code*</FormLabel>
                            <FormControl>
                              <Input placeholder="SL001" {...field} />
                            </FormControl>
                            <FormDescription>
                              Unique identifier
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name*</FormLabel>
                            <FormControl>
                              <Input placeholder="Main Warehouse" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addForm.control}
                        name="plantId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Plant*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value?.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select Plant" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {plants.map((plant) => (
                                  <SelectItem key={plant.id} value={plant.id.toString()}>
                                    {plant.code} - {plant.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={addForm.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select Type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="raw_material">Raw Material</SelectItem>
                                <SelectItem value="work_in_process">Work in Process</SelectItem>
                                <SelectItem value="finished_goods">Finished Goods</SelectItem>
                                <SelectItem value="quality_inspection">Quality Inspection</SelectItem>
                                <SelectItem value="returns">Returns</SelectItem>
                                <SelectItem value="transit">Transit</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addForm.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select Status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="maintenance">Maintenance</SelectItem>
                                <SelectItem value="restricted">Restricted</SelectItem>
                                <SelectItem value="inactive">Inactive</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={addForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Detailed description of the storage location" 
                              className="min-h-[80px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                  
                  {/* Settings Tab */}
                  <TabsContent value="settings" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-4">
                        <FormField
                          control={addForm.control}
                          name="isMrpRelevant"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>MRP Relevant</FormLabel>
                                <FormDescription>
                                  Include in materials planning
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                      
                        <FormField
                          control={addForm.control}
                          name="isGoodsReceiptRelevant"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Goods Receipt Relevant</FormLabel>
                                <FormDescription>
                                  Can receive goods
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                      
                        <FormField
                          control={addForm.control}
                          name="isInterimStorage"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Interim Storage</FormLabel>
                                <FormDescription>
                                  Temporary storage location
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="space-y-4">
                        <FormField
                          control={addForm.control}
                          name="isNegativeStockAllowed"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Negative Stock Allowed</FormLabel>
                                <FormDescription>
                                  Allow negative inventory
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                      
                        <FormField
                          control={addForm.control}
                          name="isGoodsIssueRelevant"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Goods Issue Relevant</FormLabel>
                                <FormDescription>
                                  Can issue goods
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                      
                        <FormField
                          control={addForm.control}
                          name="isRestrictedUse"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>Restricted Use</FormLabel>
                                <FormDescription>
                                  Limited access location
                                </FormDescription>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </TabsContent>
                  
                  {/* Additional Info Tab */}
                  <TabsContent value="additional" className="space-y-4">
                    <FormField
                      control={addForm.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Additional information about this storage location" 
                              className="min-h-[80px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                </Tabs>

                <DialogFooter className="pt-4">
                  <div className="flex w-full justify-between">
                    <div>
                      {activeTab !== "basic" && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            if (activeTab === "settings") setActiveTab("basic");
                            if (activeTab === "additional") setActiveTab("settings");
                          }}
                        >
                          Back
                        </Button>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setIsAddDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      
                      {activeTab !== "additional" ? (
                        <Button 
                          type="button"
                          onClick={() => {
                            // Validate current tab fields before proceeding
                            if (activeTab === "basic") {
                              // Check basic tab fields
                              const basicTabValid = addForm.trigger(["code", "name", "plantId", "type"]);
                              basicTabValid.then(isValid => {
                                if (isValid) {
                                  setActiveTab("settings");
                                } else {
                                  toast({
                                    title: "Validation Error",
                                    description: "Please fill in all required fields marked with *",
                                    variant: "destructive",
                                  });
                                }
                              });
                            }
                            if (activeTab === "settings") setActiveTab("additional");
                          }}
                        >
                          Next
                        </Button>
                      ) : (
                        <Button 
                          type="button" 
                          disabled={addStorageLocationMutation.isPending}
                          onClick={() => {
                            // Only validate and submit when Create button is clicked
                            addForm.handleSubmit(handleAddSubmit)();
                          }}
                        >
                          {addStorageLocationMutation.isPending ? "Creating..." : "Create Storage Location"}
                        </Button>
                      )}
                    </div>
                  </div>
                </DialogFooter>
              </form>
            </Form>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Storage Location Dialog */}
      <Dialog 
        open={isEditDialogOpen} 
        onOpenChange={(open) => {
          setIsEditDialogOpen(open);
          if (!open) {
            setActiveTab("basic");
            setEditingStorageLocation(null);
          }
        }}
      >
        <DialogContent className="sm:max-w-[800px] max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Edit Storage Location</DialogTitle>
            <DialogDescription>
              Update storage location details.
            </DialogDescription>
          </DialogHeader>
          
          <div className="overflow-y-auto max-h-[calc(90vh-180px)] pr-2 my-2">
            {editingStorageLocation && (
              <Form {...editForm}>
                <form className="space-y-6">
                  
                  <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="mb-4 grid w-full grid-cols-3">
                      <TabsTrigger value="basic">Basic Info</TabsTrigger>
                      <TabsTrigger value="settings">Settings</TabsTrigger>
                      <TabsTrigger value="additional">Additional Info</TabsTrigger>
                    </TabsList>
                    
                    {/* Basic Info Tab */}
                    <TabsContent value="basic" className="space-y-4">
                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={editForm.control}
                          name="code"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Storage Location Code*</FormLabel>
                              <FormControl>
                                <Input placeholder="SL001" {...field} />
                              </FormControl>
                              <FormDescription>
                                Unique identifier
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={editForm.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Name*</FormLabel>
                              <FormControl>
                                <Input placeholder="Main Warehouse" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={editForm.control}
                          name="plantId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Plant*</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value?.toString()}
                                value={field.value?.toString()}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select Plant" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {plants.map((plant) => (
                                    <SelectItem key={plant.id} value={plant.id.toString()}>
                                      {plant.code} - {plant.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={editForm.control}
                          name="type"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Type*</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select Type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="raw_material">Raw Material</SelectItem>
                                  <SelectItem value="work_in_process">Work in Process</SelectItem>
                                  <SelectItem value="finished_goods">Finished Goods</SelectItem>
                                  <SelectItem value="quality_inspection">Quality Inspection</SelectItem>
                                  <SelectItem value="returns">Returns</SelectItem>
                                  <SelectItem value="transit">Transit</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={editForm.control}
                          name="status"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Status*</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select Status" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="active">Active</SelectItem>
                                  <SelectItem value="maintenance">Maintenance</SelectItem>
                                  <SelectItem value="restricted">Restricted</SelectItem>
                                  <SelectItem value="inactive">Inactive</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={editForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Detailed description of the storage location" 
                                className="min-h-[80px]" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </TabsContent>
                    
                    {/* Settings Tab */}
                    <TabsContent value="settings" className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-4">
                          <FormField
                            control={editForm.control}
                            name="isMrpRelevant"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>MRP Relevant</FormLabel>
                                  <FormDescription>
                                    Include in materials planning
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                        
                          <FormField
                            control={editForm.control}
                            name="isGoodsReceiptRelevant"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>Goods Receipt Relevant</FormLabel>
                                  <FormDescription>
                                    Can receive goods
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                        
                          <FormField
                            control={editForm.control}
                            name="isInterimStorage"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>Interim Storage</FormLabel>
                                  <FormDescription>
                                    Temporary storage location
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="space-y-4">
                          <FormField
                            control={editForm.control}
                            name="isNegativeStockAllowed"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>Negative Stock Allowed</FormLabel>
                                  <FormDescription>
                                    Allow negative inventory
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                        
                          <FormField
                            control={editForm.control}
                            name="isGoodsIssueRelevant"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>Goods Issue Relevant</FormLabel>
                                  <FormDescription>
                                    Can issue goods
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                        
                          <FormField
                            control={editForm.control}
                            name="isRestrictedUse"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>Restricted Use</FormLabel>
                                  <FormDescription>
                                    Limited access location
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                    </TabsContent>
                    
                    {/* Additional Info Tab */}
                    <TabsContent value="additional" className="space-y-4">
                      <FormField
                        control={editForm.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Notes</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Additional information about this storage location" 
                                className="min-h-[80px]" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </TabsContent>
                  </Tabs>

                  <DialogFooter className="pt-4">
                    <div className="flex w-full justify-between">
                      <div>
                        {activeTab !== "basic" && (
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => {
                              if (activeTab === "settings") setActiveTab("basic");
                              if (activeTab === "additional") setActiveTab("settings");
                            }}
                          >
                            Back
                          </Button>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setIsEditDialogOpen(false)}
                        >
                          Cancel
                        </Button>
                        
                        {activeTab !== "additional" ? (
                          <Button 
                            type="button"
                            onClick={() => {
                              // Validate current tab fields before proceeding
                              if (activeTab === "basic") {
                                // Check basic tab fields
                                const basicTabValid = editForm.trigger(["code", "name", "plantId", "type"]);
                                basicTabValid.then(isValid => {
                                  if (isValid) {
                                    setActiveTab("settings");
                                  } else {
                                    toast({
                                      title: "Validation Error",
                                      description: "Please fill in all required fields marked with *",
                                      variant: "destructive",
                                    });
                                  }
                                });
                              }
                              if (activeTab === "settings") setActiveTab("additional");
                            }}
                          >
                            Next
                          </Button>
                        ) : (
                          <Button 
                            type="button" 
                            disabled={updateStorageLocationMutation.isPending}
                            onClick={() => {
                              // Only validate and submit when Update button is clicked
                              editForm.handleSubmit(handleEditSubmit)();
                            }}
                          >
                            {updateStorageLocationMutation.isPending ? "Updating..." : "Update Storage Location"}
                          </Button>
                        )}
                      </div>
                    </div>
                  </DialogFooter>
                </form>
              </Form>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the storage location &ldquo;
              {deletingStorageLocation?.name}&rdquo; (Code: {deletingStorageLocation?.code}).
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeletingStorageLocation(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (deletingStorageLocation) {
                  deleteStorageLocationMutation.mutate(deletingStorageLocation.id);
                }
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteStorageLocationMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}