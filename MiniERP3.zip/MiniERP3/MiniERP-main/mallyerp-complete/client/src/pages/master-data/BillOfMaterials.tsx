import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, RefreshCw, Plus, Pencil, Trash2, ChevronDown, ChevronRight, List } from "lucide-react";

interface BOM {
  id: number;
  code: string;
  name: string;
  material_id: number;
  description: string;
  version: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface BOMItem {
  id: number;
  bom_id: number;
  material_id: number;
  quantity: number;
  unit_cost: number | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface Material {
  id: number;
  code: string;
  name: string;
  type: string;
  description: string;
}

export default function BillOfMaterialsPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedBoms, setExpandedBoms] = useState<{[key: number]: boolean}>({});
  
  // Fetch bill of materials data
  const { data: boms = [], isLoading: bomsLoading, refetch } = useQuery<BOM[]>({
    queryKey: ["/api/master-data/bom"],
    retry: 1,
  });

  // Fetch BOM items data
  const { data: bomItems = [], isLoading: bomItemsLoading } = useQuery<BOMItem[]>({
    queryKey: ["/api/master-data/bom-items"],
    retry: 1,
  });

  // Fetch materials for reference
  const { data: materials = [], isLoading: materialsLoading } = useQuery<Material[]>({
    queryKey: ["/api/master-data/material"],
    retry: 1,
  });

  // Handle search
  const filteredBoms = boms.filter((bom) => {
    return (
      bom.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bom.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bom.description?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // Handle expand/collapse of BOM details
  const toggleBomExpand = (bomId: number) => {
    setExpandedBoms(prev => ({
      ...prev,
      [bomId]: !prev[bomId]
    }));
  };

  // Get material name by ID
  const getMaterialNameById = (materialId: number) => {
    const material = materials.find(m => m.id === materialId);
    return material ? material.name : `Material #${materialId}`;
  };

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 md:gap-0">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Bill of Materials</h1>
          <p className="text-muted-foreground mt-1 text-sm md:text-base">
            Manage product structures and components
          </p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <Button variant="outline" className="flex-1 md:flex-none" onClick={() => refetch()} disabled={bomsLoading}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
          <Button 
            className="flex-1 md:flex-none"
            onClick={() => {
              toast({
                title: "New BOM",
                description: "BOM creation form will open here",
              });
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add BOM
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between gap-4 md:items-center">
            <div>
              <CardTitle>Bill of Materials</CardTitle>
              <CardDescription>
                Define product structures with components and quantities
              </CardDescription>
            </div>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search BOMs..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {bomsLoading || materialsLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="flex flex-col items-center gap-2">
                <RefreshCw className="h-8 w-8 animate-spin text-primary" />
                <p>Loading bill of materials...</p>
              </div>
            </div>
          ) : (
            <>
              {/* Desktop View */}
              <div className="hidden md:block border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-10"></TableHead>
                      <TableHead className="w-32">BOM Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>For Material</TableHead>
                      <TableHead>Version</TableHead>
                      <TableHead className="w-24">Status</TableHead>
                      <TableHead className="w-32">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBoms.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center">
                          {searchTerm ? "No matching BOMs found." : "No BOMs found."}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredBoms.map((bom) => (
                        <React.Fragment key={`desktop-bom-${bom.id}`}>
                          <TableRow className="cursor-pointer" onClick={() => toggleBomExpand(bom.id)}>
                            <TableCell>
                              {expandedBoms[bom.id] ? (
                                <ChevronDown className="h-4 w-4" />
                              ) : (
                                <ChevronRight className="h-4 w-4" />
                              )}
                            </TableCell>
                            <TableCell className="font-medium">{bom.code}</TableCell>
                            <TableCell>{bom.name}</TableCell>
                            <TableCell>{getMaterialNameById(bom.material_id)}</TableCell>
                            <TableCell>{bom.version}</TableCell>
                            <TableCell>
                              <Badge variant={bom.is_active ? "default" : "secondary"} className={bom.is_active ? "bg-green-100 text-green-800" : ""}>
                                {bom.is_active ? "Active" : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button size="icon" variant="ghost">
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button size="icon" variant="ghost">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                          
                          {/* Expanded component details */}
                          {expandedBoms[bom.id] && (
                            <TableRow>
                              <TableCell colSpan={7} className="p-0 border-t-0">
                                <div className="bg-muted/30 px-4 py-3">
                                  <div className="flex items-center gap-2 mb-2">
                                    <List className="h-4 w-4 text-muted-foreground" />
                                    <h4 className="font-medium">BOM Components</h4>
                                  </div>
                                  
                                  <Table>
                                    <TableHeader>
                                      <TableRow>
                                        <TableHead>Material</TableHead>
                                        <TableHead className="w-32">Quantity</TableHead>
                                        <TableHead className="w-32">Unit Cost</TableHead>
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {bomItems
                                        .filter(item => item.bom_id === bom.id)
                                        .map(item => (
                                          <TableRow key={`item-${item.id}`}>
                                            <TableCell>{getMaterialNameById(item.material_id)}</TableCell>
                                            <TableCell>{item.quantity}</TableCell>
                                            <TableCell>
                                              {item.unit_cost ? (
                                                `$${item.unit_cost.toFixed(2)}`
                                              ) : (
                                                "-"
                                              )}
                                            </TableCell>
                                          </TableRow>
                                        ))}
                                      
                                      {bomItems.filter(item => item.bom_id === bom.id).length === 0 && (
                                        <TableRow>
                                          <TableCell colSpan={3} className="text-center py-4">
                                            No components added to this BOM
                                          </TableCell>
                                        </TableRow>
                                      )}
                                    </TableBody>
                                  </Table>
                                </div>
                              </TableCell>
                            </TableRow>
                          )}
                        </React.Fragment>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
              
              {/* Mobile View */}
              <div className="md:hidden">
                {filteredBoms.length === 0 ? (
                  <div className="bg-white border rounded-md p-6 text-center text-gray-500">
                    {searchTerm ? "No matching BOMs found." : "No BOMs found."}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredBoms.map((bom) => (
                      <div key={`mobile-bom-${bom.id}`} className="bg-white border rounded-md overflow-hidden">
                        <div 
                          className="flex justify-between items-center p-4 cursor-pointer"
                          onClick={() => toggleBomExpand(bom.id)}
                        >
                          <div>
                            <div className="font-medium text-base">{bom.name}</div>
                            <div className="text-sm text-muted-foreground">{bom.code}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge variant={bom.is_active ? "default" : "secondary"} className={bom.is_active ? "bg-green-100 text-green-800" : ""}>
                              {bom.is_active ? "Active" : "Inactive"}
                            </Badge>
                            {expandedBoms[bom.id] ? (
                              <ChevronDown className="h-5 w-5 text-muted-foreground" />
                            ) : (
                              <ChevronRight className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                        </div>
                        
                        <div className="px-4 pb-2 text-sm grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-muted-foreground block">Material:</span>
                            <span className="truncate">{getMaterialNameById(bom.material_id)}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground block">Version:</span>
                            <span>{bom.version}</span>
                          </div>
                        </div>
                        
                        <div className="px-4 pb-3 flex justify-end gap-2">
                          <Button size="sm" variant="ghost">
                            <Pencil className="h-4 w-4 mr-1" />
                            Edit
                          </Button>
                          <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700">
                            <Trash2 className="h-4 w-4 mr-1" />
                            Delete
                          </Button>
                        </div>
                        
                        {/* Mobile BOM Components */}
                        {expandedBoms[bom.id] && (
                          <div className="px-4 py-3 bg-muted/30 border-t">
                            <div className="flex items-center gap-2 mb-2">
                              <List className="h-4 w-4 text-muted-foreground" />
                              <h4 className="font-medium">BOM Components</h4>
                            </div>
                            
                            {bomItems.filter(item => item.bom_id === bom.id).length === 0 ? (
                              <div className="text-center py-3 text-sm text-muted-foreground">
                                No components added to this BOM
                              </div>
                            ) : (
                              <div className="divide-y border-t border-b rounded-md overflow-hidden">
                                {bomItems
                                  .filter(item => item.bom_id === bom.id)
                                  .map(item => (
                                    <div key={`mobile-item-${item.id}`} className="py-2 px-3 bg-white">
                                      <div className="font-medium">{getMaterialNameById(item.material_id)}</div>
                                      <div className="grid grid-cols-2 text-sm mt-1">
                                        <div>
                                          <span className="text-muted-foreground">Quantity: </span>
                                          <span>{item.quantity}</span>
                                        </div>
                                        <div>
                                          <span className="text-muted-foreground">Unit Cost: </span>
                                          <span>{item.unit_cost ? `$${item.unit_cost.toFixed(2)}` : "-"}</span>
                                        </div>
                                      </div>
                                    </div>
                                  ))
                                }
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}