import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/apiClient";

// UI Components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialog } from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import { 
  Package2, Edit, Trash2, RefreshCw, Plus, FileUp,
  ArrowUpDown, FileText, BarChart2
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

// Define types
interface Material {
  id: number;
  code: string;
  name: string;
  type: string;
  description?: string;
  uomId: number;
  baseUnitPrice?: number;
  reOrderLevel?: number;
  minimumOrderQuantity?: number;
  leadTime?: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface UoM {
  id: number;
  code: string;
  name: string;
  description?: string;
  isActive: boolean;
}

// Form schema for material
const materialFormSchema = z.object({
  code: z.string().min(2, "Code must be at least 2 characters").max(10, "Code must be at most 10 characters"),
  name: z.string().min(3, "Name must be at least 3 characters"),
  type: z.string().min(1, "Material type is required"),
  description: z.string().optional(),
  uomId: z.coerce.number(),
  baseUnitPrice: z.coerce.number().optional(),
  reOrderLevel: z.coerce.number().optional(),
  minimumOrderQuantity: z.coerce.number().optional(),
  leadTime: z.coerce.number().optional(),
  isActive: z.boolean().default(true),
});

export default function Material() {
  // State management
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState<Material | null>(null);
  const [deletingMaterial, setDeletingMaterial] = useState<Material | null>(null);

  // Forms
  const addForm = useForm<z.infer<typeof materialFormSchema>>({
    resolver: zodResolver(materialFormSchema),
    defaultValues: {
      code: "",
      name: "",
      type: "finished_good",
      description: "",
      uomId: 0,
      baseUnitPrice: undefined,
      reOrderLevel: undefined,
      minimumOrderQuantity: undefined,
      leadTime: undefined,
      isActive: true,
    },
  });

  const editForm = useForm<z.infer<typeof materialFormSchema>>({
    resolver: zodResolver(materialFormSchema),
    defaultValues: {
      code: "",
      name: "",
      type: "finished_good",
      description: "",
      uomId: 0,
      baseUnitPrice: undefined,
      reOrderLevel: undefined,
      minimumOrderQuantity: undefined,
      leadTime: undefined,
      isActive: true,
    },
  });

  // Fetch data with simplified settings for better compatibility
  const { 
    data: materials = [], 
    isLoading: isLoadingMaterials, 
    isError: isMaterialsError,
    refetch: refetchMaterials
  } = useQuery({
    queryKey: ['/api/master-data/material'],
    retry: 3,
    retryDelay: 1000,
    refetchOnWindowFocus: false,
    staleTime: 30000 // 30 seconds
  });

  const { 
    data: uoms = [], 
    isLoading: isLoadingUoms,
    isError: isUomsError
  } = useQuery({
    queryKey: ['/api/master-data/uom'],
    retry: 3,
    retryDelay: 1000,
    refetchOnWindowFocus: false,
    staleTime: 30000 // 30 seconds
  });

  // Mutations
  const addMaterialMutation = useMutation({
    mutationFn: (data: z.infer<typeof materialFormSchema>) => 
      apiRequest('/api/master-data/material', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/material'] });
      setIsAddDialogOpen(false);
      addForm.reset();
      toast({
        title: "Material Added",
        description: "Material has been successfully added.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add material. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMaterialMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: z.infer<typeof materialFormSchema> }) => 
      apiRequest(`/api/master-data/material/${id}`, 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/material'] });
      setIsEditDialogOpen(false);
      setEditingMaterial(null);
      toast({
        title: "Material Updated",
        description: "Material has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update material. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMaterialMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/master-data/material/${id}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/material'] });
      setIsDeleteDialogOpen(false);
      setDeletingMaterial(null);
      toast({
        title: "Material Deleted",
        description: "Material has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete material. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Form submit handlers
  const handleAddSubmit = (data: z.infer<typeof materialFormSchema>) => {
    addMaterialMutation.mutate(data);
  };

  const handleEditSubmit = (data: z.infer<typeof materialFormSchema>) => {
    if (!editingMaterial) return;
    updateMaterialMutation.mutate({ id: editingMaterial.id, data });
  };

  const openEditDialog = (material: Material) => {
    setEditingMaterial(material);
    editForm.reset({
      code: material.code,
      name: material.name,
      type: material.type,
      description: material.description || "",
      uomId: material.uomId,
      baseUnitPrice: material.baseUnitPrice,
      reOrderLevel: material.reOrderLevel,
      minimumOrderQuantity: material.minimumOrderQuantity,
      leadTime: material.leadTime,
      isActive: material.isActive,
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (material: Material) => {
    setDeletingMaterial(material);
    setIsDeleteDialogOpen(true);
  };

  const isLoading = isLoadingMaterials || isLoadingUoms;

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Material Master</h1>
          <p className="text-gray-600 mt-1">
            Manage products, raw materials, and services
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
            onClick={() => {
              const csvContent = (materials as Material[])?.map((material: Material) => ({
                Code: material.code,
                Name: material.name,
                Type: material.type,
                Description: material.description || '',
                BasePrice: material.baseUnitPrice || '',
                ReorderLevel: material.reOrderLevel || '',
                LeadTime: material.leadTime || '',
                Status: material.isActive ? 'Active' : 'Inactive'
              })) || [];
              
              const csvString = [
                Object.keys(csvContent[0] || {}).join(','),
                ...csvContent.map((row: any) => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'materials.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            <FileUp className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button 
            variant="default" 
            onClick={() => setIsAddDialogOpen(true)}
            className="flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Add Material</span>
          </Button>
        </div>
      </div>
      
      <div className="flex justify-between items-center mt-8 mb-4">
        <h2 className="text-xl font-semibold">Material Catalog</h2>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm">
            <ArrowUpDown className="h-4 w-4 mr-2" />
            Sort
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => {
              const csvContent = (materials as Material[])?.map((material: Material) => ({
                Code: material.code,
                Name: material.name,
                Type: material.type,
                Description: material.description || '',
                BasePrice: material.baseUnitPrice || '',
                ReorderLevel: material.reOrderLevel || '',
                LeadTime: material.leadTime || '',
                Status: material.isActive ? 'Active' : 'Inactive'
              })) || [];
              
              const csvString = [
                Object.keys(csvContent[0] || {}).join(','),
                ...csvContent.map((row: any) => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'materials.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            <FileText className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="ghost" size="sm">
            <BarChart2 className="h-4 w-4 mr-2" />
            Reports
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Materials</TabsTrigger>
          <TabsTrigger value="finished">Finished Goods</TabsTrigger>
          <TabsTrigger value="raw">Raw Materials</TabsTrigger>
          <TabsTrigger value="packaging">Packaging</TabsTrigger>
          <TabsTrigger value="services">Services</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <MaterialTable 
            materials={materials as Material[]}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            uoms={uoms as UoM[]}
          />
        </TabsContent>
        
        <TabsContent value="finished">
          <MaterialTable 
            materials={(materials as Material[]).filter(mat => mat.type === 'FINI')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            uoms={uoms as UoM[]}
          />
        </TabsContent>
        
        <TabsContent value="raw">
          <MaterialTable 
            materials={(materials as Material[]).filter(mat => mat.type === 'RAW')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            uoms={uoms as UoM[]}
          />
        </TabsContent>
        
        <TabsContent value="packaging">
          <MaterialTable 
            materials={(materials as Material[]).filter(mat => mat.type === 'PACK')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            uoms={uoms as UoM[]}
          />
        </TabsContent>
        
        <TabsContent value="services">
          <MaterialTable 
            materials={(materials as Material[]).filter(mat => mat.type === 'SERV')}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
            uoms={uoms as UoM[]}
          />
        </TabsContent>
      </Tabs>

      {/* Add Material Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Material</DialogTitle>
            <DialogDescription>
              Enter the material details below. Required fields are marked with an asterisk.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...addForm}>
            <form onSubmit={addForm.handleSubmit(handleAddSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={addForm.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Material Code *</FormLabel>
                      <FormControl>
                        <Input placeholder="M1001" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={addForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Material Name *</FormLabel>
                      <FormControl>
                        <Input placeholder="Aluminum Plate" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={addForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Material Type *</FormLabel>
                      <FormControl>
                        <Select 
                          value={field.value} 
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select material type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="finished_good">Finished Good</SelectItem>
                            <SelectItem value="raw_material">Raw Material</SelectItem>
                            <SelectItem value="packaging">Packaging</SelectItem>
                            <SelectItem value="semifinished">Semi-Finished</SelectItem>
                            <SelectItem value="service">Service</SelectItem>
                            <SelectItem value="consumable">Consumable</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={addForm.control}
                  name="uomId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Base Unit of Measure *</FormLabel>
                      <FormControl>
                        <Select 
                          value={field.value.toString()} 
                          onValueChange={(value) => field.onChange(parseInt(value, 10))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select UoM" />
                          </SelectTrigger>
                          <SelectContent>
                            {(uoms as UoM[]).map((uom) => (
                              <SelectItem key={uom.id} value={uom.id.toString()}>
                                {uom.code} - {uom.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={addForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Provide a detailed description of the material" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={addForm.control}
                  name="baseUnitPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Base Unit Price</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          placeholder="0.00" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value ? parseFloat(e.target.value) : undefined;
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={addForm.control}
                  name="reOrderLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reorder Level</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value ? parseFloat(e.target.value) : undefined;
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={addForm.control}
                  name="minimumOrderQuantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Minimum Order Quantity</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value ? parseFloat(e.target.value) : undefined;
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={addForm.control}
                  name="leadTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Lead Time (Days)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value ? parseFloat(e.target.value) : undefined;
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={addForm.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                    <FormControl>
                      <Checkbox 
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Material will be available for transactions
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="submit" disabled={addMaterialMutation.isPending}>
                  {addMaterialMutation.isPending ? "Saving..." : "Save Material"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Material Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Material</DialogTitle>
            <DialogDescription>
              Update the material details below. Required fields are marked with an asterisk.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Material Code *</FormLabel>
                      <FormControl>
                        <Input placeholder="M1001" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Material Name *</FormLabel>
                      <FormControl>
                        <Input placeholder="Aluminum Plate" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Material Type *</FormLabel>
                      <FormControl>
                        <Select 
                          value={field.value} 
                          onValueChange={field.onChange}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select material type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="finished_good">Finished Good</SelectItem>
                            <SelectItem value="raw_material">Raw Material</SelectItem>
                            <SelectItem value="packaging">Packaging</SelectItem>
                            <SelectItem value="semifinished">Semi-Finished</SelectItem>
                            <SelectItem value="service">Service</SelectItem>
                            <SelectItem value="consumable">Consumable</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="uomId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Base Unit of Measure *</FormLabel>
                      <FormControl>
                        <Select 
                          value={field.value.toString()} 
                          onValueChange={(value) => field.onChange(parseInt(value, 10))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select UoM" />
                          </SelectTrigger>
                          <SelectContent>
                            {(uoms as UoM[]).map((uom) => (
                              <SelectItem key={uom.id} value={uom.id.toString()}>
                                {uom.code} - {uom.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={editForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Provide a detailed description of the material" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="baseUnitPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Base Unit Price</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          placeholder="0.00" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value ? parseFloat(e.target.value) : undefined;
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="reOrderLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reorder Level</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value ? parseFloat(e.target.value) : undefined;
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="minimumOrderQuantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Minimum Order Quantity</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value ? parseFloat(e.target.value) : undefined;
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editForm.control}
                  name="leadTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Lead Time (Days)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => {
                            const value = e.target.value ? parseFloat(e.target.value) : undefined;
                            field.onChange(value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={editForm.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                    <FormControl>
                      <Checkbox 
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Material will be available for transactions
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="submit" disabled={updateMaterialMutation.isPending}>
                  {updateMaterialMutation.isPending ? "Saving..." : "Update Material"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the material record for {deletingMaterial?.name}. 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingMaterial && deleteMaterialMutation.mutate(deletingMaterial.id)}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// Material Table Component with Scrolling Functionality
function MaterialTable({
  materials,
  isLoading,
  onEdit,
  onDelete,
  uoms
}: {
  materials: Material[];
  isLoading: boolean;
  onEdit: (material: Material) => void;
  onDelete: (material: Material) => void;
  uoms: UoM[];
}) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center items-center h-40">
            <div className="flex flex-col items-center">
              <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
              <p className="mt-2 text-gray-500">Loading materials...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!materials || materials.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center items-center h-40">
            <div className="flex flex-col items-center">
              <Package2 className="h-8 w-8 text-gray-400" />
              <p className="mt-2 text-gray-500">No materials found</p>
              <p className="text-sm text-gray-400">Add a material to get started</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Helper function to get UoM name by ID
  const getUomName = (uomId: number): string => {
    const uom = uoms.find(u => u.id === uomId);
    return uom ? uom.code : 'N/A';
  };

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <div className="max-h-[600px] overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-white z-10">
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>UoM</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {materials.map((material) => (
                  <TableRow key={material.id}>
                    <TableCell className="font-medium">{material.code}</TableCell>
                    <TableCell>{material.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {material.type === 'RAW' ? 'Raw Material' : 
                         material.type === 'FINI' ? 'Finished Goods' :
                         material.type === 'SEMI' ? 'Semi-Finished' :
                         material.type === 'SPAR' ? 'Spare Parts' :
                         material.type === 'PACK' ? 'Packaging Material' :
                         material.type.replace('_', ' ')}
                      </Badge>
                    </TableCell>
                    <TableCell>{getUomName(material.uomId)}</TableCell>
                    <TableCell>
                      {(material.baseUnitPrice !== null && material.baseUnitPrice !== undefined) 
                        ? `$${Number(material.baseUnitPrice).toFixed(2)}` 
                        : 'N/A'}
                    </TableCell>
                    <TableCell>
                      {material.isActive ? (
                        <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">
                          Active
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                          Inactive
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onEdit(material)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onDelete(material)}
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}