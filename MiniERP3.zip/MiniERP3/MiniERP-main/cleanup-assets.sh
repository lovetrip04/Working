#!/bin/bash

# Script to clean up unnecessary image assets
cd attached_assets
rm image_1747*.png

echo "Cleaned up image assets!"