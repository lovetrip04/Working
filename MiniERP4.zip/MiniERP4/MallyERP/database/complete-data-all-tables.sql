--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: account_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_groups (id, chart_id, group_name, account_range_from, account_range_to, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.currencies (id, code, name, symbol, decimal_places, conversion_rate, base_currency, is_active, created_at, updated_at, notes, active) FROM stdin;
1	USD	US Dollar	$	2	1.0	t	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N	t
2	EUR	Euro	€	2	1.08	f	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N	t
3	GBP	British Pound	£	2	1.27	f	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N	t
4	JPY	Japanese Yen	¥	0	0.0067	f	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N	t
5	CNY	Chinese Yuan	¥	2	0.138	f	t	2025-05-17 14:16:12.170855	2025-05-17 14:16:12.170855	\N	t
\.


--
-- Data for Name: plants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plants (id, code, name, description, company_code_id, type, category, address, city, state, country, postal_code, phone, email, manager, timezone, operating_hours, coordinates, status, is_active, created_at, created_by, updated_at, updated_by, version, notes, active, company_code) FROM stdin;
34	PLT17490897317131	Test Plant 1749089731713 1	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:15:31.782379	1	2025-06-05 02:15:31.782379	1	1	\N	t	\N
35	PLT17490897317132	Test Plant 1749089731713 2	\N	1	Warehouse	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:15:31.808377	1	2025-06-05 02:15:31.808377	1	1	\N	t	\N
36	P174908976	Test Plant 1749089769754	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:16:09.119438	1	2025-06-05 02:16:09.119438	1	1	\N	t	\N
37	P174908979	Test Plant 1749089793928	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:16:33.993409	1	2025-06-05 02:16:33.993409	1	1	\N	t	\N
1	P001	Main Factory	\N	1	Manufacturing	Production	\N	Chicago	\N	United States	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-17 13:44:11.172767	1	2025-05-17 13:44:11.172767	1	1	\N	t	\N
2	W001	East Coast Warehouse	\N	1	Warehouse	Storage	\N	Newark	\N	United States	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-17 13:44:11.172767	1	2025-05-17 13:44:11.172767	1	1	\N	t	\N
3	P002	European Production	\N	2	Manufacturing	Production	\N	Munich	\N	Germany	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-17 13:44:11.172767	1	2025-05-17 13:44:11.172767	1	1	\N	t	\N
5	P003	Berlin Production	Berlin Production - manufacturing facility	2	manufacturing	production	Fabrikstraße 25, Berlin, 10115	\N	\N	Germany	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.251247	1	2025-05-20 04:52:26.251247	1	1	\N	t	\N
6	P004	Shanghai Facility	Shanghai Facility - manufacturing facility	10	manufacturing	production	100 Industrial Zone, Shanghai, 200000	\N	\N	China	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.305857	1	2025-05-20 04:52:26.305857	1	1	\N	t	\N
7	W002	European Warehouse	European Warehouse - warehouse facility	2	warehouse	distribution	Logistikweg 10, Hamburg, 20095	\N	\N	Germany	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.370563	1	2025-05-20 04:52:26.370563	1	1	\N	t	\N
8	W003	Asian Distribution Hub	Asian Distribution Hub - warehouse facility	10	warehouse	distribution	200 Export Center, Shenzhen, 518000	\N	\N	China	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.417674	1	2025-05-20 04:52:26.417674	1	1	\N	t	\N
9	W004	UK Warehouse	UK Warehouse - warehouse facility	11	warehouse	distribution	15 Logistics Way, Manchester, M1 1AA	\N	\N	United Kingdom	\N	\N	\N	\N	\N	\N	\N	active	t	2025-05-20 04:52:26.461796	1	2025-05-20 04:52:26.461796	1	1	\N	t	\N
13	TST1	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 00:48:17.624657	1	2025-06-05 00:48:17.624657	1	1	\N	t	\N
15	PLT1749084630761	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 00:50:30.959085	1	2025-06-05 00:50:30.959085	1	1	\N	t	\N
16	PLT1749084660178	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 00:51:00.322563	1	2025-06-05 00:51:00.322563	1	1	\N	t	\N
17	P4162	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 00:51:53.417907	1	2025-06-05 00:51:53.417907	1	1	\N	t	\N
18	TP571891	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 01:56:11.962825	1	2025-06-05 01:56:11.962825	1	1	\N	t	\N
19	TP716672	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 01:58:36.728424	1	2025-06-05 01:58:36.728424	1	1	\N	t	\N
20	TP772239	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 01:59:32.302978	1	2025-06-05 01:59:32.302978	1	1	\N	t	\N
21	TP792967	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 01:59:53.009803	1	2025-06-05 01:59:53.009803	1	1	\N	t	\N
22	TP853374	Test Plant	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:00:53.445384	1	2025-06-05 02:00:53.445384	1	1	\N	t	\N
27	PLT002	Test Plant 002	\N	1	Warehouse	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:10:57.800576	1	2025-06-05 02:10:57.800576	1	1	\N	t	\N
30	PLT17490896359281	Test Plant 1749089635928 1	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:13:57.550919	1	2025-06-05 02:13:57.550919	1	1	\N	t	\N
31	PLT17490896359282	Test Plant 1749089635928 2	\N	1	Warehouse	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:13:57.608179	1	2025-06-05 02:13:57.608179	1	1	\N	t	\N
32	PLT17490897081901	Test Plant 1749089708190 1	\N	1	Manufacturing	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:15:08.299988	1	2025-06-05 02:15:08.299988	1	1	\N	t	\N
33	PLT17490897081902	Test Plant 1749089708190 2	\N	1	Warehouse	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	2025-06-05 02:15:08.32814	1	2025-06-05 02:15:08.32814	1	1	\N	t	\N
\.


--
-- Data for Name: purchase_organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_organizations (id, code, name, description, company_code_id, currency, purchasing_manager, email, phone, address, is_active, created_at, updated_at, created_by, updated_by, version, valid_from, valid_to, purchasing_group, supply_type, approval_level, city, state, country, postal_code, status, notes, manager, active) FROM stdin;
9	PO01	US Raw Materials Procurement	Purchases raw materials for US manufacturing	1	USD	\N	\N	\N	\N	t	2025-05-20 05:01:13.627938	2025-05-20 05:01:13.627938	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	USA	\N	active	\N	\N	t
10	PO02	US MRO Procurement	Purchases maintenance supplies for US operations	1	USD	\N	\N	\N	\N	t	2025-05-20 05:01:13.677542	2025-05-20 05:01:13.677542	\N	\N	1	2025-05-20	\N	indirect	maintenance	\N	\N	\N	USA	\N	active	\N	\N	t
11	PO03	European Raw Materials	Purchases raw materials for European manufacturing	2	EUR	\N	\N	\N	\N	t	2025-05-20 05:01:13.705442	2025-05-20 05:01:13.705442	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	Germany	\N	active	\N	\N	t
12	PO04	European Services	Purchases services for European operations	2	EUR	\N	\N	\N	\N	t	2025-05-20 05:01:13.730688	2025-05-20 05:01:13.730688	\N	\N	1	2025-05-20	\N	indirect	services	\N	\N	\N	Germany	\N	active	\N	\N	t
13	PO05	Asia Pacific Procurement	Handles all purchasing activities in APAC region	10	CNY	\N	\N	\N	\N	t	2025-05-20 05:01:13.754219	2025-05-20 05:01:13.754219	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	China	\N	active	\N	\N	t
14	PO06	Global Capital Purchases	Handles all major capital expenditures globally	1	USD	\N	\N	\N	\N	t	2025-05-20 05:01:13.782274	2025-05-20 05:01:13.782274	\N	\N	1	2025-05-20	\N	capital	equipment	\N	\N	\N	USA	\N	active	\N	\N	t
15	PO07	UK Procurement	Manages all procurement for UK operations	11	GBP	\N	\N	\N	\N	t	2025-05-20 05:01:13.801961	2025-05-20 05:01:13.801961	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	United Kingdom	\N	active	\N	\N	t
16	PO08	Canada Procurement	Handles all purchasing for Canadian operations	5	CAD	\N	\N	\N	\N	t	2025-05-20 05:01:13.825862	2025-05-20 05:01:13.825862	\N	\N	1	2025-05-20	\N	direct	production	\N	\N	\N	Canada	\N	active	\N	\N	t
17	NA01	North America Procurement	\N	1	USD	\N	\N	\N	\N	t	2025-05-20 21:43:20.089848	2025-05-20 21:43:20.089848	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
18	EU01	European Procurement	\N	9	EUR	\N	\N	\N	\N	t	2025-05-20 21:43:20.111292	2025-05-20 21:43:20.111292	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
19	UK01	UK Procurement	\N	11	GBP	\N	\N	\N	\N	t	2025-05-20 21:43:20.128029	2025-05-20 21:43:20.128029	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
22	IN01	India Purchasing	\N	6	INR	\N	\N	\N	\N	t	2025-05-20 21:43:20.460685	2025-05-20 21:43:20.460685	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
24	GLOB	Global Procurement	\N	1	USD	\N	\N	\N	\N	t	2025-05-20 21:43:20.621543	2025-05-20 21:43:20.621543	\N	\N	1	2025-05-20	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
25	TEST001	Test Purchase Org	Test purchase organization	1	USD	\N	\N	\N	\N	t	2025-06-05 01:50:39.933254	2025-06-05 01:50:39.933254	\N	\N	1	2025-06-05	\N	\N	\N	\N	\N	\N	\N	\N	active	Test notes	\N	t
26	PO571891	Test Purchase Org	Test	1	USD	\N	\N	\N	\N	t	2025-06-05 01:56:12.089151	2025-06-05 01:56:12.089151	\N	\N	1	2025-06-05	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
27	PO716672	Test Purchase Org	Test	1	USD	\N	\N	\N	\N	t	2025-06-05 01:58:36.826933	2025-06-05 01:58:36.826933	\N	\N	1	2025-06-05	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
28	PO772239	Test Purchase Org	Test	1	USD	\N	\N	\N	\N	t	2025-06-05 01:59:32.407661	2025-06-05 01:59:32.407661	\N	\N	1	2025-06-05	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
29	PO792967	Test Purchase Org	Test	1	USD	\N	\N	\N	\N	t	2025-06-05 01:59:53.093866	2025-06-05 01:59:53.093866	\N	\N	1	2025-06-05	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
30	PO853374	Test Purchase Org	Test	1	USD	\N	\N	\N	\N	t	2025-06-05 02:00:53.558705	2025-06-05 02:00:53.558705	\N	\N	1	2025-06-05	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
33	PO17490897	Test Purchase Org 1749089708190	Test purchase organization	1	USD	\N	\N	\N	\N	t	2025-06-05 02:15:08.459631	2025-06-05 02:15:08.459631	\N	\N	1	2025-06-05	\N	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	t
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password, name, email, role, created_at, updated_at, active) FROM stdin;
1	admin	admin123	Administrator	admin@example.com	admin	2025-05-17 05:55:13.089835	2025-05-17 05:55:13.089835	t
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, code, name, type, description, tax_id, industry, address, city, state, country, postal_code, region, phone, alt_phone, email, website, currency, payment_terms, payment_method, supplier_type, category, order_frequency, minimum_order_value, evaluation_score, lead_time, purchasing_group_id, status, blacklisted, blacklist_reason, notes, tags, company_code_id, is_active, created_at, updated_at, created_by, updated_by, version, active) FROM stdin;
1	VEND001	Global Raw Materials Inc	SUPPLIER	\N	123-45-6789	\N	100 Supplier Road, Chicago, IL 60601	\N	\N	US	\N	\N	+1-312-555-1234	\N	sales@grm.example.com	\N	\N	NET30	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	Primary raw material supplier	\N	\N	t	2025-05-20 18:17:22.279989	2025-05-20 18:17:22.279989	\N	\N	1	t
2	VEND002	European Components GmbH	MANUFACTURER	\N	DE123456789	\N	Industrieweg 10, Munich, 80331	\N	\N	DE	\N	\N	+49-89-1234-5678	\N	orders@eurocomponents.example.de	\N	\N	NET45	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	European electronics components supplier	\N	\N	t	2025-05-20 18:17:22.301591	2025-05-20 18:17:22.301591	\N	\N	1	t
3	VEND003	Asian Electronics Ltd	MANUFACTURER	\N	SG987654321	\N	1 Electronics Way, Singapore, 618989	\N	\N	SG	\N	\N	+65-6789-1234	\N	sales@asianelec.example.sg	\N	\N	NET30	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	Electronics components supplier	\N	\N	t	2025-05-20 18:17:22.320725	2025-05-20 18:17:22.320725	\N	\N	1	t
4	VEND004	Quality Packaging Ltd	SUPPLIER	\N	GB123456789	\N	10 Packaging Street, Manchester, M1 1AA	\N	\N	GB	\N	\N	+44-161-123-4567	\N	sales@qualitypack.example.uk	\N	\N	NET30	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	Packaging materials supplier	\N	\N	t	2025-05-20 18:17:22.341416	2025-05-20 18:17:22.341416	\N	\N	1	t
5	VEND005	Japan Precision Tools	MANUFACTURER	\N	JP1234567890	\N	2-1 Industrial Area, Osaka, 530-0001	\N	\N	JP	\N	\N	+81-6-1234-5678	\N	export@jpt.example.jp	\N	\N	NET15	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	Precision tools manufacturer	\N	\N	t	2025-05-20 18:17:22.360311	2025-05-20 18:17:22.360311	\N	\N	1	t
8	PRODVEND1	Production Vendor 1	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	prod1@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 00:46:56.215568	2025-06-05 00:46:56.215568	\N	\N	1	t
11	VEND1749084630761	Test Vendor	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 00:50:31.109242	2025-06-05 00:50:31.109242	\N	\N	1	t
12	VEND1749084660178	Test Vendor	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 00:51:00.479846	2025-06-05 00:51:00.479846	\N	\N	1	t
13	V214	Test Vendor	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 00:51:53.526783	2025-06-05 00:51:53.526783	\N	\N	1	t
14	TV571891	Test Vendor	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	vendor@example.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 01:56:12.064244	2025-06-05 01:56:12.064244	\N	\N	1	t
15	TV716672	Test Vendor	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	vendor@example.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 01:58:36.808742	2025-06-05 01:58:36.808742	\N	\N	1	t
16	TV772239	Test Vendor	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	vendor@example.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 01:59:32.382739	2025-06-05 01:59:32.382739	\N	\N	1	t
17	TV792967	Test Vendor	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	vendor@example.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 01:59:53.076824	2025-06-05 01:59:53.076824	\N	\N	1	t
18	TV853374	Test Vendor	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	vendor@example.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 02:00:53.534885	2025-06-05 02:00:53.534885	\N	\N	1	t
19	VEN001	Test Vendor 001	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 02:10:58.15124	2025-06-05 02:10:58.15124	\N	\N	1	t
21	VEN1749089635928	Test Vendor 1749089635928	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test1749089635928@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 02:13:57.754671	2025-06-05 02:13:57.754671	\N	\N	1	t
22	VEN1749089708190	Test Vendor 1749089708190	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test1749089708190@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 02:15:08.433054	2025-06-05 02:15:08.433054	\N	\N	1	t
23	VEN1749089731713	Test Vendor 1749089731713	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test1749089731713@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 02:15:31.90219	2025-06-05 02:15:31.90219	\N	\N	1	t
24	V174908976	Test Vendor 1749089769754	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test1749089769754@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 02:16:09.502986	2025-06-05 02:16:09.502986	\N	\N	1	t
25	V174908979	Test Vendor 1749089793928	Supplier	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	test1749089793928@vendor.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	\N	\N	\N	\N	t	2025-06-05 02:16:34.395025	2025-06-05 02:16:34.395025	\N	\N	1	t
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, order_number, vendor_id, purchase_organization_id, company_code_id, plant_id, order_date, delivery_date, payment_terms, currency_id, exchange_rate, total_amount, tax_amount, discount_amount, net_amount, status, created_by, approved_by, approval_date, notes, created_at, updated_at, active, vendor_name) FROM stdin;
1	PO-2025-001	1	\N	\N	\N	2025-06-01	2025-06-15	\N	\N	1.0000	25000.00	\N	\N	\N	Approved	1	\N	\N	\N	2025-06-04 01:15:06.542271	2025-06-04 01:15:06.542271	t	\N
2	PO-2025-002	2	\N	\N	\N	2025-06-02	2025-06-20	\N	\N	1.0000	18500.00	\N	\N	\N	Pending	1	\N	\N	\N	2025-06-04 01:15:06.542271	2025-06-04 01:15:06.542271	t	\N
3	PO-2025-003	3	\N	\N	\N	2025-06-03	2025-06-25	\N	\N	1.0000	42000.00	\N	\N	\N	Draft	1	\N	\N	\N	2025-06-04 01:15:06.542271	2025-06-04 01:15:06.542271	t	\N
4	PO-2025-004	1	\N	\N	\N	2025-06-04	2025-06-30	\N	\N	1.0000	15750.00	\N	\N	\N	Approved	1	\N	\N	\N	2025-06-04 01:15:06.542271	2025-06-04 01:15:06.542271	t	\N
5	PO-2025-005	2	\N	\N	\N	2025-06-05	2025-07-05	\N	\N	1.0000	33200.00	\N	\N	\N	Pending	1	\N	\N	\N	2025-06-04 01:15:06.542271	2025-06-04 01:15:06.542271	t	\N
\.


--
-- Data for Name: accounts_payable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts_payable (id, vendor_id, invoice_number, invoice_date, due_date, amount, currency_id, company_code_id, plant_id, purchase_order_id, payment_terms, status, payment_date, payment_reference, discount_amount, tax_amount, net_amount, notes, created_by, created_at, updated_at, active) FROM stdin;
1	1	AP000001	2025-05-30	2025-06-24	47838.36	1	1	1	\N	Net 60	Paid	\N	\N	0.00	0.00	5567.37	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
2	1	AP000002	2025-03-31	2025-06-22	9250.10	1	2	1	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	42812.95	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
3	1	AP000003	2025-05-22	2025-07-01	32224.00	1	1	2	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	3820.84	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
4	1	AP000004	2025-03-22	2025-06-24	22337.39	1	2	2	\N	Net 60	Paid	\N	\N	0.00	0.00	13850.49	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
5	2	AP000005	2025-04-08	2025-06-10	14588.97	1	1	1	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	20777.60	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
6	2	AP000006	2025-05-11	2025-06-11	21228.90	1	2	1	\N	Net 60	Open	\N	\N	0.00	0.00	5461.03	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
7	2	AP000007	2025-05-07	2025-06-10	4409.29	1	1	2	\N	Net 60	Paid	\N	\N	0.00	0.00	31608.47	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
8	2	AP000008	2025-06-01	2025-06-14	35983.42	1	2	2	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	36771.91	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
9	3	AP000009	2025-03-25	2025-06-14	13713.36	1	1	1	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	9380.00	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
10	3	AP000010	2025-05-22	2025-06-22	17510.14	1	2	1	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	9086.99	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
11	3	AP000011	2025-03-22	2025-06-29	12341.88	1	1	2	\N	2/10 Net 30	Open	\N	\N	0.00	0.00	44419.24	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
12	3	AP000012	2025-05-29	2025-06-27	6162.53	1	2	2	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	45212.87	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
13	4	AP000013	2025-05-24	2025-06-17	6752.22	1	1	1	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	31644.39	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
14	4	AP000014	2025-05-02	2025-06-28	45753.24	1	2	1	\N	2/10 Net 30	Open	\N	\N	0.00	0.00	2142.99	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
15	4	AP000015	2025-05-29	2025-06-21	27214.71	1	1	2	\N	Net 30	Paid	\N	\N	0.00	0.00	12299.88	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
16	4	AP000016	2025-03-26	2025-06-30	7709.25	1	2	2	\N	Net 60	Open	\N	\N	0.00	0.00	28709.80	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
17	5	AP000017	2025-06-03	2025-06-16	37654.25	1	1	1	\N	Net 60	Paid	\N	\N	0.00	0.00	1122.16	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
18	5	AP000018	2025-03-15	2025-06-22	23692.87	1	2	1	\N	Net 30	Paid	\N	\N	0.00	0.00	23897.81	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
19	5	AP000019	2025-03-17	2025-06-21	20784.48	1	1	2	\N	Net 30	Paid	\N	\N	0.00	0.00	23198.00	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
20	5	AP000020	2025-05-29	2025-06-26	16975.29	1	2	2	\N	2/10 Net 30	Paid	\N	\N	0.00	0.00	3105.77	\N	1	2025-06-04 00:44:42.884195	2025-06-04 00:44:42.884195	t
\.


--
-- Data for Name: company_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_codes (id, code, name, city, country, currency, language, active, created_at, updated_at) FROM stdin;
1	1000	Global Manufacturing Inc.	New York	US	USD	EN	t	2025-06-04 19:55:59.524917+00	2025-06-04 19:55:59.524917+00
2	2000	Default Company Code	Default City	US	USD	EN	t	2025-06-04 20:05:08.192779+00	2025-06-04 20:05:08.192779+00
3	TEST01	Test Company with Zero Errors	New York	United States	USD	English	t	2025-06-04 23:15:35.999816+00	2025-06-04 23:15:35.999816+00
4	4000	Pr 0004	\N	United States	USD	\N	t	2025-06-04 23:42:48.367216+00	2025-06-04 23:42:48.367216+00
5	TEST	Test Company	\N	United States	USD	\N	t	2025-06-05 00:41:23.716542+00	2025-06-05 00:41:23.716542+00
6	PROD1	Production Company 1	\N	US	USD	\N	t	2025-06-05 00:46:55.85663+00	2025-06-05 00:46:55.85663+00
7	CC563	Test Company	\N	US	USD	\N	t	2025-06-05 00:51:53.384512+00	2025-06-05 00:51:53.384512+00
8	TC571891	Test Company	\N	US	USD	\N	t	2025-06-05 01:56:11.932702+00	2025-06-05 01:56:11.932702+00
9	TC716672	Test Company	\N	US	USD	\N	t	2025-06-05 01:58:36.705077+00	2025-06-05 01:58:36.705077+00
10	TC772239	Test Company	\N	US	USD	\N	t	2025-06-05 01:59:32.277141+00	2025-06-05 01:59:32.277141+00
11	TC792967	Test Company	\N	US	USD	\N	t	2025-06-05 01:59:52.992162+00	2025-06-05 01:59:52.992162+00
12	TC853374	Test Company	\N	US	USD	\N	t	2025-06-05 02:00:53.413335+00	2025-06-05 02:00:53.413335+00
13	STAB001	Stability Test Co	\N	\N	\N	\N	t	2025-06-05 02:04:10.695278+00	2025-06-05 02:04:10.695278+00
15	TEST001	Test Company 001	\N	USA	USD	\N	t	2025-06-05 02:10:54.946262+00	2025-06-05 02:10:54.946262+00
16	TST1749089	Test Company 1749089635928	\N	USA	USD	\N	t	2025-06-05 02:13:57.487005+00	2025-06-05 02:13:57.487005+00
17	T174908976	Test Company 1749089769754	\N	USA	USD	\N	t	2025-06-05 02:16:08.981351+00	2025-06-05 02:16:08.981351+00
18	T174908979	Test Company 1749089793928	\N	USA	USD	\N	t	2025-06-05 02:16:33.856812+00	2025-06-05 02:16:33.856812+00
19	Test0101	Company PR 0101	\N	United States	USD	\N	t	2025-06-05 02:20:37.126926+00	2025-06-05 02:20:37.126926+00
20	GW01	GW 001	\N	United States	USD	\N	t	2025-06-05 13:54:06.773738+00	2025-06-05 13:54:06.773738+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, email, phone, address, notes, user_id, created_at, updated_at, active, code, type) FROM stdin;
1	Acme Corporation	orders@acme.example.com	+1-212-555-0123	123 Main Street, New York, NY 10001	Key account - has special pricing agreement	\N	2025-05-20 18:17:22.106429	2025-05-20 18:17:22.106429	t	\N	Regular
2	Global Enterprises	procurement@globalent.example.com	+1-312-555-0456	456 Park Avenue, Chicago, IL 60601	High volume customer	\N	2025-05-20 18:17:22.140573	2025-05-20 18:17:22.140573	t	\N	Regular
3	European Distributors Ltd	orders@eurodist.example.com	+44-20-7123-4567	1 Oxford Street, London, W1D 1BS	European distribution partner	\N	2025-05-20 18:17:22.160991	2025-05-20 18:17:22.160991	t	\N	Regular
4	Tech Solutions GmbH	einkauf@techsolutions.example.de	+49-30-1234-5678	Hauptstraße 1, Berlin, 10115	German tech industry client	\N	2025-05-20 18:17:22.179183	2025-05-20 18:17:22.179183	t	\N	Regular
5	Japan Manufacturing Co.	orders@japanmfg.example.jp	+81-3-1234-5678	1-1 Marunouchi, Tokyo, 100-0005	Japanese manufacturing partner	\N	2025-05-20 18:17:22.197684	2025-05-20 18:17:22.197684	t	\N	Regular
8	Test Customer	test@customer.com	123-456-7890	123 Test Street, Test City, Test State	\N	\N	2025-06-05 00:50:31.071376	2025-06-05 00:50:31.071376	t	CUST1749084630761	Regular
9	Test Customer	test@customer.com	123-456-7890	123 Test Street, Test City, Test State	\N	\N	2025-06-05 00:51:00.443298	2025-06-05 00:51:00.443298	t	CUST1749084660178	Regular
10	Test Customer	test@customer.com	123-456-7890	123 Test Street, Test City, Test State	\N	\N	2025-06-05 00:51:53.505277	2025-06-05 00:51:53.505277	t	C5447	Regular
11	Test Customer	test@example.com	123-456-7890	Test Address	\N	\N	2025-06-05 01:56:12.039741	2025-06-05 01:56:12.039741	t	TC571891	Regular
12	Test Customer	test@example.com	123-456-7890	Test Address	\N	\N	2025-06-05 01:58:36.790657	2025-06-05 01:58:36.790657	t	TC716672	Regular
13	Test Customer	test@example.com	123-456-7890	Test Address	\N	\N	2025-06-05 01:59:32.362	2025-06-05 01:59:32.362	t	TC772239	Regular
14	Test Customer	test@example.com	123-456-7890	Test Address	\N	\N	2025-06-05 01:59:53.058611	2025-06-05 01:59:53.058611	t	TC792967	Regular
15	Test Customer	test@example.com	123-456-7890	Test Address	\N	\N	2025-06-05 02:00:53.508087	2025-06-05 02:00:53.508087	t	TC853374	Regular
16	Test Customer 001	test@customer.com	123-456-7890	123 Test St	\N	\N	2025-06-05 02:10:58.11701	2025-06-05 02:10:58.11701	t	\N	Regular
17	Test Customer 001	test@customer.com	123-456-7890	123 Test St	\N	\N	2025-06-05 02:11:57.903119	2025-06-05 02:11:57.903119	t	\N	Regular
18	Test Customer 1749089635928	test1749089635928@customer.com	123-456-7890	123 Test St	\N	\N	2025-06-05 02:13:57.717338	2025-06-05 02:13:57.717338	t	\N	Regular
19	Test Customer 1749089708190	test1749089708190@customer.com	123-456-7890	123 Test St	\N	\N	2025-06-05 02:15:08.406939	2025-06-05 02:15:08.406939	t	\N	Regular
20	Test Customer 1749089731713	test1749089731713@customer.com	123-456-7890	123 Test St	\N	\N	2025-06-05 02:15:31.876872	2025-06-05 02:15:31.876872	t	\N	Regular
21	Test Customer 1749089769754	test1749089769754@customer.com	123-456-7890	123 Test St	\N	\N	2025-06-05 02:16:09.380829	2025-06-05 02:16:09.380829	t	\N	Regular
22	Test Customer 1749089793928	test1749089793928@customer.com	123-456-7890	123 Test St	\N	\N	2025-06-05 02:16:34.268957	2025-06-05 02:16:34.268957	t	\N	Regular
\.


--
-- Data for Name: erp_customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.erp_customers (id, customer_code, name, type, description, tax_id, industry, segment, address, city, state, country, postal_code, region, phone, alt_phone, email, website, currency, payment_terms, payment_method, credit_limit, credit_rating, discount_group, price_group, incoterms, shipping_method, delivery_terms, delivery_route, sales_rep_id, parent_customer_id, status, is_b2b, is_b2c, is_vip, notes, tags, company_code_id, is_active, created_at, updated_at, created_by, updated_by, version, active) FROM stdin;
1	C1001	Acme Corporation	corporate	Large manufacturing client	123-45-6789	manufacturing	enterprise	123 Main Street	Chicago	IL	US	60601	\N	+1-312-555-1234	\N	contact@acmecorp.com	\N	USD	net_30	\N	50000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	t	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
2	C1002	Global Retailers	corporate	International retail chain	987-65-4321	retail	key_account	456 Market Ave	New York	NY	US	10001	\N	+1-212-555-2345	\N	orders@globalretail.com	\N	USD	net_45	\N	100000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	t	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
3	C1003	City Hospital	corporate	Regional medical center	456-78-9012	healthcare	mid_market	789 Health Blvd	Boston	MA	US	02110	\N	+1-617-555-3456	\N	procurement@cityhospital.org	\N	USD	net_60	\N	75000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
4	C1004	Tech Innovations	corporate	Technology startup	789-01-2345	technology	small_business	321 Tech Park	San Francisco	CA	US	94105	\N	+1-415-555-4567	\N	orders@techinnovate.com	\N	USD	net_30	\N	25000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
5	C1005	John Smith	individual	Regular customer	\N	\N	consumer	555 Residential St	Los Angeles	CA	US	90001	\N	+1-213-555-5678	\N	john.smith@email.com	\N	USD	prepaid	\N	1000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	f	t	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
6	C1006	Government Agency	government	Federal procurement office	GOV-123456	government	enterprise	1 Federal Plaza	Washington	DC	US	20001	\N	+1-202-555-6789	\N	procurement@gov.agency.gov	\N	USD	net_60	\N	500000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
7	C1007	European Distributors	corporate	European distribution partner	EU-8765432	distribution	strategic	10 International Blvd	Berlin	\N	DE	10115	\N	+49-30-555-7890	\N	orders@eurodist.eu	\N	EUR	net_45	\N	200000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	t	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
8	C1008	Education Foundation	non_profit	Educational institution	TAX-EXEMPT-123	education	mid_market	200 Learning Way	Atlanta	GA	US	30301	\N	+1-404-555-8901	\N	purchases@edufoundation.org	\N	USD	net_30	\N	30000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
9	C1009	Local Restaurant	corporate	Small business customer	BUS-987654	food_service	small_business	75 Culinary Lane	Miami	FL	US	33101	\N	+1-305-555-9012	\N	orders@localrestaurant.com	\N	USD	cod	\N	5000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
10	C1010	Industrial Supplies	corporate	Industrial equipment supplier	IND-456789	industrial	mid_market	800 Factory Road	Detroit	MI	US	48201	\N	+1-313-555-0123	\N	sales@industrialsupplies.com	\N	USD	net_30	\N	150000.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	f	f	\N	\N	2	t	2025-05-17 15:45:52.538438	2025-05-17 15:45:52.538438	\N	\N	1	t
\.


--
-- Data for Name: sales_organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_organizations (id, code, name, description, company_code_id, currency, region, distribution_channel, industry, address, city, state, country, postal_code, phone, email, manager, status, is_active, notes, created_at, created_by, updated_at, updated_by, version, active) FROM stdin;
8	SO01	US Consumer Retail	Manages US retail consumer sales	1	USD	North America	retail	consumer	\N	\N	\N	USA	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.871186+00	\N	2025-05-20 05:01:13.871186+00	\N	1	t
9	SO02	US B2B Sales	Handles direct business-to-business sales in US	1	USD	North America	direct	industrial	\N	\N	\N	USA	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.903811+00	\N	2025-05-20 05:01:13.903811+00	\N	1	t
10	SO03	US eCommerce	Manages all online sales channels in US	1	USD	North America	online	consumer	\N	\N	\N	USA	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.923177+00	\N	2025-05-20 05:01:13.923177+00	\N	1	t
11	SO04	European Retail	Manages European retail sales operations	2	EUR	EMEA	retail	consumer	\N	\N	\N	Germany	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.949517+00	\N	2025-05-20 05:01:13.949517+00	\N	1	t
12	SO05	European Wholesale	Handles wholesale distribution in Europe	2	EUR	EMEA	wholesale	industrial	\N	\N	\N	Germany	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.967276+00	\N	2025-05-20 05:01:13.967276+00	\N	1	t
13	SO06	China Retail	Manages retail sales operations in China	10	CNY	APAC	retail	consumer	\N	\N	\N	China	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:13.98566+00	\N	2025-05-20 05:01:13.98566+00	\N	1	t
14	SO07	APAC Distribution	Handles distribution across Asia Pacific region	10	CNY	APAC	wholesale	mixed	\N	\N	\N	China	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:14.008718+00	\N	2025-05-20 05:01:14.008718+00	\N	1	t
15	SO08	UK Consumer Sales	Manages retail consumer sales in UK	11	GBP	EMEA	retail	consumer	\N	\N	\N	United Kingdom	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:14.03034+00	\N	2025-05-20 05:01:14.03034+00	\N	1	t
16	SO09	Canada Sales	Handles all sales operations in Canada	5	CAD	North America	mixed	mixed	\N	\N	\N	Canada	\N	\N	\N	\N	active	t	\N	2025-05-20 05:01:14.049053+00	\N	2025-05-20 05:01:14.049053+00	\N	1	t
17	US01	US East Sales	\N	1	USD	\N	\N	\N	\N	\N	\N	US	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.29688+00	\N	2025-05-20 21:43:19.29688+00	\N	1	t
19	CA01	Canada Sales	\N	5	CAD	\N	\N	\N	\N	\N	\N	CA	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.477648+00	\N	2025-05-20 21:43:19.477648+00	\N	1	t
20	UK01	UK Sales Division	\N	11	GBP	\N	\N	\N	\N	\N	\N	GB	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.499825+00	\N	2025-05-20 21:43:19.499825+00	\N	1	t
21	EU01	European Sales	\N	9	EUR	\N	\N	\N	\N	\N	\N	EU	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.51623+00	\N	2025-05-20 21:43:19.51623+00	\N	1	t
24	IN01	India Sales Division	\N	6	INR	\N	\N	\N	\N	\N	\N	IN	\N	\N	\N	\N	active	t	\N	2025-05-20 21:43:19.889334+00	\N	2025-05-20 21:43:19.889334+00	\N	1	t
26	SO1749089635928	Test Sales Org 1749089635928	Test sales organization	1	USD	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	\N	2025-06-05 02:13:59.925732+00	\N	2025-06-05 02:13:59.925732+00	\N	1	t
27	SO1749089708190	Test Sales Org 1749089708190	Test sales organization	1	USD	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	\N	2025-06-05 02:15:08.488142+00	\N	2025-06-05 02:15:08.488142+00	\N	1	t
28	SO1749089731713	Test Sales Org 1749089731713	Test sales organization	1	USD	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	\N	2025-06-05 02:15:32.04148+00	\N	2025-06-05 02:15:32.04148+00	\N	1	t
29	SO17490897	Test SO 1749089769754	Test sales organization	1	USD	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	\N	2025-06-05 02:16:09.752592+00	\N	2025-06-05 02:16:09.752592+00	\N	1	t
31	SP01	SP001 test		2	USD	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	active	t	\N	2025-06-05 02:18:50.819477+00	\N	2025-06-05 02:18:50.819477+00	\N	1	t
\.


--
-- Data for Name: sales_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_orders (id, order_number, customer_id, customer_name, order_date, delivery_date, status, total_amount, payment_status, shipping_address, billing_address, notes, created_by, created_at, updated_at, plant_id, sales_org_id, company_code_id, currency_id, active) FROM stdin;
1	SO-2025-1001	1	TechNova Inc	2025-05-10 02:19:58.867513+00	2025-05-30 02:19:58.867513+00	Confirmed	5649.75	Paid	123 Tech Park, San Francisco, CA	123 Tech Park, San Francisco, CA	\N	\N	2025-05-23 02:19:58.867513+00	2025-05-23 02:19:58.867513+00	1	8	1	\N	t
2	SO-2025-1002	2	Elevate Solutions	2025-05-12 02:19:58.867513+00	2025-05-28 02:19:58.867513+00	Processing	2375.50	Paid	456 Business Ave, Seattle, WA	456 Business Ave, Seattle, WA	\N	\N	2025-05-23 02:19:58.867513+00	2025-05-23 02:19:58.867513+00	1	8	1	\N	t
3	SO-2025-1003	3	DataWave Analytics	2025-05-15 02:19:58.867513+00	2025-06-02 02:19:58.867513+00	Processing	8925.33	Partial	789 Data Drive, Boston, MA	789 Data Drive, Boston, MA	\N	\N	2025-05-23 02:19:58.867513+00	2025-05-23 02:19:58.867513+00	1	8	1	\N	t
4	SO-2025-1004	4	Quantum Systems	2025-05-18 02:19:58.867513+00	2025-06-06 02:19:58.867513+00	Pending	3450.20	Unpaid	101 Quantum Blvd, Austin, TX	101 Quantum Blvd, Austin, TX	\N	\N	2025-05-23 02:19:58.867513+00	2025-05-23 02:19:58.867513+00	1	8	1	\N	t
5	SO-2025-1005	5	Arctic Innovations	2025-05-20 02:19:58.867513+00	2025-05-30 02:19:58.867513+00	Confirmed	1875.60	Paid	202 Ice Street, Chicago, IL	202 Ice Street, Chicago, IL	\N	\N	2025-05-23 02:19:58.867513+00	2025-05-23 02:19:58.867513+00	1	8	1	\N	t
7	SO-2025-0006	\N	CUST001	2025-06-05 00:43:35.922078+00	\N	open	0.00	Unpaid	\N	\N	\N	\N	2025-06-05 00:43:35.922078+00	2025-06-05 00:43:35.922078+00	\N	\N	\N	\N	t
8	SO-2025-0007	\N	CUST001	2025-06-05 00:46:19.478395+00	\N	open	0.00	Unpaid	\N	\N	\N	\N	2025-06-05 00:46:19.478395+00	2025-06-05 00:46:19.478395+00	\N	\N	\N	\N	t
9	SO-2025-0008	\N	Production Customer 1	2025-06-05 00:46:56.266353+00	\N	open	1000.00	Unpaid	\N	\N	\N	\N	2025-06-05 00:46:56.266353+00	2025-06-05 00:46:56.266353+00	\N	\N	\N	\N	t
10	SO-2025-0009	\N	CUST001	2025-06-05 00:48:18.57226+00	\N	open	0.00	Unpaid	\N	\N	\N	\N	2025-06-05 00:48:18.57226+00	2025-06-05 00:48:18.57226+00	\N	\N	\N	\N	t
11	SO-2025-0010	\N	CUST001	2025-06-05 00:49:24.064247+00	\N	open	0.00	Unpaid	\N	\N	\N	\N	2025-06-05 00:49:24.064247+00	2025-06-05 00:49:24.064247+00	\N	\N	\N	\N	t
\.


--
-- Data for Name: accounts_receivable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts_receivable (id, customer_id, invoice_number, invoice_date, due_date, amount, currency_id, company_code_id, plant_id, sales_order_id, payment_terms, status, payment_date, payment_reference, discount_amount, tax_amount, net_amount, notes, created_by, created_at, updated_at, active) FROM stdin;
1	1	AR000001	2025-04-09	2025-07-08	45565.28	1	1	1	\N	Net 60	Overdue	\N	\N	0.00	0.00	96575.56	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
2	2	AR000002	2025-05-05	2025-06-30	70579.07	1	1	1	\N	Net 60	Overdue	\N	\N	0.00	0.00	53968.12	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
3	3	AR000003	2025-05-16	2025-06-29	90806.55	1	1	1	\N	Net 60	Overdue	\N	\N	0.00	0.00	7895.64	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
4	4	AR000004	2025-06-03	2025-07-09	53773.31	1	1	1	\N	Net 45	Paid	\N	\N	0.00	0.00	31983.21	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
5	5	AR000005	2025-04-14	2025-06-17	14521.86	1	1	1	\N	Net 30	Paid	\N	\N	0.00	0.00	76067.68	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
6	1	AR000006	2025-04-27	2025-07-09	88330.44	1	2	1	\N	Net 60	Paid	\N	\N	0.00	0.00	72908.98	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
7	2	AR000007	2025-05-14	2025-07-07	9146.44	1	2	1	\N	Net 30	Overdue	\N	\N	0.00	0.00	41336.64	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
8	3	AR000008	2025-05-28	2025-06-16	42630.56	1	2	1	\N	Net 45	Open	\N	\N	0.00	0.00	39717.42	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
9	4	AR000009	2025-05-24	2025-07-04	69552.52	1	2	1	\N	Net 60	Paid	\N	\N	0.00	0.00	48387.89	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
10	5	AR000010	2025-04-17	2025-06-22	15146.02	1	2	1	\N	Net 60	Open	\N	\N	0.00	0.00	97124.72	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
11	1	AR000011	2025-05-11	2025-06-09	22085.06	1	1	2	\N	Net 60	Overdue	\N	\N	0.00	0.00	65227.88	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
12	2	AR000012	2025-05-02	2025-06-20	28185.91	1	1	2	\N	Net 60	Overdue	\N	\N	0.00	0.00	74679.11	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
13	3	AR000013	2025-04-09	2025-06-21	16533.58	1	1	2	\N	Net 45	Overdue	\N	\N	0.00	0.00	85472.65	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
14	4	AR000014	2025-06-02	2025-06-26	42584.48	1	1	2	\N	Net 45	Paid	\N	\N	0.00	0.00	14340.11	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
15	5	AR000015	2025-05-24	2025-06-06	7901.24	1	1	2	\N	Net 60	Overdue	\N	\N	0.00	0.00	81366.85	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
16	1	AR000016	2025-04-22	2025-06-22	16068.79	1	2	2	\N	Net 60	Overdue	\N	\N	0.00	0.00	15011.23	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
17	2	AR000017	2025-04-20	2025-07-16	52841.49	1	2	2	\N	Net 45	Paid	\N	\N	0.00	0.00	25781.58	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
18	3	AR000018	2025-05-29	2025-06-07	9468.52	1	2	2	\N	Net 45	Overdue	\N	\N	0.00	0.00	86568.69	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
19	4	AR000019	2025-05-31	2025-06-30	99156.13	1	2	2	\N	Net 45	Open	\N	\N	0.00	0.00	31387.58	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
20	5	AR000020	2025-05-03	2025-07-13	52978.43	1	2	2	\N	Net 30	Open	\N	\N	0.00	0.00	16317.79	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
21	1	AR000021	2025-05-13	2025-06-09	6883.61	2	1	1	\N	Net 45	Paid	\N	\N	0.00	0.00	16939.39	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
22	2	AR000022	2025-05-06	2025-07-09	63651.40	2	1	1	\N	Net 60	Overdue	\N	\N	0.00	0.00	56058.37	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
23	3	AR000023	2025-04-18	2025-06-24	88658.27	2	1	1	\N	Net 30	Overdue	\N	\N	0.00	0.00	25210.15	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
24	4	AR000024	2025-04-09	2025-06-04	50958.76	2	1	1	\N	Net 30	Overdue	\N	\N	0.00	0.00	72221.26	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
25	5	AR000025	2025-04-06	2025-07-06	78462.86	2	1	1	\N	Net 60	Overdue	\N	\N	0.00	0.00	38983.94	\N	1	2025-06-04 00:44:46.291765	2025-06-04 00:44:46.291765	t
\.


--
-- Data for Name: activity_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_types (id, activity_type, description, unit_of_measure, category, controlling_area, allocation_method, created_at, active, updated_at) FROM stdin;
1	MACH-HR	Machine Hours	HR	MACHINE	US01	\N	2025-06-03 17:58:50.654812	t	2025-06-04 18:39:27.006369+00
2	LABOR-HR	Labor Hours	HR	LABOR	US01	\N	2025-06-03 17:58:50.654812	t	2025-06-04 18:39:27.006369+00
3	SETUP-HR	Setup Hours	HR	SETUP	US01	\N	2025-06-03 17:58:50.654812	t	2025-06-04 18:39:27.006369+00
4	QC-HR	Quality Control Hours	HR	QUALITY	US01	\N	2025-06-03 17:58:50.654812	t	2025-06-04 18:39:27.006369+00
5	MAINT-HR	Maintenance Hours	HR	MAINTENANCE	US01	\N	2025-06-03 17:58:50.654812	t	2025-06-04 18:39:27.006369+00
\.


--
-- Data for Name: ai_agent_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_agent_configs (id, module_type, module_name, agent_name, role_description, system_prompt, expertise_areas, capabilities, is_active, created_at, updated_at, active) FROM stdin;
1	masterData	Master Data Management	Master Data Specialist	Expert in organizational structures, material management, customer/vendor data, and reference data maintenance	You are a Master Data Management specialist with deep expertise in SAP-standard organizational structures and reference data. You help users navigate complex master data relationships, ensure data integrity, and optimize organizational hierarchies. You understand the critical importance of accurate master data for all business processes.	["Organizational Structures", "Material Master", "Customer Master", "Vendor Master", "Chart of Accounts", "Cost Centers", "Profit Centers", "Plant Maintenance", "Units of Measure", "Number Ranges", "Data Governance"]	["Data Structure Analysis", "Master Data Creation Guidance", "Organizational Hierarchy Design", "Data Quality Assessment", "Reference Data Management", "Integration Mapping", "Compliance Checking", "Migration Planning"]	t	2025-06-04 04:33:55.202225+00	2025-06-04 04:33:55.202225+00	t
2	sales	Sales Management	Sales Operations Expert	Specialist in sales processes, customer relationship management, pricing strategies, and revenue optimization	You are a Sales Operations expert with comprehensive knowledge of sales processes, customer lifecycle management, and revenue optimization strategies. You help users maximize sales performance, improve customer relationships, and streamline sales operations from lead generation to order fulfillment.	["Lead Management", "Opportunity Tracking", "Quote Generation", "Order Processing", "Customer Relationship Management", "Sales Analytics", "Pricing Strategies", "Sales Forecasting", "Territory Management", "Commission Management"]	["Sales Process Optimization", "Lead Qualification", "Revenue Analysis", "Customer Segmentation", "Sales Performance Metrics", "Pipeline Management", "Pricing Strategy", "Sales Forecasting"]	t	2025-06-04 04:34:02.73724+00	2025-06-04 04:34:02.73724+00	t
3	inventory	Inventory Management	Inventory Control Specialist	Expert in stock management, warehouse operations, material movements, and inventory optimization	You are an Inventory Management specialist with deep knowledge of stock control, warehouse operations, and supply chain optimization. You help users maintain optimal inventory levels, reduce carrying costs, and ensure material availability for production and sales.	["Stock Management", "Warehouse Operations", "Material Movements", "Inventory Valuation", "ABC Analysis", "Cycle Counting", "Safety Stock Planning", "Demand Forecasting", "Supplier Management", "Inventory Optimization"]	["Stock Level Analysis", "Inventory Turnover Optimization", "Demand Planning", "Warehouse Layout Design", "Material Flow Analysis", "Cost Reduction Strategies", "Supply Chain Optimization", "Inventory Reporting"]	t	2025-06-04 04:34:14.229792+00	2025-06-04 04:34:14.229792+00	t
4	purchase	Purchase Management	Procurement Specialist	Expert in procurement processes, vendor management, sourcing strategies, and purchase optimization	You are a Procurement specialist with extensive experience in strategic sourcing, vendor management, and purchase process optimization. You help users achieve cost savings, ensure supply security, and maintain high-quality supplier relationships.	["Strategic Sourcing", "Vendor Management", "Purchase Requisitions", "Purchase Orders", "Contract Management", "Supplier Evaluation", "Cost Analysis", "Procurement Analytics", "Risk Management", "Compliance"]	["Sourcing Strategy Development", "Vendor Performance Analysis", "Cost Optimization", "Contract Negotiation Support", "Supplier Risk Assessment", "Procurement Process Improvement", "Spend Analysis", "Market Research"]	t	2025-06-04 04:34:14.229792+00	2025-06-04 04:34:14.229792+00	t
5	production	Production Management	Manufacturing Operations Expert	Specialist in production planning, manufacturing execution, quality control, and operational efficiency	You are a Manufacturing Operations expert with comprehensive knowledge of production planning, shop floor management, and manufacturing excellence. You help users optimize production processes, improve quality, and maximize operational efficiency.	["Production Planning", "Manufacturing Execution", "Quality Control", "Capacity Planning", "Bill of Materials", "Work Center Management", "Shop Floor Control", "Lean Manufacturing", "Equipment Maintenance", "Performance Monitoring"]	["Production Schedule Optimization", "Capacity Analysis", "Quality Improvement", "Process Optimization", "Equipment Efficiency", "Bottleneck Analysis", "Cost Reduction", "Performance Metrics"]	t	2025-06-04 04:34:14.229792+00	2025-06-04 04:34:14.229792+00	t
6	finance	Finance Management	Financial Operations Expert	Expert in financial accounting, treasury management, accounts payable/receivable, and financial reporting	You are a Financial Operations expert with deep knowledge of accounting principles, financial processes, and regulatory compliance. You help users manage financial transactions, optimize cash flow, and ensure accurate financial reporting.	["General Ledger", "Accounts Payable", "Accounts Receivable", "Asset Accounting", "Bank Management", "Financial Reporting", "Tax Management", "Compliance", "Cash Flow Management", "Financial Analysis"]	["Financial Process Optimization", "Cash Flow Analysis", "Financial Reporting", "Compliance Monitoring", "Risk Assessment", "Budget Analysis", "Financial Performance Metrics", "Audit Support"]	t	2025-06-04 04:34:23.866021+00	2025-06-04 04:34:23.866021+00	t
7	controlling	Controlling	Management Accounting Specialist	Specialist in cost accounting, profitability analysis, budgeting, and management reporting	You are a Management Accounting specialist with expertise in cost control, profitability analysis, and performance management. You help users understand cost structures, analyze profitability, and make data-driven business decisions.	["Cost Center Accounting", "Profit Center Accounting", "Product Costing", "Profitability Analysis", "Budget Planning", "Variance Analysis", "Activity-Based Costing", "Performance Management", "Management Reporting", "Business Intelligence"]	["Cost Analysis", "Profitability Assessment", "Budget Planning", "Variance Analysis", "Performance Monitoring", "Cost Optimization", "Management Reporting", "Business Intelligence"]	t	2025-06-04 04:34:23.866021+00	2025-06-04 04:34:23.866021+00	t
\.


--
-- Data for Name: ai_agent_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_agent_analytics (id, module_type, date, total_queries, successful_queries, failed_queries, avg_response_time, total_tokens_used, unique_users, created_at, updated_at, active) FROM stdin;
\.


--
-- Data for Name: ai_agent_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_agent_health (id, check_timestamp, openai_status, api_key_status, total_agents, active_agents, response_time, error_details, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: comprehensive_issues_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comprehensive_issues_log (id, issue_id, error_message, stack_trace, module, operation, user_id, session_id, request_data, severity, category, status, resolved_at, resolved_by, additional_data, created_at, updated_at, auto_resolvable, confidence_score, pattern_matched, recommended_actions, ai_analysis, business_context, user_impact, resolution_status) FROM stdin;
1	fddf2f6b-be73-4084-a03c-6230f222fdea	Test issue for system validation	\N	MASTER_DATA	SYSTEM_INITIALIZATION	SYSTEM	\N	\N	LOW	SYSTEM	OPEN	\N	\N	{"test": true, "initialization": "comprehensive_issues_system"}	2025-06-04 23:48:09.969185+00	2025-06-04 23:48:09.969185+00	f	0.00	\N	\N	\N	\N	\N	PENDING
2	c8e62dd6-93d4-4129-8ef7-aa164a55ec07	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "PLANT1", "name": "Production Plant 1", "type": "Manufacturing", "status": "active", "isActive": true, "companyCodeId": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:46:55.96383+00	2025-06-05 00:46:55.96383+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
3	eaec68a3-95bd-41bf-a96d-2e152a99ffcc	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "PLANT1", "name": "Production Plant 1", "type": "Manufacturing", "status": "active", "isActive": true, "companyCodeId": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:46:55.973828+00	2025-06-05 00:46:55.973828+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
4	1c7fe1d5-a040-48c3-9303-16ffeb4ee39c	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "PROD001", "name": "Production Material 1", "type": "Raw Material", "status": "active", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:46:56.064159+00	2025-06-05 00:46:56.064159+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
5	07cbce98-0f63-47fa-b8db-ea9cf8196b01	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "PROD001", "name": "Production Material 1", "type": "Raw Material", "status": "active", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:46:56.064875+00	2025-06-05 00:46:56.064875+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
6	b2813e11-a51c-4da1-a4a5-1ed0037df025	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/customer	\N	\N	{"code": "PRODCUST1", "name": "Production Customer 1", "type": "Regular", "email": "prod1@customer.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:46:56.141667+00	2025-06-05 00:46:56.141667+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
7	9197218e-2892-4f2a-b3ea-42924b854767	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/customer	\N	\N	{"code": "PRODCUST1", "name": "Production Customer 1", "type": "Regular", "email": "prod1@customer.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:46:56.142054+00	2025-06-05 00:46:56.142054+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
8	a9ed4692-42d0-47e9-a88f-68ab678c0a4d	HTTP 500 Error	\N	SALES	POST /api/sales/orders	\N	\N	{"items": [{"quantity": 1, "unit_price": 100, "product_name": "Test Product"}], "status": "open", "total_amount": 1000, "customer_name": "Production Customer 1"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:46:56.309813+00	2025-06-05 00:46:56.309813+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
9	f8f3cf28-45d3-43c0-a9d5-01d1ef871e1b	HTTP 500 Error	\N	SALES	POST /api/sales/orders	\N	\N	{"items": [{"quantity": 1, "unit_price": 100, "product_name": "Test Product"}], "status": "open", "total_amount": 1000, "customer_name": "Production Customer 1"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:46:56.311178+00	2025-06-05 00:46:56.311178+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
10	926c619c-1788-4d06-9e9c-7b42487bf806	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TEST", "name": "Test Company", "country": "United States", "currency": "USD", "fiscalYear": "Calendar Year"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:17.532883+00	2025-06-05 00:48:17.532883+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
11	1791d772-3eb2-4b31-b9e3-21884b982376	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TEST", "name": "Test Company", "country": "United States", "currency": "USD", "fiscalYear": "Calendar Year"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:17.534+00	2025-06-05 00:48:17.534+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
12	649ffee7-50d8-4dd9-8012-c21e83d05e4e	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT001", "name": "Test Material", "type": "Raw Material", "status": "active", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.29725+00	2025-06-05 00:48:18.29725+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
13	c0ce74ed-fb91-4e20-b9ff-8c7240f5211d	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT001", "name": "Test Material", "type": "Raw Material", "status": "active", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.298431+00	2025-06-05 00:48:18.298431+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
14	f0024b49-2b9e-4e12-a97d-da1fd7681126	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/customer	\N	\N	{"code": "CUST001", "name": "Test Customer", "type": "Regular", "email": "test@customer.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.383318+00	2025-06-05 00:48:18.383318+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
15	11fdb125-712d-474a-b893-d3a708c7f2b6	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/customer	\N	\N	{"code": "CUST001", "name": "Test Customer", "type": "Regular", "email": "test@customer.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.384501+00	2025-06-05 00:48:18.384501+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
16	e7f739f3-a142-4ac6-bf6e-39b93b0e6505	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/vendor	\N	\N	{"code": "VEND001", "name": "Test Vendor", "type": "Supplier", "email": "test@vendor.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.468262+00	2025-06-05 00:48:18.468262+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
17	3d96c707-909e-4746-80d7-a6a5d2fd4d55	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/vendor	\N	\N	{"code": "VEND001", "name": "Test Vendor", "type": "Supplier", "email": "test@vendor.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.468995+00	2025-06-05 00:48:18.468995+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
18	38886055-fbf9-40f1-a198-a2d353583686	HTTP 500 Error	\N	SALES	POST /api/sales/orders	\N	\N	{"items": [{"price": 100, "quantity": 10, "materialCode": "MAT001"}], "status": "open", "orderDate": "2025-06-05T00:48:18.460Z", "customerCode": "CUST001"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.618254+00	2025-06-05 00:48:18.618254+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
19	44019d04-bdd0-4b7c-bb4c-5d8d913400f0	HTTP 500 Error	\N	SALES	POST /api/sales/orders	\N	\N	{"items": [{"price": 100, "quantity": 10, "materialCode": "MAT001"}], "status": "open", "orderDate": "2025-06-05T00:48:18.460Z", "customerCode": "CUST001"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.620972+00	2025-06-05 00:48:18.620972+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
20	52644392-fb1f-4554-937c-0e6dc03dd66a	HTTP 500 Error	\N	SYSTEM	POST /orders	\N	\N	{"items": [{"price": 50, "quantity": 5, "materialCode": "MAT001"}], "status": "open", "orderDate": "2025-06-05T00:48:18.611Z", "vendorCode": "VEND001"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.711778+00	2025-06-05 00:48:18.711778+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
21	cc5daa4f-f3a5-4c1b-b61f-c597c540bdea	HTTP 500 Error	\N	SYSTEM	POST /orders	\N	\N	{"items": [{"price": 50, "quantity": 5, "materialCode": "MAT001"}], "status": "open", "orderDate": "2025-06-05T00:48:18.611Z", "vendorCode": "VEND001"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:48:18.719162+00	2025-06-05 00:48:18.719162+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
22	5781ee13-b00e-49d6-9838-aa1388645320	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TEST", "name": "Test Company", "country": "United States", "currency": "USD", "fiscalYear": "Calendar Year"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:22.360907+00	2025-06-05 00:49:22.360907+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
23	30b0d495-cba0-4b2a-9f54-8f600904583e	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TEST", "name": "Test Company", "country": "United States", "currency": "USD", "fiscalYear": "Calendar Year"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:22.361742+00	2025-06-05 00:49:22.361742+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
24	28d75bfc-b020-406a-9039-f7d921628d1c	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "TST1", "name": "Test Plant", "type": "Manufacturing", "status": "active", "isActive": true, "companyCodeId": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:22.993635+00	2025-06-05 00:49:22.993635+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
25	e7b3e1e3-f2e8-4ec5-83c7-536b4af0577f	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "TST1", "name": "Test Plant", "type": "Manufacturing", "status": "active", "isActive": true, "companyCodeId": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:22.994371+00	2025-06-05 00:49:22.994371+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
27	a168f917-e970-4e80-8052-f5c469160215	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT001", "name": "Test Material", "type": "Raw Material", "status": "active", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:23.436659+00	2025-06-05 00:49:23.436659+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
29	056ad0c3-198b-4de1-9ebb-3937ded5909f	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/customer	\N	\N	{"code": "CUST001", "name": "Test Customer", "type": "Regular", "email": "test@customer.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:23.893468+00	2025-06-05 00:49:23.893468+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
31	db998a89-8eec-4910-8566-a2de9a3d8c70	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/vendor	\N	\N	{"code": "VEND001", "name": "Test Vendor", "type": "Supplier", "email": "test@vendor.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:23.978157+00	2025-06-05 00:49:23.978157+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
33	53ddefc8-b0d6-4f07-9ad5-a0cdf906fb17	HTTP 500 Error	\N	SALES	POST /api/sales/orders	\N	\N	{"items": [{"price": 100, "quantity": 10, "materialCode": "MAT001"}], "status": "open", "orderDate": "2025-06-05T00:49:23.968Z", "customerCode": "CUST001"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:24.110071+00	2025-06-05 00:49:24.110071+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
35	2b78a0bd-f7a6-46e5-a7b5-47b0a694cacc	HTTP 500 Error	\N	SYSTEM	POST /orders	\N	\N	{"items": [{"price": 50, "quantity": 5, "materialCode": "MAT001"}], "status": "open", "orderDate": "2025-06-05T00:49:24.100Z", "vendorCode": "VEND001"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:24.203134+00	2025-06-05 00:49:24.203134+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
26	18a1163a-96dd-4811-a982-0f52e9b70120	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT001", "name": "Test Material", "type": "Raw Material", "status": "active", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:23.435773+00	2025-06-05 00:49:23.435773+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
28	16291d8d-52ac-4f43-92f2-46a2974a2bc6	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/customer	\N	\N	{"code": "CUST001", "name": "Test Customer", "type": "Regular", "email": "test@customer.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:23.890879+00	2025-06-05 00:49:23.890879+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
30	f077e548-a498-4912-be9c-f8972776b8ec	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/vendor	\N	\N	{"code": "VEND001", "name": "Test Vendor", "type": "Supplier", "email": "test@vendor.com"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:23.977401+00	2025-06-05 00:49:23.977401+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
32	bd811d74-de9d-4a85-8096-f36c7f72c69d	HTTP 500 Error	\N	SALES	POST /api/sales/orders	\N	\N	{"items": [{"price": 100, "quantity": 10, "materialCode": "MAT001"}], "status": "open", "orderDate": "2025-06-05T00:49:23.968Z", "customerCode": "CUST001"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:24.109248+00	2025-06-05 00:49:24.109248+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
34	6fe46dbc-2c09-4f48-afdf-ba27c60f13c1	HTTP 500 Error	\N	SYSTEM	POST /orders	\N	\N	{"items": [{"price": 50, "quantity": 5, "materialCode": "MAT001"}], "status": "open", "orderDate": "2025-06-05T00:49:24.100Z", "vendorCode": "VEND001"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:49:24.202577+00	2025-06-05 00:49:24.202577+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
36	70cd4c43-6597-4a1c-8a8f-6c336401c1dd	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "CC1749084630761", "name": "Test Company", "country": "US", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:50:30.959695+00	2025-06-05 00:50:30.959695+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
37	0072aee9-feed-47ff-83d6-3422f385f596	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "CC1749084630761", "name": "Test Company", "country": "US", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:50:30.959524+00	2025-06-05 00:50:30.959524+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
38	328dcd82-fc04-4aa9-864e-8a0c94d4e260	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT1749084630761", "name": "Test Material", "type": "Raw Material", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:50:31.012876+00	2025-06-05 00:50:31.012876+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
39	2828adda-3f7c-41a2-88ea-610bc007cfa6	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT1749084630761", "name": "Test Material", "type": "Raw Material", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:50:31.013343+00	2025-06-05 00:50:31.013343+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
40	b62869ac-7fe2-4896-b350-c9921987290e	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "CC1749084660178", "name": "Test Company", "country": "US", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:51:00.251197+00	2025-06-05 00:51:00.251197+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
41	77a95b6a-7c0c-4c2d-9075-fc83ac9a983b	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "CC1749084660178", "name": "Test Company", "country": "US", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:51:00.251803+00	2025-06-05 00:51:00.251803+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
42	3349000a-4e2d-481f-bbfc-f26722c9caae	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT1749084660178", "name": "Test Material", "type": "Raw Material", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:51:00.377845+00	2025-06-05 00:51:00.377845+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
43	6c592f9b-7784-46a4-91ad-ebc00511587e	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT1749084660178", "name": "Test Material", "type": "Raw Material", "baseUom": "PC"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 00:51:00.378472+00	2025-06-05 00:51:00.378472+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
45	ec88b444-f434-4d02-9502-04c4ad39ea99	HTTP 500 Error	\N	SALES	GET /api/sales/opportunities/export	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:53:33.791582+00	2025-06-05 01:53:33.791582+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
44	dfcbc680-53e1-4c74-b82e-2911f28f8cc4	HTTP 500 Error	\N	SALES	GET /api/sales/opportunities/export	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:53:33.799566+00	2025-06-05 01:53:33.799566+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
47	8ef25092-0d6a-428e-8f26-1f2cf9388298	HTTP 500 Error	\N	SALES	GET /api/sales/opportunities/export	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:56:14.472697+00	2025-06-05 01:56:14.472697+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
46	e14ad7a9-dae7-45e4-a960-05661913d9b2	HTTP 500 Error	\N	SALES	GET /api/sales/opportunities/export	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:56:14.46784+00	2025-06-05 01:56:14.46784+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
48	fcea03a0-b2b6-4882-bdc1-5f5eb2e187f2	HTTP 500 Error	\N	PURCHASE	GET /api/purchase/requests	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:58:36.147892+00	2025-06-05 01:58:36.147892+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
49	c2521fbf-4656-4a35-8f43-7958f7edd0ed	HTTP 500 Error	\N	PURCHASE	GET /api/purchase/requests	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:58:36.150119+00	2025-06-05 01:58:36.150119+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
50	979fcc27-4d43-4780-be89-e59e83e69fd5	HTTP 500 Error	\N	PRODUCTION	GET /api/production/work-orders	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:58:36.312989+00	2025-06-05 01:58:36.312989+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
51	d3338aca-cd40-4f4e-b1d0-b6e8a75140ee	HTTP 500 Error	\N	PRODUCTION	GET /api/production/work-orders	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:58:36.317023+00	2025-06-05 01:58:36.317023+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
52	9891912e-d07b-4bc6-97e9-774702724414	HTTP 500 Error	\N	CONTROLLING	GET /api/controlling/profit-centers	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:58:36.679604+00	2025-06-05 01:58:36.679604+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
53	c3e1c459-7b92-4158-acd9-81129763201c	HTTP 500 Error	\N	CONTROLLING	GET /api/controlling/profit-centers	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:58:36.681784+00	2025-06-05 01:58:36.681784+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
54	1ca1cf18-c55b-4aa2-941b-1b9129a2866e	HTTP 500 Error	\N	PURCHASE	GET /api/purchase/requests	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:59:31.664389+00	2025-06-05 01:59:31.664389+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
55	3a0c3ef1-7a21-4d34-911a-f7b626d3634f	HTTP 500 Error	\N	PURCHASE	GET /api/purchase/requests	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:59:31.66566+00	2025-06-05 01:59:31.66566+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
56	f2e9fa03-8fec-4ba9-92dd-3c509441ac3a	HTTP 500 Error	\N	CONTROLLING	GET /api/controlling/profit-centers	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:59:32.246007+00	2025-06-05 01:59:32.246007+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
57	32e5f4be-29f5-410a-a2d2-403a0bf25e6b	HTTP 500 Error	\N	CONTROLLING	GET /api/controlling/profit-centers	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:59:32.2467+00	2025-06-05 01:59:32.2467+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
58	cbd6abb2-191f-4c64-bc19-245ec9d3ec92	HTTP 500 Error	\N	PURCHASE	GET /api/purchase/requests	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:59:52.425601+00	2025-06-05 01:59:52.425601+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
59	3f523ada-93a8-40ea-a0e3-ffa189891425	HTTP 500 Error	\N	PURCHASE	GET /api/purchase/requests	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:59:52.428701+00	2025-06-05 01:59:52.428701+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
60	f56904e2-dddf-4188-93bc-1313088880dd	HTTP 500 Error	\N	CONTROLLING	GET /api/controlling/profit-centers	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:59:52.976192+00	2025-06-05 01:59:52.976192+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
61	b2f8a8a4-b173-446c-bca7-0fdec6928331	HTTP 500 Error	\N	CONTROLLING	GET /api/controlling/profit-centers	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 01:59:52.97814+00	2025-06-05 01:59:52.97814+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
62	2c240c63-a71c-493c-b2ec-a20afdf988c8	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "STAB001", "name": "Stability Test Plant", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:04:10.812964+00	2025-06-05 02:04:10.812964+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
63	77ac3c3f-08ae-40d7-967e-c075eb058abc	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "STAB001", "name": "Stability Test Plant", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:04:10.820987+00	2025-06-05 02:04:10.820987+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
64	41e5dfd0-60ec-4909-9b18-5780da4e29ae	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"invalid": "data"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:04:11.131455+00	2025-06-05 02:04:11.131455+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
65	ba9256b6-3a3f-406b-bbed-d43ab2a776e0	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"invalid": "data"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:04:11.134663+00	2025-06-05 02:04:11.134663+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
66	c5312edd-f898-40cd-addc-6b9b0c8ac52c	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:05:58.542855+00	2025-06-05 02:05:58.542855+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
67	bb19ff4c-35e3-4a22-b1c9-8841dd44754b	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:05:58.550352+00	2025-06-05 02:05:58.550352+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
68	7f601957-3ffa-4b1d-9c42-4699f1e07fd7	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "STAB001", "name": "Stability Test Co"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:03.667037+00	2025-06-05 02:06:03.667037+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
69	47f09fb1-a282-4697-afe1-04d0bbcdb9af	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "STAB001", "name": "Stability Test Co"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:03.668521+00	2025-06-05 02:06:03.668521+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
70	768aa547-e092-4451-b38a-046c656c8f6a	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "STAB001", "name": "Stability Test Plant", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:03.695152+00	2025-06-05 02:06:03.695152+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
71	4da5cfc8-d1f9-4015-935a-4ad3767ec1d9	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "STAB001", "name": "Stability Test Plant", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:03.69657+00	2025-06-05 02:06:03.69657+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
72	74589c0d-d18a-47ec-ba82-209d0c3ddc77	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "STAB001", "name": "Stability Test Material", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:03.770206+00	2025-06-05 02:06:03.770206+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
73	45646726-7ebd-49a0-b5d2-4f70a80e8001	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "STAB001", "name": "Stability Test Material", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:03.771019+00	2025-06-05 02:06:03.771019+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
74	770b12ce-976d-49e6-b41d-88fe312a1c8b	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:03.99797+00	2025-06-05 02:06:03.99797+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
75	8b181bad-139b-4a84-b075-6c6160b3fe2a	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:03.999311+00	2025-06-05 02:06:03.999311+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
76	a102cc9a-7467-42cf-888b-98b38d1ff1f0	HTTP 400 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"invalid": "data"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:04.027358+00	2025-06-05 02:06:04.027358+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
77	4695af90-1b7c-4fde-a23f-4dadfdc8e676	HTTP 400 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"invalid": "data"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:04.028069+00	2025-06-05 02:06:04.028069+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
78	ccc58a65-4458-4f67-96dc-c9a0dbeb6191	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:29.575503+00	2025-06-05 02:06:29.575503+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
79	6086a1a8-9aaf-45ed-ab43-4d79b4621d7f	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:29.642154+00	2025-06-05 02:06:29.642154+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
80	f07a9380-babb-45e2-ae29-4bbef3f31643	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:29.742248+00	2025-06-05 02:06:29.742248+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
81	e71df478-ecd6-426e-af7c-ca076a33dbb9	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:29.743074+00	2025-06-05 02:06:29.743074+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
82	1d94a101-e3fe-4e1b-bc78-637860b62180	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:29.841526+00	2025-06-05 02:06:29.841526+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
83	c98f45bc-b1ac-4861-94d0-0a67f2df434f	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:06:29.841492+00	2025-06-05 02:06:29.841492+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
84	6907a5f2-652d-4050-9137-0a9df5ef5733	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"city": "", "code": "TTTT01", "name": "TTTT 01", "type": "Regional Office", "phone": "", "state": "", "status": "active", "address": "", "country": "", "manager": "", "category": "", "isActive": true, "timezone": "", "postalCode": "", "coordinates": "", "description": "", "companyCodeId": 3, "operatingHours": ""}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:09:13.563171+00	2025-06-05 02:09:13.563171+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
85	f7085298-cb0d-491b-82f9-52e5cdbf7a6e	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"city": "", "code": "TTTT01", "name": "TTTT 01", "type": "Regional Office", "phone": "", "state": "", "status": "active", "address": "", "country": "", "manager": "", "category": "", "isActive": true, "timezone": "", "postalCode": "", "coordinates": "", "description": "", "companyCodeId": 3, "operatingHours": ""}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:09:13.565866+00	2025-06-05 02:09:13.565866+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
87	fa6ea030-ccd6-439d-8f16-f1fd81314ad1	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "PLT001", "name": "Test Plant 001", "type": "Manufacturing", "status": "active", "isActive": true, "companyCodeId": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:10:57.807667+00	2025-06-05 02:10:57.807667+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
86	ab7e7d89-98b5-4112-9360-1952e442332a	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "PLT001", "name": "Test Plant 001", "type": "Manufacturing", "status": "active", "isActive": true, "companyCodeId": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:10:57.105805+00	2025-06-05 02:10:57.105805+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
88	10cd6468-6472-4fb7-a8ee-4abc7c5d41d9	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO001", "name": "Test Purchase Org 001", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:10:58.420558+00	2025-06-05 02:10:58.420558+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
89	624afa90-fd81-41fa-857d-d5df1a1639d9	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO001", "name": "Test Purchase Org 001", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:10:58.421173+00	2025-06-05 02:10:58.421173+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
90	9164e579-e113-4b82-b781-1398dc480c2d	HTTP 404 Error	\N	SYSTEM	POST /	\N	\N	{"code": "CC001", "name": "Test Cost Center 001", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:10:58.444287+00	2025-06-05 02:10:58.444287+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
91	59a604c8-1619-420a-b983-c140b25c8a73	HTTP 404 Error	\N	SYSTEM	POST /	\N	\N	{"code": "SO001", "name": "Test Sales Org 001", "description": "Test sales organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:00.282913+00	2025-06-05 02:11:00.282913+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
92	4739c580-815d-425e-ae27-206ac4e987b5	HTTP 404 Error	\N	SYSTEM	POST /	\N	\N	{"code": "CC001", "name": "Test Cost Center 001", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:00.28597+00	2025-06-05 02:11:00.28597+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
93	3eac7f50-06ea-4e9f-9f62-58a0dcf520ee	HTTP 404 Error	\N	SYSTEM	POST /	\N	\N	{"code": "SO001", "name": "Test Sales Org 001", "description": "Test sales organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:00.287537+00	2025-06-05 02:11:00.287537+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
94	ec90e0f4-1426-4325-85f4-b6e460e1de43	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TEST001", "name": "Test Company 001", "country": "USA", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.618935+00	2025-06-05 02:11:57.618935+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
95	1b1e9677-934b-4fee-bfc2-52ca8110bcfd	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TEST001", "name": "Test Company 001", "country": "USA", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.672+00	2025-06-05 02:11:57.672+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
96	bc645731-d5b1-4d5e-bc5b-96bf25029ec4	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "PLT001", "name": "Test Plant 001", "type": "Manufacturing", "status": "active", "isActive": true, "companyCodeId": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.73862+00	2025-06-05 02:11:57.73862+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
97	83328509-12bc-4c9e-930d-5993ca6367bc	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "PLT001", "name": "Test Plant 001", "type": "Manufacturing", "status": "active", "isActive": true, "companyCodeId": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.741399+00	2025-06-05 02:11:57.741399+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
98	838a1a79-22fd-4988-a6b8-78dcc3b89973	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "PLT002", "name": "Test Plant 002", "type": "Warehouse", "status": "active", "isActive": true, "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.780983+00	2025-06-05 02:11:57.780983+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
99	a3559022-31be-4649-80b2-b098a264e8e4	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/plant	\N	\N	{"code": "PLT002", "name": "Test Plant 002", "type": "Warehouse", "status": "active", "isActive": true, "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.781909+00	2025-06-05 02:11:57.781909+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
100	4f9c5971-46bf-483c-a9e2-5049c822bf3e	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT001", "name": "Test Material 001", "type": "RAW", "uom_id": 1, "category_id": 1, "description": "Test material description"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.826843+00	2025-06-05 02:11:57.826843+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
101	547dd7bb-ad25-4c2c-b242-01d12d9ba83a	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/material	\N	\N	{"code": "MAT001", "name": "Test Material 001", "type": "RAW", "uom_id": 1, "category_id": 1, "description": "Test material description"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.829517+00	2025-06-05 02:11:57.829517+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
102	28beb971-105b-4b6a-9de5-025077923d38	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/vendor	\N	\N	{"city": "Vendor City", "code": "VEN001", "name": "Test Vendor 001", "email": "test@vendor.com", "phone": "123-456-7890", "address": "456 Vendor Ave", "country": "USA"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.954683+00	2025-06-05 02:11:57.954683+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
103	a967fe0f-8480-48f0-b365-bf88661277da	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/vendor	\N	\N	{"city": "Vendor City", "code": "VEN001", "name": "Test Vendor 001", "email": "test@vendor.com", "phone": "123-456-7890", "address": "456 Vendor Ave", "country": "USA"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:57.975689+00	2025-06-05 02:11:57.975689+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
104	805d5be4-7b37-4a26-9e76-67ece0b6f2a8	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO001", "name": "Test Purchase Org 001", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:58.042551+00	2025-06-05 02:11:58.042551+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
105	1b598742-7b4e-4c8a-acf8-99498c1eebbe	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO001", "name": "Test Purchase Org 001", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:58.044057+00	2025-06-05 02:11:58.044057+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
106	a712c7db-9ae6-45b1-8309-14e2b9a12d0f	HTTP 404 Error	\N	SYSTEM	POST /	\N	\N	{"code": "CC001", "name": "Test Cost Center 001", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:58.102679+00	2025-06-05 02:11:58.102679+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
107	6fa7d387-c42c-44eb-a388-6f92f4a87bd8	HTTP 404 Error	\N	SYSTEM	POST /	\N	\N	{"code": "SO001", "name": "Test Sales Org 001", "description": "Test sales organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:58.110841+00	2025-06-05 02:11:58.110841+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
108	5f54b2ed-559e-4ef0-bc01-b9a1ec9b5192	HTTP 404 Error	\N	SYSTEM	POST /	\N	\N	{"code": "SO001", "name": "Test Sales Org 001", "description": "Test sales organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:58.118705+00	2025-06-05 02:11:58.118705+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
109	1434626a-dc41-4740-8427-bc6cf5b31748	HTTP 404 Error	\N	SYSTEM	POST /	\N	\N	{"code": "CC001", "name": "Test Cost Center 001", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:58.122122+00	2025-06-05 02:11:58.122122+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
110	dad39bb4-931c-4c93-bbbc-3d1ed4a17f98	HTTP 400 Error	\N	SYSTEM	POST /	\N	\N	{"code": "WC001", "name": "Test Work Center 001", "capacity": 100, "plant_id": 1, "description": "Test work center"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:58.163309+00	2025-06-05 02:11:58.163309+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
111	81e582dd-67c7-4d0f-a20a-942d5a84584f	HTTP 400 Error	\N	SYSTEM	POST /	\N	\N	{"code": "WC001", "name": "Test Work Center 001", "capacity": 100, "plant_id": 1, "description": "Test work center"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:11:58.166183+00	2025-06-05 02:11:58.166183+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
112	f42ac51e-32e1-46cc-83cc-72aa54a298bd	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO1749089635928", "name": "Test Purchase Org 1749089635928", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:13:57.916395+00	2025-06-05 02:13:57.916395+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
113	2c7d6f1a-19d4-4f80-a289-4c0f5ebe69e4	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO1749089635928", "name": "Test Purchase Org 1749089635928", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:13:59.913594+00	2025-06-05 02:13:59.913594+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
114	4c5dbe59-7c46-4225-af3b-b7e65ef46f77	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC1749089635928", "name": "Test Cost Center 1749089635928", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:14:00.007856+00	2025-06-05 02:14:00.007856+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
115	a3cc65c6-267a-41d4-a455-634ce99705a7	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC1749089635928", "name": "Test Cost Center 1749089635928", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:14:00.010716+00	2025-06-05 02:14:00.010716+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
116	421a1a1f-05fa-43fd-8011-5c6c64d36ff4	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TST1749089708190", "name": "Test Company 1749089708190", "country": "USA", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:08.285071+00	2025-06-05 02:15:08.285071+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
117	9cc67a0c-32f4-438c-bdcc-f337d966f4d4	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TST1749089708190", "name": "Test Company 1749089708190", "country": "USA", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:08.286688+00	2025-06-05 02:15:08.286688+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
118	10f1dcde-c407-44c5-b866-b82360af84b5	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC1749089708190", "name": "Test Cost Center 1749089708190", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:08.536718+00	2025-06-05 02:15:08.536718+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
119	b203a650-34ee-427c-8d6d-496ebfacf500	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC1749089708190", "name": "Test Cost Center 1749089708190", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:08.53753+00	2025-06-05 02:15:08.53753+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
120	c83b3677-40ad-48a2-9c53-6adf7e1d9a9d	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TST1749089731713", "name": "Test Company 1749089731713", "country": "USA", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:31.76698+00	2025-06-05 02:15:31.76698+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
121	1e3bdeeb-0f36-4612-8663-10cbd77f91c3	HTTP 409 Error	\N	MASTER_DATA	POST /api/master-data/company-code	\N	\N	{"code": "TST1749089731713", "name": "Test Company 1749089731713", "country": "USA", "currency": "USD"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:31.768911+00	2025-06-05 02:15:31.768911+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
122	dc111ee9-c619-4f07-934b-5f196b9d6cf1	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO1749089731713", "name": "Test Purchase Org 1749089731713", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:31.9507+00	2025-06-05 02:15:31.9507+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
123	d4337ea0-ad20-43a9-bc2d-da8cd3e67bd2	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO1749089731713", "name": "Test Purchase Org 1749089731713", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:31.953631+00	2025-06-05 02:15:31.953631+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
124	8c8fa5c0-d138-4a26-b101-a880a4f081f9	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC1749089731713", "name": "Test Cost Center 1749089731713", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:32.085584+00	2025-06-05 02:15:32.085584+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
125	a1c74e0b-2855-4167-acd0-7b2682106d4e	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC1749089731713", "name": "Test Cost Center 1749089731713", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:15:32.087485+00	2025-06-05 02:15:32.087485+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
126	bfc46d96-6e6b-439f-8e7e-61bef7cc073e	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO17490897", "name": "Test PO 1749089769754", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:09.707078+00	2025-06-05 02:16:09.707078+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
127	6ac3baf1-d63a-4c30-b138-2994263b34c6	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO17490897", "name": "Test PO 1749089769754", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:09.724476+00	2025-06-05 02:16:09.724476+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
128	331a513e-3d06-4bd8-a343-f7d2558a5686	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC17490897", "name": "Test CC 1749089769754", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:09.902566+00	2025-06-05 02:16:09.902566+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
129	01a49fc6-0220-4b6d-b913-c4829661bb75	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC17490897", "name": "Test CC 1749089769754", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:09.971035+00	2025-06-05 02:16:09.971035+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
130	9bfde589-34bf-4f08-8df4-a4abd17f2c65	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO17490897", "name": "Test PO 1749089793928", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:34.543384+00	2025-06-05 02:16:34.543384+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
131	a8750c26-5437-4637-be94-8be1ee480d3d	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/purchase-organization	\N	\N	{"code": "PO17490897", "name": "Test PO 1749089793928", "description": "Test purchase organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:34.599831+00	2025-06-05 02:16:34.599831+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
132	75a04f22-9e1b-471c-aeb7-58541f68ce26	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/sales-organization	\N	\N	{"code": "SO17490897", "name": "Test SO 1749089793928", "description": "Test sales organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:34.674054+00	2025-06-05 02:16:34.674054+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
133	9fd05d16-e74f-47f1-8fb7-fa145aaaa1bf	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/sales-organization	\N	\N	{"code": "SO17490897", "name": "Test SO 1749089793928", "description": "Test sales organization", "company_code_id": 1}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:34.726743+00	2025-06-05 02:16:34.726743+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
134	5823ccbf-9af5-4aa2-9705-f4bbed545980	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC17490897", "name": "Test CC 1749089793928", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:34.79327+00	2025-06-05 02:16:34.79327+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
135	760d43ef-e057-467b-b69a-1ad4ef24abab	HTTP 500 Error	\N	MASTER_DATA	POST /api/master-data/cost-center	\N	\N	{"code": "CC17490897", "name": "Test CC 1749089793928", "description": "Test cost center", "company_code_id": 1, "cost_center_group": "ADMIN"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:34.848292+00	2025-06-05 02:16:34.848292+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
136	fd87d9e3-3fdf-4448-afe3-42b8650cbd25	HTTP 400 Error	\N	SYSTEM	POST /	\N	\N	{"code": "WC17490897", "name": "Test WC 1749089793928", "capacity": 100, "plant_id": 1, "description": "Test work center"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:34.956584+00	2025-06-05 02:16:34.956584+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
137	0c938d87-c1af-4a38-8a9b-27ff8d0f510c	HTTP 400 Error	\N	SYSTEM	POST /	\N	\N	{"code": "WC17490897", "name": "Test WC 1749089793928", "capacity": 100, "plant_id": 1, "description": "Test work center"}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 02:16:34.999601+00	2025-06-05 02:16:34.999601+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
138	fea76c52-9e5e-467a-9ca2-94ac4813563a	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 16:54:02.20414+00	2025-06-05 16:54:02.20414+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
139	7b010378-15bd-4c53-859f-584ddb5d0108	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 16:54:02.202796+00	2025-06-05 16:54:02.202796+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
140	f49ab02f-74c1-4be0-90e0-cf04d3c865ef	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 16:54:04.490632+00	2025-06-05 16:54:04.490632+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
141	0bdc27c6-72ba-45f9-9401-d9b04c4a3031	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 16:54:04.491943+00	2025-06-05 16:54:04.491943+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
142	1041b071-df0f-449f-8c16-ed9dab9f4eb1	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 17:17:08.318524+00	2025-06-05 17:17:08.318524+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
143	be3bafd8-0dfc-4074-9a9f-b37ba6c8cca7	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 17:17:08.318326+00	2025-06-05 17:17:08.318326+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
145	3e2a96e8-13ab-4697-ab30-3e7693bddbaf	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 17:24:05.65768+00	2025-06-05 17:24:05.65768+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
144	0c5207c8-e963-4593-ba49-f24785afd852	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 17:24:05.655917+00	2025-06-05 17:24:05.655917+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
146	cac49923-80d7-4b84-8f9e-09e8ea90c8a8	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 18:06:13.926513+00	2025-06-05 18:06:13.926513+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
147	50754a3b-e396-42a4-88c7-0efb8a3d822d	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 18:06:14.600497+00	2025-06-05 18:06:14.600497+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
148	aa69a5c5-c948-4d4d-b1b0-e9f131695aa5	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 18:06:35.905691+00	2025-06-05 18:06:35.905691+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
149	e9187c11-eca2-4264-b13b-44f4ebcb9bd2	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 18:06:35.907886+00	2025-06-05 18:06:35.907886+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
150	de847784-7e43-4517-85b1-78a2f9b63e2e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 18:06:35.929546+00	2025-06-05 18:06:35.929546+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
151	554297a9-fb42-46fe-8af7-f2422f02d9fa	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 18:06:37.999092+00	2025-06-05 18:06:37.999092+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
152	62abbf5a-3c55-4079-93a1-4bdf67282a25	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 18:06:39.945461+00	2025-06-05 18:06:39.945461+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
153	db3a5f36-3842-4f08-8445-06c2c36fec5e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 18:06:39.946525+00	2025-06-05 18:06:39.946525+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
155	3d300163-ec0d-4818-9985-d3d5bc9420fe	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:39.004242+00	2025-06-05 20:12:39.004242+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
156	5c51fda4-5c66-4d97-bf33-b03389bd6dbc	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:38.992108+00	2025-06-05 20:12:38.992108+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
154	6e5cfb59-26fb-4999-8a5a-09b60033fc1c	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:38.993729+00	2025-06-05 20:12:38.993729+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
157	ca176327-8840-4d29-ac00-173740a15987	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:39.078783+00	2025-06-05 20:12:39.078783+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
158	f49ac25d-08fc-4a45-8933-99b2ac91d6b3	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:40.634181+00	2025-06-05 20:12:40.634181+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
159	d82ecdf8-ee25-45dd-b40d-e172e7f6fa4c	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:40.635635+00	2025-06-05 20:12:40.635635+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
160	5caef782-fc1d-4c86-858b-c2408ce35954	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:40.641549+00	2025-06-05 20:12:40.641549+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
161	0852b2d9-8844-4a54-9188-ab9c1b909b2e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:40.643193+00	2025-06-05 20:12:40.643193+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
162	82d39eb0-04b6-468c-a7e1-40ccc7dbaec6	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:40.699042+00	2025-06-05 20:12:40.699042+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
164	4c217ee1-65d3-4b95-8968-a5afb6abda46	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:41.103219+00	2025-06-05 20:12:41.103219+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
163	fc2cfe3c-172a-47d2-8eb9-a74ed60b35bd	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:41.102628+00	2025-06-05 20:12:41.102628+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
165	44781604-5d06-4c49-b642-83c5ca3fb247	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:42.709911+00	2025-06-05 20:12:42.709911+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
166	602b13f0-852f-422c-affb-a23d38ea3d71	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:45.736025+00	2025-06-05 20:12:45.736025+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
167	afd7e864-e5fe-4817-9aa9-a8d2c08cde1d	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:45.736669+00	2025-06-05 20:12:45.736669+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
168	7d95c0ce-ca42-4cfa-aaa0-2ce13a9f3fa2	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:50.845086+00	2025-06-05 20:12:50.845086+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
169	bf4cdb05-1c3c-4cf3-a734-3f9aab687595	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:50.846539+00	2025-06-05 20:12:50.846539+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
170	f44cb7e4-e838-489d-bd65-7d7186b590dc	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:50.847742+00	2025-06-05 20:12:50.847742+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
171	5e08d089-33cd-4421-9955-b74b1148f262	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:50.850209+00	2025-06-05 20:12:50.850209+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
172	3f2d8e46-2a18-449c-ac9c-b5f8d5b77997	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:55.73037+00	2025-06-05 20:12:55.73037+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
173	bc4e94de-1c9a-4e54-8105-338230b97376	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:55.731146+00	2025-06-05 20:12:55.731146+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
175	df35396a-ab12-45c6-a32b-55020344babc	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:55.928893+00	2025-06-05 20:12:55.928893+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
174	1120de04-55ef-4d41-8c52-0347559bcd33	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:12:55.928559+00	2025-06-05 20:12:55.928559+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
176	fd32a990-c3fa-46fa-8d8a-7b81f91272e5	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:00.956356+00	2025-06-05 20:13:00.956356+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
177	badbe2fb-e0a9-4139-83f7-1adb9689e7ef	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:00.957134+00	2025-06-05 20:13:00.957134+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
178	69f05c4f-6026-4f89-9295-97627b294e9b	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:01.021693+00	2025-06-05 20:13:01.021693+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
179	f62c7be0-43ff-41fc-a448-c17660470f66	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:01.022189+00	2025-06-05 20:13:01.022189+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
180	1e23f123-8477-4501-875f-3178ab09ab95	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:06.104538+00	2025-06-05 20:13:06.104538+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
181	cafba7d2-e00d-4be5-a1ac-c4015e70973c	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:06.105402+00	2025-06-05 20:13:06.105402+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
182	1c7e85b0-aeea-4ad2-a76a-0bb12667956f	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:10.817272+00	2025-06-05 20:13:10.817272+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
183	b92304d6-4ca4-4650-8973-72b4339ab493	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:10.817911+00	2025-06-05 20:13:10.817911+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
184	fbc18647-97a2-4156-a7da-f4c065f652c8	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:11.059731+00	2025-06-05 20:13:11.059731+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
185	54e31d2d-9fbd-4206-8b70-eed1955b9b61	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:11.060423+00	2025-06-05 20:13:11.060423+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
186	fee2a21f-61c2-4af4-a9ee-cc444438d352	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:11.192601+00	2025-06-05 20:13:11.192601+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
187	7c34eaca-0246-41b5-ad80-3a428852ab64	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:11.192368+00	2025-06-05 20:13:11.192368+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
188	14750833-5d50-427f-a58a-55097d9f3bca	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:16.272917+00	2025-06-05 20:13:16.272917+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
189	0071bac9-2d83-4033-8b18-d44b3f824057	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:13:16.27354+00	2025-06-05 20:13:16.27354+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
190	a3c858fb-da3a-444c-a8d1-e2e02781c4ed	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.77636+00	2025-06-05 20:18:30.77636+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
192	08c02eb2-ffa3-4e15-b92c-cdc74addfc8a	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.791305+00	2025-06-05 20:18:30.791305+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
191	4f431518-e40a-4624-8ae1-a8e4107e9aff	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.776488+00	2025-06-05 20:18:30.776488+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
193	157c4d0f-21c1-4038-a670-36f2c237cb7b	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.843519+00	2025-06-05 20:18:30.843519+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
194	ae8d63bb-2cc9-456e-9d16-50ecfac95933	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.842814+00	2025-06-05 20:18:30.842814+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
195	417aeee9-634a-43dd-bd23-0b418b2f69c3	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.85671+00	2025-06-05 20:18:30.85671+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
196	7fc269dc-bf28-4b51-b7b8-260d9e045946	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.860506+00	2025-06-05 20:18:30.860506+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
197	205173d3-a0ce-4e84-96cf-1c227d950517	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.861671+00	2025-06-05 20:18:30.861671+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
198	c707ad24-1c50-4800-9a6d-ee23a40a2409	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.862328+00	2025-06-05 20:18:30.862328+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
199	c4c05a95-5a18-4720-bad2-0f236d3f906b	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:30.865762+00	2025-06-05 20:18:30.865762+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
200	00c351a4-21b4-4565-bfa8-4c7fb8bd0911	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.378366+00	2025-06-05 20:18:33.378366+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
201	2fba52ce-6c8c-481e-8eda-0795259cfdae	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.379171+00	2025-06-05 20:18:33.379171+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
202	c56259bb-20c9-4996-bca1-af9b2e82838e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.386131+00	2025-06-05 20:18:33.386131+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
204	6c07e636-ae34-48ab-a584-856ed637c811	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.387921+00	2025-06-05 20:18:33.387921+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
206	77fac584-a4f7-4c7e-b823-21dd9ebb7572	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.390148+00	2025-06-05 20:18:33.390148+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
207	8df53a4b-ff6b-4819-b4ea-a9dab88c9532	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.391739+00	2025-06-05 20:18:33.391739+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
203	0a8a5a6a-cc18-49c4-a550-9b45151bae16	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.386065+00	2025-06-05 20:18:33.386065+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
205	e768ff51-0154-44e3-bd70-79f11d4a54dd	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.388879+00	2025-06-05 20:18:33.388879+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
208	cebdbc8f-7f42-40ba-b539-ae111c5bec73	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.392003+00	2025-06-05 20:18:33.392003+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
209	4f052cad-e517-4fc6-afb5-da142e582474	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:18:33.392957+00	2025-06-05 20:18:33.392957+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
210	bb504b55-1c7f-4e6c-b8ca-d374ad667100	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.452589+00	2025-06-05 20:19:57.452589+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
211	135d2093-ef16-4395-8c9e-91a189b72dce	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.461174+00	2025-06-05 20:19:57.461174+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
212	3273178b-a9af-4344-b13d-7365d786f0e1	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.463458+00	2025-06-05 20:19:57.463458+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
213	32c2fd0b-b9a5-4e0e-96ce-6cadab1fd410	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.467066+00	2025-06-05 20:19:57.467066+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
214	3c4033ed-7d3e-4bbc-b064-969cc46f6fcf	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.468574+00	2025-06-05 20:19:57.468574+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
215	db1bd208-87ab-4a6c-adca-bc9cd928c54e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.476239+00	2025-06-05 20:19:57.476239+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
216	ff612882-1692-4674-afb4-5a93d127b525	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.479783+00	2025-06-05 20:19:57.479783+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
217	99c1146f-36c3-4026-ad23-1a6c8acea5b3	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.481259+00	2025-06-05 20:19:57.481259+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
219	c8776cef-643b-468a-bc25-c58e8b721868	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.488532+00	2025-06-05 20:19:57.488532+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
218	9fa91f9e-e565-4aba-ba0b-6b005a8fb76c	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:19:57.488049+00	2025-06-05 20:19:57.488049+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
220	17f8ede5-074a-499d-a66a-d851f6f8758f	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.789939+00	2025-06-05 20:20:03.789939+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
221	bf1d7216-fa58-406f-a58a-d1a45b852913	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.791347+00	2025-06-05 20:20:03.791347+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
222	211ec373-dc1f-47a5-a9c8-a2bf3982a023	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.791956+00	2025-06-05 20:20:03.791956+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
223	a769558c-a8c9-457d-9212-58d251096243	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.792424+00	2025-06-05 20:20:03.792424+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
224	b44850b0-1249-45f9-8efd-fbda4db14742	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.792997+00	2025-06-05 20:20:03.792997+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
225	09156064-5d63-4078-bc01-0149eef6255a	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.79542+00	2025-06-05 20:20:03.79542+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
226	a6dae455-88b9-404c-82c9-80891396e4e9	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.796719+00	2025-06-05 20:20:03.796719+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
227	02d41e4f-ec92-45cb-ba60-21dd84976269	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.797212+00	2025-06-05 20:20:03.797212+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
229	887b115d-b1ca-4ee7-ab36-6dfe598340d9	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.798875+00	2025-06-05 20:20:03.798875+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
228	ba038aca-19f3-4ad6-97cc-70663384c351	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 20:20:03.79871+00	2025-06-05 20:20:03.79871+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
231	787dd045-5810-4c20-9cc1-3fbdc343ef10	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:18.569165+00	2025-06-05 22:04:18.569165+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
230	7ec547f1-d28d-47ba-879c-7eebdb3172a2	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:18.568298+00	2025-06-05 22:04:18.568298+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
232	f8cf3705-02cb-41a8-8621-42b1a4a99e1c	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:18.744542+00	2025-06-05 22:04:18.744542+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
233	ddb615bc-c3a5-486a-86e2-82274632b9b3	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:18.748854+00	2025-06-05 22:04:18.748854+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
234	fea9e78d-7fcf-45fb-8deb-7867aac7ce21	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:18.754865+00	2025-06-05 22:04:18.754865+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
235	357d2bc3-b333-4a38-af1d-3aa2d808e88e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:18.75244+00	2025-06-05 22:04:18.75244+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
236	cbfc1161-2ee0-4da4-9d20-b1b21af21968	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:18.757695+00	2025-06-05 22:04:18.757695+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
237	d3bd1563-29ce-48a3-b6e9-d1f79b0ce0e3	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:19.275697+00	2025-06-05 22:04:19.275697+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
238	4147a6d0-118a-40bb-a86c-89e531f65861	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:19.282341+00	2025-06-05 22:04:19.282341+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
239	17ee435c-ba4e-4f2d-8f7b-09dcc4f8f259	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:19.285218+00	2025-06-05 22:04:19.285218+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
240	d413e4b2-dbdc-4440-9faf-61ce8ab8cd19	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:48.196117+00	2025-06-05 22:04:48.196117+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
241	c0a68f85-035f-49a1-a2d3-cbb86f600264	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:48.197138+00	2025-06-05 22:04:48.197138+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
242	0b233723-2e04-4c72-a2fc-0eb001d12069	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:48.401182+00	2025-06-05 22:04:48.401182+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
243	1ed89207-8df8-4c8b-a797-122bfd863b8d	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:04:48.401907+00	2025-06-05 22:04:48.401907+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
245	1df171d2-48a3-4711-aca4-2332054bde60	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:06:11.980247+00	2025-06-05 22:06:11.980247+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
244	b0b5e3af-b2cc-459b-84dc-7ed09397df42	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:06:11.979676+00	2025-06-05 22:06:11.979676+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
246	5b369d4d-a12d-44bb-a43c-6cde63ffec78	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:06:12.602592+00	2025-06-05 22:06:12.602592+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
247	b31ad700-200e-44f1-88e0-9ac303cda4fa	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:06:12.607072+00	2025-06-05 22:06:12.607072+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
248	f965128c-2c9e-40dc-b4f3-a29755f70d0e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:06:12.627326+00	2025-06-05 22:06:12.627326+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
249	82a7380c-5ca5-4740-b563-e4bcd5822e10	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:06:13.495611+00	2025-06-05 22:06:13.495611+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
250	7f86546a-c64a-4796-93ff-cf016380df6a	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:06:13.500104+00	2025-06-05 22:06:13.500104+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
251	4cd32601-7485-4acd-902b-8aa78b1f0104	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:06:13.536588+00	2025-06-05 22:06:13.536588+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
252	5c9a5751-3b88-448e-bf24-74a1a2b7f609	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:08:53.22966+00	2025-06-05 22:08:53.22966+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
254	ab0c19f1-44fa-45b6-96b0-22ad7784b613	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:08:53.232517+00	2025-06-05 22:08:53.232517+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
253	272ae39d-4f56-422e-9bff-b5024ced6e9e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:08:53.232381+00	2025-06-05 22:08:53.232381+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
255	af231daa-cb7e-48a9-931f-fdd4db3b373b	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:08:53.903092+00	2025-06-05 22:08:53.903092+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
256	2d3da546-2c6d-400b-932d-25357bce247e	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:08:53.934468+00	2025-06-05 22:08:53.934468+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
257	de0e7966-6386-4f24-b1b1-b736c049609d	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:08:53.944529+00	2025-06-05 22:08:53.944529+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
258	cdb3f9e4-4bd4-46f0-aab0-65c8242468ce	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:08:53.952574+00	2025-06-05 22:08:53.952574+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
259	36fb5d41-a288-4702-a99b-f649396896be	HTTP 404 Error	\N	SYSTEM	GET /	\N	\N	{}	HIGH	SYSTEM	OPEN	\N	\N	\N	2025-06-05 22:08:53.959731+00	2025-06-05 22:08:53.959731+00	f	0.00	\N	\N	\N	\N	User operation failed	PENDING
\.


--
-- Data for Name: ai_agent_interventions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_agent_interventions (id, issue_id, agent_name, agent_type, analysis_result, recommended_actions, confidence_score, execution_status, execution_start, execution_end, created_at) FROM stdin;
\.


--
-- Data for Name: ai_agent_performance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_agent_performance (id, agent_name, agent_type, performance_date, total_interventions, successful_interventions, failed_interventions, avg_confidence_score, avg_resolution_time, success_rate, pattern_matches, new_patterns_learned, accuracy_improvement, created_at) FROM stdin;
1	Master Data Specialist Agent	MODULE_SPECIALIST	2025-06-05	45	42	3	0.85	75	0.93	15	5	0.08	2025-06-05 00:05:35.279487+00
2	Sales Operations Expert Agent	MODULE_SPECIALIST	2025-06-05	38	34	4	0.80	65	0.89	12	4	0.06	2025-06-05 00:05:35.279487+00
3	Inventory Control Specialist Agent	MODULE_SPECIALIST	2025-06-05	52	48	4	0.88	55	0.92	18	6	0.09	2025-06-05 00:05:35.279487+00
4	Procurement Specialist Agent	MODULE_SPECIALIST	2025-06-05	41	36	5	0.82	70	0.88	14	5	0.07	2025-06-05 00:05:35.279487+00
5	Manufacturing Operations Expert Agent	MODULE_SPECIALIST	2025-06-05	47	43	4	0.86	60	0.91	16	5	0.08	2025-06-05 00:05:35.279487+00
6	Financial Operations Expert Agent	MODULE_SPECIALIST	2025-06-05	39	37	2	0.90	45	0.95	13	4	0.10	2025-06-05 00:05:35.279487+00
7	Management Accounting Specialist Agent	MODULE_SPECIALIST	2025-06-05	44	40	4	0.87	50	0.91	15	5	0.09	2025-06-05 00:05:35.279487+00
8	Data Integrity Guardian Agent	DATA_INTEGRITY	2025-06-05	63	60	3	0.95	35	0.95	22	7	0.12	2025-06-05 00:05:35.279487+00
9	Auto-Recovery Agent	SYSTEM_RECOVERY	2025-06-05	58	54	4	0.92	40	0.93	20	6	0.11	2025-06-05 00:05:35.279487+00
\.


--
-- Data for Name: ai_chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_chat_sessions (id, session_id, module_type, user_id, user_role, context_data, session_start, session_end, is_active, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_chat_messages (id, session_id, message_type, content, agent_name, context_data, api_response_time, tokens_used, created_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_data_analysis_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_data_analysis_sessions (id, session_id, module_type, analysis_type, input_data, analysis_result, insights, recommendations, user_id, processing_time, status, created_at, completed_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, service_name, key_name, key_value, description, is_active, created_at, updated_at, last_used, active) FROM stdin;
1	openai	OPENAI_API_KEY	c2stcHJvai0ybVVsOVJleFQ4Z3B2TXAtSkJLMXI3RTlhR0xyd050RXk1Wk41V3YwYWNPX1h0eURfY3B4WU1rWWwzUFh3Y3MybmwxQ0hFYnRuMFQzQmxia0ZKQUM1QWV1OFZjXzFHb3R5bEh3aHY0TjBfTXMyLTc2ZHFtMVV5T3BHSFh1d1RWdVVZS0F4Y2lEcGljb0d0RDlnZGJ4TEtDV25Gc0E=	OpenAI API key for AI agent functionality	t	2025-06-04 13:29:59.56228+00	2025-06-04 13:34:44.013221+00	\N	t
\.


--
-- Data for Name: approval_levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_levels (id, level, name, description, value_limit, created_at, updated_at, active) FROM stdin;
1	1	Team Lead	First level approval - up to $5,000	5000.00	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924	t
2	2	Department Manager	Second level approval - up to $25,000	25000.00	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924	t
3	3	Director	Third level approval - up to $100,000	100000.00	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924	t
4	4	VP	Fourth level approval - up to $500,000	500000.00	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924	t
5	5	CFO	Fifth level approval - unlimited	\N	2025-05-20 22:09:21.912924	2025-05-20 22:09:21.912924	t
6	1	Solutions		500.00	2025-05-21 01:42:12.929446	2025-05-21 01:42:12.929446	t
7	1	Team Lead Approval	First level approval for small purchases	1000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801	t
8	2	Manager Approval	Second level approval for medium purchases	10000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801	t
9	3	Director Approval	Third level approval for large purchases	50000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801	t
10	4	Executive Approval	Fourth level approval for very large purchases	250000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801	t
11	5	Board Approval	Highest level approval for major expenditures	1000000.00	2025-05-21 15:12:43.075801	2025-05-21 15:12:43.075801	t
\.


--
-- Data for Name: asset_master; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.asset_master (id, asset_number, name, description, asset_class, acquisition_date, acquisition_cost, current_value, depreciation_method, useful_life_years, company_code_id, cost_center_id, location, status, is_active, created_at, updated_at, active) FROM stdin;
1	A10001	CNC Machine - Haas VF-2	Vertical machining center	MACHINERY	2019-03-15	85000.00	65000.00	STRAIGHT_LINE	10	1	\N	Plant NY - Building A	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858	t
2	A10002	Forklift - Toyota 8FGCU25	Material handling equipment	EQUIPMENT	2019-05-01	28000.00	21000.00	STRAIGHT_LINE	7	1	\N	Plant NY - Warehouse	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858	t
3	A10003	Injection Molding Machine - Engel	Plastic injection molding	MACHINERY	2019-08-15	120000.00	96000.00	STRAIGHT_LINE	12	1	\N	Plant NY - Building B	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858	t
4	A10004	Server System - Dell PowerEdge	Data center servers	IT_EQUIPMENT	2020-01-10	45000.00	27000.00	ACCELERATED	5	1	\N	NY Headquarters - Server Room	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858	t
5	A10005	Office Building - NY HQ	Main office building	REAL_ESTATE	2015-11-30	3500000.00	3200000.00	STRAIGHT_LINE	40	1	\N	Manhattan, NY	ACTIVE	t	2025-05-20 22:11:02.428858	2025-05-20 22:11:02.428858	t
6	CN01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	10	9	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215	t
7	DE01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	9	5	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215	t
8	IN01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	6	14	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215	t
9	GA01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	7	15	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215	t
10	UK01-AST001	Production Machinery #1	Heavy-duty manufacturing equipment for main production line	MACHINERY	2022-05-15	125000.00	110000.00	STRAIGHT_LINE	10	11	6	Main Factory Floor	ACTIVE	t	2025-05-21 15:11:52.062215	2025-05-21 15:11:52.062215	t
11	TEST02-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	4	8	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308	t
12	DE01-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	9	5	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308	t
13	CA01-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	5	13	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308	t
14	US01-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	1	1	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308	t
15	EU01-AST002	Company Vehicle #1	Executive transportation vehicle	VEHICLES	2021-10-01	45000.00	33750.00	DECLINING_BALANCE	5	2	10	Corporate Garage	ACTIVE	t	2025-05-21 15:12:00.81308	2025-05-21 15:12:00.81308	t
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assets (id, asset_number, asset_class, description, company_code, cost_center, plant, location, acquisition_date, acquisition_value, accumulated_depreciation, book_value, useful_life, depreciation_key, status, created_at) FROM stdin;
\.


--
-- Data for Name: bank_statements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_statements (id, statement_number, bank_account, house_bank, company_code, statement_date, opening_balance, closing_balance, currency, status, created_at) FROM stdin;
\.


--
-- Data for Name: bank_statement_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_statement_items (id, statement_id, line_number, value_date, posting_date, amount, reference, text, partner_account, partner_name, cleared, document_number) FROM stdin;
\.


--
-- Data for Name: uom; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.uom (id, code, name, description, category, is_base, created_at, created_by, updated_at, updated_by, version, is_active, notes, active) FROM stdin;
1	KG	Kilogram	\N	weight	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
2	G	Gram	\N	weight	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
3	LB	Pound	\N	weight	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
4	M	Meter	\N	length	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
5	CM	Centimeter	\N	length	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
6	INCH	Inch	\N	length	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
7	L	Liter	\N	volume	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
8	ML	Milliliter	\N	volume	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
9	GAL	Gallon	\N	volume	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
10	EA	Each	\N	unit	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
11	PCS	Pieces	\N	unit	f	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
12	BOX	Box	\N	package	t	2025-05-17 05:55:13.089835	1	2025-05-17 05:55:13.089835	1	1	t	\N	t
13	Oz	OZ	OZ	Weight	f	2025-05-17 12:34:16.642	1	2025-05-17 12:34:16.642	1	1	t	\N	t
14	PC	Piece	Standard Piece	Count	t	2025-05-20 16:12:26.384342	\N	2025-05-20 16:12:26.384342	\N	1	t	\N	t
\.


--
-- Data for Name: materials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.materials (id, code, name, description, long_description, type, uom_id, category_id, weight, weight_uom_id, dimensions, base_unit_price, cost, min_order_qty, order_multiple, procurement_type, min_stock, max_stock, reorder_point, lead_time, shelf_life, lot_size, mrp_type, planning_policy, is_active, is_sellable, is_purchasable, is_manufactured, is_stockable, created_at, updated_at, created_by, updated_by, version, active, base_uom, status) FROM stdin;
1	RM-1001	Aluminum Sheet	High-grade aluminum sheet for industrial use	\N	RAW	1	1	1	1	{"width": "1000mm", "height": "2mm", "length": "1000mm"}	7.5	5.25	10	5	external	20	100	30	7	0	EX	reorder_point	standard	t	t	t	f	t	2025-05-20 14:36:38.689364	2025-05-20 14:36:38.689364	\N	\N	1	t	PC	active
2	RM-1002	Steel Rod	Carbon steel rod for structural applications	\N	RAW	1	1	2.5	1	{"length": "2m", "diameter": "20mm"}	8.75	6.5	10	5	external	15	80	20	5	0	EX	reorder_point	standard	t	t	t	f	t	2025-05-20 14:36:38.705246	2025-05-20 14:36:38.705246	\N	\N	1	t	PC	active
3	RM-1003	Plastic Granulate	ABS plastic granulate for injection molding	\N	RAW	1	1	1	1	{"bulk": true}	3.25	2.1	25	25	external	50	300	75	10	730	EX	reorder_point	lot_for_lot	t	f	t	f	t	2025-05-20 14:36:38.720782	2025-05-20 14:36:38.720782	\N	\N	1	t	PC	active
4	RM-1004	Copper Wire	Industrial grade copper wire	\N	RAW	4	1	0.05	1	{"diameter": "2mm"}	6.5	4.2	100	50	external	200	1000	300	15	0	EX	reorder_point	standard	t	f	t	f	t	2025-05-20 14:36:38.735852	2025-05-20 14:36:38.735852	\N	\N	1	t	PC	active
5	RM-1005	Cotton Fabric	Premium cotton fabric for textile manufacturing	\N	RAW	5	1	0.2	1	{"width": "1.5m"}	4.25	3	50	10	external	100	500	150	12	365	EX	reorder_point	standard	t	f	t	f	t	2025-05-20 14:36:38.750003	2025-05-20 14:36:38.750003	\N	\N	1	t	PC	active
6	SF-2001	Aluminum Frame	Partially assembled aluminum frame	\N	SEMI	10	1	3.2	1	{"width": "0.8m", "height": "0.1m", "length": "1.2m"}	35	22.5	5	5	in-house	10	50	15	3	0	EX	make_to_stock	lot_for_lot	t	f	f	t	t	2025-05-20 14:36:38.765285	2025-05-20 14:36:38.765285	\N	\N	1	t	PC	active
7	SF-2002	PCB Assembly	Partially assembled printed circuit board	\N	SEMI	10	1	0.15	1	{"width": "80mm", "height": "2mm", "length": "120mm"}	28.5	18	10	5	in-house	20	100	30	5	365	EX	make_to_stock	lot_for_lot	t	f	f	t	t	2025-05-20 14:36:38.779297	2025-05-20 14:36:38.779297	\N	\N	1	t	PC	active
8	SF-2003	Injection Molded Housing	Plastic housing for electronic devices	\N	SEMI	10	1	0.45	1	{"width": "150mm", "height": "50mm", "length": "200mm"}	12.75	8.5	25	25	in-house	50	250	75	2	0	EX	make_to_stock	lot_for_lot	t	f	f	t	t	2025-05-20 14:36:38.794055	2025-05-20 14:36:38.794055	\N	\N	1	t	PC	active
9	FG-3001	Smart Thermostat	IoT-enabled smart thermostat for home automation	\N	FINI	10	1	0.85	1	{"width": "80mm", "height": "35mm", "length": "120mm"}	85	45	1	1	in-house	10	50	15	7	730	EX	make_to_stock	lot_for_lot	t	t	f	t	t	2025-05-20 14:36:38.808153	2025-05-20 14:36:38.808153	\N	\N	1	t	PC	active
10	FG-3002	Industrial Control Panel	Advanced control panel for manufacturing equipment	\N	FINI	10	1	12.5	1	{"width": "450mm", "height": "200mm", "length": "600mm"}	1250	750	1	1	in-house	2	10	3	15	1825	EX	make_to_order	lot_for_lot	t	t	f	t	t	2025-05-20 14:36:38.822432	2025-05-20 14:36:38.822432	\N	\N	1	t	PC	active
11	FG-3003	LED Light Fixture	Energy-efficient LED ceiling light fixture	\N	FINI	10	1	1.8	1	{"width": "300mm", "height": "100mm", "length": "300mm"}	65	38	1	1	in-house	15	75	25	5	1825	EX	make_to_stock	lot_for_lot	t	t	f	t	t	2025-05-20 14:36:38.83712	2025-05-20 14:36:38.83712	\N	\N	1	t	PC	active
12	FG-3004	Wireless Router	High-speed wireless router for home and office	\N	FINI	10	1	0.9	1	{"width": "180mm", "height": "40mm", "length": "230mm"}	120	75	1	1	external	20	100	30	7	1095	EX	make_to_stock	standard	t	t	t	f	t	2025-05-20 14:36:38.851882	2025-05-20 14:36:38.851882	\N	\N	1	t	PC	active
13	FG-3005	Electric Motor	Industrial electric motor for manufacturing equipment	\N	FINI	10	1	35	1	{"width": "250mm", "height": "250mm", "length": "350mm"}	890	650	1	1	external	3	15	5	21	3650	EX	make_to_order	standard	t	t	t	f	t	2025-05-20 14:36:38.866115	2025-05-20 14:36:38.866115	\N	\N	1	t	PC	active
14	PM-4001	Cardboard Box - Small	Corrugated cardboard box for shipping small items	\N	PACK	10	1	0.15	1	{"width": "200mm", "height": "200mm", "length": "200mm"}	1.25	0.85	100	100	external	250	1000	350	3	365	EX	reorder_point	lot_for_lot	t	f	t	f	t	2025-05-20 14:36:38.885914	2025-05-20 14:36:38.885914	\N	\N	1	t	PC	active
16	CHEM-001	Industrial Cleaning Solution	Multi-purpose industrial cleaning solution	\N	RAW	1	1	\N	\N	\N	25.5	15.75	\N	\N	\N	10	50	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-05-20 16:14:07.491142	2025-05-20 16:14:07.491142	\N	\N	1	t	PC	active
17	TOOL-001	Precision Measurement Tool	High-accuracy digital measurement tool	\N	FINI	1	1	\N	\N	\N	199.99	125	\N	\N	\N	2	10	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-05-20 16:14:07.580166	2025-05-20 16:14:07.580166	\N	\N	1	t	PC	active
20	M8334	Test Material	\N	\N	Raw Material	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 00:51:53.472357	2025-06-05 00:51:53.472357	\N	\N	1	t	PC	active
21	TM571891	Test Material	\N	\N	Raw Material	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 01:56:12.008075	2025-06-05 01:56:12.008075	\N	\N	1	t	PC	active
22	TM716672	Test Material	\N	\N	Raw Material	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 01:58:36.771224	2025-06-05 01:58:36.771224	\N	\N	1	t	PC	active
23	TM772239	Test Material	\N	\N	Raw Material	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 01:59:32.340601	2025-06-05 01:59:32.340601	\N	\N	1	t	PC	active
24	TM792967	Test Material	\N	\N	Raw Material	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 01:59:53.041488	2025-06-05 01:59:53.041488	\N	\N	1	t	PC	active
25	TM853374	Test Material	\N	\N	Raw Material	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 02:00:53.486186	2025-06-05 02:00:53.486186	\N	\N	1	t	PC	active
26	STAB001	Stability Test Material	\N	\N	Raw Material	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 02:04:10.847496	2025-06-05 02:04:10.847496	\N	\N	1	t	PC	active
28	MAT001	Test Material 001	\N	\N	RAW	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 02:10:57.91415	2025-06-05 02:10:57.91415	\N	\N	1	t	PC	active
30	MAT1749089635928	Test Material 1749089635928	\N	\N	RAW	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 02:13:57.661978	2025-06-05 02:13:57.661978	\N	\N	1	t	PC	active
31	MAT1749089708190	Test Material 1749089708190	\N	\N	RAW	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 02:15:08.373377	2025-06-05 02:15:08.373377	\N	\N	1	t	PC	active
32	MAT1749089731713	Test Material 1749089731713	\N	\N	RAW	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 02:15:31.851197	2025-06-05 02:15:31.851197	\N	\N	1	t	PC	active
33	M1749089769754	Test Material 1749089769754	\N	\N	RAW	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 02:16:09.258961	2025-06-05 02:16:09.258961	\N	\N	1	t	PC	active
34	M1749089793928	Test Material 1749089793928	\N	\N	RAW	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	t	f	f	f	t	2025-06-05 02:16:34.142468	2025-06-05 02:16:34.142468	\N	\N	1	t	PC	active
\.


--
-- Data for Name: batch_master; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_master (id, batch_number, material_id, plant_id, production_date, expiry_date, shelf_life_days, vendor_batch_number, quality_status, available_quantity, reserved_quantity, blocked_quantity, unit_of_measure, created_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: bill_of_materials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bill_of_materials (id, code, name, material_id, description, version, is_active, created_at, updated_at, active) FROM stdin;
1	BOM-FG-3001	BOM for Smart Thermostat	9	Bill of Materials for Smart Thermostat	1.0	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
2	BOM-FG-3002	BOM for Industrial Control Panel	10	Bill of Materials for Industrial Control Panel	1.0	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
3	BOM-FG-3003	BOM for LED Light Fixture	11	Bill of Materials for LED Light Fixture	1.0	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
4	BOM-PM-4001	BOM for Cardboard Box - Small	14	Bill of materials for manufacturing Cardboard Box - Small	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118	t
5	BOM-FG-3004	BOM for Wireless Router	12	Bill of materials for manufacturing Wireless Router	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118	t
6	BOM-SF-2003	BOM for Injection Molded Housing	8	Bill of materials for manufacturing Injection Molded Housing	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118	t
7	BOM-FG-3005	BOM for Electric Motor	13	Bill of materials for manufacturing Electric Motor	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118	t
8	BOM-SF-2001	BOM for Aluminum Frame	6	Bill of materials for manufacturing Aluminum Frame	1.0	t	2025-05-21 15:13:02.975118	2025-05-21 15:13:02.975118	t
\.


--
-- Data for Name: bom_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bom_items (id, bom_id, material_id, quantity, unit_cost, is_active, created_at, updated_at, active) FROM stdin;
1	1	1	5.850	24.95	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
2	2	1	13.890	12.59	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
3	3	1	10.720	12.07	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
4	1	2	11.780	38.61	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
5	2	2	14.810	58.75	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
6	3	2	5.700	36.81	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
7	1	3	11.460	12.73	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
8	2	3	5.100	36.66	t	2025-05-20 22:09:48.919983	2025-05-20 22:09:48.919983	t
9	1	4	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
10	1	5	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
11	1	6	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
12	1	7	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
13	1	8	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
14	1	10	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
15	1	11	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
16	1	12	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
17	1	13	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
18	1	14	3.500	12.50	t	2025-05-21 15:13:22.453554	2025-05-21 15:13:22.453554	t
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, description, user_id, created_at, updated_at, active) FROM stdin;
1	General	General category for materials	\N	2025-05-20 14:35:23.847433	2025-05-20 14:35:23.847433	t
\.


--
-- Data for Name: change_document_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_document_analytics (id, analysis_date, object_class, application_module, total_changes, creates_count, updates_count, deletes_count, avg_fields_changed, avg_approval_time, avg_processing_time, error_count, reversal_count, quality_score, high_impact_changes, compliance_changes, emergency_changes, created_at) FROM stdin;
1	2025-06-03	COMPANY_CODE	MASTER_DATA	0	0	0	0	0.00	\N	\N	0	0	100.00	0	0	0	2025-06-04 23:31:25.028103+00
2	2025-06-03	CUSTOMER	MASTER_DATA	0	0	0	0	0.00	\N	\N	0	0	100.00	0	0	0	2025-06-04 23:31:25.028103+00
3	2025-06-03	MATERIAL	MASTER_DATA	0	0	0	0	0.00	\N	\N	0	0	100.00	0	0	0	2025-06-04 23:31:25.028103+00
4	2025-06-03	SALES_ORDER	SALES	0	0	0	0	0.00	\N	\N	0	0	100.00	0	0	0	2025-06-04 23:31:25.028103+00
5	2025-06-03	PURCHASE_ORDER	PURCHASE	0	0	0	0	0.00	\N	\N	0	0	100.00	0	0	0	2025-06-04 23:31:25.028103+00
\.


--
-- Data for Name: change_document_headers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_document_headers (id, change_document_id, object_class, object_id, change_number, user_name, user_role, session_id, transaction_code, change_type, change_reason, change_category, change_date, change_time, change_timestamp, client_ip, user_agent, application_module, business_process, reference_document, approval_status, version_number, parent_change_id, is_active, is_reversed, reversal_change_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: change_document_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_document_approvals (id, change_document_id, approval_level, approver_role, approver_name, approval_status, approval_comments, approval_timestamp, delegation_to, created_at) FROM stdin;
\.


--
-- Data for Name: change_document_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_document_attachments (id, change_document_id, attachment_type, file_name, file_path, file_size, mime_type, description, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: change_document_positions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_document_positions (id, change_document_id, position_number, table_name, field_name, field_label, data_type, old_value, new_value, old_value_formatted, new_value_formatted, value_unit, value_currency, value_language, change_indicator, change_magnitude, change_percentage, reference_table, reference_field, reference_value, data_quality_score, validation_status, validation_errors, business_impact, requires_approval, compliance_flag, created_at) FROM stdin;
\.


--
-- Data for Name: change_document_relations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_document_relations (id, source_change_id, target_change_id, relation_type, relation_strength, business_context, created_at) FROM stdin;
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_of_accounts (id, chart_id, description, account_length, maintenance_language, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clearing_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clearing_configurations (id, company_code, account_type, gl_account, tolerance_group, sort_criteria, active, created_at) FROM stdin;
\.


--
-- Data for Name: clearing_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clearing_items (id, clearing_number, company_code, account_number, document_number, line_item, amount, currency, clearing_date, created_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, company_id, name, address, country, currency, language, active, created_at, updated_at) FROM stdin;
1	GLOBL	Global Holdings	123 Business Center, New York, NY 10001	US	USD	EN	t	2025-06-04 19:55:50.088678+00	2025-06-04 19:55:50.088678+00
\.


--
-- Data for Name: company_code_chart_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_code_chart_assignments (id, company_code_id, chart_of_accounts_id, fiscal_year_variant_id, assigned_date, is_active, created_at, active, updated_at) FROM stdin;
1	1	39	1	2025-06-04 02:39:58.298261	t	2025-06-04 02:39:58.298261	t	2025-06-04 18:39:27.994297+00
\.


--
-- Data for Name: profit_centers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profit_centers (id, profit_center, description, profit_center_group, company_code, controlling_area, segment, hierarchy_area, responsible_person, valid_from, valid_to, created_at, company_code_id, plant_id, responsible_person_id, active, updated_at) FROM stdin;
1	PC001	Manufacturing Division	PRODUCTION	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
2	PC001-01	Product Line A	PRODUCTION	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
3	PC001-02	Product Line B	PRODUCTION	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
4	PC001-03	Custom Products	PRODUCTION	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
5	PC002	Sales Division	SALES	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
6	PC002-01	Domestic Sales	SALES	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
7	PC002-02	Export Sales	SALES	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
8	PC002-03	Online Sales	SALES	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
9	PC003	Service Division	SERVICE	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
10	PC003-01	Maintenance Services	SERVICE	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
11	PC003-02	Consulting Services	SERVICE	US01	US01	\N	\N	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	1	\N	\N	t	2025-06-04 18:39:30.325742+00
12	PC-PROD-A	Product Line A - Main product profitability	PRODUCT_LINE	US01	US01	\N	\N	John Smith	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
13	PC-PROD-B	Product Line B - Secondary product line	PRODUCT_LINE	US01	US01	\N	\N	Jane Doe	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
14	PC-SERV	Service Division - Service and maintenance revenue	DIVISION	US01	US01	\N	\N	Mike Johnson	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
15	PC-REG-E	Eastern Region - East coast sales region	REGION	US01	US01	\N	\N	Sarah Davis	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
16	PC-REG-W	Western Region - West coast sales region	REGION	US01	US01	\N	\N	Tom Brown	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
17	PC-REG-C	Central Region - Central US sales region	REGION	US01	US01	\N	\N	Lisa Garcia	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
18	PC-EXPORT	Export Division - International sales and exports	DIVISION	US01	US01	\N	\N	David Miller	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
19	PC-RETAIL	Retail Channel - Direct retail sales	CHANNEL	US01	US01	\N	\N	Chris Lee	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
20	PC-WHSALE	Wholesale Channel - Wholesale and distribution	CHANNEL	US01	US01	\N	\N	Emily Chen	2025-01-01	\N	2025-06-04 02:39:51.210528	1	\N	\N	t	2025-06-04 18:39:30.325742+00
\.


--
-- Data for Name: copa_actuals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.copa_actuals (id, operating_concern, fiscal_year, period, record_type, customer, material, product_group, customer_group, sales_organization, distribution_channel, division, region, country, profit_center, value_field, amount, quantity, currency, unit_of_measure, posting_date, document_number, created_at, customer_id, material_id, profit_center_id, sales_org_id, company_code_id, currency_id, active, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_allocations (id, allocation_id, allocation_type, sender_object_type, sender_object, receiver_object_type, receiver_object, fiscal_year, period, allocation_base, percentage, amount, currency, posting_date, created_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_centers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_centers (id, cost_center, description, cost_center_category, company_code, controlling_area, hierarchy_area, responsible_person, valid_from, valid_to, created_at, updated_at, company_code_id, plant_id, responsible_person_id, active) FROM stdin;
1	CC001	Manufacturing Line 1	PRODUCTION	US01	US01	PRODUCTION	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
2	CC002	Manufacturing Line 2	PRODUCTION	US01	US01	PRODUCTION	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
3	CC003	Quality Control	PRODUCTION	US01	US01	PRODUCTION	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
4	CC101	Human Resources	ADMINISTRATIVE	US01	US01	ADMIN	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
5	CC102	IT Department	SERVICE	US01	US01	ADMIN	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
6	CC103	Finance Department	ADMINISTRATIVE	US01	US01	ADMIN	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
7	CC201	Sales North	SALES	US01	US01	SALES	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
8	CC202	Sales South	SALES	US01	US01	SALES	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
9	CC203	Sales International	SALES	US01	US01	SALES	\N	2025-06-03	\N	2025-06-03 17:58:50.654812	2025-06-03 17:58:50.654812	1	\N	\N	t
11	PROD001	Production Line 1 - Manufacturing line for main products	PRODUCTION	US01	US01	\N	John Smith	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
12	PROD002	Production Line 2 - Secondary manufacturing line	PRODUCTION	US01	US01	\N	Jane Doe	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
13	QC001	Quality Control - Quality assurance and testing	QUALITY	US01	US01	\N	Mike Johnson	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
14	MAINT001	Maintenance - Equipment maintenance and repairs	MAINTENANCE	US01	US01	\N	Bob Wilson	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
15	ADMIN001	Administration - General administrative functions	ADMIN	US01	US01	\N	Sarah Davis	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
16	SALES001	Sales Department - Sales and customer relations	SALES	US01	US01	\N	Tom Brown	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
17	MKTG001	Marketing - Marketing and advertising	MARKETING	US01	US01	\N	Lisa Garcia	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
18	HR001	Human Resources - HR administration and payroll	HR	US01	US01	\N	David Miller	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
19	IT001	Information Technology - IT support and infrastructure	IT	US01	US01	\N	Chris Lee	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
20	WHSE001	Warehouse Operations - Inventory and logistics	WAREHOUSE	US01	US01	\N	Emily Chen	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
21	PURCH001	Purchasing Department - Procurement and vendor management	PURCHASING	US01	US01	\N	Mark Wilson	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
22	FIN001	Finance Department - Financial planning and accounting	FINANCE	US01	US01	\N	Jennifer Brown	2025-01-01	\N	2025-06-04 02:39:01.679531	2025-06-04 02:39:01.679531	1	\N	\N	t
\.


--
-- Data for Name: cost_center_actuals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_center_actuals (id, cost_center, fiscal_year, period, account, activity_type, actual_amount, actual_quantity, currency, unit_of_measure, posting_date, document_number, reference, created_at, cost_center_id, company_code_id, currency_id, active, updated_at) FROM stdin;
73	CC001	2025	6	400000	\N	15458.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.655769	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
74	CC001	2025	6	410000	\N	6496.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.655769	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
75	CC001	2025	6	420000	\N	4239.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.655769	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
76	CC002	2025	6	400000	\N	12745.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.681496	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
77	CC002	2025	6	410000	\N	5217.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.681496	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
78	CC002	2025	6	420000	\N	4493.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.681496	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
79	CC003	2025	6	400000	\N	12433.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.700578	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
80	CC003	2025	6	410000	\N	5814.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.700578	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
81	CC003	2025	6	420000	\N	4665.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.700578	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
82	CC101	2025	6	400000	\N	12661.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.719733	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
83	CC101	2025	6	410000	\N	5950.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.719733	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
84	CC101	2025	6	420000	\N	3854.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.719733	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
85	CC102	2025	6	400000	\N	11254.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.738956	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
86	CC102	2025	6	410000	\N	5562.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.738956	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
87	CC102	2025	6	420000	\N	4225.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.738956	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
88	CC103	2025	6	400000	\N	12331.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.757979	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
89	CC103	2025	6	410000	\N	5990.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.757979	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
90	CC103	2025	6	420000	\N	3248.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.757979	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
91	CC201	2025	6	400000	\N	13570.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.776904	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
92	CC201	2025	6	410000	\N	5203.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.776904	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
93	CC201	2025	6	420000	\N	3285.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.776904	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
94	CC202	2025	6	400000	\N	13551.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.796299	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
95	CC202	2025	6	410000	\N	6018.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.796299	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
96	CC202	2025	6	420000	\N	4622.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.796299	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
97	CC203	2025	6	400000	\N	13779.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.815951	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
98	CC203	2025	6	410000	\N	5969.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.815951	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
99	CC203	2025	6	420000	\N	4124.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.815951	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
100	PROD001	2025	6	400000	\N	14128.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.834899	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
101	PROD001	2025	6	410000	\N	6719.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.834899	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
102	PROD001	2025	6	420000	\N	4275.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.834899	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
103	PROD002	2025	6	400000	\N	11436.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.854024	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
104	PROD002	2025	6	410000	\N	4838.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.854024	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
105	PROD002	2025	6	420000	\N	3207.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.854024	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
106	QC001	2025	6	400000	\N	17617.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.87299	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
107	QC001	2025	6	410000	\N	5227.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.87299	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
108	QC001	2025	6	420000	\N	4378.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.87299	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
109	MAINT001	2025	6	400000	\N	14777.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.892291	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
110	MAINT001	2025	6	410000	\N	4942.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.892291	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
111	MAINT001	2025	6	420000	\N	4167.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.892291	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
112	ADMIN001	2025	6	400000	\N	16667.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.911419	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
113	ADMIN001	2025	6	410000	\N	5882.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.911419	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
114	ADMIN001	2025	6	420000	\N	3381.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.911419	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
115	SALES001	2025	6	400000	\N	11242.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.930376	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
116	SALES001	2025	6	410000	\N	4897.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.930376	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
117	SALES001	2025	6	420000	\N	4373.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.930376	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
118	MKTG001	2025	6	400000	\N	14653.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.949313	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
119	MKTG001	2025	6	410000	\N	5983.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.949313	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
120	MKTG001	2025	6	420000	\N	4271.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.949313	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
121	HR001	2025	6	400000	\N	16021.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.968249	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
122	HR001	2025	6	410000	\N	6506.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.968249	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
123	HR001	2025	6	420000	\N	4061.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.968249	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
124	IT001	2025	6	400000	\N	12825.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.98889	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
125	IT001	2025	6	410000	\N	4983.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.98889	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
126	IT001	2025	6	420000	\N	3086.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:46.98889	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
127	WHSE001	2025	6	400000	\N	12759.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.007928	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
128	WHSE001	2025	6	410000	\N	5878.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.007928	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
129	WHSE001	2025	6	420000	\N	3668.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.007928	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
130	PURCH001	2025	6	400000	\N	12884.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.027	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
131	PURCH001	2025	6	410000	\N	6815.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.027	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
132	PURCH001	2025	6	420000	\N	3939.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.027	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
133	FIN001	2025	6	400000	\N	16354.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.046322	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
134	FIN001	2025	6	410000	\N	6939.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.046322	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
135	FIN001	2025	6	420000	\N	4041.00	0.000	USD	\N	2025-06-01	\N	\N	2025-06-04 03:47:47.046322	\N	\N	\N	t	2025-06-04 18:39:28.246449+00
\.


--
-- Data for Name: cost_center_planning; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_center_planning (id, cost_center, fiscal_year, period, version, account, activity_type, planned_amount, planned_quantity, currency, unit_of_measure, created_by, created_at, active, updated_at) FROM stdin;
76	CC001	2025	6	000	400000	\N	17842.00	0.000	USD	\N	\N	2025-06-04 03:47:46.209456	t	2025-06-04 18:39:28.306507+00
77	CC001	2025	6	000	410000	\N	5563.00	0.000	USD	\N	\N	2025-06-04 03:47:46.209456	t	2025-06-04 18:39:28.306507+00
78	CC001	2025	6	000	420000	\N	4055.00	0.000	USD	\N	\N	2025-06-04 03:47:46.209456	t	2025-06-04 18:39:28.306507+00
79	CC002	2025	6	000	400000	\N	18925.00	0.000	USD	\N	\N	2025-06-04 03:47:46.230534	t	2025-06-04 18:39:28.306507+00
80	CC002	2025	6	000	410000	\N	5017.00	0.000	USD	\N	\N	2025-06-04 03:47:46.230534	t	2025-06-04 18:39:28.306507+00
81	CC002	2025	6	000	420000	\N	3302.00	0.000	USD	\N	\N	2025-06-04 03:47:46.230534	t	2025-06-04 18:39:28.306507+00
82	CC003	2025	6	000	400000	\N	18392.00	0.000	USD	\N	\N	2025-06-04 03:47:46.249348	t	2025-06-04 18:39:28.306507+00
83	CC003	2025	6	000	410000	\N	6902.00	0.000	USD	\N	\N	2025-06-04 03:47:46.249348	t	2025-06-04 18:39:28.306507+00
84	CC003	2025	6	000	420000	\N	3241.00	0.000	USD	\N	\N	2025-06-04 03:47:46.249348	t	2025-06-04 18:39:28.306507+00
85	CC101	2025	6	000	400000	\N	14712.00	0.000	USD	\N	\N	2025-06-04 03:47:46.268569	t	2025-06-04 18:39:28.306507+00
86	CC101	2025	6	000	410000	\N	5501.00	0.000	USD	\N	\N	2025-06-04 03:47:46.268569	t	2025-06-04 18:39:28.306507+00
87	CC101	2025	6	000	420000	\N	3737.00	0.000	USD	\N	\N	2025-06-04 03:47:46.268569	t	2025-06-04 18:39:28.306507+00
88	CC102	2025	6	000	400000	\N	13910.00	0.000	USD	\N	\N	2025-06-04 03:47:46.288525	t	2025-06-04 18:39:28.306507+00
89	CC102	2025	6	000	410000	\N	5501.00	0.000	USD	\N	\N	2025-06-04 03:47:46.288525	t	2025-06-04 18:39:28.306507+00
90	CC102	2025	6	000	420000	\N	3805.00	0.000	USD	\N	\N	2025-06-04 03:47:46.288525	t	2025-06-04 18:39:28.306507+00
91	CC103	2025	6	000	400000	\N	12115.00	0.000	USD	\N	\N	2025-06-04 03:47:46.307972	t	2025-06-04 18:39:28.306507+00
92	CC103	2025	6	000	410000	\N	5136.00	0.000	USD	\N	\N	2025-06-04 03:47:46.307972	t	2025-06-04 18:39:28.306507+00
93	CC103	2025	6	000	420000	\N	4658.00	0.000	USD	\N	\N	2025-06-04 03:47:46.307972	t	2025-06-04 18:39:28.306507+00
94	CC201	2025	6	000	400000	\N	15398.00	0.000	USD	\N	\N	2025-06-04 03:47:46.328525	t	2025-06-04 18:39:28.306507+00
95	CC201	2025	6	000	410000	\N	7382.00	0.000	USD	\N	\N	2025-06-04 03:47:46.328525	t	2025-06-04 18:39:28.306507+00
96	CC201	2025	6	000	420000	\N	4363.00	0.000	USD	\N	\N	2025-06-04 03:47:46.328525	t	2025-06-04 18:39:28.306507+00
97	CC202	2025	6	000	400000	\N	14957.00	0.000	USD	\N	\N	2025-06-04 03:47:46.351233	t	2025-06-04 18:39:28.306507+00
98	CC202	2025	6	000	410000	\N	5501.00	0.000	USD	\N	\N	2025-06-04 03:47:46.351233	t	2025-06-04 18:39:28.306507+00
99	CC202	2025	6	000	420000	\N	3547.00	0.000	USD	\N	\N	2025-06-04 03:47:46.351233	t	2025-06-04 18:39:28.306507+00
100	CC203	2025	6	000	400000	\N	18233.00	0.000	USD	\N	\N	2025-06-04 03:47:46.370862	t	2025-06-04 18:39:28.306507+00
101	CC203	2025	6	000	410000	\N	7605.00	0.000	USD	\N	\N	2025-06-04 03:47:46.370862	t	2025-06-04 18:39:28.306507+00
102	CC203	2025	6	000	420000	\N	4669.00	0.000	USD	\N	\N	2025-06-04 03:47:46.370862	t	2025-06-04 18:39:28.306507+00
103	PROD001	2025	6	000	400000	\N	13597.00	0.000	USD	\N	\N	2025-06-04 03:47:46.389604	t	2025-06-04 18:39:28.306507+00
104	PROD001	2025	6	000	410000	\N	5406.00	0.000	USD	\N	\N	2025-06-04 03:47:46.389604	t	2025-06-04 18:39:28.306507+00
105	PROD001	2025	6	000	420000	\N	4078.00	0.000	USD	\N	\N	2025-06-04 03:47:46.389604	t	2025-06-04 18:39:28.306507+00
106	PROD002	2025	6	000	400000	\N	15111.00	0.000	USD	\N	\N	2025-06-04 03:47:46.40845	t	2025-06-04 18:39:28.306507+00
107	PROD002	2025	6	000	410000	\N	6545.00	0.000	USD	\N	\N	2025-06-04 03:47:46.40845	t	2025-06-04 18:39:28.306507+00
108	PROD002	2025	6	000	420000	\N	4268.00	0.000	USD	\N	\N	2025-06-04 03:47:46.40845	t	2025-06-04 18:39:28.306507+00
109	QC001	2025	6	000	400000	\N	18547.00	0.000	USD	\N	\N	2025-06-04 03:47:46.427524	t	2025-06-04 18:39:28.306507+00
110	QC001	2025	6	000	410000	\N	7379.00	0.000	USD	\N	\N	2025-06-04 03:47:46.427524	t	2025-06-04 18:39:28.306507+00
111	QC001	2025	6	000	420000	\N	4779.00	0.000	USD	\N	\N	2025-06-04 03:47:46.427524	t	2025-06-04 18:39:28.306507+00
112	MAINT001	2025	6	000	400000	\N	14610.00	0.000	USD	\N	\N	2025-06-04 03:47:46.44636	t	2025-06-04 18:39:28.306507+00
113	MAINT001	2025	6	000	410000	\N	5918.00	0.000	USD	\N	\N	2025-06-04 03:47:46.44636	t	2025-06-04 18:39:28.306507+00
114	MAINT001	2025	6	000	420000	\N	4384.00	0.000	USD	\N	\N	2025-06-04 03:47:46.44636	t	2025-06-04 18:39:28.306507+00
115	ADMIN001	2025	6	000	400000	\N	14995.00	0.000	USD	\N	\N	2025-06-04 03:47:46.4653	t	2025-06-04 18:39:28.306507+00
116	ADMIN001	2025	6	000	410000	\N	5449.00	0.000	USD	\N	\N	2025-06-04 03:47:46.4653	t	2025-06-04 18:39:28.306507+00
117	ADMIN001	2025	6	000	420000	\N	3547.00	0.000	USD	\N	\N	2025-06-04 03:47:46.4653	t	2025-06-04 18:39:28.306507+00
118	SALES001	2025	6	000	400000	\N	15655.00	0.000	USD	\N	\N	2025-06-04 03:47:46.484297	t	2025-06-04 18:39:28.306507+00
119	SALES001	2025	6	000	410000	\N	5067.00	0.000	USD	\N	\N	2025-06-04 03:47:46.484297	t	2025-06-04 18:39:28.306507+00
120	SALES001	2025	6	000	420000	\N	3466.00	0.000	USD	\N	\N	2025-06-04 03:47:46.484297	t	2025-06-04 18:39:28.306507+00
121	MKTG001	2025	6	000	400000	\N	16753.00	0.000	USD	\N	\N	2025-06-04 03:47:46.503356	t	2025-06-04 18:39:28.306507+00
122	MKTG001	2025	6	000	410000	\N	5081.00	0.000	USD	\N	\N	2025-06-04 03:47:46.503356	t	2025-06-04 18:39:28.306507+00
123	MKTG001	2025	6	000	420000	\N	4975.00	0.000	USD	\N	\N	2025-06-04 03:47:46.503356	t	2025-06-04 18:39:28.306507+00
124	HR001	2025	6	000	400000	\N	17167.00	0.000	USD	\N	\N	2025-06-04 03:47:46.522386	t	2025-06-04 18:39:28.306507+00
125	HR001	2025	6	000	410000	\N	6228.00	0.000	USD	\N	\N	2025-06-04 03:47:46.522386	t	2025-06-04 18:39:28.306507+00
126	HR001	2025	6	000	420000	\N	3479.00	0.000	USD	\N	\N	2025-06-04 03:47:46.522386	t	2025-06-04 18:39:28.306507+00
127	IT001	2025	6	000	400000	\N	12315.00	0.000	USD	\N	\N	2025-06-04 03:47:46.542082	t	2025-06-04 18:39:28.306507+00
128	IT001	2025	6	000	410000	\N	6723.00	0.000	USD	\N	\N	2025-06-04 03:47:46.542082	t	2025-06-04 18:39:28.306507+00
129	IT001	2025	6	000	420000	\N	3600.00	0.000	USD	\N	\N	2025-06-04 03:47:46.542082	t	2025-06-04 18:39:28.306507+00
130	WHSE001	2025	6	000	400000	\N	17339.00	0.000	USD	\N	\N	2025-06-04 03:47:46.561664	t	2025-06-04 18:39:28.306507+00
131	WHSE001	2025	6	000	410000	\N	6535.00	0.000	USD	\N	\N	2025-06-04 03:47:46.561664	t	2025-06-04 18:39:28.306507+00
132	WHSE001	2025	6	000	420000	\N	4338.00	0.000	USD	\N	\N	2025-06-04 03:47:46.561664	t	2025-06-04 18:39:28.306507+00
133	PURCH001	2025	6	000	400000	\N	17253.00	0.000	USD	\N	\N	2025-06-04 03:47:46.580983	t	2025-06-04 18:39:28.306507+00
134	PURCH001	2025	6	000	410000	\N	6565.00	0.000	USD	\N	\N	2025-06-04 03:47:46.580983	t	2025-06-04 18:39:28.306507+00
135	PURCH001	2025	6	000	420000	\N	3441.00	0.000	USD	\N	\N	2025-06-04 03:47:46.580983	t	2025-06-04 18:39:28.306507+00
136	FIN001	2025	6	000	400000	\N	16024.00	0.000	USD	\N	\N	2025-06-04 03:47:46.60021	t	2025-06-04 18:39:28.306507+00
137	FIN001	2025	6	000	410000	\N	5831.00	0.000	USD	\N	\N	2025-06-04 03:47:46.60021	t	2025-06-04 18:39:28.306507+00
138	FIN001	2025	6	000	420000	\N	3808.00	0.000	USD	\N	\N	2025-06-04 03:47:46.60021	t	2025-06-04 18:39:28.306507+00
\.


--
-- Data for Name: cost_elements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_elements (id, cost_element_code, cost_element_name, cost_element_type, gl_account, cost_center, description, active, created_at, updated_at) FROM stdin;
1	CE001	Direct Labor	PRIMARY	620000	\N	Direct labor costs for production	t	2025-06-05 17:02:08.417912+00	2025-06-05 17:02:08.417912+00
2	CE002	Indirect Labor	SECONDARY	621000	\N	Indirect labor and overhead costs	t	2025-06-05 17:02:08.417912+00	2025-06-05 17:02:08.417912+00
3	CE003	Material Costs	PRIMARY	500000	\N	Raw material and component costs	t	2025-06-05 17:02:08.417912+00	2025-06-05 17:02:08.417912+00
4	CE004	Machine Depreciation	SECONDARY	650000	\N	Equipment depreciation costs	t	2025-06-05 17:02:08.417912+00	2025-06-05 17:02:08.417912+00
5	CE005	Utilities	SECONDARY	640000	\N	Electricity, water, gas costs	t	2025-06-05 17:02:08.417912+00	2025-06-05 17:02:08.417912+00
6	CE006	Maintenance	SECONDARY	630000	\N	Equipment maintenance and repair	t	2025-06-05 17:02:08.417912+00	2025-06-05 17:02:08.417912+00
7	CE007	Quality Control	SECONDARY	625000	\N	Quality assurance activities	t	2025-06-05 17:02:08.417912+00	2025-06-05 17:02:08.417912+00
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.regions (id, code, name, description, is_active, created_at, updated_at, active) FROM stdin;
1	NA	North America	United States, Canada, and Mexico	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
2	SA	South America	South American countries	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
3	EMEA	Europe, Middle East, and Africa	Europe, Middle East, and Africa regions	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
4	APAC	Asia Pacific	Asia, Australia, and Pacific Islands	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.countries (id, code, name, region_id, currency_code, language_code, is_active, created_at, updated_at, active) FROM stdin;
1	MX	Mexico	1	MXN	es-MX	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
2	CA	Canada	1	CAD	en-CA	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
3	US	United States	1	USD	en-US	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
4	AR	Argentina	2	ARS	es-AR	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
5	BR	Brazil	2	BRL	pt-BR	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
6	FR	France	3	EUR	fr-FR	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
7	DE	Germany	3	EUR	de-DE	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
8	GB	United Kingdom	3	GBP	en-GB	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
9	AU	Australia	4	AUD	en-AU	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
10	IN	India	4	INR	en-IN	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
11	CN	China	4	CNY	zh-CN	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
12	JP	Japan	4	JPY	ja-JP	t	2025-05-20 22:09:35.140169	2025-05-20 22:09:35.140169	t
\.


--
-- Data for Name: credit_control_areas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_control_areas (id, code, name, description, company_code_id, credit_checking_group, credit_period, grace_percentage, blocking_reason, review_frequency, currency, credit_approver, status, is_active, notes, created_at, updated_at, created_by, updated_by, active) FROM stdin;
1	CC001	North America Credit	Credit control for North American customers	2	medium_risk	30	15	\N	monthly	USD	Michael Brown	active	t	\N	2025-05-17 14:59:22.779157	2025-05-17 14:59:22.779157	\N	\N	t
2	CC002	EMEA Credit	Credit control for European, Middle Eastern, and African customers	2	high_risk	45	10	\N	monthly	EUR	Emma Schmidt	active	t	\N	2025-05-17 14:59:22.779157	2025-05-17 14:59:22.779157	\N	\N	t
3	CC003	APAC Credit	Credit control for Asia-Pacific customers	2	low_risk	60	5	\N	monthly	USD	James Wong	active	t	\N	2025-05-17 14:59:22.779157	2025-05-17 14:59:22.779157	\N	\N	t
4	CC004	Strategic Customers	Strategic Customers - Credit control for VIP customers	1	VIP	60	15	\N	monthly	USD	\N	active	t	\N	2025-05-20 04:52:27.962894	2025-05-20 04:52:27.962894	\N	\N	t
5	CC005	UK Credit Management	UK Credit Management - Credit control for standard customers	11	standard	30	5	\N	monthly	GBP	\N	active	t	\N	2025-05-20 04:52:28.006898	2025-05-20 04:52:28.006898	\N	\N	t
\.


--
-- Data for Name: currency_valuations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.currency_valuations (id, company_code, valuation_date, currency, exchange_rate, valuation_method, gl_account, valuation_difference, status, created_at) FROM stdin;
\.


--
-- Data for Name: custom_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_reports (id, name, description, sql_query, chart_config, parameters, category, is_shared, created_by, created_at, updated_at, active) FROM stdin;
1	Sales by Month	Monthly sales revenue analysis	SELECT DATE_TRUNC('month', order_date) as month, SUM(total_amount) as revenue FROM sales_orders WHERE order_date >= NOW() - INTERVAL '12 months' GROUP BY month ORDER BY month	{"type": "line", "title": "Sales Revenue by Month", "xLabel": "Month", "yLabel": "Revenue"}	[]	sales	f	system	2025-06-04 15:23:51.126114	2025-06-04 15:23:51.126114	t
2	Top Customers by Revenue	Customers with highest revenue contribution	SELECT c.name as customer_name, SUM(so.total_amount) as total_revenue FROM customers c JOIN sales_orders so ON c.id = so.customer_id GROUP BY c.id, c.name ORDER BY total_revenue DESC LIMIT 10	{"type": "bar", "title": "Top 10 Customers by Revenue", "xLabel": "Customer", "yLabel": "Revenue"}	[]	sales	f	system	2025-06-04 15:23:51.126114	2025-06-04 15:23:51.126114	t
3	Inventory Levels by Category	Current inventory levels grouped by material category	SELECT cat.name as category, SUM(inv.quantity) as total_quantity FROM inventory inv JOIN materials m ON inv.material_id = m.id JOIN categories cat ON m.category_id = cat.id GROUP BY cat.id, cat.name ORDER BY total_quantity DESC	{"type": "pie", "title": "Inventory Distribution by Category"}	[]	inventory	f	system	2025-06-04 15:23:51.126114	2025-06-04 15:23:51.126114	t
4	Cost Center Expenses	Expenses by cost center for current year	SELECT cc.name as cost_center, SUM(e.amount) as total_expenses FROM cost_centers cc LEFT JOIN expenses e ON cc.id = e.cost_center_id WHERE EXTRACT(YEAR FROM e.expense_date) = EXTRACT(YEAR FROM NOW()) GROUP BY cc.id, cc.name ORDER BY total_expenses DESC	{"type": "column", "title": "Expenses by Cost Center", "xLabel": "Cost Center", "yLabel": "Amount"}	[]	finance	f	system	2025-06-04 15:23:51.126114	2025-06-04 15:23:51.126114	t
5	Purchase Orders by Vendor	Purchase order volumes by vendor	SELECT v.name as vendor_name, COUNT(po.id) as order_count, SUM(po.total_amount) as total_amount FROM vendors v JOIN purchase_orders po ON v.id = po.vendor_id GROUP BY v.id, v.name ORDER BY total_amount DESC LIMIT 15	{"type": "stacked_bar", "title": "Purchase Orders by Vendor", "xLabel": "Vendor", "yLabel": "Count/Amount"}	[]	purchase	f	system	2025-06-04 15:23:51.126114	2025-06-04 15:23:51.126114	t
\.


--
-- Data for Name: customer_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_contacts (id, customer_id, first_name, last_name, "position", department, email, phone, mobile, is_primary, is_billing, is_shipping, is_technical, is_marketing, preferred_language, notes, is_active, created_at, updated_at, created_by, updated_by, active) FROM stdin;
1	1	Jessica	Brown	Operations Manager	Operations	jessica.brown@example.com	(555) 456-7890	(555) 654-3210	t	f	f	f	f	English	\N	t	2025-05-22 13:33:12.979	2025-05-22 13:33:12.979	\N	\N	t
2	1	John	Smith	Purchasing Manager	Procurement	john.smith@example.com	(555) 123-4567	(555) 987-6543	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.026	2025-05-22 13:33:13.026	\N	\N	t
3	1	Michael	Williams	CEO	Executive	michael.williams@example.com	(555) 345-6789	(555) 765-4321	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.069	2025-05-22 13:33:13.069	\N	\N	t
4	2	Jessica	Brown	Operations Manager	Operations	jessica.brown@example.com	(555) 456-7890	(555) 654-3210	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.123	2025-05-22 13:33:13.123	\N	\N	t
5	3	Michael	Williams	CEO	Executive	michael.williams@example.com	(555) 345-6789	(555) 765-4321	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.176	2025-05-22 13:33:13.176	\N	\N	t
6	3	Jessica	Brown	Operations Manager	Operations	jessica.brown@example.com	(555) 456-7890	(555) 654-3210	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.229	2025-05-22 13:33:13.229	\N	\N	t
7	3	John	Smith	Purchasing Manager	Procurement	john.smith@example.com	(555) 123-4567	(555) 987-6543	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.269	2025-05-22 13:33:13.269	\N	\N	t
8	4	Sarah	Johnson	Finance Director	Finance	sarah.johnson@example.com	(555) 234-5678	(555) 876-5432	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.306	2025-05-22 13:33:13.306	\N	\N	t
9	4	Sarah	Johnson	Finance Director	Finance	sarah.johnson@example.com	(555) 234-5678	(555) 876-5432	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.354	2025-05-22 13:33:13.354	\N	\N	t
10	5	Michael	Williams	CEO	Executive	michael.williams@example.com	(555) 345-6789	(555) 765-4321	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.393	2025-05-22 13:33:13.393	\N	\N	t
11	5	Michael	Williams	CEO	Executive	michael.williams@example.com	(555) 345-6789	(555) 765-4321	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.437	2025-05-22 13:33:13.437	\N	\N	t
12	5	Michael	Williams	CEO	Executive	michael.williams@example.com	(555) 345-6789	(555) 765-4321	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.473	2025-05-22 13:33:13.473	\N	\N	t
\.


--
-- Data for Name: dashboard_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_configs (id, user_id, config, created_at, active, updated_at) FROM stdin;
1	1	{"widgets": [{"id": "custom-widget-1748008057711", "type": "kpi", "title": "quotes Key Metrics", "width": 1, "position": 1}]}	2025-05-23 13:47:27.063425+00	t	2025-06-04 18:39:28.8052+00
2	1	{"widgets": []}	2025-05-23 13:47:51.571587+00	t	2025-06-04 18:39:28.8052+00
3	1	{"widgets": [{"id": "custom-widget-1748008102822", "type": "table", "title": "stock Summary", "width": 1, "position": 1}]}	2025-05-23 13:48:12.006036+00	t	2025-06-04 18:39:28.8052+00
4	1	{"widgets": []}	2025-05-23 13:52:34.618065+00	t	2025-06-04 18:39:28.8052+00
5	1	{"widgets": [{"id": "custom-widget-1748008386790", "type": "table", "title": "Expenses Summary", "width": 1, "position": 1}]}	2025-05-23 13:52:55.991037+00	t	2025-06-04 18:39:28.8052+00
6	1	{"widgets": [{"id": "custom-widget-1748008386790", "type": "table", "title": "Expenses Summary", "width": 1, "position": 1}, {"id": "custom-widget-1748008427350", "type": "line-chart", "title": "capacity Trend", "width": 2, "position": 2}]}	2025-05-23 13:53:36.644814+00	t	2025-06-04 18:39:28.8052+00
7	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 1}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 2}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 3}]}	2025-05-23 14:54:12.045456+00	t	2025-06-04 18:39:28.8052+00
8	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 1}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 2}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 3}]}	2025-05-23 14:54:27.164226+00	t	2025-06-04 18:39:28.8052+00
9	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:22:53.397393+00	t	2025-06-04 18:39:28.8052+00
10	1	{"widgets": [{"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 0}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:22:58.232958+00	t	2025-06-04 18:39:28.8052+00
11	1	{"widgets": [{"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 0}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 1}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:23:52.777618+00	t	2025-06-04 18:39:28.8052+00
12	1	{"widgets": [{"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 0}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:24:12.051902+00	t	2025-06-04 18:39:28.8052+00
13	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:28:50.914169+00	t	2025-06-04 18:39:28.8052+00
14	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:34:35.768835+00	t	2025-06-04 18:39:28.8052+00
15	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:35:09.742322+00	t	2025-06-04 18:39:28.8052+00
16	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:37:10.877803+00	t	2025-06-04 18:39:28.8052+00
17	1	{"widgets": [{"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 0}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 1}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:37:11.153819+00	t	2025-06-04 18:39:28.8052+00
18	1	{"widgets": [{"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 0}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 1}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 15:37:12.008393+00	t	2025-06-04 18:39:28.8052+00
19	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 1}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 17:57:03.304339+00	t	2025-06-04 18:39:28.8052+00
20	1	{"widgets": [{"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 0}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-23 17:57:12.171106+00	t	2025-06-04 18:39:28.8052+00
21	1	{"widgets": [{"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 0}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 1}, {"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-24 01:45:18.72063+00	t	2025-06-04 18:39:28.8052+00
22	1	{"widgets": [{"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 0}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 1}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}, {"id": "custom-widget-1748051153852", "type": "table", "title": "capacity Summary", "width": 1, "position": 5}]}	2025-05-24 01:45:43.473218+00	t	2025-06-04 18:39:28.8052+00
23	1	{"widgets": [{"id": "custom-widget-1748051153852", "type": "table", "title": "capacity Summary", "width": 1, "position": 5}, {"id": "custom-widget-1748052966585", "type": "pie-chart", "title": "Sales Distribution", "width": 1, "position": 2}]}	2025-05-24 02:15:56.310943+00	t	2025-06-04 18:39:28.8052+00
24	1	{"widgets": [{"id": "custom-widget-1748051153852", "type": "table", "title": "capacity Summary", "width": 1, "position": 5}]}	2025-05-26 13:07:16.942616+00	t	2025-06-04 18:39:28.8052+00
25	1	{"widgets": []}	2025-05-26 13:07:19.817058+00	t	2025-06-04 18:39:28.8052+00
26	1	{"widgets": [{"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 0}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 1}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-26 13:07:33.498415+00	t	2025-06-04 18:39:28.8052+00
27	1	{"widgets": [{"id": "default-top-products", "type": "top-products", "title": "Top Selling Products", "width": 1, "position": 0}, {"id": "default-sales-overview", "type": "sales-overview", "title": "Sales Overview", "width": 2, "position": 1}, {"id": "default-inventory-status", "type": "inventory-status", "title": "Inventory Status", "width": 1, "position": 2}, {"id": "default-recent-activity", "type": "recent-activity", "title": "Recent Activity", "width": 1, "position": 3}]}	2025-05-26 13:39:00.668615+00	t	2025-06-04 18:39:28.8052+00
28	1	{"widgets": [{"id": "custom-widget-1748266778139", "type": "table", "title": "capacity Summary", "width": 1, "position": 1}]}	2025-05-26 13:39:27.580284+00	t	2025-06-04 18:39:28.8052+00
29	1	{"widgets": []}	2025-05-26 13:39:36.825973+00	t	2025-06-04 18:39:28.8052+00
\.


--
-- Data for Name: document_posting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_posting (id, document_number, document_type, posting_date, document_date, reference, currency, exchange_rate, company_code, fiscal_year, period, total_debit, total_credit, status, user_created, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_postings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_postings (id, document_number, company_code, document_type, posting_date, document_date, reference, header_text, total_amount, currency, status, created_at, created_by, fiscal_year, period) FROM stdin;
\.


--
-- Data for Name: document_posting_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_posting_items (id, document_id, line_number, gl_account, cost_center, profit_center, debit_amount, credit_amount, text, business_area, functional_area, assignment, reference_key) FROM stdin;
\.


--
-- Data for Name: document_posting_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_posting_lines (id, document_id, line_number, gl_account, cost_center, profit_center, debit_amount, credit_amount, description, reference, assignment, text, created_at) FROM stdin;
\.


--
-- Data for Name: down_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.down_payments (id, down_payment_number, vendor_code, customer_code, company_code, amount, currency, request_date, payment_date, clearing_date, gl_account, reference, status, created_at) FROM stdin;
\.


--
-- Data for Name: employee_master; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_master (id, employee_number, first_name, last_name, middle_name, date_of_birth, gender, hire_date, employment_type, employment_status, company_code_id, cost_center_id, manager_id, work_email, work_phone, created_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, employee_id, first_name, last_name, email, phone, department, "position", company_code_id, cost_center_id, join_date, manager_id, is_active, created_at, updated_at, active) FROM stdin;
1	E1001	John	Smith	john.smith@minierp.com	212-555-1234	Executive	CEO	1	\N	2018-01-15	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641	t
2	E1002	Sarah	Johnson	sarah.johnson@minierp.com	212-555-2345	Finance	CFO	1	\N	2018-02-01	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641	t
3	E1003	Michael	Williams	michael.williams@minierp.com	212-555-3456	Operations	COO	1	\N	2018-03-15	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641	t
4	E1004	David	Brown	david.brown@minierp.com	212-555-4567	Manufacturing	VP Manufacturing	1	\N	2018-06-01	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641	t
5	E1005	Jennifer	Davis	jennifer.davis@minierp.com	212-555-5678	Sales	VP Sales	1	\N	2018-07-15	\N	t	2025-05-20 22:10:30.210641	2025-05-20 22:10:30.210641	t
8	US01-EMP2769	Emma	Johnson	emma.johnson1@example.com	+1-555-987-8217	Sales	Sales Manager	1	3	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057	t
9	EU01-EMP9748	Emma	Johnson	emma.johnson2@example.com	+1-555-987-8928	Sales	Sales Manager	2	\N	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057	t
10	TEST02-EMP9857	Emma	Johnson	emma.johnson4@example.com	+1-555-987-1855	Sales	Sales Manager	4	\N	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057	t
11	CA01-EMP8109	Emma	Johnson	emma.johnson5@example.com	+1-555-987-5968	Sales	Sales Manager	5	13	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057	t
12	GA01-EMP6705	Emma	Johnson	emma.johnson7@example.com	+1-555-987-5673	Sales	Sales Manager	7	15	2019-07-22	\N	t	2025-05-21 14:58:58.925057	2025-05-21 14:58:58.925057	t
\.


--
-- Data for Name: environment_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.environment_config (id, environment, database_url, is_active, last_transport_date, description, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: erp_customer_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.erp_customer_contacts (id, customer_id, first_name, last_name, "position", department, email, phone, mobile, is_primary, is_billing, is_shipping, is_technical, is_marketing, preferred_language, notes, is_active, created_at, updated_at, created_by, updated_by, active) FROM stdin;
1	1	James	Wilson	Purchasing Manager	Procurement	james.wilson@acmecorp.com	+1-312-555-1235	\N	t	f	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
2	1	Sarah	Johnson	Accounts Payable Manager	Finance	sarah.johnson@acmecorp.com	+1-312-555-1236	\N	f	t	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
3	1	Robert	Davis	Logistics Coordinator	Operations	robert.davis@acmecorp.com	+1-312-555-1237	\N	f	f	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
4	2	Michael	Brown	Director of Merchandising	Purchasing	michael.brown@globalretail.com	+1-212-555-2346	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
5	2	Emily	Taylor	Supply Chain Manager	Operations	emily.taylor@globalretail.com	+1-212-555-2347	\N	f	f	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
6	3	David	Martinez	Head of Procurement	Administration	david.martinez@cityhospital.org	+1-617-555-3457	\N	t	t	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
7	4	Lisa	Anderson	Operations Director	Operations	lisa.anderson@techinnovate.com	+1-415-555-4568	\N	t	t	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
8	6	Thomas	Washington	Procurement Officer	Acquisitions	thomas.washington@gov.agency.gov	+1-202-555-6790	\N	t	f	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
9	6	Jennifer	Adams	Financial Officer	Finance	jennifer.adams@gov.agency.gov	+1-202-555-6791	\N	f	t	f	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
10	7	Klaus	Schmidt	International Sales Director	Sales	klaus.schmidt@eurodist.eu	+49-30-555-7891	\N	t	t	t	f	f	English	\N	t	2025-05-17 15:46:05.273222	2025-05-17 15:46:05.273222	\N	\N	t
\.


--
-- Data for Name: erp_vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.erp_vendors (id, vendor_code, name, type, description, tax_id, industry, address, city, state, country, postal_code, region, phone, alt_phone, email, website, currency, payment_terms, payment_method, supplier_type, category, order_frequency, minimum_order_value, evaluation_score, lead_time, purchasing_group_id, status, blacklisted, blacklist_reason, notes, tags, company_code_id, is_active, created_at, updated_at, created_by, updated_by, version, active) FROM stdin;
1	V1001	Prime Steel Supply	supplier	Steel and metal supplier	PS-12345	manufacturing	100 Industrial Road	Pittsburgh	PA	US	15222	\N	+1-412-555-1111	\N	orders@primesteelsupply.com	\N	USD	net_30	\N	manufacturer	strategic	\N	\N	92	14	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
2	V1002	Quality Electronics	supplier	Electronic components supplier	QE-67890	electronics	200 Tech Avenue	San Jose	CA	US	95110	\N	+1-408-555-2222	\N	sales@qualityelectronics.com	\N	USD	net_45	\N	distributor	preferred	\N	\N	88	21	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
3	V1003	Global Logistics	service_provider	International shipping and logistics	GL-34567	transportation	300 Harbor Blvd	Long Beach	CA	US	90802	\N	+1-562-555-3333	\N	operations@globallogistics.com	\N	USD	net_30	\N	service	approved	\N	\N	95	7	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
4	V1004	Advanced Materials	supplier	Specialized manufacturing materials	AM-89012	chemicals	400 Research Parkway	Raleigh	NC	US	27601	\N	+1-919-555-4444	\N	orders@advancedmaterials.com	\N	USD	net_60	\N	manufacturer	strategic	\N	\N	90	28	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
5	V1005	Precision Engineering	contractor	Custom tooling and machining services	PE-45678	manufacturing	500 Precision Way	Cincinnati	OH	US	45202	\N	+1-513-555-5555	\N	info@precisionengineering.com	\N	USD	net_30	\N	service	preferred	\N	\N	87	35	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
6	V1006	Packaging Solutions	supplier	Industrial packaging materials	PS-90123	packaging	600 Box Street	Memphis	TN	US	38101	\N	+1-901-555-6666	\N	sales@packagingsolutions.com	\N	USD	net_30	\N	manufacturer	approved	\N	\N	83	10	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
7	V1007	Machinery Maintenance	service_provider	Equipment maintenance and repair	MM-56789	services	700 Service Road	Cleveland	OH	US	44101	\N	+1-216-555-7777	\N	service@machinerymaintenance.com	\N	USD	net_15	\N	service	approved	\N	\N	79	3	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
8	V1008	Asian Manufacturing	supplier	Overseas manufacturing partner	AM-901234	manufacturing	800 Export Zone	Shenzhen	\N	CN	518000	\N	+86-755-5558888	\N	exports@asianmanufacturing.com	\N	USD	letter_of_credit	\N	manufacturer	strategic	\N	\N	85	45	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
9	V1009	Office Supplies Co	supplier	General office and facility supplies	OSC-12345	retail	900 Retail Row	Chicago	IL	US	60602	\N	+1-312-555-9999	\N	orders@officesupplies.com	\N	USD	net_30	\N	distributor	approved	\N	\N	82	5	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
10	V1010	Unreliable Vendor	supplier	Problematic supplier with quality issues	UV-99999	manufacturing	1000 Problem Street	Phoenix	AZ	US	85001	\N	+1-602-555-0000	\N	orders@unreliablevendor.com	\N	USD	advance	\N	manufacturer	one_time	\N	\N	30	60	\N	inactive	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
11	V1011	Blacklisted Supply	supplier	Blacklisted due to contract violations	BS-00000	manufacturing	1100 Violation Road	Denver	CO	US	80201	\N	+1-303-555-1111	\N	info@blacklistedsupply.com	\N	USD	cod	\N	manufacturer	one_time	\N	\N	10	90	\N	blocked	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
12	V1012	Software Solutions	service_provider	Software and IT services provider	SS-12345	technology	1200 Code Boulevard	Seattle	WA	US	98101	\N	+1-206-555-2222	\N	services@softwaresolutions.com	\N	USD	net_30	\N	service	strategic	\N	\N	91	14	\N	active	f	\N	\N	\N	2	t	2025-05-17 15:46:35.531383	2025-05-17 15:46:35.531383	\N	\N	1	t
\.


--
-- Data for Name: erp_vendor_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.erp_vendor_contacts (id, vendor_id, first_name, last_name, "position", department, email, phone, mobile, is_primary, is_order_contact, is_purchase_contact, is_quality_contact, is_accounts_contact, preferred_language, notes, is_active, created_at, updated_at, created_by, updated_by, active) FROM stdin;
1	1	Richard	Steel	Sales Director	Sales	richard.steel@primesteelsupply.com	+1-412-555-1112	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
2	1	Patricia	Miller	Accounts Manager	Finance	patricia.miller@primesteelsupply.com	+1-412-555-1113	\N	f	f	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
3	2	Edward	Johnson	VP of Sales	Sales	edward.johnson@qualityelectronics.com	+1-408-555-2223	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
4	2	Michelle	Lee	Customer Relations	Customer Service	michelle.lee@qualityelectronics.com	+1-408-555-2224	\N	f	f	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
5	3	Carlos	Rodriguez	Operations Manager	Operations	carlos.rodriguez@globallogistics.com	+1-562-555-3334	\N	t	t	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
6	4	Stephanie	Clark	Sales Representative	Sales	stephanie.clark@advancedmaterials.com	+1-919-555-4445	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
7	4	Mark	Williams	Technical Support	Engineering	mark.williams@advancedmaterials.com	+1-919-555-4446	\N	f	f	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
8	5	Gregory	Phillips	Owner	Management	gregory.phillips@precisionengineering.com	+1-513-555-5556	\N	t	t	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
9	8	Mei	Chen	Export Manager	International Sales	mei.chen@asianmanufacturing.com	+86-755-5558889	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
10	8	Jian	Zhang	Quality Control Manager	Quality	jian.zhang@asianmanufacturing.com	+86-755-5558890	\N	f	f	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
11	12	Brian	Davis	Account Executive	Sales	brian.davis@softwaresolutions.com	+1-206-555-2223	\N	t	t	f	f	f	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
12	12	Amanda	Wilson	Support Manager	Technical Support	amanda.wilson@softwaresolutions.com	+1-206-555-2224	\N	f	f	f	f	t	English	\N	t	2025-05-17 15:46:49.348119	2025-05-17 15:46:49.348119	\N	\N	t
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, date, amount, category, description, payment_method, reference, user_id, created_at, updated_at, active) FROM stdin;
4	2025-04-07 13:40:07.532	4497.31	Professional Services	Consulting and professional fees	Credit Card	EXP-7870	1	2025-05-22 13:40:07.533	2025-05-22 13:40:07.533	t
5	2025-03-02 13:40:07.532	4652.64	Software	Software licenses and subscriptions	Petty Cash	EXP-7268	1	2025-05-22 13:40:07.575	2025-05-22 13:40:07.575	t
6	2025-03-18 13:40:07.532	1942.11	Training	Employee training and development	Credit Card	EXP-0984	1	2025-05-22 13:40:07.599	2025-05-22 13:40:07.599	t
7	2025-05-06 13:40:07.532	2303.66	Marketing	Marketing campaign expenses	Credit Card	EXP-3024	1	2025-05-22 13:40:07.617	2025-05-22 13:40:07.617	t
8	2025-05-14 13:40:07.532	4140.1	Utilities	Monthly utility bills	Petty Cash	EXP-7523	1	2025-05-22 13:40:07.635	2025-05-22 13:40:07.635	t
9	2025-05-14 13:40:07.532	3782.49	Maintenance	Equipment and building maintenance	Cash	EXP-0422	1	2025-05-22 13:40:07.654	2025-05-22 13:40:07.654	t
10	2025-03-02 13:40:07.532	3939.37	Hardware	Computer and office equipment	Corporate Card	EXP-1328	1	2025-05-22 13:40:07.68	2025-05-22 13:40:07.68	t
11	2025-02-27 13:40:07.532	2907.45	Office Supplies	Office stationery and supplies	PayPal	EXP-6739	1	2025-05-22 13:40:07.71	2025-05-22 13:40:07.71	t
12	2025-04-11 13:40:07.532	4389.24	Office Supplies	Office stationery and supplies	PayPal	EXP-4371	1	2025-05-22 13:40:07.731	2025-05-22 13:40:07.731	t
13	2025-04-21 13:40:07.532	2628.29	Marketing	Marketing campaign expenses	Bank Transfer	EXP-1703	1	2025-05-22 13:40:07.75	2025-05-22 13:40:07.75	t
14	2025-05-16 13:40:07.532	1210.63	Office Supplies	Office stationery and supplies	Corporate Card	EXP-5873	1	2025-05-22 13:40:07.768	2025-05-22 13:40:07.768	t
15	2025-03-15 13:40:07.532	2723.74	Software	Software licenses and subscriptions	Check	EXP-6857	1	2025-05-22 13:40:07.788	2025-05-22 13:40:07.788	t
16	2025-03-26 13:40:07.532	1338.37	Software	Software licenses and subscriptions	PayPal	EXP-4754	1	2025-05-22 13:40:07.808	2025-05-22 13:40:07.808	t
17	2025-05-07 13:40:07.532	1939.2	Professional Services	Consulting and professional fees	Bank Transfer	EXP-5327	1	2025-05-22 13:40:07.826	2025-05-22 13:40:07.826	t
18	2025-03-22 13:40:07.532	1458.69	Office Supplies	Office stationery and supplies	Cash	EXP-7187	1	2025-05-22 13:40:07.857	2025-05-22 13:40:07.857	t
\.


--
-- Data for Name: fiscal_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fiscal_periods (id, created_at, updated_at, version, year, period, name, start_date, end_date, status, company_code_id, active) FROM stdin;
1	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	1	2025-01	2025-01-01	2025-01-31	CLOSED	1	t
2	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	2	2025-02	2025-02-01	2025-02-28	CLOSED	1	t
3	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	3	2025-03	2025-03-01	2025-03-31	CLOSED	1	t
4	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	4	2025-04	2025-04-01	2025-04-30	CLOSED	1	t
5	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	5	2025-05	2025-05-01	2025-05-31	CLOSED	1	t
6	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	6	2025-06	2025-06-01	2025-06-30	OPEN	1	t
7	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	7	2025-07	2025-07-01	2025-07-31	OPEN	1	t
8	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	8	2025-08	2025-08-01	2025-08-31	OPEN	1	t
9	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	9	2025-09	2025-09-01	2025-09-30	OPEN	1	t
10	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	10	2025-10	2025-10-01	2025-10-31	OPEN	1	t
11	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	11	2025-11	2025-11-01	2025-11-30	OPEN	1	t
12	2025-05-20 22:11:27.296074	2025-05-20 22:11:27.296074	1	2025	12	2025-12	2025-12-01	2025-12-31	OPEN	1	t
\.


--
-- Data for Name: fiscal_year_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fiscal_year_variants (id, variant_id, description, posting_periods, special_periods, year_shift, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: general_ledger_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.general_ledger_accounts (id, account_number, account_name, account_type, account_group, parent_account_id, company_code_id, currency_id, balance_sheet_item, profit_loss_item, reconciliation_account, tax_relevant, posting_allowed, blocked, description, created_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: gl_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gl_accounts (id, account_number, account_name, chart_of_accounts_id, account_type, account_group, balance_sheet_account, pl_account, block_posting, reconciliation_account, is_active, created_at, updated_at, active) FROM stdin;
1	1000	Cash and Cash Equivalents	39	ASSETS	CURRENT_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
2	1100	Accounts Receivable	39	ASSETS	CURRENT_ASSETS	t	f	f	t	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
3	1110	Allowance for Doubtful Accounts	39	ASSETS	CURRENT_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
4	1200	Inventory - Raw Materials	39	ASSETS	CURRENT_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
5	1210	Inventory - Work in Process	39	ASSETS	CURRENT_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
6	1220	Inventory - Finished Goods	39	ASSETS	CURRENT_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
7	1300	Prepaid Expenses	39	ASSETS	CURRENT_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
8	1500	Property, Plant & Equipment	39	ASSETS	FIXED_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
9	1510	Accumulated Depreciation - PPE	39	ASSETS	FIXED_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
10	1600	Intangible Assets	39	ASSETS	FIXED_ASSETS	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
11	2000	Accounts Payable	39	LIABILITIES	CURRENT_LIABILITIES	t	f	f	t	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
12	2100	Accrued Expenses	39	LIABILITIES	CURRENT_LIABILITIES	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
13	2110	Accrued Payroll	39	LIABILITIES	CURRENT_LIABILITIES	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
14	2200	Short-term Debt	39	LIABILITIES	CURRENT_LIABILITIES	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
15	2300	Income Tax Payable	39	LIABILITIES	CURRENT_LIABILITIES	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
16	2500	Long-term Debt	39	LIABILITIES	LONG_TERM_LIABILITIES	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
17	3000	Common Stock	39	EQUITY	STOCKHOLDERS_EQUITY	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
18	3100	Retained Earnings	39	EQUITY	STOCKHOLDERS_EQUITY	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
19	3200	Additional Paid-in Capital	39	EQUITY	STOCKHOLDERS_EQUITY	t	f	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
20	4000	Sales Revenue - Products	39	REVENUE	OPERATING_REVENUE	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
21	4100	Service Revenue	39	REVENUE	OPERATING_REVENUE	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
22	4200	Other Operating Revenue	39	REVENUE	OTHER_REVENUE	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
23	5000	Cost of Goods Sold - Materials	39	EXPENSES	COST_OF_SALES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
24	5100	Cost of Goods Sold - Labor	39	EXPENSES	COST_OF_SALES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
25	5200	Cost of Goods Sold - Overhead	39	EXPENSES	COST_OF_SALES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
26	6000	Salaries and Wages	39	EXPENSES	OPERATING_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
27	6100	Rent Expense	39	EXPENSES	OPERATING_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
28	6200	Utilities Expense	39	EXPENSES	OPERATING_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
29	6300	Depreciation Expense	39	EXPENSES	OPERATING_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
30	6400	Insurance Expense	39	EXPENSES	OPERATING_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
31	6500	Marketing and Advertising	39	EXPENSES	OPERATING_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
32	6600	Research and Development	39	EXPENSES	OPERATING_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
33	7000	Interest Expense	39	EXPENSES	NON_OPERATING_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
34	7100	Interest Income	39	REVENUE	NON_OPERATING_REVENUE	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
35	8000	Income Tax Expense	39	EXPENSES	TAX_EXPENSES	f	t	f	f	t	2025-06-04 02:38:20.681585	2025-06-04 02:38:20.681585	t
\.


--
-- Data for Name: goods_receipt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_receipt (id, receipt_number, receipt_date, vendor_code, vendor_name, purchase_order, plant_code, storage_location, movement_type, total_quantity, total_value, currency, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: goods_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_receipts (id, receipt_number, purchase_order, vendor_code, plant_code, receipt_date, delivery_note, bill_of_lading, total_quantity, total_amount, currency, status, created_at, created_by, movement_type) FROM stdin;
\.


--
-- Data for Name: goods_receipt_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_receipt_items (id, receipt_id, line_number, material_code, quantity, unit_of_measure, unit_price, storage_location, batch_number, expiration_date, vendor_batch, quality_inspection) FROM stdin;
\.


--
-- Data for Name: goods_receipt_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_receipt_lines (id, receipt_id, line_number, material_code, material_name, quantity_received, unit_price, total_amount, storage_location, batch_number, expiry_date, quality_status, created_at) FROM stdin;
\.


--
-- Data for Name: internal_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.internal_orders (id, order_number, order_type, description, company_code, controlling_area, responsible_cost_center, profit_center, order_status, planned_costs, actual_costs, committed_costs, budget_amount, start_date, end_date, created_by, created_at, active, updated_at) FROM stdin;
3	IO001	INVESTMENT	Complete renovation of production facility	1000	CA01	CC001	\N	CREATED	150000.00	0.00	0.00	0.00	2024-01-01	2024-06-30	\N	2025-06-05 17:12:41.248357	t	2025-06-05 17:12:41.248357+00
4	IO002	OVERHEAD	Implementation of quality management system	1000	CA01	CC003	\N	CREATED	25000.00	0.00	0.00	0.00	2024-02-01	2024-12-31	\N	2025-06-05 17:12:41.248357	t	2025-06-05 17:12:41.248357+00
5	IO003	INVESTMENT	Installation of new production equipment	2000	CA01	CC002	\N	CREATED	85000.00	0.00	0.00	0.00	2024-03-01	2024-05-31	\N	2025-06-05 17:12:41.248357	t	2025-06-05 17:12:41.248357+00
6	IO004	OVERHEAD	Employee training and skill development	1000	CA01	CC004	\N	CREATED	12000.00	0.00	0.00	0.00	2024-01-01	2024-12-31	\N	2025-06-05 17:12:41.248357	t	2025-06-05 17:12:41.248357+00
7	IO005	INVESTMENT	Implementation of energy-saving measures	1000	CA01	CC001	\N	CREATED	45000.00	0.00	0.00	0.00	2024-04-01	2024-08-31	\N	2025-06-05 17:12:41.248357	t	2025-06-05 17:12:41.248357+00
\.


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storage_locations (id, code, name, description, plant_id, type, is_mrp_relevant, is_negative_stock_allowed, is_goods_receipt_relevant, is_goods_issue_relevant, is_interim_storage, is_transit_storage, is_restricted_use, status, is_active, created_at, created_by, updated_at, updated_by, version, notes, active) FROM stdin;
13	SL001	Raw Materials Warehouse	Primary storage for raw materials in main factory	1	raw_material	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.094952	\N	2025-05-20 05:01:14.094952	\N	1	\N	t
14	SL002	Work-in-Progress	Temporary storage for work-in-progress items	1	wip	t	f	f	f	f	f	f	active	t	2025-05-20 05:01:14.125555	\N	2025-05-20 05:01:14.125555	\N	1	\N	t
15	SL003	Finished Goods	Storage for completed products ready for shipping	1	finished_goods	t	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.149165	\N	2025-05-20 05:01:14.149165	\N	1	\N	t
16	SL004	Quality Control Area	Area for quality inspection and testing	1	quality_control	f	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.170727	\N	2025-05-20 05:01:14.170727	\N	1	\N	t
17	SL005	Components Storage	Storage for assembly components and parts	3	components	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.195182	\N	2025-05-20 05:01:14.195182	\N	1	\N	t
18	SL006	Assembly WIP	Work-in-progress area for assembly operations	3	wip	t	f	f	f	f	f	f	active	t	2025-05-20 05:01:14.215786	\N	2025-05-20 05:01:14.215786	\N	1	\N	t
19	SL007	Berlin Raw Materials	Raw material storage for Berlin plant	5	raw_material	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.233335	\N	2025-05-20 05:01:14.233335	\N	1	\N	t
20	SL008	Berlin Finished Goods	Finished product storage for Berlin plant	5	finished_goods	t	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.250899	\N	2025-05-20 05:01:14.250899	\N	1	\N	t
21	SL009	Shanghai Materials	Raw material storage for Shanghai facility	6	raw_material	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.273873	\N	2025-05-20 05:01:14.273873	\N	1	\N	t
22	SL010	Shanghai Finished Goods	Finished product storage for Shanghai facility	6	finished_goods	t	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.293642	\N	2025-05-20 05:01:14.293642	\N	1	\N	t
23	SL011	US Distribution - Zone A	High-volume products distribution area	2	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.314699	\N	2025-05-20 05:01:14.314699	\N	1	\N	t
24	SL012	US Distribution - Zone B	Specialty products distribution area	2	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.339057	\N	2025-05-20 05:01:14.339057	\N	1	\N	t
25	SL013	European Warehouse - General	General storage area for European warehouse	7	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.365961	\N	2025-05-20 05:01:14.365961	\N	1	\N	t
26	SL014	European Warehouse - Cold Storage	Temperature-controlled storage area	7	special_handling	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.386335	\N	2025-05-20 05:01:14.386335	\N	1	\N	t
27	SL015	Asia Distribution - General	General storage area for Asian distribution hub	8	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.408615	\N	2025-05-20 05:01:14.408615	\N	1	\N	t
28	SL016	UK Warehouse - Main	Main storage area for UK warehouse	9	distribution	f	f	f	t	f	f	f	active	t	2025-05-20 05:01:14.426302	\N	2025-05-20 05:01:14.426302	\N	1	\N	t
29	SL017	Hazardous Materials	Special storage for hazardous materials	1	hazardous	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.444301	\N	2025-05-20 05:01:14.444301	\N	1	\N	t
30	SL018	Returns Processing	Area for processing customer returns	2	returns	f	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.465474	\N	2025-05-20 05:01:14.465474	\N	1	\N	t
31	SL019	Maintenance Supplies	Storage for maintenance tools and supplies	1	maintenance	f	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.484431	\N	2025-05-20 05:01:14.484431	\N	1	\N	t
32	SL020	Packaging Materials	Storage for packaging materials and supplies	1	packaging	t	f	t	f	f	f	f	active	t	2025-05-20 05:01:14.506819	\N	2025-05-20 05:01:14.506819	\N	1	\N	t
\.


--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_transactions (id, transaction_number, transaction_type, material_id, plant_id, storage_location_id, movement_type, quantity, unit_of_measure, unit_price, total_value, batch_number, serial_number, reference_document, posting_date, document_date, cost_center_id, reason_code, notes, created_by, created_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, order_number, customer_id, date, status, total, notes, shipping_address, user_id, created_at, updated_at, active) FROM stdin;
3	SO-10000	5	2025-02-11 07:25:12.502	DELIVERED	7469.740000000001	Sample order 1 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:35.988	2025-05-21 16:29:35.988	t
4	SO-10001	1	2025-05-13 05:02:26.31	CONFIRMED	2449.9300000000003	Sample order 2 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:36.13	2025-05-21 16:29:36.13	t
5	SO-10002	5	2025-04-24 07:05:56.36	DRAFT	9999.9	Sample order 3 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:36.178	2025-05-21 16:29:36.178	t
6	SO-10003	3	2025-03-01 02:13:26.649	DRAFT	2309.8100000000004	Sample order 4 for European Distributors Ltd	Shipping to European Distributors Ltd at their registered address	\N	2025-05-21 16:29:36.225	2025-05-21 16:29:36.225	t
7	SO-10004	2	2025-02-04 03:01:03.697	CONFIRMED	3499.9	Sample order 5 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:36.304	2025-05-21 16:29:36.304	t
8	SO-10005	5	2025-02-11 09:32:58.133	DRAFT	2649.81	Sample order 6 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:36.352	2025-05-21 16:29:36.352	t
9	SO-10006	1	2024-12-31 19:00:58.283	DRAFT	2079.9300000000003	Sample order 7 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:36.431	2025-05-21 16:29:36.431	t
10	SO-10007	3	2025-05-13 13:56:33.214	PROCESSING	389.97	Sample order 8 for European Distributors Ltd	Shipping to European Distributors Ltd at their registered address	\N	2025-05-21 16:29:36.493	2025-05-21 16:29:36.493	t
11	SO-10008	5	2025-04-02 01:46:56.499	DRAFT	4689.81	Sample order 9 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:36.541	2025-05-21 16:29:36.541	t
12	SO-10009	1	2025-05-17 16:51:54.19	DRAFT	5119.7	Sample order 10 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:36.622	2025-05-21 16:29:36.622	t
13	SO-10010	1	2025-02-08 11:36:41.019	CONFIRMED	779.94	Sample order 11 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:36.727	2025-05-21 16:29:36.727	t
14	SO-10011	1	2025-03-25 04:45:53.561	CONFIRMED	3669.83	Sample order 12 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:36.774	2025-05-21 16:29:36.774	t
15	SO-10012	2	2025-04-25 09:54:02.31	DRAFT	2649.9300000000003	Sample order 13 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:36.854	2025-05-21 16:29:36.854	t
16	SO-10013	2	2025-02-26 11:17:58.421	CONFIRMED	5299.89	Sample order 14 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:36.917	2025-05-21 16:29:36.917	t
17	SO-10014	5	2024-12-31 20:35:27.996	DRAFT	849.9100000000001	Sample order 15 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:36.979	2025-05-21 16:29:36.979	t
18	SO-10015	5	2025-05-12 17:12:33.098	CONFIRMED	4299.93	Sample order 16 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:37.042	2025-05-21 16:29:37.042	t
19	SO-10016	3	2025-05-13 20:10:12.347	DRAFT	3159.78	Sample order 17 for European Distributors Ltd	Shipping to European Distributors Ltd at their registered address	\N	2025-05-21 16:29:37.121	2025-05-21 16:29:37.121	t
20	SO-10017	4	2025-05-01 21:09:29.634	DELIVERED	11439.71	Sample order 18 for Tech Solutions GmbH	Shipping to Tech Solutions GmbH at their registered address	\N	2025-05-21 16:29:37.218	2025-05-21 16:29:37.218	t
21	SO-10018	4	2024-11-22 16:16:12.929	DRAFT	2969.83	Sample order 19 for Tech Solutions GmbH	Shipping to Tech Solutions GmbH at their registered address	\N	2025-05-21 16:29:37.344	2025-05-21 16:29:37.344	t
22	SO-10019	1	2025-05-14 07:41:52.633	DRAFT	3199.9300000000003	Sample order 20 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:37.416	2025-05-21 16:29:37.416	t
23	SO-10020	3	2024-11-23 20:26:31.944	DRAFT	19399.72	Sample order 21 for European Distributors Ltd	Shipping to European Distributors Ltd at their registered address	\N	2025-05-21 16:29:37.484	2025-05-21 16:29:37.484	t
24	SO-10021	2	2025-04-06 06:02:00.824	PROCESSING	1039.92	Sample order 22 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:37.562	2025-05-21 16:29:37.562	t
25	SO-10022	3	2025-04-18 03:56:30.454	DRAFT	2939.82	Sample order 23 for European Distributors Ltd	Shipping to European Distributors Ltd at their registered address	\N	2025-05-21 16:29:37.609	2025-05-21 16:29:37.609	t
26	SO-10023	1	2024-12-28 18:43:15.488	DELIVERED	2289.85	Sample order 24 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:37.689	2025-05-21 16:29:37.689	t
27	SO-10024	4	2025-04-01 03:12:19.304	SHIPPED	5399.91	Sample order 25 for Tech Solutions GmbH	Shipping to Tech Solutions GmbH at their registered address	\N	2025-05-21 16:29:37.801	2025-05-21 16:29:37.801	t
28	SO-10025	1	2024-12-17 00:56:14.765	PROCESSING	1889.93	Sample order 26 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:37.863	2025-05-21 16:29:37.863	t
29	SO-10026	1	2025-04-09 15:27:28.084	PROCESSING	5039.889999999999	Sample order 27 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:37.941	2025-05-21 16:29:37.941	t
30	SO-10027	1	2025-03-05 08:43:30.987	PROCESSING	3399.92	Sample order 28 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:38.003	2025-05-21 16:29:38.003	t
31	SO-10028	2	2025-01-21 22:23:11.444	SHIPPED	5069.94	Sample order 29 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:38.066	2025-05-21 16:29:38.066	t
32	SO-10029	3	2025-04-27 22:45:20.308	DRAFT	239.96999999999997	Sample order 30 for European Distributors Ltd	Shipping to European Distributors Ltd at their registered address	\N	2025-05-21 16:29:38.145	2025-05-21 16:29:38.145	t
33	SO-10030	3	2025-03-22 08:01:44.102	DRAFT	4499.91	Sample order 31 for European Distributors Ltd	Shipping to European Distributors Ltd at their registered address	\N	2025-05-21 16:29:38.192	2025-05-21 16:29:38.192	t
34	SO-10031	5	2025-05-15 11:21:24.615	CONFIRMED	11399.69	Sample order 32 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:38.239	2025-05-21 16:29:38.239	t
35	SO-10032	5	2025-03-02 04:57:18.132	CONFIRMED	1049.94	Sample order 33 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:38.333	2025-05-21 16:29:38.333	t
36	SO-10033	2	2025-04-02 18:15:28.827	DELIVERED	4029.66	Sample order 34 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:38.397	2025-05-21 16:29:38.397	t
37	SO-10034	2	2024-12-30 02:51:24.05	CONFIRMED	319.96	Sample order 35 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:38.523	2025-05-21 16:29:38.523	t
38	SO-10035	4	2025-02-20 15:40:35.692	CONFIRMED	9349.92	Sample order 36 for Tech Solutions GmbH	Shipping to Tech Solutions GmbH at their registered address	\N	2025-05-21 16:29:38.571	2025-05-21 16:29:38.571	t
39	SO-10036	1	2024-12-18 11:36:51.5	DELIVERED	9339.75	Sample order 37 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:38.644	2025-05-21 16:29:38.644	t
40	SO-10037	1	2024-12-12 07:21:42.349	SHIPPED	5749.83	Sample order 38 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:38.756	2025-05-21 16:29:38.756	t
41	SO-10038	1	2024-12-17 22:48:02.894	CONFIRMED	3479.86	Sample order 39 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:38.853	2025-05-21 16:29:38.853	t
42	SO-10039	2	2025-04-26 05:01:08.069	CONFIRMED	5749.8099999999995	Sample order 40 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:38.917	2025-05-21 16:29:38.917	t
43	SO-10040	1	2025-03-29 04:54:40.334	PROCESSING	3209.79	Sample order 41 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:39.012	2025-05-21 16:29:39.012	t
44	SO-10041	1	2025-03-09 00:25:18.663	DRAFT	11469.87	Sample order 42 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:39.092	2025-05-21 16:29:39.092	t
45	SO-10042	2	2025-02-16 07:37:27.292	CONFIRMED	6129.85	Sample order 43 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:39.17	2025-05-21 16:29:39.17	t
46	SO-10043	5	2025-02-16 07:23:13.799	DRAFT	2239.8500000000004	Sample order 44 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:39.289	2025-05-21 16:29:39.289	t
47	SO-10044	2	2025-02-12 01:25:13.831	DRAFT	10849.87	Sample order 45 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:39.37	2025-05-21 16:29:39.37	t
48	SO-10045	5	2025-04-18 12:23:00.681	SHIPPED	869.9300000000001	Sample order 46 for Japan Manufacturing Co.	Shipping to Japan Manufacturing Co. at their registered address	\N	2025-05-21 16:29:39.433	2025-05-21 16:29:39.433	t
49	SO-10046	4	2025-03-29 13:28:24.852	SHIPPED	1199.98	Sample order 47 for Tech Solutions GmbH	Shipping to Tech Solutions GmbH at their registered address	\N	2025-05-21 16:29:39.527	2025-05-21 16:29:39.527	t
50	SO-10047	2	2024-12-13 18:44:12.34	DRAFT	4799.83	Sample order 48 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:39.59	2025-05-21 16:29:39.59	t
51	SO-10048	1	2024-11-21 17:19:52.771	CONFIRMED	6689.6900000000005	Sample order 49 for Acme Corporation	Shipping to Acme Corporation at their registered address	\N	2025-05-21 16:29:39.653	2025-05-21 16:29:39.653	t
52	SO-10049	2	2025-03-22 10:52:52.984	DRAFT	15159.69	Sample order 50 for Global Enterprises	Shipping to Global Enterprises at their registered address	\N	2025-05-21 16:29:39.765	2025-05-21 16:29:39.765	t
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, invoice_number, order_id, issue_date, due_date, amount, status, paid_date, user_id, created_at, updated_at, active) FROM stdin;
1	INV-10000	3	2025-02-14 07:25:12.502	2025-03-16 07:25:12.502	7469.740000000001	PAID	2025-03-05 07:25:12.502	1	2025-05-21 16:29:36.095	2025-05-21 16:29:36.095	t
2	INV-10017	20	2025-05-01 21:09:29.634	2025-05-31 21:09:29.634	11439.71	PAID	2025-05-09 21:09:29.634	1	2025-05-21 16:29:37.327	2025-05-21 16:29:37.327	t
3	INV-10023	26	2024-12-29 18:43:15.488	2025-01-28 18:43:15.488	2289.85	PAID	2025-01-14 18:43:15.488	1	2025-05-21 16:29:37.785	2025-05-21 16:29:37.785	t
4	INV-10024	27	2025-04-02 03:12:19.304	2025-05-02 03:12:19.304	5399.91	ISSUED	\N	1	2025-05-21 16:29:37.848	2025-05-21 16:29:37.848	t
5	INV-10028	31	2025-01-24 22:23:11.444	2025-02-23 22:23:11.444	5069.94	ISSUED	\N	1	2025-05-21 16:29:38.129	2025-05-21 16:29:38.129	t
6	INV-10033	36	2025-04-02 18:15:28.827	2025-05-02 18:15:28.827	4029.66	PAID	2025-04-25 18:15:28.827	1	2025-05-21 16:29:38.506	2025-05-21 16:29:38.506	t
7	INV-10036	39	2024-12-18 11:36:51.5	2025-01-17 11:36:51.5	9339.75	PAID	2025-01-07 11:36:51.5	1	2025-05-21 16:29:38.739	2025-05-21 16:29:38.739	t
8	INV-10037	40	2024-12-16 07:21:42.349	2025-01-15 07:21:42.349	5749.83	ISSUED	\N	1	2025-05-21 16:29:38.837	2025-05-21 16:29:38.837	t
9	INV-10045	48	2025-04-19 12:23:00.681	2025-05-19 12:23:00.681	869.9300000000001	ISSUED	\N	1	2025-05-21 16:29:39.511	2025-05-21 16:29:39.511	t
10	INV-10046	49	2025-03-30 13:28:24.852	2025-04-29 13:28:24.852	1199.98	ISSUED	\N	1	2025-05-21 16:29:39.574	2025-05-21 16:29:39.574	t
\.


--
-- Data for Name: issue_analytics_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_analytics_summary (id, analysis_date, total_issues, critical_issues, high_issues, medium_issues, low_issues, ai_resolved, auto_resolved, manual_resolved, unresolved, avg_resolution_time, median_resolution_time, fastest_resolution, slowest_resolution, master_data_issues, transaction_issues, system_issues, api_issues, database_issues, validation_issues, created_at) FROM stdin;
1	2025-06-04	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	2025-06-04 23:48:09.610857+00
\.


--
-- Data for Name: issue_patterns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_patterns (id, pattern_name, pattern_regex, category, match_count, success_rate, avg_resolution_time, auto_resolvable, resolution_template, confidence_threshold, created_at, updated_at) FROM stdin;
1	Database Constraint Violation	violates.*constraint|unique.*constraint|foreign key	DATABASE	0	0.00	0	t	{"actions": ["expand_constraints", "create_references", "fix_sequences"]}	0.90	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
2	Data Validation Error	validation.*failed|invalid.*format|required.*field	VALIDATION	0	0.00	0	t	{"actions": ["sanitize_data", "apply_defaults", "validate_format"]}	0.85	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
3	Master Data Reference Missing	does not exist|not found.*reference|missing.*master	MASTER_DATA	0	0.00	0	t	{"actions": ["create_master_reference", "validate_hierarchy", "ensure_organizational_structure"]}	0.88	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
4	API Connection Error	connection.*refused|timeout|network.*error|service.*unavailable	API	0	0.00	0	f	{"actions": ["retry_request", "check_service_status", "escalate_to_admin"]}	0.70	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
5	Authorization Error	unauthorized|forbidden|access.*denied|permission.*denied	SYSTEM	0	0.00	0	f	{"actions": ["verify_permissions", "check_user_roles", "escalate_security"]}	0.75	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
\.


--
-- Data for Name: issue_resolutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_resolutions (id, resolution_id, issue_id, resolved_by, resolution_time, steps, success, additional_notes, validation_checks, rollback_info, created_at) FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entries (id, document_number, company_code_id, document_type, posting_date, document_date, fiscal_period, fiscal_year, currency_id, exchange_rate, reference_document, header_text, total_debit_amount, total_credit_amount, created_by, posted_by, posting_time, status, created_at, entry_date, active, updated_at) FROM stdin;
1	JE-2025-001	\N	SA	2025-06-01	2025-06-01	06	2025	\N	1.0000	\N	Monthly depreciation expense	5000.00	5000.00	\N	\N	\N	Posted	2025-06-04 01:15:51.540258	\N	t	2025-06-04 18:39:29.727143+00
2	JE-2025-002	\N	SA	2025-06-02	2025-06-02	06	2025	\N	1.0000	\N	Accrued salaries payable	15000.00	15000.00	\N	\N	\N	Posted	2025-06-04 01:15:51.540258	\N	t	2025-06-04 18:39:29.727143+00
3	JE-2025-003	\N	SA	2025-06-03	2025-06-03	06	2025	\N	1.0000	\N	Purchase of office supplies	2500.00	2500.00	\N	\N	\N	Posted	2025-06-04 01:15:51.540258	\N	t	2025-06-04 18:39:29.727143+00
4	JE-2025-004	\N	SA	2025-06-04	2025-06-04	06	2025	\N	1.0000	\N	Bank loan interest expense	1200.00	1200.00	\N	\N	\N	Draft	2025-06-04 01:15:51.540258	\N	t	2025-06-04 18:39:29.727143+00
5	JE-2025-005	\N	SA	2025-06-05	2025-06-05	06	2025	\N	1.0000	\N	Inventory adjustment	3200.00	3200.00	\N	\N	\N	Posted	2025-06-04 01:15:51.540258	\N	t	2025-06-04 18:39:29.727143+00
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leads (id, first_name, last_name, company_name, job_title, email, phone, status, source, industry, annual_revenue, employee_count, website, address, city, state, country, postal_code, description, last_contacted, next_followup, assigned_to, lead_score, is_converted, notes, created_at, updated_at, active) FROM stdin;
1	John	Smith	Tech Innovations	CTO	john.smith@techinnovations.com	(555) 123-4567	New	Website	Technology	5000000.00	50	www.techinnovations.com	\N	\N	\N	\N	\N	Interested in ERP solutions for tech startups	\N	\N	\N	\N	f	\N	2025-05-21 23:38:46.934661	2025-05-21 23:38:46.934661	t
2	Emma	Johnson	Healthcare Solutions	Director of Operations	emma.johnson@healthcaresolutions.com	(555) 234-5678	New	Trade Show	Healthcare	12000000.00	120	www.healthcaresolutions.com	\N	\N	\N	\N	\N	Looking for inventory management solutions	\N	\N	\N	\N	f	\N	2025-05-21 23:38:46.95743	2025-05-21 23:38:46.95743	t
3	Michael	Davis	Davis Manufacturing	CEO	michael.davis@davismanufacturing.com	(555) 345-6789	New	Referral	Manufacturing	8500000.00	75	www.davismanufacturing.com	\N	\N	\N	\N	\N	Needs a complete ERP system	\N	\N	\N	\N	f	\N	2025-05-21 23:38:46.975151	2025-05-21 23:38:46.975151	t
4	Sarah	Wilson	Wilson Retail Group	Procurement Manager	sarah.wilson@wilsonretail.com	(555) 456-7890	New	Email Campaign	Retail	20000000.00	200	www.wilsonretail.com	\N	\N	\N	\N	\N	Interested in inventory and POS integration	\N	\N	\N	\N	f	\N	2025-05-21 23:38:46.993483	2025-05-21 23:38:46.993483	t
5	Robert	Brown	Brown Financial	CFO	robert.brown@brownfinancial.com	(555) 567-8901	New	Webinar	Financial Services	15000000.00	65	www.brownfinancial.com	\N	\N	\N	\N	\N	Looking for financial management modules	\N	\N	\N	\N	f	\N	2025-05-21 23:38:47.012149	2025-05-21 23:38:47.012149	t
6	Jennifer	Lee	Lee Education Services	Director	jennifer.lee@leeeducation.com	(555) 678-9012	Contacted	Website	Education	3000000.00	30	www.leeeducation.com	\N	\N	\N	\N	\N	Initial call completed, requested demo	2025-05-18 23:38:46.923	2025-05-28 23:38:46.924	\N	\N	f	\N	2025-05-21 23:38:47.034029	2025-05-21 23:38:47.034029	t
7	David	Miller	Miller Tech Solutions	COO	david.miller@millertech.com	(555) 789-0123	Contacted	Social Media	Technology	7500000.00	45	www.millertech.com	\N	\N	\N	\N	\N	Spoke about inventory needs, follow up with pricing	2025-05-16 23:38:46.924	2025-05-26 23:38:46.924	\N	\N	f	\N	2025-05-21 23:38:47.05167	2025-05-21 23:38:47.05167	t
8	Patricia	Garcia	Garcia Manufacturing	Operations Manager	patricia.garcia@garciamanufacturing.com	(555) 890-1234	Contacted	Trade Show	Manufacturing	10000000.00	90	www.garciamanufacturing.com	\N	\N	\N	\N	\N	Initial discussion about production modules	2025-05-19 23:38:46.924	2025-05-31 23:38:46.924	\N	\N	f	\N	2025-05-21 23:38:47.06892	2025-05-21 23:38:47.06892	t
9	James	Taylor	Taylor Consulting	Managing Partner	james.taylor@taylorconsulting.com	(555) 901-2345	Contacted	Referral	Professional Services	2500000.00	15	www.taylorconsulting.com	\N	\N	\N	\N	\N	Had intro call, wants demo next week	2025-05-20 23:38:46.924	2025-05-27 23:38:46.924	\N	\N	f	\N	2025-05-21 23:38:47.086203	2025-05-21 23:38:47.086203	t
10	Elizabeth	Moore	Moore Health Systems	CIO	elizabeth.moore@moorehealth.com	(555) 012-3456	Qualified	Webinar	Healthcare	18000000.00	150	www.moorehealth.com	\N	\N	\N	\N	\N	Completed needs assessment, high potential	2025-05-13 23:38:46.924	2025-05-24 23:38:46.924	\N	85	f	\N	2025-05-21 23:38:47.104021	2025-05-21 23:38:47.104021	t
11	William	White	White Industries	VP of Operations	william.white@whiteindustries.com	(555) 123-4567	Qualified	Partner	Manufacturing	25000000.00	200	www.whiteindustries.com	\N	\N	\N	\N	\N	Ready for detailed proposal, budget approved	2025-05-17 23:38:46.924	2025-05-23 23:38:46.924	\N	90	f	\N	2025-05-21 23:38:47.121482	2025-05-21 23:38:47.121482	t
12	Barbara	Jones	Jones Retail	CEO	barbara.jones@jonesretail.com	(555) 234-5678	Qualified	Website	Retail	12000000.00	120	www.jonesretail.com	\N	\N	\N	\N	\N	Completed requirements gathering, good fit	2025-05-15 23:38:46.924	2025-05-25 23:38:46.924	\N	80	f	\N	2025-05-21 23:38:47.139809	2025-05-21 23:38:47.139809	t
13	Richard	Clark	Clark Financial	Director of IT	richard.clark@clarkfinancial.com	(555) 345-6789	Qualified	Email Campaign	Financial Services	30000000.00	80	www.clarkfinancial.com	\N	\N	\N	\N	\N	Has specific requirements, ready for formal quote	2025-05-11 23:38:46.924	2025-05-22 23:38:46.924	\N	95	f	\N	2025-05-21 23:38:47.158429	2025-05-21 23:38:47.158429	t
14	Susan	Anderson	Anderson Academy	President	susan.anderson@andersonacademy.edu	(555) 456-7890	Nurturing	Trade Show	Education	5000000.00	75	www.andersonacademy.edu	\N	\N	\N	\N	\N	Interested but no budget until next quarter	2025-05-06 23:38:46.924	2025-06-20 23:38:46.924	\N	60	f	\N	2025-05-21 23:38:47.178116	2025-05-21 23:38:47.178116	t
15	Thomas	Martinez	Martinez Technologies	CTO	thomas.martinez@martineztech.com	(555) 567-8901	Nurturing	Webinar	Technology	8000000.00	40	www.martineztech.com	\N	\N	\N	\N	\N	Needs more education about solution benefits	2025-05-01 23:38:46.924	2025-06-05 23:38:46.924	\N	45	f	\N	2025-05-21 23:38:47.195594	2025-05-21 23:38:47.195594	t
16	Mary	Robinson	Robinson Healthcare	Procurement Director	mary.robinson@robinsonhealth.com	(555) 678-9012	Nurturing	Social Media	Healthcare	15000000.00	130	www.robinsonhealth.com	\N	\N	\N	\N	\N	Still researching options, send case studies	2025-05-09 23:38:46.924	2025-06-10 23:38:46.924	\N	55	f	\N	2025-05-21 23:38:47.21573	2025-05-21 23:38:47.21573	t
17	Charles	Lewis	Lewis Manufacturing	Operations Director	charles.lewis@lewismanufacturing.com	(555) 789-0123	Nurturing	Email Campaign	Manufacturing	20000000.00	180	www.lewismanufacturing.com	\N	\N	\N	\N	\N	Implementing another system now, revisit later	2025-04-26 23:38:46.924	2025-07-20 23:38:46.924	\N	40	f	\N	2025-05-21 23:38:47.233772	2025-05-21 23:38:47.233772	t
18	Lisa	Walker	Walker Group	CFO	lisa.walker@walkergroup.com	(555) 890-1234	Disqualified	Website	Professional Services	1000000.00	8	www.walkergroup.com	\N	\N	\N	\N	\N	Too small for our solution, not a good fit	2025-04-21 23:38:46.924	\N	\N	10	f	\N	2025-05-21 23:38:47.251179	2025-05-21 23:38:47.251179	t
19	Daniel	Hall	Hall Tech	CEO	daniel.hall@halltech.com	(555) 901-2345	Disqualified	Cold Call	Technology	500000.00	5	www.halltech.com	\N	\N	\N	\N	\N	No budget, using free alternatives	2025-04-06 23:38:46.924	\N	\N	5	f	\N	2025-05-21 23:38:47.268622	2025-05-21 23:38:47.268622	t
20	Nancy	Allen	Allen Consulting	Principal	nancy.allen@allenconsulting.com	(555) 012-3456	Disqualified	Partner	Professional Services	750000.00	4	www.allenconsulting.com	\N	\N	\N	\N	\N	Outside our target market segment	2025-03-22 23:38:46.924	\N	\N	15	f	\N	2025-05-21 23:38:47.286383	2025-05-21 23:38:47.286383	t
21	Paul	Young	Young Enterprises	Owner	paul.young@youngenterprises.com	(555) 123-4567	Disqualified	Trade Show	Retail	300000.00	3	www.youngenterprises.com	\N	\N	\N	\N	\N	Selected competitor solution	2025-05-06 23:38:46.924	\N	\N	20	f	\N	2025-05-21 23:38:47.303792	2025-05-21 23:38:47.303792	t
22	Sam	Josh	samJ	\N	samj@gmail.com		Contacted	Website	Technology	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2025-05-22 19:00:33.604778	2025-05-22 19:00:33.604778	t
23	aF		TES	\N	sapbdc1@mail.com	22	Qualified	Website		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2025-05-23 01:53:09.735372	2025-05-23 01:53:09.735372	t
24	Rita		May23	\N	Rita12@mail.com		New	Website		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2025-05-23 04:51:05.225758	2025-05-23 04:51:05.225758	t
\.


--
-- Data for Name: material_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_categories (id, code, name, description, parent_id, created_at, updated_at, active) FROM stdin;
1	RM	Raw Materials	Base materials used in production	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374	t
2	FG	Finished Goods	Products ready for sale	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374	t
3	SFG	Semi-finished	Intermediate products	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374	t
4	SPRT	Spare Parts	Components for maintenance and repair	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374	t
5	PKG	Packaging	Materials used for packaging products	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374	t
6	CONS	Consumables	Materials consumed during production	\N	2025-05-21 15:12:13.362374	2025-05-21 15:12:13.362374	t
7	RM-MET	Metals	Metal raw materials	1	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947	t
8	RM-PLST	Plastics	Plastic raw materials	1	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947	t
9	FG-ELEC	Electronics	Electronic finished products	2	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947	t
10	FG-TOOL	Tools	Hand and power tools	2	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947	t
11	PKG-BOX	Boxes	Cardboard and corrugated boxes	5	2025-05-21 15:12:24.470947	2025-05-21 15:12:24.470947	t
\.


--
-- Data for Name: module_health_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.module_health_status (id, module_name, health_score, total_issues, critical_issues, resolved_issues, avg_resolution_time, response_time_avg, error_rate, availability_score, ai_intervention_count, ai_success_rate, last_check, created_at) FROM stdin;
4	INVENTORY	100.00	0	0	0	0	50	0.00	100.00	0	0.00	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
6	FINANCE	100.00	0	0	0	0	50	0.00	100.00	0	0.00	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
8	TRANSPORT	100.00	0	0	0	0	50	0.00	100.00	0	0.00	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
9	REPORTS	100.00	0	0	0	0	50	0.00	100.00	0	0.00	2025-06-04 23:48:09.610857+00	2025-06-04 23:48:09.610857+00
29	SYSTEM	50.00	148	0	0	0	0	0.00	100.00	0	0.00	2025-06-05 22:08:53.959731+00	2025-06-05 00:48:18.711778+00
1	MASTER_DATA	50.00	87	0	0	0	50	0.00	100.00	0	0.00	2025-06-05 02:16:34.848292+00	2025-06-04 23:48:09.610857+00
2	SALES	50.00	9	0	0	0	50	0.00	100.00	0	0.00	2025-06-05 01:56:14.46784+00	2025-06-04 23:48:09.610857+00
5	PRODUCTION	100.00	1	0	0	0	50	0.00	100.00	0	0.00	2025-06-05 01:58:36.317023+00	2025-06-04 23:48:09.610857+00
3	PURCHASE	50.00	6	0	0	0	50	0.00	100.00	0	0.00	2025-06-05 01:59:52.428701+00	2025-06-04 23:48:09.610857+00
7	CONTROLLING	100.00	5	0	0	0	50	0.00	100.00	0	0.00	2025-06-05 01:59:52.97814+00	2025-06-04 23:48:09.610857+00
\.


--
-- Data for Name: movement_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.movement_types (id, movement_code, movement_name, description, movement_category, debit_credit_indicator, quantity_update, value_update, reversal_allowed, active, created_at, updated_at, movement_type) FROM stdin;
1	101	Goods Receipt (Purchase)	Receipt of goods from vendor	RECEIPT	D	t	t	t	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
2	102	Goods Receipt (Production)	Receipt from production	RECEIPT	D	t	t	t	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
3	201	Goods Issue (Sales)	Issue for customer delivery	ISSUE	C	t	t	t	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
4	261	Goods Issue (Production)	Issue to production order	ISSUE	C	t	t	t	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
5	301	Plant Transfer	Transfer between plants	TRANSFER	C	t	t	t	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
6	302	Storage Location Transfer	Transfer between locations	TRANSFER	C	t	t	t	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
7	501	Stock Adjustment (+)	Positive inventory adjustment	ADJUSTMENT	D	t	t	f	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
8	502	Stock Adjustment (-)	Negative inventory adjustment	ADJUSTMENT	C	t	t	f	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
9	601	Return to Vendor	Return goods to supplier	RETURN	C	t	t	t	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
10	602	Return from Customer	Customer return receipt	RETURN	D	t	t	t	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
11	701	Consumption	Material consumption	CONSUMPTION	C	t	t	f	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
12	702	Scrapping	Material scrapping	CONSUMPTION	C	t	t	f	t	2025-06-05 16:53:42.401258+00	2025-06-05 16:53:42.401258+00	000
\.


--
-- Data for Name: opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.opportunities (id, name, lead_id, customer_id, status, stage, amount, expected_revenue, probability, close_date, next_step, type, source, campaign_source, description, assigned_to, is_closed, is_won, notes, created_at, updated_at, active) FROM stdin;
1	Lee Education Services - Education Solution	6	\N	Open	Prospecting	98612.00	9861.20	10	2025-08-23 23:38:47.376	Follow up with Jennifer	Upgrade	Lead Conversion	\N	Opportunity for Lee Education Services in the Education industry	\N	f	f	\N	2025-05-21 23:38:47.38633	2025-05-21 23:38:47.38633	t
2	Miller Tech Solutions - Technology Solution	7	\N	Open	Qualification	67801.00	13560.20	20	2025-09-01 23:38:47.376	Follow up with David	Existing Business	Lead Conversion	\N	Opportunity for Miller Tech Solutions in the Technology industry	\N	f	f	\N	2025-05-21 23:38:47.405549	2025-05-21 23:38:47.405549	t
3	Garcia Manufacturing - Manufacturing Solution	8	\N	Open	Needs Analysis	38398.00	11519.40	30	2025-10-23 23:38:47.376	Follow up with Patricia	New Business	Lead Conversion	\N	Opportunity for Garcia Manufacturing in the Manufacturing industry	\N	f	f	\N	2025-05-21 23:38:47.423186	2025-05-21 23:38:47.423186	t
4	Taylor Consulting - Professional Services Solution	9	\N	Open	Value Proposition	30785.00	12314.00	40	2025-10-05 23:38:47.376	Follow up with James	Existing Business	Lead Conversion	\N	Opportunity for Taylor Consulting in the Professional Services industry	\N	f	f	\N	2025-05-21 23:38:47.440964	2025-05-21 23:38:47.440964	t
5	Moore Health Systems - Healthcare Solution	10	\N	Open	Identify Decision Makers	59384.00	29692.00	50	2025-08-24 23:38:47.376	Follow up with Elizabeth	New Business	Lead Conversion	\N	Opportunity for Moore Health Systems in the Healthcare industry	\N	f	f	\N	2025-05-21 23:38:47.459055	2025-05-21 23:38:47.459055	t
6	White Industries - Manufacturing Solution	11	\N	Open	Proposal/Price Quote	34939.00	20963.40	60	2025-09-06 23:38:47.376	Follow up with William	Upgrade	Lead Conversion	\N	Opportunity for White Industries in the Manufacturing industry	\N	f	f	\N	2025-05-21 23:38:47.476515	2025-05-21 23:38:47.476515	t
7	Jones Retail - Retail Solution	12	\N	Open	Negotiation/Review	63504.00	47628.00	75	2025-07-04 23:38:47.376	Follow up with Barbara	Upgrade	Lead Conversion	\N	Opportunity for Jones Retail in the Retail industry	\N	f	f	\N	2025-05-21 23:38:47.49444	2025-05-21 23:38:47.49444	t
8	Clark Financial - Financial Services Solution	13	\N	Closed Won	Closed Won	89097.00	89097.00	100	2025-05-21 23:38:47.376	None	Existing Business	Lead Conversion	\N	Opportunity for Clark Financial in the Financial Services industry	\N	t	t	\N	2025-05-21 23:38:47.512112	2025-05-21 23:38:47.512112	t
9	Lee Education Services - Education Solution	6	\N	Closed Lost	Closed Lost	90911.00	0.00	0	2025-05-11 23:38:47.376	None	New Business	Lead Conversion	\N	Opportunity for Lee Education Services in the Education industry	\N	t	f	\N	2025-05-21 23:38:47.532369	2025-05-21 23:38:47.532369	t
10	Jones Retail - Additional Retail Project	12	\N	Open	Qualification	28807.00	5761.40	20	2025-06-02 23:38:47.376	Schedule meeting with Barbara	Upgrade	Lead Conversion	\N	Additional opportunity for Jones Retail in the Retail industry	\N	f	f	\N	2025-05-21 23:38:47.550037	2025-05-21 23:38:47.550037	t
11	Clark Financial - Additional Financial Services Project	13	\N	Open	Needs Analysis	43756.00	13126.80	30	2025-05-31 23:38:47.376	Schedule meeting with Richard	Upgrade	Lead Conversion	\N	Additional opportunity for Clark Financial in the Financial Services industry	\N	f	f	\N	2025-05-21 23:38:47.568149	2025-05-21 23:38:47.568149	t
12	Jones Retail - Additional Retail Project	12	\N	Open	Identify Decision Makers	75321.00	37660.50	50	2025-08-06 23:38:47.376	Schedule meeting with Barbara	New Business	Lead Conversion	\N	Additional opportunity for Jones Retail in the Retail industry	\N	f	f	\N	2025-05-21 23:38:47.585741	2025-05-21 23:38:47.585741	t
13	Taylor Consulting - Additional Professional Services Project	9	\N	Open	Proposal/Price Quote	26130.00	15678.00	60	2025-06-15 23:38:47.376	Schedule meeting with James	Upgrade	Lead Conversion	\N	Additional opportunity for Taylor Consulting in the Professional Services industry	\N	f	f	\N	2025-05-21 23:38:47.603145	2025-05-21 23:38:47.603145	t
14	Lee Education Services - Additional Education Project	6	\N	Open	Negotiation/Review	15916.00	11937.00	75	2025-07-09 23:38:47.376	Schedule meeting with Jennifer	Existing Business	Lead Conversion	\N	Additional opportunity for Lee Education Services in the Education industry	\N	f	f	\N	2025-05-21 23:38:47.620392	2025-05-21 23:38:47.620392	t
15	Jones Retail - Additional Retail Project	12	\N	Open	Prospecting	18557.00	1855.70	10	2025-07-02 23:38:47.376	Schedule meeting with Barbara	New Business	Lead Conversion	\N	Additional opportunity for Jones Retail in the Retail industry	\N	f	f	\N	2025-05-21 23:38:47.637868	2025-05-21 23:38:47.637868	t
16	Miller Tech Solutions - Additional Technology Project	7	\N	Open	Value Proposition	14051.00	5620.40	40	2025-06-16 23:38:47.376	Schedule meeting with David	Existing Business	Lead Conversion	\N	Additional opportunity for Miller Tech Solutions in the Technology industry	\N	f	f	\N	2025-05-21 23:38:47.655522	2025-05-21 23:38:47.655522	t
17	NewOpportunity	2	\N	Open	Needs Analysis	200.00	0.00	10	2025-05-23 00:00:00		New Business	Manual Entry	\N		\N	f	f	\N	2025-05-23 01:33:26.916831	2025-05-23 01:33:26.916831	t
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, sku, description, price, cost, stock, min_stock, category_id, user_id, created_at, updated_at, active) FROM stdin;
1	Premium Laptop	TECH-001	High-quality premium laptop for professional use	1299.99	950	25	5	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
2	Office Chair	FURN-001	High-quality office chair for professional use	249.99	150	50	10	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
3	Standing Desk	FURN-002	High-quality standing desk for professional use	599.99	350	15	3	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
4	Wireless Earbuds	TECH-002	High-quality wireless earbuds for professional use	129.99	65	100	20	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
5	Smart Watch	TECH-003	High-quality smart watch for professional use	349.99	200	30	8	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
6	External Hard Drive	TECH-004	High-quality external hard drive for professional use	89.99	45	40	10	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
7	Wireless Mouse	TECH-005	High-quality wireless mouse for professional use	49.99	25	75	15	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
8	Bluetooth Speaker	TECH-006	High-quality bluetooth speaker for professional use	79.99	40	60	12	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
9	Monitor	TECH-007	High-quality monitor for professional use	299.99	180	35	7	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
10	Printer	TECH-008	High-quality printer for professional use	179.99	120	20	5	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
11	Smartphone	TECH-009	High-quality smartphone for professional use	899.99	650	40	8	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
12	Tablet	TECH-010	High-quality tablet for professional use	499.99	350	30	6	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
13	Desktop PC	TECH-011	High-quality desktop pc for professional use	999.99	750	15	3	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
14	Keyboard	TECH-012	High-quality keyboard for professional use	69.99	35	50	10	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
15	USB-C Hub	TECH-013	High-quality usb-c hub for professional use	39.99	18	80	20	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
16	Webcam	TECH-014	High-quality webcam for professional use	59.99	30	45	10	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
17	Microphone	TECH-015	High-quality microphone for professional use	129.99	65	25	5	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
18	Router	TECH-016	High-quality router for professional use	149.99	80	20	5	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
19	Power Bank	TECH-017	High-quality power bank for professional use	49.99	25	60	15	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
20	VR Headset	TECH-018	High-quality vr headset for professional use	399.99	250	10	2	1	\N	2025-05-21 16:28:39.279	2025-05-21 16:28:39.279	t
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, product_id, quantity, unit_price, total, created_at, updated_at, active) FROM stdin;
2	3	15	7	39.99	279.93	2025-05-21 16:29:36.011	2025-05-21 16:29:36.011	t
3	3	17	3	129.99	389.97	2025-05-21 16:29:36.028	2025-05-21 16:29:36.028	t
4	3	8	10	79.99	799.9	2025-05-21 16:29:36.045	2025-05-21 16:29:36.045	t
5	3	13	6	999.99	5999.9400000000005	2025-05-21 16:29:36.061	2025-05-21 16:29:36.061	t
6	4	5	7	349.99	2449.9300000000003	2025-05-21 16:29:36.146	2025-05-21 16:29:36.146	t
7	5	13	10	999.99	9999.9	2025-05-21 16:29:36.193	2025-05-21 16:29:36.193	t
8	6	7	4	49.99	199.96	2025-05-21 16:29:36.241	2025-05-21 16:29:36.241	t
9	6	17	7	129.99	909.9300000000001	2025-05-21 16:29:36.257	2025-05-21 16:29:36.257	t
10	6	18	8	149.99	1199.92	2025-05-21 16:29:36.272	2025-05-21 16:29:36.272	t
11	7	5	10	349.99	3499.9	2025-05-21 16:29:36.32	2025-05-21 16:29:36.32	t
12	8	16	10	59.99	599.9	2025-05-21 16:29:36.367	2025-05-21 16:29:36.367	t
13	8	2	7	249.99	1749.93	2025-05-21 16:29:36.383	2025-05-21 16:29:36.383	t
14	8	18	2	149.99	299.98	2025-05-21 16:29:36.399	2025-05-21 16:29:36.399	t
15	9	13	1	999.99	999.99	2025-05-21 16:29:36.447	2025-05-21 16:29:36.447	t
16	9	10	6	179.99	1079.94	2025-05-21 16:29:36.462	2025-05-21 16:29:36.462	t
17	10	4	3	129.99	389.97	2025-05-21 16:29:36.509	2025-05-21 16:29:36.509	t
18	11	14	2	69.99	139.98	2025-05-21 16:29:36.559	2025-05-21 16:29:36.559	t
19	11	18	7	149.99	1049.93	2025-05-21 16:29:36.575	2025-05-21 16:29:36.575	t
20	11	5	10	349.99	3499.9	2025-05-21 16:29:36.59	2025-05-21 16:29:36.59	t
21	12	19	10	49.99	499.90000000000003	2025-05-21 16:29:36.638	2025-05-21 16:29:36.638	t
22	12	8	9	79.99	719.91	2025-05-21 16:29:36.657	2025-05-21 16:29:36.657	t
23	12	20	1	399.99	399.99	2025-05-21 16:29:36.673	2025-05-21 16:29:36.673	t
24	12	5	10	349.99	3499.9	2025-05-21 16:29:36.689	2025-05-21 16:29:36.689	t
25	13	4	6	129.99	779.94	2025-05-21 16:29:36.742	2025-05-21 16:29:36.742	t
26	14	8	2	79.99	159.98	2025-05-21 16:29:36.79	2025-05-21 16:29:36.79	t
27	14	5	9	349.99	3149.91	2025-05-21 16:29:36.806	2025-05-21 16:29:36.806	t
28	14	16	6	59.99	359.94	2025-05-21 16:29:36.822	2025-05-21 16:29:36.822	t
29	15	13	2	999.99	1999.98	2025-05-21 16:29:36.87	2025-05-21 16:29:36.87	t
30	15	4	5	129.99	649.95	2025-05-21 16:29:36.885	2025-05-21 16:29:36.885	t
31	16	1	1	1299.99	1299.99	2025-05-21 16:29:36.932	2025-05-21 16:29:36.932	t
32	16	20	10	399.99	3999.9	2025-05-21 16:29:36.948	2025-05-21 16:29:36.948	t
33	17	17	5	129.99	649.95	2025-05-21 16:29:36.995	2025-05-21 16:29:36.995	t
34	17	19	4	49.99	199.96	2025-05-21 16:29:37.01	2025-05-21 16:29:37.01	t
35	18	1	3	1299.99	3899.9700000000003	2025-05-21 16:29:37.058	2025-05-21 16:29:37.058	t
36	18	19	3	49.99	149.97	2025-05-21 16:29:37.074	2025-05-21 16:29:37.074	t
37	18	2	1	249.99	249.99	2025-05-21 16:29:37.09	2025-05-21 16:29:37.09	t
38	19	9	3	299.99	899.97	2025-05-21 16:29:37.137	2025-05-21 16:29:37.137	t
39	19	16	6	59.99	359.94	2025-05-21 16:29:37.153	2025-05-21 16:29:37.153	t
40	19	14	4	69.99	279.96	2025-05-21 16:29:37.169	2025-05-21 16:29:37.169	t
41	19	10	9	179.99	1619.91	2025-05-21 16:29:37.185	2025-05-21 16:29:37.185	t
42	20	9	5	299.99	1499.95	2025-05-21 16:29:37.233	2025-05-21 16:29:37.233	t
43	20	12	10	499.99	4999.9	2025-05-21 16:29:37.249	2025-05-21 16:29:37.249	t
44	20	1	1	1299.99	1299.99	2025-05-21 16:29:37.265	2025-05-21 16:29:37.265	t
45	20	8	8	79.99	639.92	2025-05-21 16:29:37.28	2025-05-21 16:29:37.28	t
46	20	3	5	599.99	2999.95	2025-05-21 16:29:37.296	2025-05-21 16:29:37.296	t
47	21	6	8	89.99	719.92	2025-05-21 16:29:37.367	2025-05-21 16:29:37.367	t
48	21	2	9	249.99	2249.91	2025-05-21 16:29:37.383	2025-05-21 16:29:37.383	t
49	22	3	3	599.99	1799.97	2025-05-21 16:29:37.437	2025-05-21 16:29:37.437	t
50	22	5	4	349.99	1399.96	2025-05-21 16:29:37.453	2025-05-21 16:29:37.453	t
51	23	3	9	599.99	5399.91	2025-05-21 16:29:37.499	2025-05-21 16:29:37.499	t
52	23	13	9	999.99	8999.91	2025-05-21 16:29:37.515	2025-05-21 16:29:37.515	t
53	23	12	10	499.99	4999.9	2025-05-21 16:29:37.531	2025-05-21 16:29:37.531	t
54	24	4	8	129.99	1039.92	2025-05-21 16:29:37.578	2025-05-21 16:29:37.578	t
55	25	15	8	39.99	319.92	2025-05-21 16:29:37.625	2025-05-21 16:29:37.625	t
56	25	5	6	349.99	2099.94	2025-05-21 16:29:37.641	2025-05-21 16:29:37.641	t
57	25	4	4	129.99	519.96	2025-05-21 16:29:37.657	2025-05-21 16:29:37.657	t
58	26	20	2	399.99	799.98	2025-05-21 16:29:37.705	2025-05-21 16:29:37.705	t
59	26	4	5	129.99	649.95	2025-05-21 16:29:37.721	2025-05-21 16:29:37.721	t
60	26	9	2	299.99	599.98	2025-05-21 16:29:37.737	2025-05-21 16:29:37.737	t
61	26	15	6	39.99	239.94	2025-05-21 16:29:37.752	2025-05-21 16:29:37.752	t
62	27	3	9	599.99	5399.91	2025-05-21 16:29:37.816	2025-05-21 16:29:37.816	t
63	28	5	1	349.99	349.99	2025-05-21 16:29:37.879	2025-05-21 16:29:37.879	t
64	28	9	5	299.99	1499.95	2025-05-21 16:29:37.894	2025-05-21 16:29:37.894	t
65	28	15	1	39.99	39.99	2025-05-21 16:29:37.91	2025-05-21 16:29:37.91	t
66	29	15	1	39.99	39.99	2025-05-21 16:29:37.957	2025-05-21 16:29:37.957	t
67	29	12	10	499.99	4999.9	2025-05-21 16:29:37.972	2025-05-21 16:29:37.972	t
68	30	12	4	499.99	1999.96	2025-05-21 16:29:38.019	2025-05-21 16:29:38.019	t
69	30	5	4	349.99	1399.96	2025-05-21 16:29:38.034	2025-05-21 16:29:38.034	t
70	31	13	5	999.99	4999.95	2025-05-21 16:29:38.082	2025-05-21 16:29:38.082	t
71	31	14	1	69.99	69.99	2025-05-21 16:29:38.097	2025-05-21 16:29:38.097	t
72	32	8	3	79.99	239.96999999999997	2025-05-21 16:29:38.16	2025-05-21 16:29:38.16	t
73	33	12	9	499.99	4499.91	2025-05-21 16:29:38.208	2025-05-21 16:29:38.208	t
74	34	18	8	149.99	1199.92	2025-05-21 16:29:38.255	2025-05-21 16:29:38.255	t
75	34	13	8	999.99	7999.92	2025-05-21 16:29:38.271	2025-05-21 16:29:38.271	t
76	34	14	10	69.99	699.9	2025-05-21 16:29:38.286	2025-05-21 16:29:38.286	t
77	34	9	5	299.99	1499.95	2025-05-21 16:29:38.302	2025-05-21 16:29:38.302	t
78	35	19	3	49.99	149.97	2025-05-21 16:29:38.349	2025-05-21 16:29:38.349	t
79	35	9	3	299.99	899.97	2025-05-21 16:29:38.365	2025-05-21 16:29:38.365	t
80	36	7	7	49.99	349.93	2025-05-21 16:29:38.412	2025-05-21 16:29:38.412	t
81	36	8	10	79.99	799.9	2025-05-21 16:29:38.428	2025-05-21 16:29:38.428	t
82	36	5	1	349.99	349.99	2025-05-21 16:29:38.443	2025-05-21 16:29:38.443	t
83	36	17	7	129.99	909.9300000000001	2025-05-21 16:29:38.459	2025-05-21 16:29:38.459	t
84	36	10	9	179.99	1619.91	2025-05-21 16:29:38.475	2025-05-21 16:29:38.475	t
85	37	8	4	79.99	319.96	2025-05-21 16:29:38.539	2025-05-21 16:29:38.539	t
86	38	2	1	249.99	249.99	2025-05-21 16:29:38.586	2025-05-21 16:29:38.586	t
87	38	1	7	1299.99	9099.93	2025-05-21 16:29:38.611	2025-05-21 16:29:38.611	t
88	39	9	1	299.99	299.99	2025-05-21 16:29:38.659	2025-05-21 16:29:38.659	t
89	39	5	8	349.99	2799.92	2025-05-21 16:29:38.676	2025-05-21 16:29:38.676	t
90	39	10	8	179.99	1439.92	2025-05-21 16:29:38.692	2025-05-21 16:29:38.692	t
91	39	3	8	599.99	4799.92	2025-05-21 16:29:38.708	2025-05-21 16:29:38.708	t
92	40	7	8	49.99	399.92	2025-05-21 16:29:38.771	2025-05-21 16:29:38.771	t
93	40	5	5	349.99	1749.95	2025-05-21 16:29:38.787	2025-05-21 16:29:38.787	t
94	40	11	4	899.99	3599.96	2025-05-21 16:29:38.805	2025-05-21 16:29:38.805	t
95	41	10	6	179.99	1079.94	2025-05-21 16:29:38.869	2025-05-21 16:29:38.869	t
96	41	9	8	299.99	2399.92	2025-05-21 16:29:38.885	2025-05-21 16:29:38.885	t
97	42	4	1	129.99	129.99	2025-05-21 16:29:38.933	2025-05-21 16:29:38.933	t
98	42	3	8	599.99	4799.92	2025-05-21 16:29:38.949	2025-05-21 16:29:38.949	t
99	42	14	8	69.99	559.92	2025-05-21 16:29:38.965	2025-05-21 16:29:38.965	t
100	42	17	2	129.99	259.98	2025-05-21 16:29:38.981	2025-05-21 16:29:38.981	t
101	43	2	7	249.99	1749.93	2025-05-21 16:29:39.028	2025-05-21 16:29:39.028	t
102	43	18	6	149.99	899.94	2025-05-21 16:29:39.044	2025-05-21 16:29:39.044	t
103	43	14	8	69.99	559.92	2025-05-21 16:29:39.06	2025-05-21 16:29:39.06	t
104	44	1	4	1299.99	5199.96	2025-05-21 16:29:39.108	2025-05-21 16:29:39.108	t
105	44	6	3	89.99	269.96999999999997	2025-05-21 16:29:39.124	2025-05-21 16:29:39.124	t
106	44	13	6	999.99	5999.9400000000005	2025-05-21 16:29:39.139	2025-05-21 16:29:39.139	t
107	45	15	2	39.99	79.98	2025-05-21 16:29:39.187	2025-05-21 16:29:39.187	t
108	45	9	3	299.99	899.97	2025-05-21 16:29:39.202	2025-05-21 16:29:39.202	t
109	45	13	1	999.99	999.99	2025-05-21 16:29:39.224	2025-05-21 16:29:39.224	t
110	45	12	8	499.99	3999.92	2025-05-21 16:29:39.24	2025-05-21 16:29:39.24	t
111	45	18	1	149.99	149.99	2025-05-21 16:29:39.256	2025-05-21 16:29:39.256	t
112	46	17	8	129.99	1039.92	2025-05-21 16:29:39.305	2025-05-21 16:29:39.305	t
113	46	18	2	149.99	299.98	2025-05-21 16:29:39.322	2025-05-21 16:29:39.322	t
114	46	10	5	179.99	899.95	2025-05-21 16:29:39.338	2025-05-21 16:29:39.338	t
115	47	1	8	1299.99	10399.92	2025-05-21 16:29:39.386	2025-05-21 16:29:39.386	t
116	47	6	5	89.99	449.95	2025-05-21 16:29:39.401	2025-05-21 16:29:39.401	t
117	48	6	5	89.99	449.95	2025-05-21 16:29:39.448	2025-05-21 16:29:39.448	t
118	48	5	1	349.99	349.99	2025-05-21 16:29:39.464	2025-05-21 16:29:39.464	t
119	48	14	1	69.99	69.99	2025-05-21 16:29:39.48	2025-05-21 16:29:39.48	t
120	49	3	2	599.99	1199.98	2025-05-21 16:29:39.543	2025-05-21 16:29:39.543	t
121	50	3	7	599.99	4199.93	2025-05-21 16:29:39.605	2025-05-21 16:29:39.605	t
122	50	16	10	59.99	599.9	2025-05-21 16:29:39.622	2025-05-21 16:29:39.622	t
123	51	17	10	129.99	1299.9	2025-05-21 16:29:39.669	2025-05-21 16:29:39.669	t
124	51	4	9	129.99	1169.91	2025-05-21 16:29:39.685	2025-05-21 16:29:39.685	t
125	51	8	4	79.99	319.96	2025-05-21 16:29:39.701	2025-05-21 16:29:39.701	t
126	51	9	3	299.99	899.97	2025-05-21 16:29:39.718	2025-05-21 16:29:39.718	t
127	51	3	5	599.99	2999.95	2025-05-21 16:29:39.733	2025-05-21 16:29:39.733	t
128	52	14	8	69.99	559.92	2025-05-21 16:29:39.781	2025-05-21 16:29:39.781	t
129	52	1	4	1299.99	5199.96	2025-05-21 16:29:39.796	2025-05-21 16:29:39.796	t
130	52	20	10	399.99	3999.9	2025-05-21 16:29:39.812	2025-05-21 16:29:39.812	t
131	52	3	9	599.99	5399.91	2025-05-21 16:29:39.828	2025-05-21 16:29:39.828	t
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, payment_number, payment_date, payment_method, vendor_code, vendor_name, customer_code, customer_name, payment_type, total_amount, currency, bank_account, reference, status, cleared_amount, remaining_amount, created_by, created_at, updated_at, amount) FROM stdin;
\.


--
-- Data for Name: payment_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_lines (id, payment_id, line_number, invoice_number, original_amount, discount_amount, payment_amount, cash_discount, assignment, text, created_at) FROM stdin;
\.


--
-- Data for Name: work_centers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_centers (id, code, name, plant_id, description, capacity, capacity_unit, cost_rate, is_active, created_at, updated_at, status, cost_center_id, company_code_id, active) FROM stdin;
1	WC-ASM-01	Primary Assembly Line	1	Main assembly line for final product assembly with automated stations	120.00	units/day	65.75	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active	\N	\N	t
2	WC-ASM-02	Secondary Assembly	1	Manual assembly operations for complex components	85.00	units/day	48.50	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active	\N	\N	t
3	WC-SUBASM	Sub-Assembly Station	2	Pre-assembly of component groups before main assembly	200.00	units/day	42.25	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active	\N	\N	t
4	WC-MCH-01	CNC Machining Center	2	Precision CNC machining for critical components	65.00	units/day	78.50	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active	\N	\N	t
5	WC-MCH-02	Milling Station	3	Multi-axis milling operations for complex geometries	40.00	units/day	82.75	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active	\N	\N	t
6	WC-QC-01	Quality Inspection	1	Manual and automated quality inspection station	180.00	units/day	45.25	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active	\N	\N	t
7	WC-PKG-01	Packaging Line	1	Automated packaging system for finished products	200.00	units/day	38.75	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active	\N	\N	t
8	WC-WELD-01	Robotic Welding	4	Automated welding cells for consistent high-quality joints	60.00	units/day	72.25	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	active	\N	\N	t
9	WC-LASER	Laser Cutting Station	5	Precision laser cutting for sheet materials	70.00	units/day	92.50	t	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	maintenance	\N	\N	t
10	WC-3DPRINT	Additive Manufacturing	6	3D printing facility for prototypes and small production runs	30.00	units/day	105.75	f	2025-05-21 02:02:30.35722	2025-05-21 02:02:30.35722	inactive	\N	\N	t
11	WC-W001A	Assembly Line - East Coast Warehouse	2	Main assembly line for East Coast Warehouse	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE	\N	\N	t
12	WC-p001A	Assembly Line - plant South East	4	Main assembly line for plant South East	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE	\N	\N	t
13	WC-P004A	Assembly Line - Shanghai Facility	6	Main assembly line for Shanghai Facility	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE	\N	\N	t
14	WC-P003A	Assembly Line - Berlin Production	5	Main assembly line for Berlin Production	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE	\N	\N	t
15	WC-P001A	Assembly Line - Main Factory	1	Main assembly line for Main Factory	480.00	\N	\N	t	2025-05-21 14:57:16.95612	2025-05-21 14:57:16.95612	ACTIVE	\N	\N	t
16	WC-W003P	Packaging - Asian Distribution Hub	8	Packaging workstation for Asian Distribution Hub	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE	\N	\N	t
17	WC-P004P	Packaging - Shanghai Facility	6	Packaging workstation for Shanghai Facility	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE	\N	\N	t
18	WC-p001P	Packaging - plant South East	4	Packaging workstation for plant South East	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE	\N	\N	t
19	WC-W004P	Packaging - UK Warehouse	9	Packaging workstation for UK Warehouse	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE	\N	\N	t
20	WC-W001P	Packaging - East Coast Warehouse	2	Packaging workstation for East Coast Warehouse	960.00	\N	\N	t	2025-05-21 14:57:26.598637	2025-05-21 14:57:26.598637	ACTIVE	\N	\N	t
21	WC-AB01	Abdul WC	1	Abdul Workcenter Demo	50.00	units/day	50.00	t	2025-05-21 16:40:07.940798	2025-05-21 16:40:07.940798	active	\N	\N	t
22	WC001	Test Work Center 001	1	Test work center	100.00	units/day	\N	t	2025-06-05 02:10:58.469163	2025-06-05 02:10:58.469163	active	\N	\N	t
24	WC1749089635928	Test Work Center 1749089635928	1	Test work center	100.00	units/day	\N	t	2025-06-05 02:14:02.101598	2025-06-05 02:14:02.101598	active	\N	\N	t
25	WC1749089708190	Test Work Center 1749089708190	1	Test work center	100.00	units/day	\N	t	2025-06-05 02:15:08.614264	2025-06-05 02:15:08.614264	active	\N	\N	t
26	WC1749089731713	Test Work Center 1749089731713	1	Test work center	100.00	units/day	\N	t	2025-06-05 02:15:32.153728	2025-06-05 02:15:32.153728	active	\N	\N	t
27	WC17490897	Test WC 1749089769754	1	Test work center	100.00	units/day	\N	t	2025-06-05 02:16:10.027247	2025-06-05 02:16:10.027247	active	\N	\N	t
\.


--
-- Data for Name: production_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_orders (id, order_number, material_id, bom_id, plant_id, work_center_id, order_type, planned_quantity, actual_quantity, scrap_quantity, unit_of_measure, planned_start_date, planned_end_date, actual_start_date, actual_end_date, priority, status, cost_center_id, created_by, released_by, release_date, notes, created_at, active, updated_at) FROM stdin;
1	PROD-2025-001	1	\N	\N	1	Production	100.000	85.000	0.000	\N	2025-06-01	2025-06-15	\N	\N	NORMAL	In Progress	\N	\N	\N	\N	\N	2025-06-04 01:16:16.078961	t	2025-06-04 18:39:30.207886+00
2	PROD-2025-002	2	\N	\N	2	Production	250.000	250.000	0.000	\N	2025-05-20	2025-06-10	\N	\N	NORMAL	Completed	\N	\N	\N	\N	\N	2025-06-04 01:16:16.078961	t	2025-06-04 18:39:30.207886+00
3	PROD-2025-003	3	\N	\N	3	Production	150.000	0.000	0.000	\N	2025-06-10	2025-06-25	\N	\N	NORMAL	Planned	\N	\N	\N	\N	\N	2025-06-04 01:16:16.078961	t	2025-06-04 18:39:30.207886+00
4	PROD-2025-004	4	\N	\N	1	Production	300.000	180.000	0.000	\N	2025-06-05	2025-06-20	\N	\N	NORMAL	In Progress	\N	\N	\N	\N	\N	2025-06-04 01:16:16.078961	t	2025-06-04 18:39:30.207886+00
5	PROD-2025-005	5	\N	\N	2	Production	75.000	75.000	0.000	\N	2025-05-25	2025-06-08	\N	\N	NORMAL	Completed	\N	\N	\N	\N	\N	2025-06-04 01:16:16.078961	t	2025-06-04 18:39:30.207886+00
\.


--
-- Data for Name: production_work_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_work_orders (id, production_order_id, material_id, work_center_id, quantity, start_date, end_date, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: purchase_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_groups (id, code, name, description, is_active, created_at, updated_at, created_by, updated_by, version, valid_from, valid_to, active) FROM stdin;
1	MECH	Mechanical Parts	Procurement group for mechanical components and parts	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N	t
2	ELEC	Electrical Components	Procurement group for electrical components and supplies	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N	t
3	RAW	Raw Materials	Basic raw materials used in manufacturing processes	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N	t
4	PACK	Packaging Materials	Materials used for packaging finished products	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N	t
5	TOOL	Tools & Equipment	Tools and equipment for maintenance and operations	t	2025-05-20 03:25:48.01028	2025-05-20 03:25:48.01028	\N	\N	1	2025-05-20 03:25:48.01028	\N	t
6	PG001	Raw Materials	Purchasing group for raw materials procurement	t	2025-05-20 04:52:27.386821	2025-05-20 04:52:27.386821	\N	\N	1	2025-05-20 04:52:27.386821	\N	t
7	PG002	Production Equipment	Purchasing group for manufacturing equipment	t	2025-05-20 04:52:27.427776	2025-05-20 04:52:27.427776	\N	\N	1	2025-05-20 04:52:27.427776	\N	t
8	PG003	Office Supplies	Purchasing group for office and administrative supplies	t	2025-05-20 04:52:27.459234	2025-05-20 04:52:27.459234	\N	\N	1	2025-05-20 04:52:27.459234	\N	t
9	PG004	IT Hardware	Purchasing group for computers and IT equipment	t	2025-05-20 04:52:27.490428	2025-05-20 04:52:27.490428	\N	\N	1	2025-05-20 04:52:27.490428	\N	t
10	PG005	Packaging Materials	Purchasing group for packaging supplies	t	2025-05-20 04:52:27.526279	2025-05-20 04:52:27.526279	\N	\N	1	2025-05-20 04:52:27.526279	\N	t
11	PG006	Services	Purchasing group for third-party services	t	2025-05-20 04:52:27.560699	2025-05-20 04:52:27.560699	\N	\N	1	2025-05-20 04:52:27.560699	\N	t
12	PG007	Maintenance	Purchasing group for maintenance supplies and services	t	2025-05-20 04:52:27.592969	2025-05-20 04:52:27.592969	\N	\N	1	2025-05-20 04:52:27.592969	\N	t
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order_items (id, purchase_order_id, line_number, material_id, description, quantity, unit_price, total_price, delivery_date, plant_id, storage_location_id, tax_code, discount_percent, received_quantity, invoiced_quantity, status, created_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: purchase_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_requests (id, description, amount, priority, cost_center_id, requester_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: purchasing_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchasing_groups (id, group_code, group_name, description, phone, email, responsible_person, active, created_at, updated_at) FROM stdin;
1	PUR001	Raw Materials Purchasing	Handles all raw material procurement	+1-555-0101	john.smith@company.com	John Smith	t	2025-06-05 16:53:42.34052+00	2025-06-05 16:53:42.34052+00
2	PUR002	Finished Goods Purchasing	Manages finished goods procurement	+1-555-0102	sarah.johnson@company.com	Sarah Johnson	t	2025-06-05 16:53:42.34052+00	2025-06-05 16:53:42.34052+00
3	PUR003	Services Purchasing	Responsible for service procurement	+1-555-0103	mike.davis@company.com	Mike Davis	t	2025-06-05 16:53:42.34052+00	2025-06-05 16:53:42.34052+00
4	PUR004	Equipment Purchasing	Handles equipment and machinery	+1-555-0104	lisa.wilson@company.com	Lisa Wilson	t	2025-06-05 16:53:42.34052+00	2025-06-05 16:53:42.34052+00
5	PUR005	Indirect Materials	Manages indirect material purchases	+1-555-0105	tom.brown@company.com	Tom Brown	t	2025-06-05 16:53:42.34052+00	2025-06-05 16:53:42.34052+00
\.


--
-- Data for Name: purchasing_organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchasing_organizations (id, org_code, org_name, description, company_code, plant_code, currency, address, phone, email, active, created_at, updated_at) FROM stdin;
1	PO01	Main Purchasing Organization	Primary procurement organization	CC01	PLT001	USD	123 Business Ave, City, State	\N	\N	t	2025-06-05 16:53:42.360363+00	2025-06-05 16:53:42.360363+00
2	PO02	Regional Purchasing West	West coast procurement hub	CC01	PLT002	USD	456 West St, Los Angeles, CA	\N	\N	t	2025-06-05 16:53:42.360363+00	2025-06-05 16:53:42.360363+00
3	PO03	Regional Purchasing East	East coast procurement hub	CC01	PLT003	USD	789 East Ave, New York, NY	\N	\N	t	2025-06-05 16:53:42.360363+00	2025-06-05 16:53:42.360363+00
4	PO04	International Purchasing	Global procurement operations	CC02	PLT004	EUR	321 Global Blvd, London, UK	\N	\N	t	2025-06-05 16:53:42.360363+00	2025-06-05 16:53:42.360363+00
5	PO05	Strategic Purchasing	Strategic sourcing and contracts	CC01	PLT001	USD	654 Strategy Lane, Chicago, IL	\N	\N	t	2025-06-05 16:53:42.360363+00	2025-06-05 16:53:42.360363+00
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotes (id, quote_number, opportunity_id, customer_id, status, valid_until, total_amount, discount_amount, tax_amount, grand_total, terms, notes, assigned_to, approval_status, approved_by, approved_at, rejected_reason, created_at, updated_at, active) FROM stdin;
1	Q-10000	4	\N	Draft	2025-07-20 23:38:47.725	31422.69	123.42	2190.95	33490.22	Net 30 days from invoice date	Quote for Taylor Consulting - Professional Services Solution	\N	Pending	\N	\N	\N	2025-05-21 23:38:47.735855	2025-05-21 23:38:47.735855	t
2	Q-10001	6	\N	Draft	2025-07-20 23:38:47.725	36841.54	2387.72	2411.77	36865.58	Net 30 days from invoice date	Quote for White Industries - Manufacturing Solution	\N	Pending	\N	\N	\N	2025-05-21 23:38:47.791841	2025-05-21 23:38:47.791841	t
3	Q-10002	7	\N	Draft	2025-07-20 23:38:47.725	69242.43	2302.19	4685.82	71626.05	Net 30 days from invoice date	Quote for Jones Retail - Retail Solution	\N	Pending	\N	\N	\N	2025-05-21 23:38:47.827033	2025-05-21 23:38:47.827033	t
4	Q-10003	8	\N	Draft	2025-07-20 23:38:47.725	86299.49	7798.41	5495.08	83996.15	Net 30 days from invoice date	Quote for Clark Financial - Financial Services Solution	\N	Pending	\N	\N	\N	2025-05-21 23:38:47.862695	2025-05-21 23:38:47.862695	t
5	Q-10004	13	\N	Draft	2025-07-20 23:38:47.725	24764.53	1062.54	1659.14	25361.13	Net 30 days from invoice date	Quote for Taylor Consulting - Additional Professional Services Project	\N	Pending	\N	\N	\N	2025-05-21 23:38:47.899481	2025-05-21 23:38:47.899481	t
6	Q-10005	14	\N	Draft	2025-07-20 23:38:47.725	14741.10	1285.18	941.92	14397.84	Net 30 days from invoice date	Quote for Lee Education Services - Additional Education Project	\N	Pending	\N	\N	\N	2025-05-21 23:38:47.952958	2025-05-21 23:38:47.952958	t
7	Q-10006	16	\N	Draft	2025-07-20 23:38:47.725	14007.43	1287.56	890.39	13610.26	Net 30 days from invoice date	Quote for Miller Tech Solutions - Additional Technology Project	\N	Pending	\N	\N	\N	2025-05-21 23:38:47.988115	2025-05-21 23:38:47.988115	t
\.


--
-- Data for Name: quote_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_approvals (id, quote_id, requested_by, requested_at, status, current_approver, approved_by, approved_at, rejected_by, rejected_at, rejection_reason, comments, approval_level, created_at, updated_at, active) FROM stdin;
7	7	2	2025-04-25 13:35:46.205	Rejected	\N	\N	\N	1	2025-04-28 13:35:46.205	Price is too high or terms need adjustment.	Quote needs revision.	Level 3	2025-05-22 13:35:46.206	2025-05-22 13:35:46.206	t
8	5	1	2025-05-12 13:35:46.235	Rejected	\N	\N	\N	2	2025-05-17 13:35:46.235	Price is too high or terms need adjustment.	Quote needs revision.	Level 2	2025-05-22 13:35:46.235	2025-05-22 13:35:46.235	t
9	7	2	2025-05-15 13:35:46.254	In Review	2	\N	\N	\N	\N	\N	Currently reviewing details.	Level 2	2025-05-22 13:35:46.254	2025-05-22 13:35:46.254	t
10	7	1	2025-04-25 13:35:46.271	In Review	1	\N	\N	\N	\N	\N	Currently reviewing details.	Level 3	2025-05-22 13:35:46.271	2025-05-22 13:35:46.271	t
11	6	2	2025-05-17 13:35:46.293	Rejected	\N	\N	\N	3	2025-05-21 13:35:46.293	Price is too high or terms need adjustment.	Quote needs revision.	Level 2	2025-05-22 13:35:46.293	2025-05-22 13:35:46.293	t
12	1	1	2025-05-22 13:35:46.329	Approved	\N	1	2025-05-23 13:35:46.329	\N	\N	\N	Quote looks good, approved.	Level 2	2025-05-22 13:35:46.329	2025-05-22 13:35:46.329	t
13	7	2	2025-05-05 13:35:46.346	Approved	\N	3	2025-05-08 13:35:46.346	\N	\N	\N	Quote looks good, approved.	Level 1	2025-05-22 13:35:46.346	2025-05-22 13:35:46.346	t
14	2	1	2025-04-27 13:35:46.363	In Review	2	\N	\N	\N	\N	\N	Currently reviewing details.	Level 2	2025-05-22 13:35:46.363	2025-05-22 13:35:46.363	t
15	1	2	2025-05-04 13:35:46.385	Pending	2	\N	\N	\N	\N	\N	Awaiting review	Level 2	2025-05-22 13:35:46.385	2025-05-22 13:35:46.385	t
16	2	1	2025-04-23 13:35:46.404	In Review	2	\N	\N	\N	\N	\N	Currently reviewing details.	Level 3	2025-05-22 13:35:46.404	2025-05-22 13:35:46.404	t
\.


--
-- Data for Name: quote_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_items (id, quote_id, product_id, description, quantity, unit_price, discount_percent, tax_percent, line_total, created_at, updated_at, active) FROM stdin;
1	1	13	Desktop PC	4	999.99	1.00	7.00	4237.16	2025-05-21 23:38:47.755728	2025-05-21 23:38:47.755728	t
2	1	11	Smartphone	4	899.99	2.00	7.00	3774.92	2025-05-21 23:38:47.774319	2025-05-21 23:38:47.774319	t
3	2	1	Premium Laptop	4	1299.99	8.00	7.00	5118.84	2025-05-21 23:38:47.809738	2025-05-21 23:38:47.809738	t
4	3	18	Router	1	149.99	0.00	7.00	160.49	2025-05-21 23:38:47.844784	2025-05-21 23:38:47.844784	t
5	4	8	Bluetooth Speaker	1	79.99	7.00	7.00	79.60	2025-05-21 23:38:47.88047	2025-05-21 23:38:47.88047	t
6	5	1	Premium Laptop	2	1299.99	6.00	7.00	2615.06	2025-05-21 23:38:47.917178	2025-05-21 23:38:47.917178	t
7	5	16	Webcam	4	59.99	7.00	7.00	238.78	2025-05-21 23:38:47.935082	2025-05-21 23:38:47.935082	t
8	6	5	Smart Watch	1	349.99	8.00	7.00	344.53	2025-05-21 23:38:47.970515	2025-05-21 23:38:47.970515	t
9	7	18	Router	1	149.99	8.00	7.00	147.65	2025-05-21 23:38:48.005675	2025-05-21 23:38:48.005675	t
10	7	16	Webcam	1	59.99	4.00	7.00	61.62	2025-05-21 23:38:48.023953	2025-05-21 23:38:48.023953	t
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reports (id, name, description, sql_query, chart_config, category, created_at, updated_at, active) FROM stdin;
1	Sales by Month	Monthly sales revenue analysis	SELECT \n        DATE_TRUNC('month', order_date) as month,\n        COUNT(*) as order_count,\n        SUM(total_amount) as total_revenue\n    FROM sales_orders \n    WHERE order_date >= CURRENT_DATE - INTERVAL '12 months'\n    GROUP BY DATE_TRUNC('month', order_date)\n    ORDER BY month	{"type": "line", "xAxis": "month", "yAxis": "total_revenue", "showLegend": true}	sales	2025-06-04 17:17:13.453916	2025-06-04 17:17:13.453916	t
2	Top Customers by Revenue	Customers with highest revenue contribution	SELECT \n        c.name as customer_name,\n        COUNT(so.id) as order_count,\n        SUM(so.total_amount) as total_revenue\n    FROM customers c\n    JOIN sales_orders so ON c.id = so.customer_id\n    GROUP BY c.id, c.name\n    ORDER BY total_revenue DESC\n    LIMIT 10	{"type": "bar", "xAxis": "customer_name", "yAxis": "total_revenue", "showLegend": false}	sales	2025-06-04 17:17:13.453916	2025-06-04 17:17:13.453916	t
3	Inventory Levels by Category	Current inventory levels grouped by material category	SELECT \n        cat.name as category_name,\n        COUNT(m.id) as material_count,\n        SUM(inv.quantity) as total_quantity\n    FROM categories cat\n    JOIN materials m ON cat.id = m.category_id\n    JOIN inventory inv ON m.id = inv.material_id\n    GROUP BY cat.id, cat.name\n    ORDER BY total_quantity DESC	{"type": "pie", "dataKey": "total_quantity", "nameKey": "category_name", "showLegend": true}	inventory	2025-06-04 17:17:13.453916	2025-06-04 17:17:13.453916	t
4	Cost Center Expenses	Expenses by cost center for current year	SELECT \n        cc.name as cost_center,\n        SUM(e.amount) as total_expenses\n    FROM cost_centers cc\n    LEFT JOIN expenses e ON cc.id = e.cost_center_id\n    WHERE e.expense_date >= DATE_TRUNC('year', CURRENT_DATE)\n    GROUP BY cc.id, cc.name\n    ORDER BY total_expenses DESC	{"type": "bar", "xAxis": "cost_center", "yAxis": "total_expenses", "showLegend": false}	finance	2025-06-04 17:17:13.453916	2025-06-04 17:17:13.453916	t
5	Purchase Orders by Vendor	Purchase order volumes by vendor	SELECT \n        v.name as vendor_name,\n        COUNT(po.id) as order_count,\n        SUM(po.total_amount) as total_amount\n    FROM vendors v\n    JOIN purchase_orders po ON v.id = po.vendor_id\n    WHERE po.order_date >= CURRENT_DATE - INTERVAL '6 months'\n    GROUP BY v.id, v.name\n    ORDER BY total_amount DESC\n    LIMIT 10	{"type": "bar", "xAxis": "vendor_name", "yAxis": "total_amount", "showLegend": false}	purchase	2025-06-04 17:17:13.453916	2025-06-04 17:17:13.453916	t
\.


--
-- Data for Name: sales_customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_customers (id, customer_number, company_name, contact_person, email, phone, website, industry, customer_type, billing_address, shipping_address, tax_id, payment_terms, credit_limit, status, notes, created_at, updated_at, active) FROM stdin;
1	CUST-1001	TechNova Inc	John Smith	john.smith@technova.com	(555) 123-4567	www.technova.com	Technology	Business	\N	\N	\N	\N	50000.00	Active	\N	2025-05-23 02:20:10.071348+00	2025-05-23 02:20:10.071348+00	t
2	CUST-1002	Elevate Solutions	Sarah Johnson	sarah@elevatesolutions.com	(555) 234-5678	www.elevatesolutions.com	Consulting	Business	\N	\N	\N	\N	35000.00	Active	\N	2025-05-23 02:20:10.071348+00	2025-05-23 02:20:10.071348+00	t
3	CUST-1003	DataWave Analytics	Michael Chen	michael@datawave.com	(555) 345-6789	www.datawave.com	Data Services	Business	\N	\N	\N	\N	75000.00	Active	\N	2025-05-23 02:20:10.071348+00	2025-05-23 02:20:10.071348+00	t
4	CUST-1004	Quantum Systems	Emily Rodriguez	emily@quantumsystems.com	(555) 456-7890	www.quantumsystems.com	Manufacturing	Business	\N	\N	\N	\N	100000.00	Active	\N	2025-05-23 02:20:10.071348+00	2025-05-23 02:20:10.071348+00	t
5	CUST-1005	Arctic Innovations	David Wilson	david@arcticinnovations.com	(555) 567-8901	www.arcticinnovations.com	Research	Business	\N	\N	\N	\N	25000.00	Active	\N	2025-05-23 02:20:10.071348+00	2025-05-23 02:20:10.071348+00	t
6	CUST-1006	Sunrise Healthcare	Lisa Morgan	lisa@sunrisehealthcare.com	(555) 678-9012	www.sunrisehealthcare.com	Healthcare	Business	\N	\N	\N	\N	40000.00	Inactive	\N	2025-05-23 02:20:10.071348+00	2025-05-23 02:20:10.071348+00	t
7	CUST-1007	Velocity Logistics	Robert Brown	robert@velocitylogistics.com	(555) 789-0123	www.velocitylogistics.com	Transportation	Business	\N	\N	\N	\N	60000.00	Active	\N	2025-05-23 02:20:10.071348+00	2025-05-23 02:20:10.071348+00	t
\.


--
-- Data for Name: sales_customer_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_customer_contacts (id, customer_id, name, "position", email, phone, is_primary, notes, created_at, updated_at, active) FROM stdin;
1	1	John Smith	Primary Contact	john.smith@technova.com	(555) 123-4567	t	\N	2025-05-23 02:20:10.142606+00	2025-05-23 02:20:10.142606+00	t
2	2	Sarah Johnson	Primary Contact	sarah@elevatesolutions.com	(555) 234-5678	t	\N	2025-05-23 02:20:10.160107+00	2025-05-23 02:20:10.160107+00	t
3	2	Tom Baker	Finance Director	tom@elevatesolutions.com	(555) 541-3019	f	\N	2025-05-23 02:20:10.176177+00	2025-05-23 02:20:10.176177+00	t
4	3	Michael Chen	Primary Contact	michael@datawave.com	(555) 345-6789	t	\N	2025-05-23 02:20:10.192015+00	2025-05-23 02:20:10.192015+00	t
5	3	Tom Baker	Technical Lead	tom@datawave.com	(555) 736-3307	f	\N	2025-05-23 02:20:10.207854+00	2025-05-23 02:20:10.207854+00	t
6	4	Emily Rodriguez	Primary Contact	emily@quantumsystems.com	(555) 456-7890	t	\N	2025-05-23 02:20:10.223908+00	2025-05-23 02:20:10.223908+00	t
7	4	Jessica Lee	Technical Lead	jessica@quantumsystems.com	(555) 464-2074	f	\N	2025-05-23 02:20:10.240059+00	2025-05-23 02:20:10.240059+00	t
8	5	David Wilson	Primary Contact	david@arcticinnovations.com	(555) 567-8901	t	\N	2025-05-23 02:20:10.257459+00	2025-05-23 02:20:10.257459+00	t
9	5	Jessica Lee	Technical Lead	jessica@arcticinnovations.com	(555) 186-3388	f	\N	2025-05-23 02:20:10.273451+00	2025-05-23 02:20:10.273451+00	t
10	6	Lisa Morgan	Primary Contact	lisa@sunrisehealthcare.com	(555) 678-9012	t	\N	2025-05-23 02:20:10.289534+00	2025-05-23 02:20:10.289534+00	t
11	7	Robert Brown	Primary Contact	robert@velocitylogistics.com	(555) 789-0123	t	\N	2025-05-23 02:20:10.305579+00	2025-05-23 02:20:10.305579+00	t
\.


--
-- Data for Name: sales_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_invoices (id, invoice_number, order_id, customer_name, invoice_date, due_date, status, total_amount, discount_amount, tax_amount, grand_total, paid_amount, payment_method, payment_date, notes, created_by, created_at, updated_at, active) FROM stdin;
1	INV-2025-1001	\N	TechNova Inc	2025-05-03 02:20:07.072407+00	2025-05-18 02:20:07.072407+00	Paid	5649.75	0.00	0.00	5932.24	5932.24	Credit Card	2025-05-16 02:20:07.072407+00	\N	\N	2025-05-23 02:20:07.072407+00	2025-05-23 02:20:07.072407+00	t
2	INV-2025-1002	\N	Elevate Solutions	2025-05-05 02:20:07.072407+00	2025-05-20 02:20:07.072407+00	Paid	2375.50	0.00	0.00	2494.28	2494.28	Bank Transfer	2025-05-17 02:20:07.072407+00	\N	\N	2025-05-23 02:20:07.072407+00	2025-05-23 02:20:07.072407+00	t
3	INV-2025-1003	\N	DataWave Analytics	2025-05-08 02:20:07.072407+00	2025-06-07 02:20:07.072407+00	Partially Paid	8925.33	0.00	0.00	9371.60	4000.00	Bank Transfer	2025-05-13 02:20:07.072407+00	\N	\N	2025-05-23 02:20:07.072407+00	2025-05-23 02:20:07.072407+00	t
4	INV-2025-1004	\N	Quantum Systems	2025-05-13 02:20:07.072407+00	2025-06-12 02:20:07.072407+00	Unpaid	3450.20	0.00	0.00	3622.71	0.00	\N	\N	\N	\N	2025-05-23 02:20:07.072407+00	2025-05-23 02:20:07.072407+00	t
5	INV-2025-1005	\N	Arctic Innovations	2025-05-16 02:20:07.072407+00	2025-06-15 02:20:07.072407+00	Unpaid	1875.60	0.00	0.00	1969.38	0.00	\N	\N	\N	\N	2025-05-23 02:20:07.072407+00	2025-05-23 02:20:07.072407+00	t
\.


--
-- Data for Name: sales_invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_invoice_items (id, invoice_id, product_name, description, quantity, unit_price, discount_percent, tax_percent, subtotal, created_at, updated_at, active) FROM stdin;
1	1	Enterprise SaaS License	Annual subscription	5	1299.99	0.00	0.00	6499.95	2025-05-23 02:20:07.133409+00	2025-05-23 02:20:07.133409+00	t
2	2	Network Infrastructure	Network hardware and setup	2	2499.50	0.00	0.00	4999.00	2025-05-23 02:20:07.151846+00	2025-05-23 02:20:07.151846+00	t
3	3	Data Analytics Platform	Business intelligence tools	1	1499.75	0.00	0.00	1499.75	2025-05-23 02:20:07.167522+00	2025-05-23 02:20:07.167522+00	t
4	3	Data Analytics Platform	Business intelligence tools	3	1499.75	0.00	0.00	4499.25	2025-05-23 02:20:07.183249+00	2025-05-23 02:20:07.183249+00	t
5	3	Cloud Security Package	Advanced security suite	4	899.50	0.00	0.00	3598.00	2025-05-23 02:20:07.198912+00	2025-05-23 02:20:07.198912+00	t
6	4	Cloud Security Package	Advanced security suite	5	899.50	0.00	0.00	4497.50	2025-05-23 02:20:07.214642+00	2025-05-23 02:20:07.214642+00	t
7	4	Cloud Security Package	Advanced security suite	4	899.50	0.00	0.00	3598.00	2025-05-23 02:20:07.230456+00	2025-05-23 02:20:07.230456+00	t
8	5	Mobile Device Management	Enterprise mobility solution	1	699.99	0.00	0.00	699.99	2025-05-23 02:20:07.246834+00	2025-05-23 02:20:07.246834+00	t
9	5	Mobile Device Management	Enterprise mobility solution	3	699.99	0.00	0.00	2099.97	2025-05-23 02:20:07.262681+00	2025-05-23 02:20:07.262681+00	t
\.


--
-- Data for Name: sales_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_order_items (id, order_id, product_id, product_name, quantity, unit_price, discount_percent, tax_percent, subtotal, created_at, updated_at, active) FROM stdin;
1	1	\N	Network Infrastructure	4	2499.50	0.00	0.00	9998.00	2025-05-23 02:19:58.99797+00	2025-05-23 02:19:58.99797+00	t
2	1	\N	Enterprise SaaS License	4	1299.99	0.00	0.00	5199.96	2025-05-23 02:19:59.015933+00	2025-05-23 02:19:59.015933+00	t
3	2	\N	Cloud Security Package	5	899.50	0.00	0.00	4497.50	2025-05-23 02:19:59.031645+00	2025-05-23 02:19:59.031645+00	t
4	3	\N	Enterprise SaaS License	5	1299.99	0.00	0.00	6499.95	2025-05-23 02:19:59.047403+00	2025-05-23 02:19:59.047403+00	t
5	3	\N	Enterprise SaaS License	5	1299.99	0.00	0.00	6499.95	2025-05-23 02:19:59.063361+00	2025-05-23 02:19:59.063361+00	t
6	4	\N	Cloud Security Package	3	899.50	0.00	0.00	2698.50	2025-05-23 02:19:59.07912+00	2025-05-23 02:19:59.07912+00	t
7	4	\N	Cloud Security Package	5	899.50	0.00	0.00	4497.50	2025-05-23 02:19:59.094803+00	2025-05-23 02:19:59.094803+00	t
8	4	\N	Data Analytics Platform	5	1499.75	0.00	0.00	7498.75	2025-05-23 02:19:59.110759+00	2025-05-23 02:19:59.110759+00	t
9	5	\N	Data Analytics Platform	4	1499.75	0.00	0.00	5999.00	2025-05-23 02:19:59.126744+00	2025-05-23 02:19:59.126744+00	t
10	5	\N	Enterprise SaaS License	3	1299.99	0.00	0.00	3899.97	2025-05-23 02:19:59.142363+00	2025-05-23 02:19:59.142363+00	t
11	5	\N	Enterprise SaaS License	5	1299.99	0.00	0.00	6499.95	2025-05-23 02:19:59.158064+00	2025-05-23 02:19:59.158064+00	t
\.


--
-- Data for Name: sales_quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_quotes (id, quote_number, opportunity_id, customer_name, quote_date, valid_until, status, total_amount, discount_amount, tax_amount, grand_total, notes, terms_conditions, created_by, created_at, updated_at, active) FROM stdin;
1	QT-2025-1001	\N	TechNova Inc	2025-05-08 02:20:05.38177+00	2025-07-07 02:20:05.38177+00	Sent	6200.00	0.00	0.00	6510.00	\N	Net 30 payment terms. Quoted prices valid for 60 days.	\N	2025-05-23 02:20:05.38177+00	2025-05-23 02:20:05.38177+00	t
2	QT-2025-1002	\N	Elevate Solutions	2025-05-11 02:20:05.38177+00	2025-07-10 02:20:05.38177+00	Draft	3750.50	0.00	0.00	3938.03	\N	Net 30 payment terms. Quoted prices valid for 60 days.	\N	2025-05-23 02:20:05.38177+00	2025-05-23 02:20:05.38177+00	t
3	QT-2025-1003	\N	DataWave Analytics	2025-05-13 02:20:05.38177+00	2025-07-12 02:20:05.38177+00	Approved	9200.00	0.00	0.00	9660.00	\N	Net 30 payment terms. Quoted prices valid for 60 days.	\N	2025-05-23 02:20:05.38177+00	2025-05-23 02:20:05.38177+00	t
4	QT-2025-1004	\N	Quantum Systems	2025-05-16 02:20:05.38177+00	2025-07-15 02:20:05.38177+00	Rejected	4800.75	0.00	0.00	5040.79	\N	Net 30 payment terms. Quoted prices valid for 60 days.	\N	2025-05-23 02:20:05.38177+00	2025-05-23 02:20:05.38177+00	t
5	QT-2025-1005	\N	Arctic Innovations	2025-05-18 02:20:05.38177+00	2025-07-17 02:20:05.38177+00	Sent	2350.25	0.00	0.00	2467.76	\N	Net 30 payment terms. Quoted prices valid for 60 days.	\N	2025-05-23 02:20:05.38177+00	2025-05-23 02:20:05.38177+00	t
\.


--
-- Data for Name: sales_quote_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_quote_items (id, quote_id, product_name, description, quantity, unit_price, discount_percent, tax_percent, subtotal, created_at, updated_at, active) FROM stdin;
1	1	Technical Support Plan	24/7 technical support	2	499.99	0.00	0.00	999.98	2025-05-23 02:20:05.446439+00	2025-05-23 02:20:05.446439+00	t
2	1	Cloud Security Package	Advanced security suite	5	899.50	0.00	0.00	4497.50	2025-05-23 02:20:05.464681+00	2025-05-23 02:20:05.464681+00	t
3	2	Data Analytics Platform	Business intelligence tools	3	1499.75	0.00	0.00	4499.25	2025-05-23 02:20:05.481121+00	2025-05-23 02:20:05.481121+00	t
4	2	Network Infrastructure	Network hardware and setup	3	2499.50	0.00	0.00	7498.50	2025-05-23 02:20:05.497218+00	2025-05-23 02:20:05.497218+00	t
5	2	Data Analytics Platform	Business intelligence tools	3	1499.75	0.00	0.00	4499.25	2025-05-23 02:20:05.513114+00	2025-05-23 02:20:05.513114+00	t
6	3	Enterprise SaaS License	Annual subscription	3	1299.99	0.00	0.00	3899.97	2025-05-23 02:20:05.529484+00	2025-05-23 02:20:05.529484+00	t
7	4	Data Analytics Platform	Business intelligence tools	2	1499.75	0.00	0.00	2999.50	2025-05-23 02:20:05.545361+00	2025-05-23 02:20:05.545361+00	t
8	4	Custom Development	Custom software development (hourly)	5	150.00	0.00	0.00	750.00	2025-05-23 02:20:05.561196+00	2025-05-23 02:20:05.561196+00	t
9	4	Cloud Security Package	Advanced security suite	4	899.50	0.00	0.00	3598.00	2025-05-23 02:20:05.576626+00	2025-05-23 02:20:05.576626+00	t
10	5	Data Analytics Platform	Business intelligence tools	5	1499.75	0.00	0.00	7498.75	2025-05-23 02:20:05.592399+00	2025-05-23 02:20:05.592399+00	t
11	5	Custom Development	Custom software development (hourly)	2	150.00	0.00	0.00	300.00	2025-05-23 02:20:05.609084+00	2025-05-23 02:20:05.609084+00	t
12	5	Network Infrastructure	Network hardware and setup	3	2499.50	0.00	0.00	7498.50	2025-05-23 02:20:05.624837+00	2025-05-23 02:20:05.624837+00	t
\.


--
-- Data for Name: sales_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_returns (id, return_number, order_id, invoice_id, customer_name, return_date, status, total_amount, return_reason, notes, created_by, created_at, updated_at, active) FROM stdin;
1	RET-2025-1001	\N	\N	TechNova Inc	2025-05-13 02:20:08.463433+00	Completed	1299.99	Product not needed anymore	\N	\N	2025-05-23 02:20:08.463433+00	2025-05-23 02:20:08.463433+00	t
2	RET-2025-1002	\N	\N	Elevate Solutions	2025-05-16 02:20:08.463433+00	Processing	899.50	Incompatible with current systems	\N	\N	2025-05-23 02:20:08.463433+00	2025-05-23 02:20:08.463433+00	t
3	RET-2025-1003	\N	\N	DataWave Analytics	2025-05-18 02:20:08.463433+00	Approved	699.99	Duplicate order	\N	\N	2025-05-23 02:20:08.463433+00	2025-05-23 02:20:08.463433+00	t
4	RET-2025-1004	\N	\N	Quantum Systems	2025-05-20 02:20:08.463433+00	Pending	1499.75	Wrong product received	\N	\N	2025-05-23 02:20:08.463433+00	2025-05-23 02:20:08.463433+00	t
\.


--
-- Data for Name: sales_return_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_return_items (id, return_id, product_name, quantity, unit_price, subtotal, return_reason, condition, created_at, updated_at, active) FROM stdin;
1	1	Data Analytics Platform	2	1499.75	2999.50	\N	New	2025-05-23 02:20:08.524521+00	2025-05-23 02:20:08.524521+00	t
2	1	Enterprise SaaS License	1	1299.99	1299.99	\N	Like New	2025-05-23 02:20:08.541858+00	2025-05-23 02:20:08.541858+00	t
3	2	Cloud Security Package	2	899.50	1799.00	\N	Damaged	2025-05-23 02:20:08.557869+00	2025-05-23 02:20:08.557869+00	t
4	3	Enterprise SaaS License	2	1299.99	2599.98	\N	Used	2025-05-23 02:20:08.573484+00	2025-05-23 02:20:08.573484+00	t
5	3	Network Infrastructure	2	2499.50	4999.00	\N	Used	2025-05-23 02:20:08.589491+00	2025-05-23 02:20:08.589491+00	t
6	4	Data Analytics Platform	1	1499.75	1499.75	\N	Like New	2025-05-23 02:20:08.60648+00	2025-05-23 02:20:08.60648+00	t
7	4	Network Infrastructure	1	2499.50	2499.50	\N	New	2025-05-23 02:20:08.622107+00	2025-05-23 02:20:08.622107+00	t
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, product_id, type, quantity, reason, date, user_id, created_at, active, updated_at) FROM stdin;
4	2	Return	29	Wrong item return	2025-05-05 13:40:07.915	1	2025-05-22 13:40:07.915	t	2025-06-04 18:39:31.543654+00
5	5	Return	80	Customer order cancellation	2025-01-24 13:40:07.915	1	2025-05-22 13:40:07.937	t	2025-06-04 18:39:31.543654+00
6	10	Transfer	78	Cross-docking operation	2025-03-19 13:40:07.915	1	2025-05-22 13:40:07.954	t	2025-06-04 18:39:31.543654+00
7	7	Adjustment	26	System data correction	2024-12-16 13:40:07.915	1	2025-05-22 13:40:07.974	t	2025-06-04 18:39:31.543654+00
8	2	Receipt	81	Return from customer	2025-01-19 13:40:07.915	1	2025-05-22 13:40:07.992	t	2025-06-04 18:39:31.543654+00
9	3	Issue	37	Sample issuance	2025-02-03 13:40:07.915	1	2025-05-22 13:40:08.018	t	2025-06-04 18:39:31.543654+00
10	8	Transfer	39	Relocation optimization	2025-02-11 13:40:07.915	1	2025-05-22 13:40:08.038	t	2025-06-04 18:39:31.543654+00
11	5	Issue	95	Damaged goods disposal	2024-12-22 13:40:07.915	1	2025-05-22 13:40:08.057	t	2025-06-04 18:39:31.543654+00
12	7	Receipt	30	Transfer from another location	2025-02-22 13:40:07.915	1	2025-05-22 13:40:08.076	t	2025-06-04 18:39:31.543654+00
13	6	Receipt	55	Return from customer	2025-01-11 13:40:07.915	1	2025-05-22 13:40:08.098	t	2025-06-04 18:39:31.543654+00
14	1	Receipt	72	Inventory count adjustment	2025-02-14 13:40:07.915	1	2025-05-22 13:40:08.116	t	2025-06-04 18:39:31.543654+00
15	9	Receipt	40	Return from customer	2025-04-20 13:40:07.915	1	2025-05-22 13:40:08.136	t	2025-06-04 18:39:31.543654+00
16	10	Adjustment	41	System data correction	2025-04-08 13:40:07.915	1	2025-05-22 13:40:08.154	t	2025-06-04 18:39:31.543654+00
17	2	Return	86	Wrong item return	2025-05-07 13:40:07.915	1	2025-05-22 13:40:08.176	t	2025-06-04 18:39:31.543654+00
18	4	Issue	27	Sales order fulfillment	2024-11-27 13:40:07.915	1	2025-05-22 13:40:08.194	t	2025-06-04 18:39:31.543654+00
19	7	Transfer	3	Relocation optimization	2024-12-28 13:40:07.915	1	2025-05-22 13:40:08.213	t	2025-06-04 18:39:31.543654+00
20	5	Issue	45	Damaged goods disposal	2024-12-05 13:40:07.915	1	2025-05-22 13:40:08.23	t	2025-06-04 18:39:31.543654+00
21	3	Transfer	35	Warehouse rebalancing	2025-04-08 13:40:07.915	1	2025-05-22 13:40:08.249	t	2025-06-04 18:39:31.543654+00
22	2	Transfer	22	Warehouse rebalancing	2025-05-04 13:40:07.915	1	2025-05-22 13:40:08.271	t	2025-06-04 18:39:31.543654+00
23	8	Return	88	Customer order cancellation	2025-01-04 13:40:07.915	1	2025-05-22 13:40:08.295	t	2025-06-04 18:39:31.543654+00
24	8	Receipt	23	Production output	2025-05-13 13:40:07.915	1	2025-05-22 13:40:08.326	t	2025-06-04 18:39:31.543654+00
25	10	Return	52	Damaged goods return	2025-03-21 13:40:07.915	1	2025-05-22 13:40:08.344	t	2025-06-04 18:39:31.543654+00
26	8	Issue	79	Sales order fulfillment	2025-02-05 13:40:07.915	1	2025-05-22 13:40:08.363	t	2025-06-04 18:39:31.543654+00
27	7	Receipt	24	Production output	2025-02-07 13:40:07.915	1	2025-05-22 13:40:08.387	t	2025-06-04 18:39:31.543654+00
28	1	Transfer	39	Warehouse rebalancing	2025-03-02 13:40:07.915	1	2025-05-22 13:40:08.407	t	2025-06-04 18:39:31.543654+00
\.


--
-- Data for Name: supply_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_types (id, code, name, description, is_active, created_at, updated_at, created_by, updated_by, version, valid_from, valid_to, active) FROM stdin;
1	DIR	Direct Materials	Materials directly used in manufacturing products	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N	t
2	IND	Indirect Materials	Materials indirectly used in manufacturing	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N	t
3	SERV	Services	Service-related procurement	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N	t
4	CAPEX	Capital Expenditure	Large equipment and capital investments	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N	t
5	MRO	Maintenance & Repair	Maintenance, repair, and operations supplies	t	2025-05-20 03:25:53.97972	2025-05-20 03:25:53.97972	\N	\N	1	2025-05-20 03:25:53.97972	\N	t
6	ST001	Direct Materials	Materials directly used in manufacturing	t	2025-05-20 04:52:27.64864	2025-05-20 04:52:27.64864	\N	\N	1	2025-05-20 04:52:27.64864	\N	t
7	ST002	Indirect Materials	Materials not directly used in manufacturing	t	2025-05-20 04:52:27.683957	2025-05-20 04:52:27.683957	\N	\N	1	2025-05-20 04:52:27.683957	\N	t
8	ST003	Capital Equipment	Long-term assets and equipment	t	2025-05-20 04:52:27.71506	2025-05-20 04:52:27.71506	\N	\N	1	2025-05-20 04:52:27.71506	\N	t
9	ST004	Services	External services and contracted work	t	2025-05-20 04:52:27.75151	2025-05-20 04:52:27.75151	\N	\N	1	2025-05-20 04:52:27.75151	\N	t
10	ST005	Trading Goods	Finished goods purchased for resale	t	2025-05-20 04:52:27.788036	2025-05-20 04:52:27.788036	\N	\N	1	2025-05-20 04:52:27.788036	\N	t
11	ST006	MRO Supplies	Maintenance, repair, and operations supplies	t	2025-05-20 04:52:27.83183	2025-05-20 04:52:27.83183	\N	\N	1	2025-05-20 04:52:27.83183	\N	t
\.


--
-- Data for Name: system_error_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_error_logs (id, "timestamp", level, module, message, stack, additional_data, created_at) FROM stdin;
1	2025-06-04 22:52:27.68+00	ERROR	DemoModule	Testing dual storage system	\N	{"user": "admin", "action": "test"}	2025-06-04 22:52:30.152222+00
2	2025-06-04 23:01:05.997+00	INFO	CompanyCode	Creating new company code	\N	{"code": "PO01", "name": "PPPP", "country": "United States", "currency": "USD"}	2025-06-04 23:01:06.086381+00
3	2025-06-04 23:01:06.13+00	ERROR	CompanyCode	Failed to create company code	error: value too long for type character varying(2)\n    at file:///home/runner/workspace/node_modules/@neondatabase/serverless/index.mjs:1345:74\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async <anonymous> (/home/runner/workspace/server/routes.ts:197:22)	{"errorCode": "22001", "requestBody": {"city": "", "code": "PO01", "name": "PPPP", "phone": "", "state": "", "taxId": "", "address": "", "country": "United States", "currency": "USD", "isActive": true, "fiscalYear": "Calendar Year (Jan-Dec)", "postalCode": "", "description": ""}, "errorMessage": "value too long for type character varying(2)"}	2025-06-04 23:01:06.214482+00
4	2025-06-04 23:02:37.867+00	INFO	CompanyCode	Creating new company code	\N	{"code": "PO01", "name": "PPPP", "country": "United States", "currency": "USD"}	2025-06-04 23:02:37.939264+00
5	2025-06-04 23:02:37.969+00	ERROR	CompanyCode	Failed to create company code	error: duplicate key value violates unique constraint "company_codes_pkey"\n    at file:///home/runner/workspace/node_modules/@neondatabase/serverless/index.mjs:1345:74\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)\n    at async <anonymous> (/home/runner/workspace/server/routes.ts:197:22)	{"errorCode": "23505", "requestBody": {"city": "", "code": "PO01", "name": "PPPP", "phone": "", "state": "", "taxId": "", "address": "", "country": "United States", "currency": "USD", "isActive": true, "fiscalYear": "Calendar Year (Jan-Dec)", "postalCode": "", "description": ""}, "errorMessage": "duplicate key value violates unique constraint \\"company_codes_pkey\\""}	2025-06-04 23:02:37.979096+00
6	2025-06-04 23:15:32.132+00	INFO	CompanyCode	Creating new company code	\N	{"code": "TEST01", "name": "Test Company with Zero Errors", "country": "United States", "currency": "USD"}	2025-06-04 23:15:35.920817+00
7	2025-06-04 23:15:36.016+00	INFO	CompanyCode	Company code created successfully	\N	{"id": 3, "code": "TEST01", "name": "Test Company with Zero Errors"}	2025-06-04 23:15:36.025585+00
8	2025-06-04 23:42:48.382+00	INFO	ZeroErrorDataHandler	Successfully saved data to company_codes on attempt 1	\N	{"attempts": 1, "operation": "INSERT", "tableName": "company_codes", "fixesApplied": []}	2025-06-04 23:42:48.394913+00
9	2025-06-04 23:42:48.303+00	INFO	CompanyCode	Creating new company code	\N	{"code": "4000", "name": "Pr 0004", "country": "United States", "currency": "USD"}	2025-06-04 23:42:50.371321+00
10	2025-06-04 23:42:48.383+00	INFO	CompanyCode	Company code created successfully	\N	{"id": 4, "code": "4000", "name": "Pr 0004", "fixesApplied": []}	2025-06-04 23:42:50.445464+00
11	2025-06-05 00:41:21.57+00	INFO	CompanyCode	Creating new company code	\N	{"code": "TEST", "name": "Test Company", "country": "United States", "currency": "USD"}	2025-06-05 00:41:22.003391+00
13	2025-06-05 00:41:23.733+00	INFO	CompanyCode	Company code created successfully	\N	{"id": 5, "code": "TEST", "name": "Test Company", "fixesApplied": []}	2025-06-05 00:41:23.743865+00
12	2025-06-05 00:41:23.732+00	INFO	ZeroErrorDataHandler	Successfully saved data to company_codes on attempt 1	\N	{"attempts": 1, "operation": "INSERT", "tableName": "company_codes", "fixesApplied": []}	2025-06-05 00:41:23.743447+00
14	2025-06-05 00:43:32.622+00	INFO	CompanyCode	Creating new company code	\N	{"code": "TEST", "name": "Test Company", "country": "United States", "currency": "USD"}	2025-06-05 00:43:32.907226+00
15	2025-06-05 00:43:33.171+00	WARN	CompanyCode	Attempted to create duplicate company code	\N	{"code": "TEST"}	2025-06-05 00:43:33.885045+00
16	2025-06-05 00:46:18.875+00	INFO	CompanyCode	Creating new company code	\N	{"code": "TEST", "name": "Test Company", "country": "United States", "currency": "USD"}	2025-06-05 00:46:18.940258+00
17	2025-06-05 00:46:18.959+00	WARN	CompanyCode	Attempted to create duplicate company code	\N	{"code": "TEST"}	2025-06-05 00:46:19.045688+00
18	2025-06-05 00:46:55.758+00	INFO	CompanyCode	Creating new company code	\N	{"code": "PROD1", "name": "Production Company 1", "country": "US", "currency": "USD"}	2025-06-05 00:46:55.842606+00
19	2025-06-05 00:46:55.873+00	INFO	ZeroErrorDataHandler	Successfully saved data to company_codes on attempt 1	\N	{"attempts": 1, "operation": "INSERT", "tableName": "company_codes", "fixesApplied": []}	2025-06-05 00:46:55.883821+00
20	2025-06-05 00:46:55.873+00	INFO	CompanyCode	Company code created successfully	\N	{"id": 6, "code": "PROD1", "name": "Production Company 1", "fixesApplied": []}	2025-06-05 00:46:55.886024+00
\.


--
-- Data for Name: tax_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_codes (id, code, name, country, tax_type, percentage, description, is_active, created_at, updated_at, active) FROM stdin;
1	US-EX	US Exempt	US	SALES	0.00	Tax exempt sales in US	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264	t
2	US-STD	US Standard	US	SALES	6.00	Standard US sales tax	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264	t
3	US-NY	New York	US	SALES	8.88	New York City sales tax	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264	t
4	DE-STD	Germany Standard	DE	VAT	19.00	Standard German VAT	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264	t
5	DE-RED	Germany Reduced	DE	VAT	7.00	Reduced German VAT	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264	t
6	UK-STD	UK Standard	GB	VAT	20.00	Standard UK VAT	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264	t
7	JP-STD	Japan Standard	JP	CONSUMPTION	10.00	Standard Japanese consumption tax	t	2025-05-20 22:10:47.493264	2025-05-20 22:10:47.493264	t
10	US-RED	US Reduced Tax	US	SALES	2.50	United States reduced sales tax rate	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
11	US-EXE	US Tax Exempt	US	EXEMPT	0.00	United States tax exempt status	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
12	CA-GST	Canada GST	CA	SALES	5.00	Canada Goods and Services Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
13	CA-HST	Canada HST	CA	SALES	13.00	Canada Harmonized Sales Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
14	UK-VAT	UK Standard VAT	UK	VAT	20.00	United Kingdom standard Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
15	UK-RED	UK Reduced VAT	UK	VAT	5.00	United Kingdom reduced Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
16	UK-ZER	UK Zero VAT	UK	VAT	0.00	United Kingdom zero-rated Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
17	EU-STD	EU Standard VAT	EU	VAT	21.00	European Union standard Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
18	EU-RED	EU Reduced VAT	EU	VAT	10.00	European Union reduced Value Added Tax	t	2025-05-21 15:11:30.587326	2025-05-21 15:11:30.587326	t
\.


--
-- Data for Name: transport_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transport_requests (id, request_number, request_type, description, owner, status, source_environment, target_environment, created_at, released_at, imported_at, release_notes, active, updated_at) FROM stdin;
1	MDK395986	MD	Transport Company Code with dependent master data	DEVELOPER_001	CREATED	DEV	QA	2025-06-03 05:09:56.056941	\N	\N	\N	t	2025-06-04 18:39:31.949764+00
2	MDK434665	MD	Complete organizational structure transport with referential integrity	SYSTEM_ADMIN	FAILED	DEV	QA	2025-06-03 05:10:34.676022	2025-06-03 05:10:54.159074	2025-06-03 05:10:57.699986	Organizational structure ready for QA testing - includes Company Code US01 with dependent plants P001 and W001. All referential integrity validated.	t	2025-06-04 18:39:31.949764+00
3	MDK494346	MD	Complete CI/CD demonstration - organizational master data with referential integrity	SYSTEM_ADMIN	CREATED	DEV	QA	2025-06-03 05:11:34.355374	\N	\N	\N	t	2025-06-04 18:39:31.949764+00
4	MDK557474	MD	Final CI/CD demonstration - SAP-style master data transport with referential integrity	ERP_ADMIN	FAILED	DEV	QA	2025-06-03 05:12:37.485285	2025-06-03 05:12:47.003937	2025-06-03 05:12:51.258397	SAP-style CI/CD transport ready for QA - Company Code US01 with dependent Plants P001 and W001. Complete referential integrity validation passed.	t	2025-06-04 18:39:31.949764+00
5	A1100003	MANUAL	MD - Company Code UK01	SYSTEM_USER	MODIFIABLE	DEV	QA	2025-06-03 16:34:14.606	\N	\N	\N	t	2025-06-04 18:39:31.949764+00
\.


--
-- Data for Name: transport_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transport_logs (id, request_id, environment, action, status, message, executed_by, executed_at, active, created_at, updated_at) FROM stdin;
1	1	DEV	TRANSPORT_CREATED	SUCCESS	Transport request MDK395986 created	DEVELOPER_001	2025-06-03 05:09:56.088744	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
2	2	DEV	TRANSPORT_CREATED	SUCCESS	Transport request MDK434665 created	SYSTEM_ADMIN	2025-06-03 05:10:34.710041	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
3	2	DEV	TRANSPORT_RELEASED	SUCCESS	Transport MDK434665 released for QA	SYSTEM	2025-06-03 05:10:54.196096	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
4	2	QA	TRANSPORT_IMPORTED	FAILED	Transport MDK434665 imported to QA	QA_ADMIN	2025-06-03 05:10:57.717893	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
5	3	DEV	TRANSPORT_CREATED	SUCCESS	Transport request MDK494346 created	SYSTEM_ADMIN	2025-06-03 05:11:34.379077	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
6	4	DEV	TRANSPORT_CREATED	SUCCESS	Transport request MDK557474 created	ERP_ADMIN	2025-06-03 05:12:37.509983	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
7	4	DEV	TRANSPORT_RELEASED	SUCCESS	Transport MDK557474 released for QA	SYSTEM	2025-06-03 05:12:47.03698	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
8	4	QA	TRANSPORT_IMPORTED	FAILED	Transport MDK557474 imported to QA	QA_ADMIN	2025-06-03 05:12:51.277264	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
9	5	DEV	CREATE	SUCCESS	Transport request A1100003 created with 1 objects	SYSTEM_USER	2025-06-03 16:34:14.749	t	2025-06-04 18:39:31.77377+00	2025-06-04 18:39:31.77377+00
\.


--
-- Data for Name: transport_number_ranges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transport_number_ranges (id, range_prefix, range_type, description, current_number, max_number, is_active, created_at, updated_at, active) FROM stdin;
2	Y1	CUSTOM_DEV	Custom Development Objects - Level 1	100000	999999	t	2025-06-03 16:19:15.360657	2025-06-03 16:19:15.360657	t
3	Z1	CUSTOMER	Customer Customization Objects - Level 1	100000	999999	t	2025-06-03 16:19:15.379191	2025-06-03 16:19:15.379191	t
1	A1	STANDARD	Standard ERP Objects - Level 1	100003	999999	t	2025-06-03 16:19:15.319047	2025-06-03 16:34:14.437086	t
\.


--
-- Data for Name: transport_objects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transport_objects (id, request_id, object_type, object_name, table_name, record_id, action, data_snapshot, created_at, active, updated_at) FROM stdin;
1	1	COMPANY_CODE	US01	company_codes	1	INSERT	{"id": 1, "city": null, "code": "US01", "name": "ACME Corporation USA", "email": null, "notes": null, "phone": null, "state": null, "tax_id": null, "address": null, "country": "United States", "version": 1, "website": null, "currency": "USD", "logo_url": null, "is_active": true, "created_at": "2025-05-17T13:43:44.835Z", "created_by": null, "updated_at": "2025-05-17T13:43:44.835Z", "updated_by": null, "description": null, "fiscal_year": "Calendar Year (Jan-Dec)", "postal_code": null}	2025-06-03 05:10:04.045575	t	2025-06-04 18:39:31.889538+00
2	1	PLANT	P001	plants	1	INSERT	{"id": 1, "city": "Chicago", "code": "P001", "name": "Main Factory", "type": "Manufacturing", "email": null, "notes": null, "phone": null, "state": null, "status": "active", "address": null, "country": "United States", "manager": null, "version": 1, "category": "Production", "timezone": null, "is_active": true, "created_at": "2025-05-17T13:44:11.172Z", "created_by": null, "updated_at": "2025-05-17T13:44:11.172Z", "updated_by": null, "coordinates": null, "description": null, "postal_code": null, "company_code_id": 1, "operating_hours": null}	2025-06-03 05:10:10.185206	t	2025-06-04 18:39:31.889538+00
3	2	COMPANY_CODE	US01	company_codes	1	INSERT	{"id": 1, "city": null, "code": "US01", "name": "ACME Corporation USA", "email": null, "notes": null, "phone": null, "state": null, "tax_id": null, "address": null, "country": "United States", "version": 1, "website": null, "currency": "USD", "logo_url": null, "is_active": true, "created_at": "2025-05-17T13:43:44.835Z", "created_by": null, "updated_at": "2025-05-17T13:43:44.835Z", "updated_by": null, "description": null, "fiscal_year": "Calendar Year (Jan-Dec)", "postal_code": null}	2025-06-03 05:10:38.682137	t	2025-06-04 18:39:31.889538+00
4	2	PLANT	P001	plants	1	INSERT	{"id": 1, "city": "Chicago", "code": "P001", "name": "Main Factory", "type": "Manufacturing", "email": null, "notes": null, "phone": null, "state": null, "status": "active", "address": null, "country": "United States", "manager": null, "version": 1, "category": "Production", "timezone": null, "is_active": true, "created_at": "2025-05-17T13:44:11.172Z", "created_by": null, "updated_at": "2025-05-17T13:44:11.172Z", "updated_by": null, "coordinates": null, "description": null, "postal_code": null, "company_code_id": 1, "operating_hours": null}	2025-06-03 05:10:38.725666	t	2025-06-04 18:39:31.889538+00
5	2	PLANT	W001	plants	2	INSERT	{"id": 2, "city": "Newark", "code": "W001", "name": "East Coast Warehouse", "type": "Warehouse", "email": null, "notes": null, "phone": null, "state": null, "status": "active", "address": null, "country": "United States", "manager": null, "version": 1, "category": "Storage", "timezone": null, "is_active": true, "created_at": "2025-05-17T13:44:11.172Z", "created_by": null, "updated_at": "2025-05-17T13:44:11.172Z", "updated_by": null, "coordinates": null, "description": null, "postal_code": null, "company_code_id": 1, "operating_hours": null}	2025-06-03 05:10:38.76116	t	2025-06-04 18:39:31.889538+00
6	3	COMPANY_CODE	US01	company_codes	1	INSERT	{"id": 1, "city": null, "code": "US01", "name": "ACME Corporation USA", "email": null, "notes": null, "phone": null, "state": null, "tax_id": null, "address": null, "country": "United States", "version": 1, "website": null, "currency": "USD", "logo_url": null, "is_active": true, "created_at": "2025-05-17T13:43:44.835Z", "created_by": null, "updated_at": "2025-05-17T13:43:44.835Z", "updated_by": null, "description": null, "fiscal_year": "Calendar Year (Jan-Dec)", "postal_code": null}	2025-06-03 05:11:38.890332	t	2025-06-04 18:39:31.889538+00
7	3	PLANT	P001	plants	1	INSERT	{"id": 1, "city": "Chicago", "code": "P001", "name": "Main Factory", "type": "Manufacturing", "email": null, "notes": null, "phone": null, "state": null, "status": "active", "address": null, "country": "United States", "manager": null, "version": 1, "category": "Production", "timezone": null, "is_active": true, "created_at": "2025-05-17T13:44:11.172Z", "created_by": null, "updated_at": "2025-05-17T13:44:11.172Z", "updated_by": null, "coordinates": null, "description": null, "postal_code": null, "company_code_id": 1, "operating_hours": null}	2025-06-03 05:11:38.923908	t	2025-06-04 18:39:31.889538+00
8	3	PLANT	W001	plants	2	INSERT	{"id": 2, "city": "Newark", "code": "W001", "name": "East Coast Warehouse", "type": "Warehouse", "email": null, "notes": null, "phone": null, "state": null, "status": "active", "address": null, "country": "United States", "manager": null, "version": 1, "category": "Storage", "timezone": null, "is_active": true, "created_at": "2025-05-17T13:44:11.172Z", "created_by": null, "updated_at": "2025-05-17T13:44:11.172Z", "updated_by": null, "coordinates": null, "description": null, "postal_code": null, "company_code_id": 1, "operating_hours": null}	2025-06-03 05:11:38.957773	t	2025-06-04 18:39:31.889538+00
9	4	COMPANY_CODE	US01	company_codes	1	INSERT	{"id": 1, "city": null, "code": "US01", "name": "ACME Corporation USA", "email": null, "notes": null, "phone": null, "state": null, "tax_id": null, "address": null, "country": "United States", "version": 1, "website": null, "currency": "USD", "logo_url": null, "is_active": true, "created_at": "2025-05-17T13:43:44.835Z", "created_by": null, "updated_at": "2025-05-17T13:43:44.835Z", "updated_by": null, "description": null, "fiscal_year": "Calendar Year (Jan-Dec)", "postal_code": null}	2025-06-03 05:12:42.300606	t	2025-06-04 18:39:31.889538+00
10	4	PLANT	P001	plants	1	INSERT	{"id": 1, "city": "Chicago", "code": "P001", "name": "Main Factory", "type": "Manufacturing", "email": null, "notes": null, "phone": null, "state": null, "status": "active", "address": null, "country": "United States", "manager": null, "version": 1, "category": "Production", "timezone": null, "is_active": true, "created_at": "2025-05-17T13:44:11.172Z", "created_by": null, "updated_at": "2025-05-17T13:44:11.172Z", "updated_by": null, "coordinates": null, "description": null, "postal_code": null, "company_code_id": 1, "operating_hours": null}	2025-06-03 05:12:42.337057	t	2025-06-04 18:39:31.889538+00
11	4	PLANT	W001	plants	2	INSERT	{"id": 2, "city": "Newark", "code": "W001", "name": "East Coast Warehouse", "type": "Warehouse", "email": null, "notes": null, "phone": null, "state": null, "status": "active", "address": null, "country": "United States", "manager": null, "version": 1, "category": "Storage", "timezone": null, "is_active": true, "created_at": "2025-05-17T13:44:11.172Z", "created_by": null, "updated_at": "2025-05-17T13:44:11.172Z", "updated_by": null, "coordinates": null, "description": null, "postal_code": null, "company_code_id": 1, "operating_hours": null}	2025-06-03 05:12:42.371786	t	2025-06-04 18:39:31.889538+00
12	5	Master Data	UK01	company_codes	\N	CREATE	{"id": 11, "city": null, "code": "UK01", "name": "United Kingdom Branch", "email": null, "notes": null, "phone": null, "state": null, "tax_id": null, "address": null, "country": "United Kingdom", "version": 1, "website": null, "currency": "GBP", "logo_url": null, "is_active": true, "created_at": "2025-05-20T03:55:35.337Z", "created_by": null, "updated_at": "2025-05-20T03:55:35.337Z", "updated_by": null, "description": "UK sales and distribution", "fiscal_year": "2025", "postal_code": null}	2025-06-03 16:34:14.698	t	2025-06-04 18:39:31.889538+00
\.


--
-- Data for Name: units_of_measure; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.units_of_measure (id, code, name, description, is_active, dimension, conversion_factor, base_uom_id, created_at, updated_at, version, active) FROM stdin;
21	BOX	Box	Standard shipping box	t	Count	1.00000	1	2025-05-20 14:35:23.427158	2025-05-20 14:35:23.427158	1	t
22	PK	Pack	Standard package unit	t	Count	1.00000	1	2025-05-20 14:35:23.450134	2025-05-20 14:35:23.450134	1	t
23	CS	Case	Standard shipping case	t	Count	1.00000	1	2025-05-20 14:35:23.469472	2025-05-20 14:35:23.469472	1	t
24	PAL	Pallet	Standard shipping pallet	t	Count	1.00000	1	2025-05-20 14:35:23.487324	2025-05-20 14:35:23.487324	1	t
25	BDL	Bundle	Bundled items	t	Count	1.00000	1	2025-05-20 14:35:23.504645	2025-05-20 14:35:23.504645	1	t
26	ROL	Roll	Material in roll form	t	Count	1.00000	1	2025-05-20 14:35:23.523414	2025-05-20 14:35:23.523414	1	t
1	EA	Each	Individual units/pieces	t	Count	1.00000	\N	2025-05-20 14:35:22.9723	2025-05-20 14:35:22.9723	1	t
2	KG	Kilogram	Standard weight measure	t	Weight	1.00000	\N	2025-05-20 14:35:22.993509	2025-05-20 14:35:22.993509	1	t
3	L	Liter	Standard volume measure	t	Volume	1.00000	\N	2025-05-20 14:35:23.012083	2025-05-20 14:35:23.012083	1	t
4	M	Meter	Standard length measure	t	Length	1.00000	\N	2025-05-20 14:35:23.031217	2025-05-20 14:35:23.031217	1	t
5	M2	Square Meter	Standard area measure	t	Area	1.00000	\N	2025-05-20 14:35:23.051068	2025-05-20 14:35:23.051068	1	t
6	M3	Cubic Meter	Standard cubic measure	t	Volume	1.00000	\N	2025-05-20 14:35:23.091756	2025-05-20 14:35:23.091756	1	t
7	HR	Hour	Time duration in hours	t	Time	1.00000	\N	2025-05-20 14:35:23.126854	2025-05-20 14:35:23.126854	1	t
8	DZ	Dozen	12 pieces	t	Count	12.00000	1	2025-05-20 14:35:23.149004	2025-05-20 14:35:23.149004	1	t
18	LB	Pound	Imperial weight unit	t	Weight	0.45359	2	2025-05-20 14:35:23.360131	2025-05-20 14:35:23.360131	1	t
19	OZ	Ounce	Imperial weight unit	t	Weight	0.02835	2	2025-05-20 14:35:23.380406	2025-05-20 14:35:23.380406	1	t
9	G	Gram	1/1000 of a kilogram	t	Weight	0.00100	2	2025-05-20 14:35:23.167923	2025-05-20 14:35:23.167923	1	t
10	TON	Metric Ton	1000 kilograms	t	Weight	1000.00000	2	2025-05-20 14:35:23.188929	2025-05-20 14:35:23.188929	1	t
20	GAL	Gallon	Imperial volume unit	t	Volume	3.78541	3	2025-05-20 14:35:23.407112	2025-05-20 14:35:23.407112	1	t
11	ML	Milliliter	1/1000 of a liter	t	Volume	0.00100	3	2025-05-20 14:35:23.211278	2025-05-20 14:35:23.211278	1	t
14	KM	Kilometer	1000 meters	t	Length	1000.00000	4	2025-05-20 14:35:23.278287	2025-05-20 14:35:23.278287	1	t
15	FT	Feet	Imperial length unit	t	Length	0.30480	4	2025-05-20 14:35:23.296244	2025-05-20 14:35:23.296244	1	t
16	IN	Inch	Imperial length unit	t	Length	0.02540	4	2025-05-20 14:35:23.318598	2025-05-20 14:35:23.318598	1	t
17	YD	Yard	Imperial length unit	t	Length	0.91440	4	2025-05-20 14:35:23.338962	2025-05-20 14:35:23.338962	1	t
12	CM	Centimeter	1/100 of a meter	t	Length	0.01000	4	2025-05-20 14:35:23.240106	2025-05-20 14:35:23.240106	1	t
13	MM	Millimeter	1/1000 of a meter	t	Length	0.00100	4	2025-05-20 14:35:23.260301	2025-05-20 14:35:23.260301	1	t
27	MIN	Minute	Time duration in minutes	t	Time	0.01667	7	2025-05-20 14:35:23.542799	2025-05-20 14:35:23.542799	1	t
28	DAY	Day	Time duration in days	t	Time	24.00000	7	2025-05-20 14:35:23.562736	2025-05-20 14:35:23.562736	1	t
29	WK	Week	Time duration in weeks	t	Time	168.00000	7	2025-05-20 14:35:23.581007	2025-05-20 14:35:23.581007	1	t
30	MO	Month	Time duration in months	t	Time	730.00000	7	2025-05-20 14:35:23.601732	2025-05-20 14:35:23.601732	1	t
\.


--
-- Data for Name: uom_conversions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.uom_conversions (id, from_uom_id, to_uom_id, conversion_factor, created_at, created_by, updated_at, updated_by, version, is_active, notes, active) FROM stdin;
1	1	2	1000	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N	t
2	1	3	2.20462	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N	t
3	4	5	100	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N	t
4	4	6	39.3701	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N	t
5	7	8	1000	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N	t
6	7	9	0.264172	2025-05-17 05:55:19.590846	1	2025-05-17 05:55:19.590846	1	1	t	\N	t
\.


--
-- Data for Name: valuation_classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.valuation_classes (id, class_code, class_name, description, valuation_method, price_control, moving_price, standard_price, active, created_at, updated_at) FROM stdin;
1	VC001	Raw Materials	Valuation for raw materials	FIFO	V	t	f	t	2025-06-05 16:53:42.380973+00	2025-06-05 16:53:42.380973+00
2	VC002	Finished Goods	Valuation for finished products	WAC	S	f	t	t	2025-06-05 16:53:42.380973+00	2025-06-05 16:53:42.380973+00
3	VC003	Work in Progress	WIP material valuation	STANDARD	S	f	t	t	2025-06-05 16:53:42.380973+00	2025-06-05 16:53:42.380973+00
4	VC004	Trading Goods	External trading materials	LIFO	V	t	f	t	2025-06-05 16:53:42.380973+00	2025-06-05 16:53:42.380973+00
5	VC005	Consumables	Consumable materials	MOVING	V	t	f	t	2025-06-05 16:53:42.380973+00	2025-06-05 16:53:42.380973+00
6	VC006	Packaging Materials	Packaging and wrapping	FIFO	V	t	f	t	2025-06-05 16:53:42.380973+00	2025-06-05 16:53:42.380973+00
7	VC007	Spare Parts	Equipment spare parts	WAC	S	f	t	t	2025-06-05 16:53:42.380973+00	2025-06-05 16:53:42.380973+00
\.


--
-- Data for Name: variance_analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.variance_analysis (id, variance_type, object_type, object_number, fiscal_year, period, account, cost_element, planned_amount, actual_amount, variance_amount, variance_percentage, currency, analysis_date, created_at, active, updated_at) FROM stdin;
\.


--
-- Data for Name: vendor_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_contacts (id, vendor_id, first_name, last_name, "position", department, email, phone, mobile, is_primary, is_order_contact, is_purchase_contact, is_quality_contact, is_accounts_contact, preferred_language, notes, is_active, created_at, updated_at, created_by, updated_by, active) FROM stdin;
1	1	Thomas	Anderson	Technical Support	Support	thomas.anderson@supplier.com	(555) 333-4444	(555) 555-6666	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.574	2025-05-22 13:33:13.574	\N	\N	t
2	1	Jennifer	Taylor	Account Manager	Customer Relations	jennifer.taylor@supplier.com	(555) 222-3333	(555) 444-5555	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.615	2025-05-22 13:33:13.615	\N	\N	t
3	2	Robert	Wilson	Sales Representative	Sales	robert.wilson@supplier.com	(555) 111-2222	(555) 333-4444	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.655	2025-05-22 13:33:13.655	\N	\N	t
4	3	William	Thompson	Logistics Coordinator	Logistics	william.thompson@supplier.com	(555) 555-6666	(555) 777-8888	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.692	2025-05-22 13:33:13.692	\N	\N	t
5	3	William	Thompson	Logistics Coordinator	Logistics	william.thompson@supplier.com	(555) 555-6666	(555) 777-8888	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.729	2025-05-22 13:33:13.729	\N	\N	t
6	3	Elizabeth	Martin	VP of Sales	Executive	elizabeth.martin@supplier.com	(555) 444-5555	(555) 666-7777	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.767	2025-05-22 13:33:13.767	\N	\N	t
7	4	Robert	Wilson	Sales Representative	Sales	robert.wilson@supplier.com	(555) 111-2222	(555) 333-4444	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.807	2025-05-22 13:33:13.807	\N	\N	t
8	5	Elizabeth	Martin	VP of Sales	Executive	elizabeth.martin@supplier.com	(555) 444-5555	(555) 666-7777	t	f	f	f	f	English	\N	t	2025-05-22 13:33:13.864	2025-05-22 13:33:13.864	\N	\N	t
9	5	Robert	Wilson	Sales Representative	Sales	robert.wilson@supplier.com	(555) 111-2222	(555) 333-4444	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.905	2025-05-22 13:33:13.905	\N	\N	t
10	5	William	Thompson	Logistics Coordinator	Logistics	william.thompson@supplier.com	(555) 555-6666	(555) 777-8888	f	f	f	f	f	English	\N	t	2025-05-22 13:33:13.944	2025-05-22 13:33:13.944	\N	\N	t
\.


--
-- Data for Name: warehouse_bins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouse_bins (id, bin_code, bin_name, storage_location_id, bin_type, zone, aisle, shelf, capacity_volume, capacity_weight, current_volume, current_weight, status, created_at, active, updated_at) FROM stdin;
\.


--
-- Name: account_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_groups_id_seq', 1, false);


--
-- Name: accounts_payable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounts_payable_id_seq', 20, true);


--
-- Name: accounts_receivable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounts_receivable_id_seq', 25, true);


--
-- Name: activity_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activity_types_id_seq', 5, true);


--
-- Name: ai_agent_analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_agent_analytics_id_seq', 1, false);


--
-- Name: ai_agent_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_agent_configs_id_seq', 7, true);


--
-- Name: ai_agent_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_agent_health_id_seq', 1, false);


--
-- Name: ai_agent_interventions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_agent_interventions_id_seq', 1, false);


--
-- Name: ai_agent_performance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_agent_performance_id_seq', 9, true);


--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_chat_messages_id_seq', 1, false);


--
-- Name: ai_chat_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_chat_sessions_id_seq', 1, false);


--
-- Name: ai_data_analysis_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_data_analysis_sessions_id_seq', 1, false);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 2, true);


--
-- Name: approval_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.approval_levels_id_seq', 11, true);


--
-- Name: asset_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.asset_master_id_seq', 15, true);


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assets_id_seq', 1, false);


--
-- Name: bank_statement_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_statement_items_id_seq', 1, false);


--
-- Name: bank_statements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_statements_id_seq', 1, false);


--
-- Name: batch_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_master_id_seq', 1, false);


--
-- Name: bill_of_materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bill_of_materials_id_seq', 8, true);


--
-- Name: bom_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bom_items_id_seq', 18, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, true);


--
-- Name: change_document_analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_document_analytics_id_seq', 5, true);


--
-- Name: change_document_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_document_approvals_id_seq', 1, false);


--
-- Name: change_document_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_document_attachments_id_seq', 1, false);


--
-- Name: change_document_headers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_document_headers_id_seq', 1, false);


--
-- Name: change_document_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_document_number_seq', 1000000, true);


--
-- Name: change_document_positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_document_positions_id_seq', 1, false);


--
-- Name: change_document_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_document_relations_id_seq', 1, false);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 1, false);


--
-- Name: clearing_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clearing_configurations_id_seq', 1, false);


--
-- Name: clearing_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clearing_items_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.companies_id_seq', 1, true);


--
-- Name: company_code_chart_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.company_code_chart_assignments_id_seq', 1, true);


--
-- Name: company_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.company_codes_id_seq', 20, true);


--
-- Name: comprehensive_issues_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comprehensive_issues_log_id_seq', 259, true);


--
-- Name: copa_actuals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.copa_actuals_id_seq', 1, false);


--
-- Name: cost_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_allocations_id_seq', 1, false);


--
-- Name: cost_center_actuals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_center_actuals_id_seq', 135, true);


--
-- Name: cost_center_planning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_center_planning_id_seq', 138, true);


--
-- Name: cost_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_centers_id_seq', 24, true);


--
-- Name: cost_elements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_elements_id_seq', 35, true);


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.countries_id_seq', 12, true);


--
-- Name: credit_control_areas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_control_areas_id_seq', 5, true);


--
-- Name: currencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.currencies_id_seq', 5, true);


--
-- Name: currency_valuations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.currency_valuations_id_seq', 1, false);


--
-- Name: custom_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_reports_id_seq', 5, true);


--
-- Name: customer_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_contacts_id_seq', 12, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 22, true);


--
-- Name: dashboard_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dashboard_configs_id_seq', 29, true);


--
-- Name: document_posting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_posting_id_seq', 1, false);


--
-- Name: document_posting_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_posting_items_id_seq', 1, false);


--
-- Name: document_posting_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_posting_lines_id_seq', 1, false);


--
-- Name: document_postings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_postings_id_seq', 1, false);


--
-- Name: down_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.down_payments_id_seq', 1, false);


--
-- Name: employee_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_master_id_seq', 1, false);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_id_seq', 12, true);


--
-- Name: environment_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.environment_config_id_seq', 1, false);


--
-- Name: erp_customer_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.erp_customer_contacts_id_seq', 10, true);


--
-- Name: erp_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.erp_customers_id_seq', 10, true);


--
-- Name: erp_vendor_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.erp_vendor_contacts_id_seq', 12, true);


--
-- Name: erp_vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.erp_vendors_id_seq', 12, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 18, true);


--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fiscal_periods_id_seq', 12, true);


--
-- Name: fiscal_year_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fiscal_year_variants_id_seq', 1, false);


--
-- Name: general_ledger_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.general_ledger_accounts_id_seq', 1, false);


--
-- Name: gl_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gl_accounts_id_seq', 35, true);


--
-- Name: goods_receipt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goods_receipt_id_seq', 1, false);


--
-- Name: goods_receipt_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goods_receipt_items_id_seq', 1, false);


--
-- Name: goods_receipt_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goods_receipt_lines_id_seq', 1, false);


--
-- Name: goods_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goods_receipts_id_seq', 1, false);


--
-- Name: internal_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.internal_orders_id_seq', 7, true);


--
-- Name: inventory_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_transactions_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 10, true);


--
-- Name: issue_analytics_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.issue_analytics_summary_id_seq', 1, true);


--
-- Name: issue_patterns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.issue_patterns_id_seq', 5, true);


--
-- Name: issue_resolutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.issue_resolutions_id_seq', 1, false);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_entries_id_seq', 5, true);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leads_id_seq', 24, true);


--
-- Name: material_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_categories_id_seq', 11, true);


--
-- Name: materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.materials_id_seq', 34, true);


--
-- Name: module_health_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.module_health_status_id_seq', 268, true);


--
-- Name: movement_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.movement_types_id_seq', 12, true);


--
-- Name: opportunities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.opportunities_id_seq', 17, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_id_seq', 131, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 52, true);


--
-- Name: payment_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_lines_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: plants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plants_id_seq', 37, true);


--
-- Name: production_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_orders_id_seq', 5, true);


--
-- Name: production_work_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_work_orders_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 20, true);


--
-- Name: profit_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.profit_centers_id_seq', 20, true);


--
-- Name: purchase_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_groups_id_seq', 12, true);


--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_order_items_id_seq', 1, false);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 5, true);


--
-- Name: purchase_organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_organizations_id_seq', 36, true);


--
-- Name: purchase_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_requests_id_seq', 1, false);


--
-- Name: purchasing_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchasing_groups_id_seq', 5, true);


--
-- Name: purchasing_organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchasing_organizations_id_seq', 5, true);


--
-- Name: quote_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quote_approvals_id_seq', 16, true);


--
-- Name: quote_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quote_items_id_seq', 10, true);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotes_id_seq', 7, true);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.regions_id_seq', 4, true);


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reports_id_seq', 5, true);


--
-- Name: sales_customer_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_customer_contacts_id_seq', 11, true);


--
-- Name: sales_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_customers_id_seq', 7, true);


--
-- Name: sales_invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_invoice_items_id_seq', 9, true);


--
-- Name: sales_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_invoices_id_seq', 5, true);


--
-- Name: sales_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_order_items_id_seq', 16, true);


--
-- Name: sales_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_orders_id_seq', 11, true);


--
-- Name: sales_organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_organizations_id_seq', 31, true);


--
-- Name: sales_quote_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_quote_items_id_seq', 12, true);


--
-- Name: sales_quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_quotes_id_seq', 5, true);


--
-- Name: sales_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_return_items_id_seq', 7, true);


--
-- Name: sales_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_returns_id_seq', 4, true);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 28, true);


--
-- Name: storage_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.storage_locations_id_seq', 52, true);


--
-- Name: supply_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supply_types_id_seq', 11, true);


--
-- Name: system_error_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_error_logs_id_seq', 20, true);


--
-- Name: tax_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tax_codes_id_seq', 18, true);


--
-- Name: transport_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transport_logs_id_seq', 9, true);


--
-- Name: transport_number_ranges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transport_number_ranges_id_seq', 1601, true);


--
-- Name: transport_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transport_objects_id_seq', 12, true);


--
-- Name: transport_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transport_requests_id_seq', 5, true);


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.units_of_measure_id_seq', 30, true);


--
-- Name: uom_conversions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.uom_conversions_id_seq', 6, true);


--
-- Name: uom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.uom_id_seq', 14, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: valuation_classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.valuation_classes_id_seq', 7, true);


--
-- Name: variance_analysis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.variance_analysis_id_seq', 1, false);


--
-- Name: vendor_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_contacts_id_seq', 10, true);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendors_id_seq', 25, true);


--
-- Name: warehouse_bins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouse_bins_id_seq', 1, false);


--
-- Name: work_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_centers_id_seq', 28, true);


--
-- PostgreSQL database dump complete
--

