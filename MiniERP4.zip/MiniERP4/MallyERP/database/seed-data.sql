-- =====================================================
-- MallyProj Seed Data
-- Essential master data for system initialization
-- =====================================================

-- Company Codes
INSERT INTO company_codes (company_code, company_name, city, country, currency, fiscal_year_variant, chart_of_accounts) VALUES
('1000', 'MallyProj Corporation', 'New York', 'US', 'USD', 'K4', 'INT'),
('2000', 'MallyProj Europe GmbH', 'Berlin', 'DE', 'EUR', 'K4', 'INT'),
('3000', 'MallyProj Asia Pacific', 'Singapore', 'SG', 'SGD', 'K4', 'INT');

-- Chart of Accounts
INSERT INTO chart_of_accounts (chart_id, chart_name, description) VALUES
('INT', 'International Chart of Accounts', 'Standard international accounting structure'),
('US', 'US GAAP Chart of Accounts', 'US Generally Accepted Accounting Principles'),
('EU', 'European Chart of Accounts', 'European accounting standards');

-- GL Accounts
INSERT INTO gl_accounts (account_number, account_name, account_type, account_group, chart_of_accounts, balance_sheet_account, profit_loss_account) VALUES
('1000000', 'Cash and Cash Equivalents', 'A', 'CASH', 'INT', true, false),
('1100000', 'Accounts Receivable', 'A', 'RECV', 'INT', true, false),
('1200000', 'Inventory - Raw Materials', 'A', 'INVT', 'INT', true, false),
('1300000', 'Fixed Assets', 'A', 'FIXD', 'INT', true, false),
('2000000', 'Accounts Payable', 'L', 'PAYB', 'INT', true, false),
('2100000', 'Accrued Liabilities', 'L', 'ACCR', 'INT', true, false),
('3000000', 'Share Capital', 'E', 'EQUI', 'INT', true, false),
('4000000', 'Sales Revenue', 'R', 'SALE', 'INT', false, true),
('5000000', 'Cost of Goods Sold', 'X', 'COGS', 'INT', false, true),
('6000000', 'Operating Expenses', 'X', 'OPEX', 'INT', false, true);

-- Plants
INSERT INTO plants (plant, plant_name, company_code, address, country, region) VALUES
('1000', 'New York Manufacturing', '1000', '123 Industrial Ave, New York, NY', 'US', 'NA'),
('2000', 'Berlin Production Facility', '2000', 'Industriestraße 45, Berlin', 'DE', 'EU'),
('3000', 'Singapore Assembly Plant', '3000', '50 Tuas South Ave, Singapore', 'SG', 'AP');

-- Storage Locations
INSERT INTO storage_locations (plant, storage_location, storage_location_name) VALUES
('1000', '0001', 'Main Warehouse'),
('1000', '0002', 'Finished Goods'),
('2000', '0001', 'Hauptlager'),
('2000', '0002', 'Fertigwaren'),
('3000', '0001', 'Main Storage'),
('3000', '0002', 'FG Storage');

-- Cost Centers
INSERT INTO cost_centers (cost_center, cost_center_name, company_code, valid_from, valid_to, responsible_person) VALUES
('1000000001', 'Production Department', '1000', '2024-01-01', '2099-12-31', 'John Smith'),
('1000000002', 'Quality Control', '1000', '2024-01-01', '2099-12-31', 'Sarah Johnson'),
('1000000003', 'Sales Department', '1000', '2024-01-01', '2099-12-31', 'Mike Wilson'),
('2000000001', 'Produktion', '2000', '2024-01-01', '2099-12-31', 'Hans Mueller'),
('2000000002', 'Qualitätskontrolle', '2000', '2024-01-01', '2099-12-31', 'Anna Schmidt'),
('3000000001', 'Production Unit', '3000', '2024-01-01', '2099-12-31', 'Lee Wei Ming');

-- Profit Centers
INSERT INTO profit_centers (profit_center, profit_center_name, company_code, valid_from, valid_to, segment) VALUES
('1000000001', 'Electronics Division', '1000', '2024-01-01', '2099-12-31', 'ELEC'),
('1000000002', 'Software Division', '1000', '2024-01-01', '2099-12-31', 'SOFT'),
('2000000001', 'Elektronik Sparte', '2000', '2024-01-01', '2099-12-31', 'ELEC'),
('3000000001', 'Asia Pacific Operations', '3000', '2024-01-01', '2099-12-31', 'APAC');

-- Materials Master
INSERT INTO materials (material_number, material_type, material_description, base_unit_of_measure, material_group, gross_weight, net_weight, weight_unit) VALUES
('100000001', 'FERT', 'Smart Watch Pro', 'PC', 'ELEC001', 0.250, 0.200, 'KG'),
('100000002', 'FERT', 'Wireless Headphones', 'PC', 'ELEC002', 0.300, 0.250, 'KG'),
('100000003', 'FERT', 'Smartphone X1', 'PC', 'ELEC003', 0.180, 0.160, 'KG'),
('200000001', 'ROH', 'Lithium Battery 3000mAh', 'PC', 'BATT001', 0.050, 0.045, 'KG'),
('200000002', 'ROH', 'OLED Display 1.4 inch', 'PC', 'DISP001', 0.020, 0.018, 'KG'),
('200000003', 'ROH', 'Aluminum Casing', 'PC', 'CASE001', 0.080, 0.075, 'KG');

-- Customers Master
INSERT INTO customers (customer_number, customer_name, customer_name2, address, city, postal_code, country, telephone, email, account_group) VALUES
('10000001', 'TechMart Solutions Inc', '', '456 Technology Blvd', 'San Francisco', '94105', 'US', '+1-415-555-0123', 'orders@techmart.com', 'Z001'),
('10000002', 'ElectroWorld Chain', '', '789 Retail Street', 'Chicago', '60601', 'US', '+1-312-555-0456', 'purchasing@electroworld.com', 'Z001'),
('10000003', 'Digital Innovations GmbH', '', 'Technologiepark 12', 'Munich', '80992', 'DE', '+49-89-555-0789', 'einkauf@digital-innovations.de', 'Z002'),
('10000004', 'Asia Electronics Pte Ltd', '', '25 Science Park Road', 'Singapore', '117528', 'SG', '+65-6555-0123', 'procurement@asiaelectronics.sg', 'Z003');

-- Vendors Master
INSERT INTO vendors (vendor_number, vendor_name, vendor_name2, address, city, postal_code, country, telephone, email, account_group, payment_terms) VALUES
('20000001', 'ComponentSource Ltd', '', '123 Supply Chain Ave', 'Shenzhen', '518000', 'CN', '+86-755-555-0123', 'sales@componentsource.cn', 'V001', 'Z030'),
('20000002', 'BatteryTech Manufacturing', '', '567 Industrial Zone', 'Seoul', '04524', 'KR', '+82-2-555-0456', 'export@batterytech.kr', 'V001', 'Z030'),
('20000003', 'Display Solutions Inc', '', '890 Innovation Drive', 'San Jose', '95110', 'US', '+1-408-555-0789', 'b2b@displaysolutions.com', 'V002', 'Z015'),
('20000004', 'Precision Casings Europe', '', 'Industrieweg 45', 'Eindhoven', '5612AP', 'NL', '+31-40-555-0123', 'orders@precisioncasings.nl', 'V003', 'Z030');

-- Sales Organizations
INSERT INTO sales_organizations (sales_org, sales_org_name, company_code, currency) VALUES
('1000', 'North America Sales', '1000', 'USD'),
('2000', 'Europe Sales', '2000', 'EUR'),
('3000', 'Asia Pacific Sales', '3000', 'SGD');

-- Purchasing Organizations
INSERT INTO purchasing_organizations (purchasing_org, purchasing_org_name, company_code) VALUES
('1000', 'North America Procurement', '1000'),
('2000', 'Europe Procurement', '2000'),
('3000', 'Asia Pacific Procurement', '3000');

-- Work Centers
INSERT INTO work_centers (work_center, work_center_name, plant, work_center_category, machine_hours_capacity, labor_hours_capacity, standard_available_capacity, cost_center) VALUES
('10000001', 'Assembly Line 1', '1000', '1', 160.00, 320.00, 480.00, '1000000001'),
('10000002', 'Quality Check Station', '1000', '2', 80.00, 160.00, 240.00, '1000000002'),
('20000001', 'Montage Linie 1', '2000', '1', 160.00, 320.00, 480.00, '2000000001'),
('30000001', 'Assembly Unit A', '3000', '1', 160.00, 320.00, 480.00, '3000000001');

-- Cost Elements
INSERT INTO cost_elements (cost_element, cost_element_name, cost_element_category, gl_account) VALUES
('4000000001', 'Direct Material', '1', '5000000'),
('4000000002', 'Direct Labor', '1', '5000000'),
('4000000003', 'Manufacturing Overhead', '1', '6000000'),
('4000000004', 'Quality Control', '2', '6000000'),
('4000000005', 'Administrative Costs', '2', '6000000');

-- Sample Sales Orders
INSERT INTO sales_orders (sales_order_number, order_type, sales_org, distribution_channel, division, customer_number, order_date, requested_delivery_date, net_value, currency, created_by) VALUES
('5000000001', 'OR', '1000', '10', '01', '10000001', '2024-12-01', '2024-12-15', 25000.00, 'USD', 'SYSTEM'),
('5000000002', 'OR', '2000', '10', '01', '10000003', '2024-12-02', '2024-12-16', 18500.00, 'EUR', 'SYSTEM'),
('5000000003', 'OR', '3000', '10', '01', '10000004', '2024-12-03', '2024-12-17', 15200.00, 'SGD', 'SYSTEM');

-- Sample Sales Order Items
INSERT INTO sales_order_items (sales_order_number, item_number, material_number, description, order_quantity, unit_of_measure, net_price, net_value, plant, storage_location, delivery_date) VALUES
('5000000001', '000010', '100000001', 'Smart Watch Pro', 100, 'PC', 199.99, 19999.00, '1000', '0002', '2024-12-15'),
('5000000001', '000020', '100000002', 'Wireless Headphones', 50, 'PC', 99.99, 4999.50, '1000', '0002', '2024-12-15'),
('5000000002', '000010', '100000001', 'Smart Watch Pro', 75, 'PC', 179.99, 13499.25, '2000', '0002', '2024-12-16'),
('5000000002', '000020', '100000003', 'Smartphone X1', 25, 'PC', 199.99, 4999.75, '2000', '0002', '2024-12-16'),
('5000000003', '000010', '100000002', 'Wireless Headphones', 120, 'PC', 89.99, 10798.80, '3000', '0002', '2024-12-17'),
('5000000003', '000020', '100000003', 'Smartphone X1', 30, 'PC', 149.99, 4499.70, '3000', '0002', '2024-12-17');

-- Sample Purchase Orders
INSERT INTO purchase_orders (purchase_order_number, document_type, purchasing_org, purchasing_group, vendor_number, order_date, currency, net_order_value, created_by) VALUES
('4500000001', 'NB', '1000', '001', '20000001', '2024-12-01', 'USD', 15000.00, 'SYSTEM'),
('4500000002', 'NB', '2000', '002', '20000002', '2024-12-02', 'EUR', 12500.00, 'SYSTEM'),
('4500000003', 'NB', '3000', '003', '20000003', '2024-12-03', 'SGD', 8750.00, 'SYSTEM');

-- Sample Purchase Order Items
INSERT INTO purchase_order_items (purchase_order_number, item_number, material_number, short_text, order_quantity, unit_of_measure, net_price, net_order_value, plant, storage_location, delivery_date) VALUES
('4500000001', '00010', '200000001', 'Lithium Battery 3000mAh', 500, 'PC', 25.50, 12750.00, '1000', '0001', '2024-12-10'),
('4500000001', '00020', '200000002', 'OLED Display 1.4 inch', 300, 'PC', 7.50, 2250.00, '1000', '0001', '2024-12-10'),
('4500000002', '00010', '200000001', 'Lithium Battery 3000mAh', 400, 'PC', 23.50, 9400.00, '2000', '0001', '2024-12-11'),
('4500000002', '00020', '200000003', 'Aluminum Casing', 250, 'PC', 12.40, 3100.00, '2000', '0001', '2024-12-11'),
('4500000003', '00010', '200000002', 'OLED Display 1.4 inch', 600, 'PC', 6.80, 4080.00, '3000', '0001', '2024-12-12'),
('4500000003', '00020', '200000003', 'Aluminum Casing', 350, 'PC', 13.34, 4669.00, '3000', '0001', '2024-12-12');

-- Sample Production Orders
INSERT INTO production_orders (order_number, order_type, material_number, plant, order_quantity, unit_of_measure, basic_start_date, basic_finish_date, system_status, created_by) VALUES
('1000000001', 'PP01', '100000001', '1000', 200, 'PC', '2024-12-05', '2024-12-12', 'REL', 'SYSTEM'),
('2000000001', 'PP01', '100000002', '2000', 150, 'PC', '2024-12-06', '2024-12-13', 'REL', 'SYSTEM'),
('3000000001', 'PP01', '100000003', '3000', 100, 'PC', '2024-12-07', '2024-12-14', 'REL', 'SYSTEM');

-- Sample Journal Entries
INSERT INTO journal_entries (document_number, document_type, company_code, posting_date, document_date, reference, document_header_text, fiscal_year, period, currency, posted_by) VALUES
('1900000001', 'SA', '1000', '2024-12-01', '2024-12-01', 'SO-5000000001', 'Sales Invoice', 2024, 12, 'USD', 'SYSTEM'),
('1900000002', 'RE', '1000', '2024-12-01', '2024-12-01', 'PO-4500000001', 'Vendor Invoice', 2024, 12, 'USD', 'SYSTEM'),
('1900000003', 'SA', '2000', '2024-12-02', '2024-12-02', 'SO-5000000002', 'Sales Invoice', 2024, 12, 'EUR', 'SYSTEM');

-- Sample Document Line Items
INSERT INTO document_posting_lines (document_number, line_item, gl_account, debit_amount, credit_amount, document_currency, local_currency, amount_in_local_currency, cost_center, text) VALUES
('1900000001', '001', '1100000', 25000.00, 0.00, 'USD', 'USD', 25000.00, '1000000003', 'Customer Invoice'),
('1900000001', '002', '4000000', 0.00, 25000.00, 'USD', 'USD', 25000.00, '1000000003', 'Sales Revenue'),
('1900000002', '001', '5000000', 15000.00, 0.00, 'USD', 'USD', 15000.00, '1000000001', 'Material Purchase'),
('1900000002', '002', '2000000', 0.00, 15000.00, 'USD', 'USD', 15000.00, '1000000001', 'Vendor Payable'),
('1900000003', '001', '1100000', 18500.00, 0.00, 'EUR', 'EUR', 18500.00, '2000000003', 'Customer Invoice'),
('1900000003', '002', '4000000', 0.00, 18500.00, 'EUR', 'EUR', 18500.00, '2000000003', 'Sales Revenue');

-- Sample Accounts Receivable
INSERT INTO accounts_receivable (document_number, line_item, customer_number, amount, currency, due_date, payment_terms, baseline_date, net_due_date) VALUES
('1900000001', '001', '10000001', 25000.00, 'USD', '2024-12-31', 'Z030', '2024-12-01', '2024-12-31'),
('1900000003', '001', '10000003', 18500.00, 'EUR', '2024-12-31', 'Z030', '2024-12-02', '2024-12-31');

-- Sample Accounts Payable
INSERT INTO accounts_payable (document_number, line_item, vendor_number, amount, currency, due_date, payment_terms, baseline_date, net_due_date) VALUES
('1900000002', '002', '20000001', 15000.00, 'USD', '2024-12-31', 'Z030', '2024-12-01', '2024-12-31');

-- Update sequences to reflect inserted data
SELECT setval('company_codes_id_seq', 3);
SELECT setval('chart_of_accounts_id_seq', 3);
SELECT setval('gl_accounts_id_seq', 10);
SELECT setval('plants_id_seq', 3);
SELECT setval('storage_locations_id_seq', 6);
SELECT setval('cost_centers_id_seq', 6);
SELECT setval('profit_centers_id_seq', 4);
SELECT setval('materials_id_seq', 6);
SELECT setval('customers_id_seq', 4);
SELECT setval('vendors_id_seq', 4);
SELECT setval('sales_organizations_id_seq', 3);
SELECT setval('purchasing_organizations_id_seq', 3);
SELECT setval('work_centers_id_seq', 4);
SELECT setval('cost_elements_id_seq', 5);
SELECT setval('sales_orders_id_seq', 3);
SELECT setval('sales_order_items_id_seq', 6);
SELECT setval('purchase_orders_id_seq', 3);
SELECT setval('purchase_order_items_id_seq', 6);
SELECT setval('production_orders_id_seq', 3);
SELECT setval('journal_entries_id_seq', 3);
SELECT setval('document_posting_lines_id_seq', 6);
SELECT setval('accounts_receivable_id_seq', 2);
SELECT setval('accounts_payable_id_seq', 1);