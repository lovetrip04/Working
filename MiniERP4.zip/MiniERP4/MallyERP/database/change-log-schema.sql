-- Change Log System - Complete Audit Trail Implementation
-- Similar to LOGHDR and LOGITEMS standards but with enhanced functionality for MallyERP
-- This system captures all data changes across all modules with full delta tracking

-- Change Document Header Table (similar to LOGHDR)
CREATE TABLE IF NOT EXISTS change_document_headers (
    id BIGSERIAL PRIMARY KEY,
    change_document_id UUID UNIQUE DEFAULT gen_random_uuid(),
    object_class VARCHAR(50) NOT NULL, -- Table/Object type (e.g., 'CUSTOMER', 'MATERIAL', 'PURCHASE_ORDER')
    object_id VARCHAR(100) NOT NULL,   -- Primary key value of changed object
    change_number VARCHAR(20) UNIQUE NOT NULL, -- Sequential change number
    
    -- User and Session Information
    user_name VARCHAR(100) NOT NULL,
    user_role VARCHAR(50),
    session_id VARCHAR(100),
    transaction_code VARCHAR(20),
    
    -- Change Metadata
    change_type VARCHAR(20) NOT NULL CHECK (change_type IN ('CREATE', 'UPDATE', 'DELETE', 'ACTIVATE', 'DEACTIVATE')),
    change_reason VARCHAR(100),
    change_category VARCHAR(50), -- Business category (MASTER_DATA, TRANSACTION, CONFIGURATION)
    
    -- Timing Information
    change_date DATE NOT NULL DEFAULT CURRENT_DATE,
    change_time TIME NOT NULL DEFAULT CURRENT_TIME,
    change_timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- System Information
    client_ip VARCHAR(45),
    user_agent TEXT,
    application_module VARCHAR(50), -- ERP module (SALES, PURCHASE, FINANCE, etc.)
    
    -- Business Context
    business_process VARCHAR(100), -- Process context (ORDER_CREATION, INVOICE_POSTING, etc.)
    reference_document VARCHAR(100), -- Related document number
    approval_status VARCHAR(20) DEFAULT 'PENDING',
    
    -- Versioning
    version_number INTEGER DEFAULT 1,
    parent_change_id UUID REFERENCES change_document_headers(change_document_id),
    
    -- Status and Control
    is_active BOOLEAN DEFAULT true,
    is_reversed BOOLEAN DEFAULT false,
    reversal_change_id UUID REFERENCES change_document_headers(change_document_id),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Change Document Position Table (similar to LOGITEMS)
CREATE TABLE IF NOT EXISTS change_document_positions (
    id BIGSERIAL PRIMARY KEY,
    change_document_id UUID NOT NULL REFERENCES change_document_headers(change_document_id) ON DELETE CASCADE,
    position_number INTEGER NOT NULL, -- Sequential position within change document
    
    -- Field Information
    table_name VARCHAR(100) NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    field_label VARCHAR(200), -- Human-readable field description
    data_type VARCHAR(50),
    
    -- Change Values
    old_value TEXT,
    new_value TEXT,
    old_value_formatted TEXT, -- Human-readable old value
    new_value_formatted TEXT, -- Human-readable new value
    
    -- Value Metadata
    value_unit VARCHAR(20), -- Unit of measure for numeric values
    value_currency VARCHAR(10), -- Currency for monetary values
    value_language VARCHAR(10), -- Language for text values
    
    -- Change Analysis
    change_indicator VARCHAR(10) NOT NULL CHECK (change_indicator IN ('INSERT', 'UPDATE', 'DELETE', 'MOVE')),
    change_magnitude DECIMAL(15,4), -- Numeric difference for quantities/amounts
    change_percentage DECIMAL(5,2), -- Percentage change for analysis
    
    -- Reference Information
    reference_table VARCHAR(100), -- Foreign key reference table
    reference_field VARCHAR(100), -- Foreign key reference field
    reference_value VARCHAR(200), -- Referenced record identifier
    
    -- Data Quality
    data_quality_score INTEGER CHECK (data_quality_score BETWEEN 0 AND 100),
    validation_status VARCHAR(20) DEFAULT 'VALID',
    validation_errors JSONB,
    
    -- Business Impact
    business_impact VARCHAR(20) CHECK (business_impact IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    requires_approval BOOLEAN DEFAULT false,
    compliance_flag BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Change Document Relations Table - Track relationships between changes
CREATE TABLE IF NOT EXISTS change_document_relations (
    id BIGSERIAL PRIMARY KEY,
    source_change_id UUID NOT NULL REFERENCES change_document_headers(change_document_id),
    target_change_id UUID NOT NULL REFERENCES change_document_headers(change_document_id),
    relation_type VARCHAR(50) NOT NULL, -- CAUSED_BY, TRIGGERS, DEPENDS_ON, CONFLICTS_WITH
    relation_strength VARCHAR(20) DEFAULT 'MEDIUM', -- WEAK, MEDIUM, STRONG
    business_context TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(source_change_id, target_change_id, relation_type)
);

-- Change Document Approvals Table - Approval workflow tracking
CREATE TABLE IF NOT EXISTS change_document_approvals (
    id BIGSERIAL PRIMARY KEY,
    change_document_id UUID NOT NULL REFERENCES change_document_headers(change_document_id),
    approval_level INTEGER NOT NULL,
    approver_role VARCHAR(50) NOT NULL,
    approver_name VARCHAR(100),
    approval_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' 
        CHECK (approval_status IN ('PENDING', 'APPROVED', 'REJECTED', 'DELEGATED')),
    approval_comments TEXT,
    approval_timestamp TIMESTAMP WITH TIME ZONE,
    delegation_to VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Change Document Attachments Table - Supporting documents
CREATE TABLE IF NOT EXISTS change_document_attachments (
    id BIGSERIAL PRIMARY KEY,
    change_document_id UUID NOT NULL REFERENCES change_document_headers(change_document_id),
    attachment_type VARCHAR(50) NOT NULL, -- DOCUMENT, IMAGE, APPROVAL_FORM, BACKUP
    file_name VARCHAR(500) NOT NULL,
    file_path TEXT,
    file_size BIGINT,
    mime_type VARCHAR(100),
    description TEXT,
    uploaded_by VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Change Document Analytics Table - Performance and trend analysis
CREATE TABLE IF NOT EXISTS change_document_analytics (
    id BIGSERIAL PRIMARY KEY,
    analysis_date DATE NOT NULL DEFAULT CURRENT_DATE,
    object_class VARCHAR(50) NOT NULL,
    application_module VARCHAR(50) NOT NULL,
    
    -- Volume Metrics
    total_changes INTEGER DEFAULT 0,
    creates_count INTEGER DEFAULT 0,
    updates_count INTEGER DEFAULT 0,
    deletes_count INTEGER DEFAULT 0,
    
    -- Performance Metrics
    avg_fields_changed DECIMAL(10,2),
    avg_approval_time INTERVAL,
    avg_processing_time INTERVAL,
    
    -- Quality Metrics
    error_count INTEGER DEFAULT 0,
    reversal_count INTEGER DEFAULT 0,
    quality_score DECIMAL(5,2),
    
    -- Business Impact
    high_impact_changes INTEGER DEFAULT 0,
    compliance_changes INTEGER DEFAULT 0,
    emergency_changes INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(analysis_date, object_class, application_module)
);

-- Indexes for optimal performance
CREATE INDEX IF NOT EXISTS idx_change_headers_object ON change_document_headers(object_class, object_id);
CREATE INDEX IF NOT EXISTS idx_change_headers_timestamp ON change_document_headers(change_timestamp);
CREATE INDEX IF NOT EXISTS idx_change_headers_user ON change_document_headers(user_name, change_date);
CREATE INDEX IF NOT EXISTS idx_change_headers_module ON change_document_headers(application_module, change_type);
CREATE INDEX IF NOT EXISTS idx_change_headers_business_process ON change_document_headers(business_process);

CREATE INDEX IF NOT EXISTS idx_change_positions_change_id ON change_document_positions(change_document_id);
CREATE INDEX IF NOT EXISTS idx_change_positions_table_field ON change_document_positions(table_name, field_name);
CREATE INDEX IF NOT EXISTS idx_change_positions_values ON change_document_positions(old_value, new_value);

CREATE INDEX IF NOT EXISTS idx_change_relations_source ON change_document_relations(source_change_id);
CREATE INDEX IF NOT EXISTS idx_change_relations_target ON change_document_relations(target_change_id);
CREATE INDEX IF NOT EXISTS idx_change_relations_type ON change_document_relations(relation_type);

-- Sequences for change numbering
CREATE SEQUENCE IF NOT EXISTS change_document_number_seq START 1000000;

-- Function to generate change document numbers
CREATE OR REPLACE FUNCTION generate_change_number()
RETURNS VARCHAR(20) AS $$
DECLARE
    next_val BIGINT;
    change_num VARCHAR(20);
BEGIN
    next_val := nextval('change_document_number_seq');
    change_num := 'CHG' || LPAD(next_val::TEXT, 10, '0');
    RETURN change_num;
END;
$$ LANGUAGE plpgsql;

-- Auto-generate change numbers
ALTER TABLE change_document_headers 
ALTER COLUMN change_number SET DEFAULT generate_change_number();

-- Comments for documentation
COMMENT ON TABLE change_document_headers IS 'Main change document table tracking all data modifications across the system';
COMMENT ON TABLE change_document_positions IS 'Detailed field-level changes for each change document';
COMMENT ON TABLE change_document_relations IS 'Relationships and dependencies between different change documents';
COMMENT ON TABLE change_document_approvals IS 'Approval workflow tracking for change documents requiring authorization';
COMMENT ON TABLE change_document_attachments IS 'Supporting documents and files related to change documents';
COMMENT ON TABLE change_document_analytics IS 'Aggregated analytics and metrics for change document analysis';