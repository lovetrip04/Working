-- Transaction Tables Schema
-- Creates all required tables for transaction API endpoints

-- Document Postings Table
CREATE TABLE IF NOT EXISTS document_postings (
    id SERIAL PRIMARY KEY,
    document_number VARCHAR(20) NOT NULL UNIQUE,
    company_code VARCHAR(4) NOT NULL,
    document_type VARCHAR(2) NOT NULL,
    posting_date DATE NOT NULL,
    document_date DATE NOT NULL,
    reference VARCHAR(16),
    header_text VARCHAR(25),
    total_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    currency VARCHAR(3) NOT NULL DEFAULT 'USD',
    status VARCHAR(10) NOT NULL DEFAULT 'Posted',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    fiscal_year INTEGER,
    period INTEGER
);

-- Document Posting Line Items
CREATE TABLE IF NOT EXISTS document_posting_items (
    id SERIAL PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES document_postings(id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    gl_account VARCHAR(10) NOT NULL,
    cost_center VARCHAR(10),
    profit_center VARCHAR(10),
    debit_amount DECIMAL(15,2) DEFAULT 0,
    credit_amount DECIMAL(15,2) DEFAULT 0,
    text VARCHAR(50),
    business_area VARCHAR(4),
    functional_area VARCHAR(16),
    assignment VARCHAR(18),
    reference_key VARCHAR(12),
    CONSTRAINT unique_document_line UNIQUE(document_id, line_number)
);

-- Goods Receipts Table
CREATE TABLE IF NOT EXISTS goods_receipts (
    id SERIAL PRIMARY KEY,
    receipt_number VARCHAR(20) NOT NULL UNIQUE,
    purchase_order VARCHAR(10),
    vendor_code VARCHAR(10) NOT NULL,
    plant_code VARCHAR(4) NOT NULL,
    receipt_date DATE NOT NULL,
    delivery_note VARCHAR(16),
    bill_of_lading VARCHAR(16),
    total_quantity DECIMAL(13,3) NOT NULL DEFAULT 0,
    total_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    currency VARCHAR(3) NOT NULL DEFAULT 'USD',
    status VARCHAR(10) NOT NULL DEFAULT 'Received',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    movement_type VARCHAR(3) DEFAULT '101'
);

-- Goods Receipt Line Items
CREATE TABLE IF NOT EXISTS goods_receipt_items (
    id SERIAL PRIMARY KEY,
    receipt_id INTEGER NOT NULL REFERENCES goods_receipts(id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    material_code VARCHAR(18) NOT NULL,
    quantity DECIMAL(13,3) NOT NULL,
    unit_of_measure VARCHAR(3) NOT NULL,
    unit_price DECIMAL(11,2),
    storage_location VARCHAR(4),
    batch_number VARCHAR(10),
    expiration_date DATE,
    vendor_batch VARCHAR(15),
    quality_inspection BOOLEAN DEFAULT false,
    CONSTRAINT unique_receipt_line UNIQUE(receipt_id, line_number)
);

-- Payments Table
CREATE TABLE IF NOT EXISTS payments (
    id SERIAL PRIMARY KEY,
    payment_number VARCHAR(20) NOT NULL UNIQUE,
    payment_method VARCHAR(1) NOT NULL, -- T=Transfer, C=Check, etc.
    vendor_code VARCHAR(10),
    customer_code VARCHAR(10),
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'USD',
    payment_date DATE NOT NULL,
    value_date DATE NOT NULL,
    reference VARCHAR(20),
    bank_account VARCHAR(18),
    house_bank VARCHAR(5),
    payment_reason VARCHAR(4),
    status VARCHAR(10) NOT NULL DEFAULT 'Processed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50),
    company_code VARCHAR(4) NOT NULL,
    cleared_document VARCHAR(10)
);

-- Movement Types Master Data
CREATE TABLE IF NOT EXISTS movement_types (
    id SERIAL PRIMARY KEY,
    movement_type VARCHAR(3) NOT NULL UNIQUE,
    description VARCHAR(40) NOT NULL,
    movement_indicator VARCHAR(1), -- B=Goods Receipt, I=Goods Issue, etc.
    special_stock_indicator VARCHAR(1),
    quantity_update BOOLEAN DEFAULT true,
    value_update BOOLEAN DEFAULT true,
    account_modification BOOLEAN DEFAULT false,
    negative_posting BOOLEAN DEFAULT false,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert standard movement types
INSERT INTO movement_types (movement_type, description, movement_indicator, quantity_update, value_update) VALUES
('101', 'GR Goods Receipt for Purchase Order', 'B', true, true),
('102', 'GR Reversal', 'B', true, true),
('201', 'Goods Issue to Cost Center', 'I', true, true),
('261', 'Goods Issue to Project', 'I', true, true),
('311', 'Transfer Posting Plant to Plant', 'T', true, true),
('315', 'Transfer Posting Storage Location', 'T', true, true),
('501', 'Receipt Without Purchase Order', 'B', true, true),
('551', 'Scrapping', 'I', true, true),
('601', 'Goods Issue to Customer', 'I', true, true),
('701', 'Physical Inventory Difference', 'D', true, true)
ON CONFLICT (movement_type) DO NOTHING;

-- Automatic Clearing Configuration
CREATE TABLE IF NOT EXISTS clearing_configurations (
    id SERIAL PRIMARY KEY,
    company_code VARCHAR(4) NOT NULL,
    account_type VARCHAR(1) NOT NULL, -- D=Debitor, K=Kreditor, S=GL Account
    gl_account VARCHAR(10),
    tolerance_group VARCHAR(4),
    sort_criteria VARCHAR(20),
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Clearing Items Log
CREATE TABLE IF NOT EXISTS clearing_items (
    id SERIAL PRIMARY KEY,
    clearing_number VARCHAR(20) NOT NULL,
    company_code VARCHAR(4) NOT NULL,
    account_number VARCHAR(10) NOT NULL,
    document_number VARCHAR(10) NOT NULL,
    line_item INTEGER NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) NOT NULL,
    clearing_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Foreign Currency Valuation
CREATE TABLE IF NOT EXISTS currency_valuations (
    id SERIAL PRIMARY KEY,
    company_code VARCHAR(4) NOT NULL,
    valuation_date DATE NOT NULL,
    currency VARCHAR(3) NOT NULL,
    exchange_rate DECIMAL(9,5) NOT NULL,
    valuation_method VARCHAR(2),
    gl_account VARCHAR(10),
    valuation_difference DECIMAL(15,2),
    status VARCHAR(10) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Asset Accounting
CREATE TABLE IF NOT EXISTS assets (
    id SERIAL PRIMARY KEY,
    asset_number VARCHAR(12) NOT NULL UNIQUE,
    asset_class VARCHAR(8) NOT NULL,
    description VARCHAR(50) NOT NULL,
    company_code VARCHAR(4) NOT NULL,
    cost_center VARCHAR(10),
    plant VARCHAR(4),
    location VARCHAR(10),
    acquisition_date DATE,
    acquisition_value DECIMAL(15,2) DEFAULT 0,
    accumulated_depreciation DECIMAL(15,2) DEFAULT 0,
    book_value DECIMAL(15,2) DEFAULT 0,
    useful_life INTEGER,
    depreciation_key VARCHAR(4),
    status VARCHAR(1) DEFAULT 'A', -- A=Active, I=Inactive
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bank Statement Processing
CREATE TABLE IF NOT EXISTS bank_statements (
    id SERIAL PRIMARY KEY,
    statement_number VARCHAR(20) NOT NULL UNIQUE,
    bank_account VARCHAR(18) NOT NULL,
    house_bank VARCHAR(5) NOT NULL,
    company_code VARCHAR(4) NOT NULL,
    statement_date DATE NOT NULL,
    opening_balance DECIMAL(15,2) NOT NULL,
    closing_balance DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'USD',
    status VARCHAR(10) DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bank Statement Line Items
CREATE TABLE IF NOT EXISTS bank_statement_items (
    id SERIAL PRIMARY KEY,
    statement_id INTEGER NOT NULL REFERENCES bank_statements(id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    value_date DATE NOT NULL,
    posting_date DATE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    reference VARCHAR(35),
    text VARCHAR(50),
    partner_account VARCHAR(34),
    partner_name VARCHAR(35),
    cleared BOOLEAN DEFAULT false,
    document_number VARCHAR(10),
    CONSTRAINT unique_statement_line UNIQUE(statement_id, line_number)
);

-- Down Payment Management
CREATE TABLE IF NOT EXISTS down_payments (
    id SERIAL PRIMARY KEY,
    down_payment_number VARCHAR(20) NOT NULL UNIQUE,
    vendor_code VARCHAR(10),
    customer_code VARCHAR(10),
    company_code VARCHAR(4) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'USD',
    request_date DATE NOT NULL,
    payment_date DATE,
    clearing_date DATE,
    gl_account VARCHAR(10) NOT NULL,
    reference VARCHAR(20),
    status VARCHAR(10) DEFAULT 'Requested',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_document_postings_company_date ON document_postings(company_code, posting_date);
CREATE INDEX IF NOT EXISTS idx_goods_receipts_vendor_date ON goods_receipts(vendor_code, receipt_date);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_vendor ON payments(vendor_code);
CREATE INDEX IF NOT EXISTS idx_payments_customer ON payments(customer_code);
CREATE INDEX IF NOT EXISTS idx_assets_company ON assets(company_code);
CREATE INDEX IF NOT EXISTS idx_bank_statements_account ON bank_statements(bank_account, statement_date);

-- Add constraints for data integrity
ALTER TABLE document_postings ADD CONSTRAINT check_total_amount_positive CHECK (total_amount >= 0);
ALTER TABLE goods_receipts ADD CONSTRAINT check_quantity_positive CHECK (total_quantity >= 0);
ALTER TABLE payments ADD CONSTRAINT check_payment_amount_positive CHECK (amount > 0);
ALTER TABLE assets ADD CONSTRAINT check_acquisition_value_positive CHECK (acquisition_value >= 0);