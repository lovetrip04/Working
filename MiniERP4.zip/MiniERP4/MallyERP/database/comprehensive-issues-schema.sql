-- Comprehensive Issues and AI Agent Resolution System
-- This system captures all issues across Master Data and Modules with AI-powered resolution

-- Main issues log table
CREATE TABLE IF NOT EXISTS comprehensive_issues_log (
    id BIGSERIAL PRIMARY KEY,
    issue_id UUID UNIQUE DEFAULT gen_random_uuid(),
    error_message TEXT NOT NULL,
    stack_trace TEXT,
    
    -- Context Information
    module VARCHAR(100) NOT NULL,
    operation VARCHAR(200) NOT NULL,
    user_id VARCHAR(100),
    session_id VARCHAR(100),
    request_data JSONB,
    
    -- Classification
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    category VARCHAR(20) NOT NULL CHECK (category IN ('MASTER_DATA', 'TRANSACTION', 'SYSTEM', 'API', 'DATABASE', 'VALIDATION')),
    
    -- Resolution Tracking
    status VARCHAR(20) DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'IN_PROGRESS', 'RESOLVED', 'ESCALATED')),
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by VARCHAR(50),
    
    -- Additional Data
    additional_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- AI Agent Interventions Table
CREATE TABLE IF NOT EXISTS ai_agent_interventions (
    id BIGSERIAL PRIMARY KEY,
    issue_id UUID NOT NULL REFERENCES comprehensive_issues_log(issue_id) ON DELETE CASCADE,
    agent_name VARCHAR(200) NOT NULL,
    agent_type VARCHAR(50) NOT NULL,
    
    -- Analysis Results
    analysis_result JSONB NOT NULL,
    recommended_actions JSONB NOT NULL,
    confidence_score DECIMAL(3,2) CHECK (confidence_score BETWEEN 0 AND 1),
    
    -- Execution Status
    execution_status VARCHAR(20) DEFAULT 'PENDING' CHECK (execution_status IN ('PENDING', 'EXECUTING', 'COMPLETED', 'FAILED')),
    execution_start TIMESTAMP WITH TIME ZONE,
    execution_end TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Issue Resolutions Table
CREATE TABLE IF NOT EXISTS issue_resolutions (
    id BIGSERIAL PRIMARY KEY,
    resolution_id UUID UNIQUE DEFAULT gen_random_uuid(),
    issue_id UUID NOT NULL REFERENCES comprehensive_issues_log(issue_id) ON DELETE CASCADE,
    
    -- Resolution Information
    resolved_by VARCHAR(50) NOT NULL CHECK (resolved_by IN ('AI_AGENT', 'AUTO_RECOVERY', 'MANUAL', 'SYSTEM')),
    resolution_time INTEGER, -- milliseconds
    steps JSONB NOT NULL,
    success BOOLEAN NOT NULL,
    
    -- Additional Information
    additional_notes TEXT,
    validation_checks JSONB,
    rollback_info JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Issue Patterns Table for Learning
CREATE TABLE IF NOT EXISTS issue_patterns (
    id BIGSERIAL PRIMARY KEY,
    pattern_name VARCHAR(200) NOT NULL,
    pattern_regex VARCHAR(500) NOT NULL,
    category VARCHAR(20) NOT NULL,
    
    -- Pattern Effectiveness
    match_count INTEGER DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0.00,
    avg_resolution_time INTEGER DEFAULT 0,
    
    -- Auto-resolution Configuration
    auto_resolvable BOOLEAN DEFAULT false,
    resolution_template JSONB,
    confidence_threshold DECIMAL(3,2) DEFAULT 0.80,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Module Health Monitoring
CREATE TABLE IF NOT EXISTS module_health_status (
    id BIGSERIAL PRIMARY KEY,
    module_name VARCHAR(100) NOT NULL UNIQUE,
    health_score DECIMAL(5,2) NOT NULL CHECK (health_score BETWEEN 0 AND 100),
    
    -- Issue Metrics
    total_issues INTEGER DEFAULT 0,
    critical_issues INTEGER DEFAULT 0,
    resolved_issues INTEGER DEFAULT 0,
    avg_resolution_time INTEGER DEFAULT 0,
    
    -- Performance Metrics
    response_time_avg INTEGER DEFAULT 0,
    error_rate DECIMAL(5,2) DEFAULT 0.00,
    availability_score DECIMAL(5,2) DEFAULT 100.00,
    
    -- AI Agent Performance
    ai_intervention_count INTEGER DEFAULT 0,
    ai_success_rate DECIMAL(5,2) DEFAULT 0.00,
    
    last_check TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Issue Analytics Summary
CREATE TABLE IF NOT EXISTS issue_analytics_summary (
    id BIGSERIAL PRIMARY KEY,
    analysis_date DATE NOT NULL DEFAULT CURRENT_DATE,
    
    -- Volume Metrics
    total_issues INTEGER DEFAULT 0,
    critical_issues INTEGER DEFAULT 0,
    high_issues INTEGER DEFAULT 0,
    medium_issues INTEGER DEFAULT 0,
    low_issues INTEGER DEFAULT 0,
    
    -- Resolution Metrics
    ai_resolved INTEGER DEFAULT 0,
    auto_resolved INTEGER DEFAULT 0,
    manual_resolved INTEGER DEFAULT 0,
    unresolved INTEGER DEFAULT 0,
    
    -- Performance Metrics
    avg_resolution_time INTEGER DEFAULT 0,
    median_resolution_time INTEGER DEFAULT 0,
    fastest_resolution INTEGER DEFAULT 0,
    slowest_resolution INTEGER DEFAULT 0,
    
    -- Category Breakdown
    master_data_issues INTEGER DEFAULT 0,
    transaction_issues INTEGER DEFAULT 0,
    system_issues INTEGER DEFAULT 0,
    api_issues INTEGER DEFAULT 0,
    database_issues INTEGER DEFAULT 0,
    validation_issues INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(analysis_date)
);

-- AI Agent Performance Tracking
CREATE TABLE IF NOT EXISTS ai_agent_performance (
    id BIGSERIAL PRIMARY KEY,
    agent_name VARCHAR(200) NOT NULL,
    agent_type VARCHAR(50) NOT NULL,
    performance_date DATE NOT NULL DEFAULT CURRENT_DATE,
    
    -- Intervention Metrics
    total_interventions INTEGER DEFAULT 0,
    successful_interventions INTEGER DEFAULT 0,
    failed_interventions INTEGER DEFAULT 0,
    
    -- Performance Metrics
    avg_confidence_score DECIMAL(3,2) DEFAULT 0.00,
    avg_resolution_time INTEGER DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0.00,
    
    -- Learning Metrics
    pattern_matches INTEGER DEFAULT 0,
    new_patterns_learned INTEGER DEFAULT 0,
    accuracy_improvement DECIMAL(5,2) DEFAULT 0.00,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(agent_name, agent_type, performance_date)
);

-- Indexes for optimal performance
CREATE INDEX IF NOT EXISTS idx_issues_log_module_status ON comprehensive_issues_log(module, status);
CREATE INDEX IF NOT EXISTS idx_issues_log_category_severity ON comprehensive_issues_log(category, severity);
CREATE INDEX IF NOT EXISTS idx_issues_log_created_at ON comprehensive_issues_log(created_at);
CREATE INDEX IF NOT EXISTS idx_issues_log_resolved_by ON comprehensive_issues_log(resolved_by);

CREATE INDEX IF NOT EXISTS idx_ai_interventions_issue_id ON ai_agent_interventions(issue_id);
CREATE INDEX IF NOT EXISTS idx_ai_interventions_agent_type ON ai_agent_interventions(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_interventions_confidence ON ai_agent_interventions(confidence_score);

CREATE INDEX IF NOT EXISTS idx_resolutions_issue_id ON issue_resolutions(issue_id);
CREATE INDEX IF NOT EXISTS idx_resolutions_resolved_by ON issue_resolutions(resolved_by);
CREATE INDEX IF NOT EXISTS idx_resolutions_success ON issue_resolutions(success);

CREATE INDEX IF NOT EXISTS idx_patterns_category ON issue_patterns(category);
CREATE INDEX IF NOT EXISTS idx_patterns_auto_resolvable ON issue_patterns(auto_resolvable);

CREATE INDEX IF NOT EXISTS idx_module_health_module ON module_health_status(module_name);
CREATE INDEX IF NOT EXISTS idx_module_health_score ON module_health_status(health_score);

-- Triggers for automatic updates
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_issues_log_updated_at BEFORE UPDATE
    ON comprehensive_issues_log FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_patterns_updated_at BEFORE UPDATE
    ON issue_patterns FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically update module health
CREATE OR REPLACE FUNCTION update_module_health()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO module_health_status (
        module_name, health_score, total_issues, critical_issues,
        resolved_issues, last_check
    )
    SELECT 
        NEW.module,
        CASE 
            WHEN COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END) > 0 THEN 25.0
            WHEN COUNT(CASE WHEN severity = 'HIGH' THEN 1 END) > 5 THEN 50.0
            WHEN COUNT(CASE WHEN severity = 'MEDIUM' THEN 1 END) > 10 THEN 75.0
            ELSE 100.0
        END,
        COUNT(*),
        COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END),
        COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END),
        CURRENT_TIMESTAMP
    FROM comprehensive_issues_log
    WHERE module = NEW.module
    GROUP BY module
    ON CONFLICT (module_name) DO UPDATE SET
        health_score = EXCLUDED.health_score,
        total_issues = EXCLUDED.total_issues,
        critical_issues = EXCLUDED.critical_issues,
        resolved_issues = EXCLUDED.resolved_issues,
        last_check = EXCLUDED.last_check;
    
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trigger_update_module_health
    AFTER INSERT OR UPDATE ON comprehensive_issues_log
    FOR EACH ROW EXECUTE FUNCTION update_module_health();

-- Comments for documentation
COMMENT ON TABLE comprehensive_issues_log IS 'Central logging for all system issues with comprehensive context tracking';
COMMENT ON TABLE ai_agent_interventions IS 'Tracks AI agent analysis and intervention attempts for issues';
COMMENT ON TABLE issue_resolutions IS 'Records all resolution attempts and their outcomes';
COMMENT ON TABLE issue_patterns IS 'Learning database for issue pattern recognition and auto-resolution';
COMMENT ON TABLE module_health_status IS 'Real-time health monitoring for all ERP modules';
COMMENT ON TABLE issue_analytics_summary IS 'Daily aggregated analytics for issue trends and patterns';
COMMENT ON TABLE ai_agent_performance IS 'Performance tracking and learning metrics for AI agents';