--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: approval_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.approval_status AS ENUM (
    'draft',
    'pending_approval',
    'approved',
    'rejected',
    'superseded'
);


--
-- Name: generate_change_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_change_number() RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    next_val BIGINT;
    change_num VARCHAR(20);
BEGIN
    next_val := nextval('change_document_number_seq');
    change_num := 'CHG' || LPAD(next_val::TEXT, 10, '0');
    RETURN change_num;
END;
$$;


--
-- Name: update_module_health(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_module_health() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO module_health_status (
        module_name, health_score, total_issues, critical_issues,
        resolved_issues, last_check
    )
    SELECT 
        NEW.module,
        CASE 
            WHEN COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END) > 0 THEN 25.0
            WHEN COUNT(CASE WHEN severity = 'HIGH' THEN 1 END) > 5 THEN 50.0
            WHEN COUNT(CASE WHEN severity = 'MEDIUM' THEN 1 END) > 10 THEN 75.0
            ELSE 100.0
        END,
        COUNT(*),
        COUNT(CASE WHEN severity = 'CRITICAL' THEN 1 END),
        COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END),
        CURRENT_TIMESTAMP
    FROM comprehensive_issues_log
    WHERE module = NEW.module
    GROUP BY module
    ON CONFLICT (module_name) DO UPDATE SET
        health_score = EXCLUDED.health_score,
        total_issues = EXCLUDED.total_issues,
        critical_issues = EXCLUDED.critical_issues,
        resolved_issues = EXCLUDED.resolved_issues,
        last_check = EXCLUDED.last_check;
    
    RETURN NEW;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_groups (
    id integer NOT NULL,
    chart_id character varying(10) NOT NULL,
    group_name character varying(50) NOT NULL,
    account_range_from character varying(10),
    account_range_to character varying(10),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: account_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_groups_id_seq OWNED BY public.account_groups.id;


--
-- Name: accounts_payable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts_payable (
    id integer NOT NULL,
    vendor_id integer,
    invoice_number character varying(50) NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency_id integer,
    company_code_id integer,
    plant_id integer,
    purchase_order_id integer,
    payment_terms character varying(50),
    status character varying(20) DEFAULT 'Open'::character varying,
    payment_date date,
    payment_reference character varying(100),
    discount_amount numeric(15,2) DEFAULT 0,
    tax_amount numeric(15,2) DEFAULT 0,
    net_amount numeric(15,2) NOT NULL,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: accounts_payable_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounts_payable_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_payable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounts_payable_id_seq OWNED BY public.accounts_payable.id;


--
-- Name: accounts_receivable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts_receivable (
    id integer NOT NULL,
    customer_id integer,
    invoice_number character varying(50) NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency_id integer,
    company_code_id integer,
    plant_id integer,
    sales_order_id integer,
    payment_terms character varying(50),
    status character varying(20) DEFAULT 'Open'::character varying,
    payment_date date,
    payment_reference character varying(100),
    discount_amount numeric(15,2) DEFAULT 0,
    tax_amount numeric(15,2) DEFAULT 0,
    net_amount numeric(15,2) NOT NULL,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: accounts_receivable_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounts_receivable_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_receivable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounts_receivable_id_seq OWNED BY public.accounts_receivable.id;


--
-- Name: activity_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_types (
    id integer NOT NULL,
    activity_type character varying(10) NOT NULL,
    description character varying(100) NOT NULL,
    unit_of_measure character varying(3) NOT NULL,
    category character varying(20) NOT NULL,
    controlling_area character varying(4) NOT NULL,
    allocation_method character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: activity_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activity_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activity_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activity_types_id_seq OWNED BY public.activity_types.id;


--
-- Name: ai_agent_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agent_analytics (
    id integer NOT NULL,
    module_type character varying(50) NOT NULL,
    date date DEFAULT CURRENT_DATE,
    total_queries integer DEFAULT 0,
    successful_queries integer DEFAULT 0,
    failed_queries integer DEFAULT 0,
    avg_response_time numeric(10,2),
    total_tokens_used integer DEFAULT 0,
    unique_users integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: ai_agent_analytics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_agent_analytics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_agent_analytics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_agent_analytics_id_seq OWNED BY public.ai_agent_analytics.id;


--
-- Name: ai_agent_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agent_configs (
    id integer NOT NULL,
    module_type character varying(50) NOT NULL,
    module_name character varying(100) NOT NULL,
    agent_name character varying(100) NOT NULL,
    role_description text NOT NULL,
    system_prompt text NOT NULL,
    expertise_areas jsonb NOT NULL,
    capabilities jsonb NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: ai_agent_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_agent_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_agent_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_agent_configs_id_seq OWNED BY public.ai_agent_configs.id;


--
-- Name: ai_agent_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agent_health (
    id integer NOT NULL,
    check_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    openai_status character varying(20) NOT NULL,
    api_key_status character varying(20) NOT NULL,
    total_agents integer NOT NULL,
    active_agents integer NOT NULL,
    response_time integer,
    error_details jsonb,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: ai_agent_health_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_agent_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_agent_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_agent_health_id_seq OWNED BY public.ai_agent_health.id;


--
-- Name: ai_agent_interventions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agent_interventions (
    id bigint NOT NULL,
    issue_id uuid NOT NULL,
    agent_name character varying(200) NOT NULL,
    agent_type character varying(50) NOT NULL,
    analysis_result jsonb NOT NULL,
    recommended_actions jsonb NOT NULL,
    confidence_score numeric(3,2),
    execution_status character varying(20) DEFAULT 'PENDING'::character varying,
    execution_start timestamp with time zone,
    execution_end timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ai_agent_interventions_confidence_score_check CHECK (((confidence_score >= (0)::numeric) AND (confidence_score <= (1)::numeric))),
    CONSTRAINT ai_agent_interventions_execution_status_check CHECK (((execution_status)::text = ANY ((ARRAY['PENDING'::character varying, 'EXECUTING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying])::text[])))
);


--
-- Name: TABLE ai_agent_interventions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ai_agent_interventions IS 'Tracks AI agent analysis and intervention attempts for issues';


--
-- Name: ai_agent_interventions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_agent_interventions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_agent_interventions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_agent_interventions_id_seq OWNED BY public.ai_agent_interventions.id;


--
-- Name: ai_agent_performance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agent_performance (
    id bigint NOT NULL,
    agent_name character varying(200) NOT NULL,
    agent_type character varying(50) NOT NULL,
    performance_date date DEFAULT CURRENT_DATE NOT NULL,
    total_interventions integer DEFAULT 0,
    successful_interventions integer DEFAULT 0,
    failed_interventions integer DEFAULT 0,
    avg_confidence_score numeric(3,2) DEFAULT 0.00,
    avg_resolution_time integer DEFAULT 0,
    success_rate numeric(5,2) DEFAULT 0.00,
    pattern_matches integer DEFAULT 0,
    new_patterns_learned integer DEFAULT 0,
    accuracy_improvement numeric(5,2) DEFAULT 0.00,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE ai_agent_performance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ai_agent_performance IS 'Performance tracking and learning metrics for AI agents';


--
-- Name: ai_agent_performance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_agent_performance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_agent_performance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_agent_performance_id_seq OWNED BY public.ai_agent_performance.id;


--
-- Name: ai_chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_chat_messages (
    id integer NOT NULL,
    session_id uuid NOT NULL,
    message_type character varying(20) NOT NULL,
    content text NOT NULL,
    agent_name character varying(100),
    context_data jsonb,
    api_response_time integer,
    tokens_used integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ai_chat_messages_message_type_check CHECK (((message_type)::text = ANY ((ARRAY['user'::character varying, 'agent'::character varying])::text[])))
);


--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_chat_messages_id_seq OWNED BY public.ai_chat_messages.id;


--
-- Name: ai_chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_chat_sessions (
    id integer NOT NULL,
    session_id uuid DEFAULT gen_random_uuid(),
    module_type character varying(50) NOT NULL,
    user_id integer,
    user_role character varying(50),
    context_data jsonb,
    session_start timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    session_end timestamp with time zone,
    is_active boolean DEFAULT true,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: ai_chat_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_chat_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_chat_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_chat_sessions_id_seq OWNED BY public.ai_chat_sessions.id;


--
-- Name: ai_data_analysis_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_data_analysis_sessions (
    id integer NOT NULL,
    session_id uuid DEFAULT gen_random_uuid(),
    module_type character varying(50) NOT NULL,
    analysis_type character varying(50) NOT NULL,
    input_data jsonb NOT NULL,
    analysis_result text,
    insights jsonb,
    recommendations jsonb,
    user_id integer,
    processing_time integer,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ai_data_analysis_sessions_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'completed'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: ai_data_analysis_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_data_analysis_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_data_analysis_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_data_analysis_sessions_id_seq OWNED BY public.ai_data_analysis_sessions.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    key_name character varying(100) NOT NULL,
    key_value text NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_used timestamp with time zone,
    active boolean DEFAULT true
);


--
-- Name: TABLE api_keys; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.api_keys IS 'Secure storage for API keys and external service credentials';


--
-- Name: COLUMN api_keys.service_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.api_keys.service_name IS 'Name of the service (e.g., openai, stripe, twilio)';


--
-- Name: COLUMN api_keys.key_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.api_keys.key_name IS 'Environment variable name for the key';


--
-- Name: COLUMN api_keys.key_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.api_keys.key_value IS 'Encrypted API key value';


--
-- Name: COLUMN api_keys.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.api_keys.is_active IS 'Whether the key is currently active and should be used';


--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: approval_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_levels (
    id integer NOT NULL,
    level integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    value_limit numeric(15,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: approval_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.approval_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: approval_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.approval_levels_id_seq OWNED BY public.approval_levels.id;


--
-- Name: asset_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_master (
    id integer NOT NULL,
    asset_number character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    asset_class character varying(50),
    acquisition_date date,
    acquisition_cost numeric(15,2),
    current_value numeric(15,2),
    depreciation_method character varying(50),
    useful_life_years integer,
    company_code_id integer,
    cost_center_id integer,
    location character varying(100),
    status character varying(20),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: asset_master_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.asset_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.asset_master_id_seq OWNED BY public.asset_master.id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    asset_number character varying(12) NOT NULL,
    asset_class character varying(8) NOT NULL,
    description character varying(50) NOT NULL,
    company_code character varying(4) NOT NULL,
    cost_center character varying(10),
    plant character varying(4),
    location character varying(10),
    acquisition_date date,
    acquisition_value numeric(15,2) DEFAULT 0,
    accumulated_depreciation numeric(15,2) DEFAULT 0,
    book_value numeric(15,2) DEFAULT 0,
    useful_life integer,
    depreciation_key character varying(4),
    status character varying(1) DEFAULT 'A'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_acquisition_value_positive CHECK ((acquisition_value >= (0)::numeric))
);


--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assets_id_seq OWNED BY public.assets.id;


--
-- Name: bank_statement_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_statement_items (
    id integer NOT NULL,
    statement_id integer NOT NULL,
    line_number integer NOT NULL,
    value_date date NOT NULL,
    posting_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    reference character varying(35),
    text character varying(50),
    partner_account character varying(34),
    partner_name character varying(35),
    cleared boolean DEFAULT false,
    document_number character varying(10)
);


--
-- Name: bank_statement_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_statement_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_statement_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_statement_items_id_seq OWNED BY public.bank_statement_items.id;


--
-- Name: bank_statements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_statements (
    id integer NOT NULL,
    statement_number character varying(20) NOT NULL,
    bank_account character varying(18) NOT NULL,
    house_bank character varying(5) NOT NULL,
    company_code character varying(4) NOT NULL,
    statement_date date NOT NULL,
    opening_balance numeric(15,2) NOT NULL,
    closing_balance numeric(15,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    status character varying(10) DEFAULT 'Open'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: bank_statements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_statements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_statements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_statements_id_seq OWNED BY public.bank_statements.id;


--
-- Name: batch_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_master (
    id integer NOT NULL,
    batch_number character varying(50) NOT NULL,
    material_id integer,
    plant_id integer,
    production_date date,
    expiry_date date,
    shelf_life_days integer,
    vendor_batch_number character varying(50),
    quality_status character varying(20) DEFAULT 'UNRESTRICTED'::character varying,
    available_quantity numeric(15,3),
    reserved_quantity numeric(15,3),
    blocked_quantity numeric(15,3),
    unit_of_measure character varying(10),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: batch_master_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batch_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batch_master_id_seq OWNED BY public.batch_master.id;


--
-- Name: bill_of_materials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bill_of_materials (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    material_id integer NOT NULL,
    description text,
    version character varying(10) DEFAULT '1.0'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: bill_of_materials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bill_of_materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bill_of_materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bill_of_materials_id_seq OWNED BY public.bill_of_materials.id;


--
-- Name: bom_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bom_items (
    id integer NOT NULL,
    bom_id integer NOT NULL,
    material_id integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    unit_cost numeric(15,2),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: bom_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bom_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bom_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bom_items_id_seq OWNED BY public.bom_items.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: change_document_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_document_analytics (
    id bigint NOT NULL,
    analysis_date date DEFAULT CURRENT_DATE NOT NULL,
    object_class character varying(50) NOT NULL,
    application_module character varying(50) NOT NULL,
    total_changes integer DEFAULT 0,
    creates_count integer DEFAULT 0,
    updates_count integer DEFAULT 0,
    deletes_count integer DEFAULT 0,
    avg_fields_changed numeric(10,2),
    avg_approval_time interval,
    avg_processing_time interval,
    error_count integer DEFAULT 0,
    reversal_count integer DEFAULT 0,
    quality_score numeric(5,2),
    high_impact_changes integer DEFAULT 0,
    compliance_changes integer DEFAULT 0,
    emergency_changes integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE change_document_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.change_document_analytics IS 'Aggregated analytics and metrics for change document analysis';


--
-- Name: change_document_analytics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_document_analytics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_document_analytics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_document_analytics_id_seq OWNED BY public.change_document_analytics.id;


--
-- Name: change_document_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_document_approvals (
    id bigint NOT NULL,
    change_document_id uuid NOT NULL,
    approval_level integer NOT NULL,
    approver_role character varying(50) NOT NULL,
    approver_name character varying(100),
    approval_status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    approval_comments text,
    approval_timestamp timestamp with time zone,
    delegation_to character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT change_document_approvals_approval_status_check CHECK (((approval_status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'REJECTED'::character varying, 'DELEGATED'::character varying])::text[])))
);


--
-- Name: TABLE change_document_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.change_document_approvals IS 'Approval workflow tracking for change documents requiring authorization';


--
-- Name: change_document_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_document_approvals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_document_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_document_approvals_id_seq OWNED BY public.change_document_approvals.id;


--
-- Name: change_document_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_document_attachments (
    id bigint NOT NULL,
    change_document_id uuid NOT NULL,
    attachment_type character varying(50) NOT NULL,
    file_name character varying(500) NOT NULL,
    file_path text,
    file_size bigint,
    mime_type character varying(100),
    description text,
    uploaded_by character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE change_document_attachments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.change_document_attachments IS 'Supporting documents and files related to change documents';


--
-- Name: change_document_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_document_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_document_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_document_attachments_id_seq OWNED BY public.change_document_attachments.id;


--
-- Name: change_document_headers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_document_headers (
    id bigint NOT NULL,
    change_document_id uuid DEFAULT gen_random_uuid(),
    object_class character varying(50) NOT NULL,
    object_id character varying(100) NOT NULL,
    change_number character varying(20) DEFAULT public.generate_change_number() NOT NULL,
    user_name character varying(100) NOT NULL,
    user_role character varying(50),
    session_id character varying(100),
    transaction_code character varying(20),
    change_type character varying(20) NOT NULL,
    change_reason character varying(100),
    change_category character varying(50),
    change_date date DEFAULT CURRENT_DATE NOT NULL,
    change_time time without time zone DEFAULT CURRENT_TIME NOT NULL,
    change_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    client_ip character varying(45),
    user_agent text,
    application_module character varying(50),
    business_process character varying(100),
    reference_document character varying(100),
    approval_status character varying(20) DEFAULT 'PENDING'::character varying,
    version_number integer DEFAULT 1,
    parent_change_id uuid,
    is_active boolean DEFAULT true,
    is_reversed boolean DEFAULT false,
    reversal_change_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT change_document_headers_change_type_check CHECK (((change_type)::text = ANY ((ARRAY['CREATE'::character varying, 'UPDATE'::character varying, 'DELETE'::character varying, 'ACTIVATE'::character varying, 'DEACTIVATE'::character varying])::text[])))
);


--
-- Name: TABLE change_document_headers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.change_document_headers IS 'Main change document table tracking all data modifications across the system';


--
-- Name: change_document_headers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_document_headers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_document_headers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_document_headers_id_seq OWNED BY public.change_document_headers.id;


--
-- Name: change_document_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_document_number_seq
    START WITH 1000000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_document_positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_document_positions (
    id bigint NOT NULL,
    change_document_id uuid NOT NULL,
    position_number integer NOT NULL,
    table_name character varying(100) NOT NULL,
    field_name character varying(100) NOT NULL,
    field_label character varying(200),
    data_type character varying(50),
    old_value text,
    new_value text,
    old_value_formatted text,
    new_value_formatted text,
    value_unit character varying(20),
    value_currency character varying(10),
    value_language character varying(10),
    change_indicator character varying(10) NOT NULL,
    change_magnitude numeric(15,4),
    change_percentage numeric(5,2),
    reference_table character varying(100),
    reference_field character varying(100),
    reference_value character varying(200),
    data_quality_score integer,
    validation_status character varying(20) DEFAULT 'VALID'::character varying,
    validation_errors jsonb,
    business_impact character varying(20),
    requires_approval boolean DEFAULT false,
    compliance_flag boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT change_document_positions_business_impact_check CHECK (((business_impact)::text = ANY ((ARRAY['LOW'::character varying, 'MEDIUM'::character varying, 'HIGH'::character varying, 'CRITICAL'::character varying])::text[]))),
    CONSTRAINT change_document_positions_change_indicator_check CHECK (((change_indicator)::text = ANY ((ARRAY['INSERT'::character varying, 'UPDATE'::character varying, 'DELETE'::character varying, 'MOVE'::character varying])::text[]))),
    CONSTRAINT change_document_positions_data_quality_score_check CHECK (((data_quality_score >= 0) AND (data_quality_score <= 100)))
);


--
-- Name: TABLE change_document_positions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.change_document_positions IS 'Detailed field-level changes for each change document';


--
-- Name: change_document_positions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_document_positions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_document_positions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_document_positions_id_seq OWNED BY public.change_document_positions.id;


--
-- Name: change_document_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_document_relations (
    id bigint NOT NULL,
    source_change_id uuid NOT NULL,
    target_change_id uuid NOT NULL,
    relation_type character varying(50) NOT NULL,
    relation_strength character varying(20) DEFAULT 'MEDIUM'::character varying,
    business_context text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE change_document_relations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.change_document_relations IS 'Relationships and dependencies between different change documents';


--
-- Name: change_document_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_document_relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_document_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_document_relations_id_seq OWNED BY public.change_document_relations.id;


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    chart_id character varying(10) NOT NULL,
    description character varying(255) NOT NULL,
    account_length integer DEFAULT 6,
    maintenance_language character varying(2),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;


--
-- Name: clearing_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clearing_configurations (
    id integer NOT NULL,
    company_code character varying(4) NOT NULL,
    account_type character varying(1) NOT NULL,
    gl_account character varying(10),
    tolerance_group character varying(4),
    sort_criteria character varying(20),
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: clearing_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clearing_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clearing_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clearing_configurations_id_seq OWNED BY public.clearing_configurations.id;


--
-- Name: clearing_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clearing_items (
    id integer NOT NULL,
    clearing_number character varying(20) NOT NULL,
    company_code character varying(4) NOT NULL,
    account_number character varying(10) NOT NULL,
    document_number character varying(10) NOT NULL,
    line_item integer NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency character varying(3) NOT NULL,
    clearing_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: clearing_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clearing_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clearing_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clearing_items_id_seq OWNED BY public.clearing_items.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    company_id character varying(10) NOT NULL,
    name character varying(255) NOT NULL,
    address text,
    country character varying(2),
    currency character varying(3),
    language character varying(2),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: company_code_chart_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_code_chart_assignments (
    id integer NOT NULL,
    company_code_id integer,
    chart_of_accounts_id integer,
    fiscal_year_variant_id integer,
    assigned_date timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: company_code_chart_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.company_code_chart_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_code_chart_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.company_code_chart_assignments_id_seq OWNED BY public.company_code_chart_assignments.id;


--
-- Name: company_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_codes (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(255) NOT NULL,
    city character varying(100),
    country character varying(100),
    currency character varying(3),
    language character varying(50),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: company_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.company_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.company_codes_id_seq OWNED BY public.company_codes.id;


--
-- Name: comprehensive_issues_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comprehensive_issues_log (
    id bigint NOT NULL,
    issue_id uuid DEFAULT gen_random_uuid(),
    error_message text NOT NULL,
    stack_trace text,
    module character varying(100) NOT NULL,
    operation character varying(200) NOT NULL,
    user_id character varying(100),
    session_id character varying(100),
    request_data jsonb,
    severity character varying(20) NOT NULL,
    category character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'OPEN'::character varying,
    resolved_at timestamp with time zone,
    resolved_by character varying(50),
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    auto_resolvable boolean DEFAULT false,
    confidence_score numeric(3,2) DEFAULT 0.0,
    pattern_matched jsonb,
    recommended_actions jsonb,
    ai_analysis jsonb,
    business_context text,
    user_impact text,
    resolution_status character varying(20) DEFAULT 'PENDING'::character varying,
    CONSTRAINT comprehensive_issues_log_category_check CHECK (((category)::text = ANY ((ARRAY['MASTER_DATA'::character varying, 'TRANSACTION'::character varying, 'SYSTEM'::character varying, 'API'::character varying, 'DATABASE'::character varying, 'VALIDATION'::character varying])::text[]))),
    CONSTRAINT comprehensive_issues_log_severity_check CHECK (((severity)::text = ANY ((ARRAY['LOW'::character varying, 'MEDIUM'::character varying, 'HIGH'::character varying, 'CRITICAL'::character varying])::text[]))),
    CONSTRAINT comprehensive_issues_log_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'IN_PROGRESS'::character varying, 'RESOLVED'::character varying, 'ESCALATED'::character varying])::text[])))
);


--
-- Name: TABLE comprehensive_issues_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.comprehensive_issues_log IS 'Central logging for all system issues with comprehensive context tracking';


--
-- Name: comprehensive_issues_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comprehensive_issues_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comprehensive_issues_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comprehensive_issues_log_id_seq OWNED BY public.comprehensive_issues_log.id;


--
-- Name: copa_actuals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.copa_actuals (
    id integer NOT NULL,
    operating_concern character varying(4) NOT NULL,
    fiscal_year integer NOT NULL,
    period integer NOT NULL,
    record_type character varying(1) NOT NULL,
    customer character varying(10),
    material character varying(18),
    product_group character varying(10),
    customer_group character varying(5),
    sales_organization character varying(4),
    distribution_channel character varying(2),
    division character varying(2),
    region character varying(10),
    country character varying(3),
    profit_center character varying(10),
    value_field character varying(5) NOT NULL,
    amount numeric(15,2) NOT NULL,
    quantity numeric(15,3) DEFAULT 0,
    currency character varying(3) DEFAULT 'USD'::character varying,
    unit_of_measure character varying(3),
    posting_date date NOT NULL,
    document_number character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    customer_id integer,
    material_id integer,
    profit_center_id integer,
    sales_org_id integer,
    company_code_id integer,
    currency_id integer,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: copa_actuals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.copa_actuals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: copa_actuals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.copa_actuals_id_seq OWNED BY public.copa_actuals.id;


--
-- Name: cost_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_allocations (
    id integer NOT NULL,
    allocation_id character varying(20) NOT NULL,
    allocation_type character varying(20) NOT NULL,
    sender_object_type character varying(20) NOT NULL,
    sender_object character varying(20) NOT NULL,
    receiver_object_type character varying(20) NOT NULL,
    receiver_object character varying(20) NOT NULL,
    fiscal_year integer NOT NULL,
    period integer NOT NULL,
    allocation_base character varying(20),
    percentage numeric(5,2),
    amount numeric(15,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying,
    posting_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: cost_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_allocations_id_seq OWNED BY public.cost_allocations.id;


--
-- Name: cost_center_actuals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_center_actuals (
    id integer NOT NULL,
    cost_center character varying(10) NOT NULL,
    fiscal_year integer NOT NULL,
    period integer NOT NULL,
    account character varying(10) NOT NULL,
    activity_type character varying(10),
    actual_amount numeric(15,2) DEFAULT 0,
    actual_quantity numeric(15,3) DEFAULT 0,
    currency character varying(3) DEFAULT 'USD'::character varying,
    unit_of_measure character varying(3),
    posting_date date NOT NULL,
    document_number character varying(20),
    reference character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    cost_center_id integer,
    company_code_id integer,
    currency_id integer,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: cost_center_actuals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_center_actuals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_center_actuals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_center_actuals_id_seq OWNED BY public.cost_center_actuals.id;


--
-- Name: cost_center_planning; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_center_planning (
    id integer NOT NULL,
    cost_center character varying(10) NOT NULL,
    fiscal_year integer NOT NULL,
    period integer NOT NULL,
    version character varying(10) DEFAULT '000'::character varying,
    account character varying(10) NOT NULL,
    activity_type character varying(10),
    planned_amount numeric(15,2) DEFAULT 0,
    planned_quantity numeric(15,3) DEFAULT 0,
    currency character varying(3) DEFAULT 'USD'::character varying,
    unit_of_measure character varying(3),
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: cost_center_planning_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_center_planning_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_center_planning_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_center_planning_id_seq OWNED BY public.cost_center_planning.id;


--
-- Name: cost_centers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_centers (
    id integer NOT NULL,
    cost_center character varying(10) NOT NULL,
    description character varying(100) NOT NULL,
    cost_center_category character varying(20) NOT NULL,
    company_code character varying(4) NOT NULL,
    controlling_area character varying(4) NOT NULL,
    hierarchy_area character varying(20),
    responsible_person character varying(50),
    valid_from date NOT NULL,
    valid_to date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    company_code_id integer,
    plant_id integer,
    responsible_person_id integer,
    active boolean DEFAULT true
);


--
-- Name: cost_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_centers_id_seq OWNED BY public.cost_centers.id;


--
-- Name: cost_elements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_elements (
    id integer NOT NULL,
    cost_element_code character varying(50) NOT NULL,
    cost_element_name character varying(255) NOT NULL,
    cost_element_type character varying(20) NOT NULL,
    gl_account character varying(50),
    cost_center character varying(50),
    description text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: cost_elements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_elements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_elements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_elements_id_seq OWNED BY public.cost_elements.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    code character varying(2) NOT NULL,
    name character varying(100) NOT NULL,
    region_id integer,
    currency_code character varying(3),
    language_code character varying(5),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: credit_control_areas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_control_areas (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    company_code_id integer NOT NULL,
    credit_checking_group character varying(50),
    credit_period integer DEFAULT 30,
    grace_percentage numeric DEFAULT 10,
    blocking_reason character varying(100),
    review_frequency character varying(20) DEFAULT 'monthly'::character varying,
    currency character varying(3) DEFAULT 'USD'::character varying,
    credit_approver character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    is_active boolean DEFAULT true,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    active boolean DEFAULT true
);


--
-- Name: credit_control_areas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_control_areas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_control_areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_control_areas_id_seq OWNED BY public.credit_control_areas.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.currencies (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    symbol text NOT NULL,
    decimal_places text NOT NULL,
    conversion_rate text NOT NULL,
    base_currency boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    notes text,
    active boolean DEFAULT true
);


--
-- Name: currencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.currencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: currencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.currencies_id_seq OWNED BY public.currencies.id;


--
-- Name: currency_valuations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.currency_valuations (
    id integer NOT NULL,
    company_code character varying(4) NOT NULL,
    valuation_date date NOT NULL,
    currency character varying(3) NOT NULL,
    exchange_rate numeric(9,5) NOT NULL,
    valuation_method character varying(2),
    gl_account character varying(10),
    valuation_difference numeric(15,2),
    status character varying(10) DEFAULT 'Active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: currency_valuations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.currency_valuations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: currency_valuations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.currency_valuations_id_seq OWNED BY public.currency_valuations.id;


--
-- Name: custom_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_reports (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    sql_query text NOT NULL,
    chart_config jsonb DEFAULT '{}'::jsonb,
    parameters jsonb DEFAULT '[]'::jsonb,
    category character varying(100) DEFAULT 'custom'::character varying,
    is_shared boolean DEFAULT false,
    created_by character varying(100) DEFAULT 'system'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    active boolean DEFAULT true
);


--
-- Name: custom_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_reports_id_seq OWNED BY public.custom_reports.id;


--
-- Name: customer_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_contacts (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    "position" character varying(100),
    department character varying(100),
    email character varying(100),
    phone character varying(30),
    mobile character varying(30),
    is_primary boolean DEFAULT false,
    is_billing boolean DEFAULT false,
    is_shipping boolean DEFAULT false,
    is_technical boolean DEFAULT false,
    is_marketing boolean DEFAULT false,
    preferred_language character varying(50) DEFAULT 'English'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    active boolean DEFAULT true
);


--
-- Name: customer_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_contacts_id_seq OWNED BY public.customer_contacts.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    address text NOT NULL,
    notes text,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true,
    code character varying(20),
    type character varying(50) DEFAULT 'Regular'::character varying
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: dashboard_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_configs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    config jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: dashboard_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dashboard_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dashboard_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dashboard_configs_id_seq OWNED BY public.dashboard_configs.id;


--
-- Name: document_posting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_posting (
    id integer NOT NULL,
    document_number character varying(50) NOT NULL,
    document_type character varying(10) NOT NULL,
    posting_date date NOT NULL,
    document_date date,
    reference character varying(255),
    currency character varying(10) DEFAULT 'USD'::character varying,
    exchange_rate numeric(10,4) DEFAULT 1.0,
    company_code character varying(50) NOT NULL,
    fiscal_year character varying(4),
    period character varying(3),
    total_debit numeric(15,2) DEFAULT 0,
    total_credit numeric(15,2) DEFAULT 0,
    status character varying(20) DEFAULT 'posted'::character varying,
    user_created character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: document_posting_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_posting_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_posting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_posting_id_seq OWNED BY public.document_posting.id;


--
-- Name: document_posting_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_posting_items (
    id integer NOT NULL,
    document_id integer NOT NULL,
    line_number integer NOT NULL,
    gl_account character varying(10) NOT NULL,
    cost_center character varying(10),
    profit_center character varying(10),
    debit_amount numeric(15,2) DEFAULT 0,
    credit_amount numeric(15,2) DEFAULT 0,
    text character varying(50),
    business_area character varying(4),
    functional_area character varying(16),
    assignment character varying(18),
    reference_key character varying(12)
);


--
-- Name: document_posting_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_posting_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_posting_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_posting_items_id_seq OWNED BY public.document_posting_items.id;


--
-- Name: document_posting_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_posting_lines (
    id integer NOT NULL,
    document_id integer,
    line_number integer NOT NULL,
    gl_account character varying(50) NOT NULL,
    cost_center character varying(50),
    profit_center character varying(50),
    debit_amount numeric(15,2) DEFAULT 0,
    credit_amount numeric(15,2) DEFAULT 0,
    description text,
    reference character varying(255),
    assignment character varying(255),
    text character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: document_posting_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_posting_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_posting_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_posting_lines_id_seq OWNED BY public.document_posting_lines.id;


--
-- Name: document_postings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_postings (
    id integer NOT NULL,
    document_number character varying(20) NOT NULL,
    company_code character varying(4) NOT NULL,
    document_type character varying(2) NOT NULL,
    posting_date date NOT NULL,
    document_date date NOT NULL,
    reference character varying(16),
    header_text character varying(25),
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    status character varying(10) DEFAULT 'Posted'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(50),
    fiscal_year integer,
    period integer,
    CONSTRAINT check_total_amount_positive CHECK ((total_amount >= (0)::numeric))
);


--
-- Name: document_postings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_postings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_postings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_postings_id_seq OWNED BY public.document_postings.id;


--
-- Name: down_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.down_payments (
    id integer NOT NULL,
    down_payment_number character varying(20) NOT NULL,
    vendor_code character varying(10),
    customer_code character varying(10),
    company_code character varying(4) NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    request_date date NOT NULL,
    payment_date date,
    clearing_date date,
    gl_account character varying(10) NOT NULL,
    reference character varying(20),
    status character varying(10) DEFAULT 'Requested'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: down_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.down_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: down_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.down_payments_id_seq OWNED BY public.down_payments.id;


--
-- Name: employee_master; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_master (
    id integer NOT NULL,
    employee_number character varying(20) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    middle_name character varying(50),
    date_of_birth date,
    gender character varying(10),
    hire_date date NOT NULL,
    employment_type character varying(20),
    employment_status character varying(20) DEFAULT 'ACTIVE'::character varying,
    company_code_id integer,
    cost_center_id integer,
    manager_id integer,
    work_email character varying(100),
    work_phone character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_master_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_master_id_seq OWNED BY public.employee_master.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    employee_id character varying(20) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(100),
    phone character varying(20),
    department character varying(100),
    "position" character varying(100),
    company_code_id integer,
    cost_center_id integer,
    join_date date,
    manager_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: environment_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environment_config (
    id integer NOT NULL,
    environment character varying(10) NOT NULL,
    database_url text,
    is_active boolean DEFAULT true,
    last_transport_date timestamp without time zone,
    description text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: environment_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.environment_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: environment_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.environment_config_id_seq OWNED BY public.environment_config.id;


--
-- Name: erp_customer_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.erp_customer_contacts (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    "position" character varying(100),
    department character varying(100),
    email character varying(100),
    phone character varying(30),
    mobile character varying(30),
    is_primary boolean DEFAULT false,
    is_billing boolean DEFAULT false,
    is_shipping boolean DEFAULT false,
    is_technical boolean DEFAULT false,
    is_marketing boolean DEFAULT false,
    preferred_language character varying(50) DEFAULT 'English'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    active boolean DEFAULT true
);


--
-- Name: erp_customer_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.erp_customer_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: erp_customer_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.erp_customer_contacts_id_seq OWNED BY public.erp_customer_contacts.id;


--
-- Name: erp_customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.erp_customers (
    id integer NOT NULL,
    customer_code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    tax_id character varying(50),
    industry character varying(50),
    segment character varying(50),
    address text,
    city character varying(100),
    state character varying(50),
    country character varying(50),
    postal_code character varying(20),
    region character varying(50),
    phone character varying(30),
    alt_phone character varying(30),
    email character varying(100),
    website character varying(255),
    currency character varying(10),
    payment_terms character varying(50),
    payment_method character varying(50),
    credit_limit numeric,
    credit_rating character varying(10),
    discount_group character varying(50),
    price_group character varying(50),
    incoterms character varying(20),
    shipping_method character varying(50),
    delivery_terms character varying(100),
    delivery_route character varying(100),
    sales_rep_id integer,
    parent_customer_id integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    is_b2b boolean DEFAULT true,
    is_b2c boolean DEFAULT false,
    is_vip boolean DEFAULT false,
    notes text,
    tags text[],
    company_code_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: erp_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.erp_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: erp_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.erp_customers_id_seq OWNED BY public.erp_customers.id;


--
-- Name: erp_vendor_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.erp_vendor_contacts (
    id integer NOT NULL,
    vendor_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    "position" character varying(100),
    department character varying(100),
    email character varying(100),
    phone character varying(30),
    mobile character varying(30),
    is_primary boolean DEFAULT false,
    is_order_contact boolean DEFAULT false,
    is_purchase_contact boolean DEFAULT false,
    is_quality_contact boolean DEFAULT false,
    is_accounts_contact boolean DEFAULT false,
    preferred_language character varying(50) DEFAULT 'English'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    active boolean DEFAULT true
);


--
-- Name: erp_vendor_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.erp_vendor_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: erp_vendor_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.erp_vendor_contacts_id_seq OWNED BY public.erp_vendor_contacts.id;


--
-- Name: erp_vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.erp_vendors (
    id integer NOT NULL,
    vendor_code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    tax_id character varying(50),
    industry character varying(50),
    address text,
    city character varying(100),
    state character varying(50),
    country character varying(50),
    postal_code character varying(20),
    region character varying(50),
    phone character varying(30),
    alt_phone character varying(30),
    email character varying(100),
    website character varying(255),
    currency character varying(10),
    payment_terms character varying(50),
    payment_method character varying(50),
    supplier_type character varying(50),
    category character varying(50),
    order_frequency character varying(50),
    minimum_order_value numeric,
    evaluation_score numeric,
    lead_time integer,
    purchasing_group_id integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    blacklisted boolean DEFAULT false,
    blacklist_reason text,
    notes text,
    tags text[],
    company_code_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: erp_vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.erp_vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: erp_vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.erp_vendors_id_seq OWNED BY public.erp_vendors.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    amount double precision NOT NULL,
    category text NOT NULL,
    description text NOT NULL,
    payment_method text NOT NULL,
    reference text,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: fiscal_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_periods (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    version integer DEFAULT 1,
    year integer NOT NULL,
    period integer NOT NULL,
    name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status character varying(50) DEFAULT 'Open'::character varying,
    company_code_id integer,
    active boolean DEFAULT true
);


--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_periods_id_seq OWNED BY public.fiscal_periods.id;


--
-- Name: fiscal_year_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_year_variants (
    id integer NOT NULL,
    variant_id character varying(10) NOT NULL,
    description character varying(255) NOT NULL,
    posting_periods integer DEFAULT 12,
    special_periods integer DEFAULT 0,
    year_shift integer DEFAULT 0,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: fiscal_year_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_year_variants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_year_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_year_variants_id_seq OWNED BY public.fiscal_year_variants.id;


--
-- Name: general_ledger_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.general_ledger_accounts (
    id integer NOT NULL,
    account_number character varying(20) NOT NULL,
    account_name character varying(100) NOT NULL,
    account_type character varying(20) NOT NULL,
    account_group character varying(50),
    parent_account_id integer,
    company_code_id integer,
    currency_id integer,
    balance_sheet_item boolean DEFAULT false,
    profit_loss_item boolean DEFAULT false,
    reconciliation_account boolean DEFAULT false,
    tax_relevant boolean DEFAULT false,
    posting_allowed boolean DEFAULT true,
    blocked boolean DEFAULT false,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: general_ledger_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.general_ledger_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: general_ledger_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.general_ledger_accounts_id_seq OWNED BY public.general_ledger_accounts.id;


--
-- Name: gl_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gl_accounts (
    id integer NOT NULL,
    account_number text NOT NULL,
    account_name text NOT NULL,
    chart_of_accounts_id integer,
    account_type text NOT NULL,
    account_group text,
    balance_sheet_account boolean DEFAULT false NOT NULL,
    pl_account boolean DEFAULT false NOT NULL,
    block_posting boolean DEFAULT false NOT NULL,
    reconciliation_account boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: gl_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gl_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gl_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gl_accounts_id_seq OWNED BY public.gl_accounts.id;


--
-- Name: goods_receipt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_receipt (
    id integer NOT NULL,
    receipt_number character varying(50) NOT NULL,
    receipt_date date NOT NULL,
    vendor_code character varying(50),
    vendor_name character varying(255),
    purchase_order character varying(50),
    plant_code character varying(50) NOT NULL,
    storage_location character varying(50),
    movement_type character varying(10) DEFAULT '101'::character varying,
    total_quantity numeric(15,3) DEFAULT 0,
    total_value numeric(15,2) DEFAULT 0,
    currency character varying(10) DEFAULT 'USD'::character varying,
    status character varying(20) DEFAULT 'posted'::character varying,
    created_by character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: goods_receipt_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goods_receipt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goods_receipt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goods_receipt_id_seq OWNED BY public.goods_receipt.id;


--
-- Name: goods_receipt_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_receipt_items (
    id integer NOT NULL,
    receipt_id integer NOT NULL,
    line_number integer NOT NULL,
    material_code character varying(18) NOT NULL,
    quantity numeric(13,3) NOT NULL,
    unit_of_measure character varying(3) NOT NULL,
    unit_price numeric(11,2),
    storage_location character varying(4),
    batch_number character varying(10),
    expiration_date date,
    vendor_batch character varying(15),
    quality_inspection boolean DEFAULT false
);


--
-- Name: goods_receipt_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goods_receipt_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goods_receipt_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goods_receipt_items_id_seq OWNED BY public.goods_receipt_items.id;


--
-- Name: goods_receipt_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_receipt_lines (
    id integer NOT NULL,
    receipt_id integer,
    line_number integer NOT NULL,
    material_code character varying(50) NOT NULL,
    material_name character varying(255),
    quantity_received numeric(15,3) NOT NULL,
    unit_price numeric(15,2) DEFAULT 0,
    total_amount numeric(15,2) DEFAULT 0,
    storage_location character varying(50),
    batch_number character varying(50),
    expiry_date date,
    quality_status character varying(20) DEFAULT 'UNRESTRICTED'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: goods_receipt_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goods_receipt_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goods_receipt_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goods_receipt_lines_id_seq OWNED BY public.goods_receipt_lines.id;


--
-- Name: goods_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_receipts (
    id integer NOT NULL,
    receipt_number character varying(20) NOT NULL,
    purchase_order character varying(10),
    vendor_code character varying(10) NOT NULL,
    plant_code character varying(4) NOT NULL,
    receipt_date date NOT NULL,
    delivery_note character varying(16),
    bill_of_lading character varying(16),
    total_quantity numeric(13,3) DEFAULT 0 NOT NULL,
    total_amount numeric(15,2) DEFAULT 0 NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    status character varying(10) DEFAULT 'Received'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(50),
    movement_type character varying(3) DEFAULT '101'::character varying,
    CONSTRAINT check_quantity_positive CHECK ((total_quantity >= (0)::numeric))
);


--
-- Name: goods_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goods_receipts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goods_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goods_receipts_id_seq OWNED BY public.goods_receipts.id;


--
-- Name: internal_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.internal_orders (
    id integer NOT NULL,
    order_number character varying(20) NOT NULL,
    order_type character varying(10) NOT NULL,
    description character varying(100) NOT NULL,
    company_code character varying(4) NOT NULL,
    controlling_area character varying(4) NOT NULL,
    responsible_cost_center character varying(10),
    profit_center character varying(10),
    order_status character varying(20) DEFAULT 'CREATED'::character varying,
    planned_costs numeric(15,2) DEFAULT 0,
    actual_costs numeric(15,2) DEFAULT 0,
    committed_costs numeric(15,2) DEFAULT 0,
    budget_amount numeric(15,2) DEFAULT 0,
    start_date date,
    end_date date,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: internal_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.internal_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: internal_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.internal_orders_id_seq OWNED BY public.internal_orders.id;


--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_transactions (
    id integer NOT NULL,
    transaction_number character varying(20) NOT NULL,
    transaction_type character varying(20) NOT NULL,
    material_id integer,
    plant_id integer,
    storage_location_id integer,
    movement_type character varying(10) NOT NULL,
    quantity numeric(15,3) NOT NULL,
    unit_of_measure character varying(10),
    unit_price numeric(15,2),
    total_value numeric(15,2),
    batch_number character varying(50),
    serial_number character varying(50),
    reference_document character varying(50),
    posting_date date NOT NULL,
    document_date date NOT NULL,
    cost_center_id integer,
    reason_code character varying(10),
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: inventory_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_transactions_id_seq OWNED BY public.inventory_transactions.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    invoice_number text NOT NULL,
    order_id integer,
    issue_date timestamp without time zone DEFAULT now() NOT NULL,
    due_date timestamp without time zone NOT NULL,
    amount double precision NOT NULL,
    status text DEFAULT 'Due'::text NOT NULL,
    paid_date timestamp without time zone,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: issue_analytics_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_analytics_summary (
    id bigint NOT NULL,
    analysis_date date DEFAULT CURRENT_DATE NOT NULL,
    total_issues integer DEFAULT 0,
    critical_issues integer DEFAULT 0,
    high_issues integer DEFAULT 0,
    medium_issues integer DEFAULT 0,
    low_issues integer DEFAULT 0,
    ai_resolved integer DEFAULT 0,
    auto_resolved integer DEFAULT 0,
    manual_resolved integer DEFAULT 0,
    unresolved integer DEFAULT 0,
    avg_resolution_time integer DEFAULT 0,
    median_resolution_time integer DEFAULT 0,
    fastest_resolution integer DEFAULT 0,
    slowest_resolution integer DEFAULT 0,
    master_data_issues integer DEFAULT 0,
    transaction_issues integer DEFAULT 0,
    system_issues integer DEFAULT 0,
    api_issues integer DEFAULT 0,
    database_issues integer DEFAULT 0,
    validation_issues integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE issue_analytics_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.issue_analytics_summary IS 'Daily aggregated analytics for issue trends and patterns';


--
-- Name: issue_analytics_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.issue_analytics_summary_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: issue_analytics_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.issue_analytics_summary_id_seq OWNED BY public.issue_analytics_summary.id;


--
-- Name: issue_patterns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_patterns (
    id bigint NOT NULL,
    pattern_name character varying(200) NOT NULL,
    pattern_regex character varying(500) NOT NULL,
    category character varying(20) NOT NULL,
    match_count integer DEFAULT 0,
    success_rate numeric(5,2) DEFAULT 0.00,
    avg_resolution_time integer DEFAULT 0,
    auto_resolvable boolean DEFAULT false,
    resolution_template jsonb,
    confidence_threshold numeric(3,2) DEFAULT 0.80,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE issue_patterns; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.issue_patterns IS 'Learning database for issue pattern recognition and auto-resolution';


--
-- Name: issue_patterns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.issue_patterns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: issue_patterns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.issue_patterns_id_seq OWNED BY public.issue_patterns.id;


--
-- Name: issue_resolutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_resolutions (
    id bigint NOT NULL,
    resolution_id uuid DEFAULT gen_random_uuid(),
    issue_id uuid NOT NULL,
    resolved_by character varying(50) NOT NULL,
    resolution_time integer,
    steps jsonb NOT NULL,
    success boolean NOT NULL,
    additional_notes text,
    validation_checks jsonb,
    rollback_info jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT issue_resolutions_resolved_by_check CHECK (((resolved_by)::text = ANY ((ARRAY['AI_AGENT'::character varying, 'AUTO_RECOVERY'::character varying, 'MANUAL'::character varying, 'SYSTEM'::character varying])::text[])))
);


--
-- Name: TABLE issue_resolutions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.issue_resolutions IS 'Records all resolution attempts and their outcomes';


--
-- Name: issue_resolutions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.issue_resolutions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: issue_resolutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.issue_resolutions_id_seq OWNED BY public.issue_resolutions.id;


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    document_number character varying(20) NOT NULL,
    company_code_id integer,
    document_type character varying(10) NOT NULL,
    posting_date date NOT NULL,
    document_date date NOT NULL,
    fiscal_period character varying(7) NOT NULL,
    fiscal_year integer NOT NULL,
    currency_id integer,
    exchange_rate numeric(10,4) DEFAULT 1.0,
    reference_document character varying(50),
    header_text text,
    total_debit_amount numeric(15,2) NOT NULL,
    total_credit_amount numeric(15,2) NOT NULL,
    created_by integer,
    posted_by integer,
    posting_time timestamp without time zone,
    status character varying(20) DEFAULT 'POSTED'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    entry_date date,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    company_name character varying(200),
    job_title character varying(100),
    email character varying(200) NOT NULL,
    phone character varying(50),
    status character varying(50) DEFAULT 'New'::character varying NOT NULL,
    source character varying(100),
    industry character varying(100),
    annual_revenue numeric(15,2),
    employee_count integer,
    website character varying(200),
    address text,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    postal_code character varying(20),
    description text,
    last_contacted timestamp without time zone,
    next_followup timestamp without time zone,
    assigned_to integer,
    lead_score integer,
    is_converted boolean DEFAULT false,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: material_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_categories (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    parent_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: material_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_categories_id_seq OWNED BY public.material_categories.id;


--
-- Name: materials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.materials (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    long_description text,
    type character varying(50) NOT NULL,
    uom_id integer NOT NULL,
    category_id integer,
    weight numeric,
    weight_uom_id integer,
    dimensions jsonb,
    base_unit_price numeric,
    cost numeric,
    min_order_qty numeric,
    order_multiple numeric,
    procurement_type character varying(20),
    min_stock numeric DEFAULT 0,
    max_stock numeric,
    reorder_point numeric,
    lead_time integer,
    shelf_life integer,
    lot_size character varying(20),
    mrp_type character varying(30),
    planning_policy character varying(30),
    is_active boolean DEFAULT true,
    is_sellable boolean DEFAULT false,
    is_purchasable boolean DEFAULT false,
    is_manufactured boolean DEFAULT false,
    is_stockable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true,
    base_uom character varying(10) DEFAULT 'PC'::character varying,
    status character varying(20) DEFAULT 'active'::character varying
);


--
-- Name: materials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.materials_id_seq OWNED BY public.materials.id;


--
-- Name: module_health_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_health_status (
    id bigint NOT NULL,
    module_name character varying(100) NOT NULL,
    health_score numeric(5,2) NOT NULL,
    total_issues integer DEFAULT 0,
    critical_issues integer DEFAULT 0,
    resolved_issues integer DEFAULT 0,
    avg_resolution_time integer DEFAULT 0,
    response_time_avg integer DEFAULT 0,
    error_rate numeric(5,2) DEFAULT 0.00,
    availability_score numeric(5,2) DEFAULT 100.00,
    ai_intervention_count integer DEFAULT 0,
    ai_success_rate numeric(5,2) DEFAULT 0.00,
    last_check timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT module_health_status_health_score_check CHECK (((health_score >= (0)::numeric) AND (health_score <= (100)::numeric)))
);


--
-- Name: TABLE module_health_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.module_health_status IS 'Real-time health monitoring for all ERP modules';


--
-- Name: module_health_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.module_health_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: module_health_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.module_health_status_id_seq OWNED BY public.module_health_status.id;


--
-- Name: movement_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.movement_types (
    id integer NOT NULL,
    movement_code character varying(50) NOT NULL,
    movement_name character varying(255) NOT NULL,
    description text,
    movement_category character varying(50),
    debit_credit_indicator character varying(1),
    quantity_update boolean DEFAULT true,
    value_update boolean DEFAULT true,
    reversal_allowed boolean DEFAULT false,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    movement_type character varying(3) DEFAULT '000'::character varying NOT NULL
);


--
-- Name: movement_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.movement_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: movement_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.movement_types_id_seq OWNED BY public.movement_types.id;


--
-- Name: opportunities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opportunities (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    lead_id integer,
    customer_id integer,
    status character varying(50) DEFAULT 'Prospecting'::character varying NOT NULL,
    stage character varying(50) NOT NULL,
    amount numeric(15,2),
    expected_revenue numeric(15,2),
    probability integer,
    close_date timestamp without time zone,
    next_step character varying(200),
    type character varying(100),
    source character varying(100),
    campaign_source character varying(100),
    description text,
    assigned_to integer,
    is_closed boolean DEFAULT false,
    is_won boolean DEFAULT false,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: opportunities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.opportunities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: opportunities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.opportunities_id_seq OWNED BY public.opportunities.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer,
    product_id integer,
    quantity integer NOT NULL,
    unit_price double precision NOT NULL,
    total double precision NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    order_number text NOT NULL,
    customer_id integer,
    date timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'Processing'::text NOT NULL,
    total double precision NOT NULL,
    notes text,
    shipping_address text,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payment_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_lines (
    id integer NOT NULL,
    payment_id integer,
    line_number integer NOT NULL,
    invoice_number character varying(50),
    original_amount numeric(15,2) DEFAULT 0,
    discount_amount numeric(15,2) DEFAULT 0,
    payment_amount numeric(15,2) NOT NULL,
    cash_discount numeric(15,2) DEFAULT 0,
    assignment character varying(255),
    text character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: payment_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_lines_id_seq OWNED BY public.payment_lines.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    payment_number character varying(50) NOT NULL,
    payment_date date NOT NULL,
    payment_method character varying(50) NOT NULL,
    vendor_code character varying(50),
    vendor_name character varying(255),
    customer_code character varying(50),
    customer_name character varying(255),
    payment_type character varying(20) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    bank_account character varying(100),
    reference character varying(255),
    status character varying(20) DEFAULT 'processed'::character varying,
    cleared_amount numeric(15,2) DEFAULT 0,
    remaining_amount numeric(15,2) DEFAULT 0,
    created_by character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    amount numeric(15,2) DEFAULT 0 NOT NULL
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: plants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plants (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    company_code_id integer NOT NULL,
    type text NOT NULL,
    category text,
    address text,
    city text,
    state text,
    country text,
    postal_code text,
    phone text,
    email text,
    manager text,
    timezone text,
    operating_hours text,
    coordinates text,
    status text DEFAULT 'active'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    notes text,
    active boolean DEFAULT true,
    company_code character varying(50)
);


--
-- Name: plants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plants_id_seq OWNED BY public.plants.id;


--
-- Name: production_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_orders (
    id integer NOT NULL,
    order_number character varying(20) NOT NULL,
    material_id integer,
    bom_id integer,
    plant_id integer,
    work_center_id integer,
    order_type character varying(20) NOT NULL,
    planned_quantity numeric(15,3) NOT NULL,
    actual_quantity numeric(15,3) DEFAULT 0,
    scrap_quantity numeric(15,3) DEFAULT 0,
    unit_of_measure character varying(10),
    planned_start_date date NOT NULL,
    planned_end_date date NOT NULL,
    actual_start_date date,
    actual_end_date date,
    priority character varying(10) DEFAULT 'NORMAL'::character varying,
    status character varying(20) DEFAULT 'CREATED'::character varying,
    cost_center_id integer,
    created_by integer,
    released_by integer,
    release_date timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: production_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_orders_id_seq OWNED BY public.production_orders.id;


--
-- Name: production_work_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_work_orders (
    id integer NOT NULL,
    production_order_id integer,
    material_id integer,
    work_center_id integer,
    quantity numeric(15,3),
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    status character varying(20) DEFAULT 'planned'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: production_work_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_work_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_work_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_work_orders_id_seq OWNED BY public.production_work_orders.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    description text,
    price double precision NOT NULL,
    cost double precision NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    min_stock integer DEFAULT 10 NOT NULL,
    category_id integer,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: profit_centers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profit_centers (
    id integer NOT NULL,
    profit_center character varying(10) NOT NULL,
    description character varying(100) NOT NULL,
    profit_center_group character varying(20),
    company_code character varying(4) NOT NULL,
    controlling_area character varying(4) NOT NULL,
    segment character varying(10),
    hierarchy_area character varying(20),
    responsible_person character varying(50),
    valid_from date NOT NULL,
    valid_to date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    company_code_id integer,
    plant_id integer,
    responsible_person_id integer,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: profit_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.profit_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: profit_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.profit_centers_id_seq OWNED BY public.profit_centers.id;


--
-- Name: purchase_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_groups (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by text,
    updated_by text,
    version integer DEFAULT 1 NOT NULL,
    valid_from timestamp without time zone DEFAULT now() NOT NULL,
    valid_to timestamp without time zone,
    active boolean DEFAULT true
);


--
-- Name: purchase_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_groups_id_seq OWNED BY public.purchase_groups.id;


--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_items (
    id integer NOT NULL,
    purchase_order_id integer,
    line_number integer NOT NULL,
    material_id integer,
    description text,
    quantity numeric(15,3) NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    total_price numeric(15,2) NOT NULL,
    delivery_date date,
    plant_id integer,
    storage_location_id integer,
    tax_code character varying(10),
    discount_percent numeric(5,2),
    received_quantity numeric(15,3) DEFAULT 0,
    invoiced_quantity numeric(15,3) DEFAULT 0,
    status character varying(20) DEFAULT 'OPEN'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_order_items_id_seq OWNED BY public.purchase_order_items.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id integer NOT NULL,
    order_number character varying(20) NOT NULL,
    vendor_id integer,
    purchase_organization_id integer,
    company_code_id integer,
    plant_id integer,
    order_date date NOT NULL,
    delivery_date date,
    payment_terms character varying(50),
    currency_id integer,
    exchange_rate numeric(10,4) DEFAULT 1.0,
    total_amount numeric(15,2),
    tax_amount numeric(15,2),
    discount_amount numeric(15,2),
    net_amount numeric(15,2),
    status character varying(20) DEFAULT 'OPEN'::character varying,
    created_by integer,
    approved_by integer,
    approval_date timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    vendor_name character varying(255)
);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_orders_id_seq OWNED BY public.purchase_orders.id;


--
-- Name: purchase_organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_organizations (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    company_code_id integer NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying,
    purchasing_manager character varying(100),
    email character varying(100),
    phone character varying(50),
    address text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1,
    valid_from date DEFAULT CURRENT_DATE,
    valid_to date,
    purchasing_group text,
    supply_type text,
    approval_level text,
    city text,
    state text,
    country text,
    postal_code text,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    manager text,
    active boolean DEFAULT true
);


--
-- Name: purchase_organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_organizations_id_seq OWNED BY public.purchase_organizations.id;


--
-- Name: purchase_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_requests (
    id integer NOT NULL,
    description text NOT NULL,
    amount numeric(15,2),
    priority character varying(20) DEFAULT 'Medium'::character varying,
    cost_center_id integer,
    requester_id integer,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: purchase_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_requests_id_seq OWNED BY public.purchase_requests.id;


--
-- Name: purchasing_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchasing_groups (
    id integer NOT NULL,
    group_code character varying(50) NOT NULL,
    group_name character varying(255) NOT NULL,
    description text,
    phone character varying(50),
    email character varying(255),
    responsible_person character varying(255),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: purchasing_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchasing_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchasing_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchasing_groups_id_seq OWNED BY public.purchasing_groups.id;


--
-- Name: purchasing_organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchasing_organizations (
    id integer NOT NULL,
    org_code character varying(50) NOT NULL,
    org_name character varying(255) NOT NULL,
    description text,
    company_code character varying(50),
    plant_code character varying(50),
    currency character varying(10),
    address text,
    phone character varying(50),
    email character varying(255),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: purchasing_organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchasing_organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchasing_organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchasing_organizations_id_seq OWNED BY public.purchasing_organizations.id;


--
-- Name: quote_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_approvals (
    id integer NOT NULL,
    quote_id integer,
    requested_by integer NOT NULL,
    requested_at timestamp without time zone DEFAULT now() NOT NULL,
    status character varying(50) DEFAULT 'Pending'::character varying NOT NULL,
    current_approver integer,
    approved_by integer,
    approved_at timestamp without time zone,
    rejected_by integer,
    rejected_at timestamp without time zone,
    rejection_reason text,
    comments text,
    approval_level character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: quote_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quote_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quote_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quote_approvals_id_seq OWNED BY public.quote_approvals.id;


--
-- Name: quote_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_items (
    id integer NOT NULL,
    quote_id integer,
    product_id integer,
    description text NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    discount_percent numeric(5,2) DEFAULT 0,
    tax_percent numeric(5,2) DEFAULT 0,
    line_total numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: quote_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quote_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quote_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quote_items_id_seq OWNED BY public.quote_items.id;


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotes (
    id integer NOT NULL,
    quote_number character varying(50) NOT NULL,
    opportunity_id integer,
    customer_id integer,
    status character varying(50) DEFAULT 'Draft'::character varying NOT NULL,
    valid_until timestamp without time zone,
    total_amount numeric(15,2) NOT NULL,
    discount_amount numeric(15,2) DEFAULT 0,
    tax_amount numeric(15,2) DEFAULT 0,
    grand_total numeric(15,2) NOT NULL,
    terms text,
    notes text,
    assigned_to integer,
    approval_status character varying(50) DEFAULT 'Pending'::character varying,
    approved_by integer,
    approved_at timestamp without time zone,
    rejected_reason text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.regions (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    sql_query text NOT NULL,
    chart_config jsonb,
    category character varying(100) DEFAULT 'custom'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- Name: sales_customer_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_customer_contacts (
    id integer NOT NULL,
    customer_id integer,
    name character varying(255) NOT NULL,
    "position" character varying(100),
    email character varying(255),
    phone character varying(50),
    is_primary boolean DEFAULT false,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_customer_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_customer_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_customer_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_customer_contacts_id_seq OWNED BY public.sales_customer_contacts.id;


--
-- Name: sales_customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_customers (
    id integer NOT NULL,
    customer_number character varying(50) NOT NULL,
    company_name character varying(255) NOT NULL,
    contact_person character varying(255),
    email character varying(255),
    phone character varying(50),
    website character varying(255),
    industry character varying(100),
    customer_type character varying(50) DEFAULT 'Business'::character varying,
    billing_address text,
    shipping_address text,
    tax_id character varying(100),
    payment_terms character varying(100),
    credit_limit numeric(15,2),
    status character varying(50) DEFAULT 'Active'::character varying,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_customers_id_seq OWNED BY public.sales_customers.id;


--
-- Name: sales_invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_invoice_items (
    id integer NOT NULL,
    invoice_id integer,
    product_name character varying(255) NOT NULL,
    description text,
    quantity integer NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    discount_percent numeric(5,2) DEFAULT 0,
    tax_percent numeric(5,2) DEFAULT 0,
    subtotal numeric(15,2) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_invoice_items_id_seq OWNED BY public.sales_invoice_items.id;


--
-- Name: sales_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_invoices (
    id integer NOT NULL,
    invoice_number character varying(50) NOT NULL,
    order_id integer,
    customer_name character varying(255) NOT NULL,
    invoice_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    due_date timestamp with time zone,
    status character varying(50) DEFAULT 'Pending'::character varying,
    total_amount numeric(15,2) DEFAULT 0,
    discount_amount numeric(15,2) DEFAULT 0,
    tax_amount numeric(15,2) DEFAULT 0,
    grand_total numeric(15,2) DEFAULT 0,
    paid_amount numeric(15,2) DEFAULT 0,
    payment_method character varying(50),
    payment_date timestamp with time zone,
    notes text,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_invoices_id_seq OWNED BY public.sales_invoices.id;


--
-- Name: sales_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_order_items (
    id integer NOT NULL,
    order_id integer,
    product_id integer,
    product_name character varying(255),
    quantity integer NOT NULL,
    unit_price numeric(15,2) DEFAULT 0 NOT NULL,
    discount_percent numeric(5,2) DEFAULT 0,
    tax_percent numeric(5,2) DEFAULT 0,
    subtotal numeric(15,2) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_order_items_id_seq OWNED BY public.sales_order_items.id;


--
-- Name: sales_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_orders (
    id integer NOT NULL,
    order_number character varying(50) NOT NULL,
    customer_id integer,
    customer_name character varying(255) NOT NULL,
    order_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    delivery_date timestamp with time zone,
    status character varying(50) DEFAULT 'Pending'::character varying,
    total_amount numeric(15,2) DEFAULT 0,
    payment_status character varying(50) DEFAULT 'Unpaid'::character varying,
    shipping_address text,
    billing_address text,
    notes text,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    plant_id integer,
    sales_org_id integer,
    company_code_id integer,
    currency_id integer,
    active boolean DEFAULT true
);


--
-- Name: sales_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_orders_id_seq OWNED BY public.sales_orders.id;


--
-- Name: sales_organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_organizations (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    company_code_id integer NOT NULL,
    currency text DEFAULT 'USD'::text,
    region text,
    distribution_channel text,
    industry text,
    address text,
    city text,
    state text,
    country text,
    postal_code text,
    phone text,
    email text,
    manager text,
    status text DEFAULT 'active'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: sales_organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_organizations_id_seq OWNED BY public.sales_organizations.id;


--
-- Name: sales_quote_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_quote_items (
    id integer NOT NULL,
    quote_id integer,
    product_name character varying(255) NOT NULL,
    description text,
    quantity integer NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    discount_percent numeric(5,2) DEFAULT 0,
    tax_percent numeric(5,2) DEFAULT 0,
    subtotal numeric(15,2) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_quote_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_quote_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_quote_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_quote_items_id_seq OWNED BY public.sales_quote_items.id;


--
-- Name: sales_quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_quotes (
    id integer NOT NULL,
    quote_number character varying(50) NOT NULL,
    opportunity_id integer,
    customer_name character varying(255) NOT NULL,
    quote_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    valid_until timestamp with time zone,
    status character varying(50) DEFAULT 'Draft'::character varying,
    total_amount numeric(15,2) DEFAULT 0,
    discount_amount numeric(15,2) DEFAULT 0,
    tax_amount numeric(15,2) DEFAULT 0,
    grand_total numeric(15,2) DEFAULT 0,
    notes text,
    terms_conditions text,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_quotes_id_seq OWNED BY public.sales_quotes.id;


--
-- Name: sales_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_return_items (
    id integer NOT NULL,
    return_id integer,
    product_name character varying(255) NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    subtotal numeric(15,2) NOT NULL,
    return_reason text,
    condition character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_return_items_id_seq OWNED BY public.sales_return_items.id;


--
-- Name: sales_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_returns (
    id integer NOT NULL,
    return_number character varying(50) NOT NULL,
    order_id integer,
    invoice_id integer,
    customer_name character varying(255) NOT NULL,
    return_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50) DEFAULT 'Pending'::character varying,
    total_amount numeric(15,2) DEFAULT 0,
    return_reason text,
    notes text,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: sales_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_returns_id_seq OWNED BY public.sales_returns.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    product_id integer,
    type text NOT NULL,
    quantity integer NOT NULL,
    reason text NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_locations (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    plant_id integer NOT NULL,
    type text NOT NULL,
    is_mrp_relevant boolean DEFAULT true NOT NULL,
    is_negative_stock_allowed boolean DEFAULT false NOT NULL,
    is_goods_receipt_relevant boolean DEFAULT true NOT NULL,
    is_goods_issue_relevant boolean DEFAULT true NOT NULL,
    is_interim_storage boolean DEFAULT false NOT NULL,
    is_transit_storage boolean DEFAULT false NOT NULL,
    is_restricted_use boolean DEFAULT false NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    notes text,
    active boolean DEFAULT true
);


--
-- Name: storage_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.storage_locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: storage_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.storage_locations_id_seq OWNED BY public.storage_locations.id;


--
-- Name: supply_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_types (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by text,
    updated_by text,
    version integer DEFAULT 1 NOT NULL,
    valid_from timestamp without time zone DEFAULT now() NOT NULL,
    valid_to timestamp without time zone,
    active boolean DEFAULT true
);


--
-- Name: supply_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supply_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supply_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supply_types_id_seq OWNED BY public.supply_types.id;


--
-- Name: system_error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_error_logs (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    level character varying(10) NOT NULL,
    module character varying(100) NOT NULL,
    message text NOT NULL,
    stack text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: system_error_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_error_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_error_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_error_logs_id_seq OWNED BY public.system_error_logs.id;


--
-- Name: tax_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_codes (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(2) NOT NULL,
    tax_type character varying(20) NOT NULL,
    percentage numeric(5,2) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: tax_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tax_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tax_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tax_codes_id_seq OWNED BY public.tax_codes.id;


--
-- Name: transport_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transport_logs (
    id integer NOT NULL,
    request_id integer,
    environment character varying(10) NOT NULL,
    action character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    message text,
    executed_by character varying(100),
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: transport_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transport_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transport_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transport_logs_id_seq OWNED BY public.transport_logs.id;


--
-- Name: transport_number_ranges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transport_number_ranges (
    id integer NOT NULL,
    range_prefix character varying(2) NOT NULL,
    range_type character varying(50) NOT NULL,
    description text,
    current_number integer DEFAULT 100000,
    max_number integer DEFAULT 999999,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true
);


--
-- Name: transport_number_ranges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transport_number_ranges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transport_number_ranges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transport_number_ranges_id_seq OWNED BY public.transport_number_ranges.id;


--
-- Name: transport_objects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transport_objects (
    id integer NOT NULL,
    request_id integer,
    object_type character varying(50) NOT NULL,
    object_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id integer,
    action character varying(20) NOT NULL,
    data_snapshot jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: transport_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transport_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transport_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transport_objects_id_seq OWNED BY public.transport_objects.id;


--
-- Name: transport_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transport_requests (
    id integer NOT NULL,
    request_number character varying(20) NOT NULL,
    request_type character varying(20) NOT NULL,
    description text,
    owner character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'CREATED'::character varying,
    source_environment character varying(10) DEFAULT 'DEV'::character varying,
    target_environment character varying(10),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    released_at timestamp without time zone,
    imported_at timestamp without time zone,
    release_notes text,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: transport_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transport_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transport_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transport_requests_id_seq OWNED BY public.transport_requests.id;


--
-- Name: units_of_measure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.units_of_measure (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    dimension character varying(50),
    conversion_factor numeric(15,5) DEFAULT 1.0,
    base_uom_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    version integer DEFAULT 1,
    active boolean DEFAULT true
);


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.units_of_measure_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.units_of_measure_id_seq OWNED BY public.units_of_measure.id;


--
-- Name: uom; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uom (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    is_base boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    active boolean DEFAULT true
);


--
-- Name: uom_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uom_conversions (
    id integer NOT NULL,
    from_uom_id integer NOT NULL,
    to_uom_id integer NOT NULL,
    conversion_factor numeric NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    active boolean DEFAULT true
);


--
-- Name: uom_conversions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uom_conversions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uom_conversions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uom_conversions_id_seq OWNED BY public.uom_conversions.id;


--
-- Name: uom_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uom_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uom_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uom_id_seq OWNED BY public.uom.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: valuation_classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.valuation_classes (
    id integer NOT NULL,
    class_code character varying(50) NOT NULL,
    class_name character varying(255) NOT NULL,
    description text,
    valuation_method character varying(50),
    price_control character varying(10),
    moving_price boolean DEFAULT false,
    standard_price boolean DEFAULT false,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: valuation_classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.valuation_classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: valuation_classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.valuation_classes_id_seq OWNED BY public.valuation_classes.id;


--
-- Name: variance_analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.variance_analysis (
    id integer NOT NULL,
    variance_type character varying(20) NOT NULL,
    object_type character varying(20) NOT NULL,
    object_number character varying(20) NOT NULL,
    fiscal_year integer NOT NULL,
    period integer NOT NULL,
    account character varying(10),
    cost_element character varying(10),
    planned_amount numeric(15,2) DEFAULT 0,
    actual_amount numeric(15,2) DEFAULT 0,
    variance_amount numeric(15,2) DEFAULT 0,
    variance_percentage numeric(5,2) DEFAULT 0,
    currency character varying(3) DEFAULT 'USD'::character varying,
    analysis_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: variance_analysis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.variance_analysis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: variance_analysis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.variance_analysis_id_seq OWNED BY public.variance_analysis.id;


--
-- Name: vendor_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_contacts (
    id integer NOT NULL,
    vendor_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    "position" character varying(100),
    department character varying(100),
    email character varying(100),
    phone character varying(30),
    mobile character varying(30),
    is_primary boolean DEFAULT false,
    is_order_contact boolean DEFAULT false,
    is_purchase_contact boolean DEFAULT false,
    is_quality_contact boolean DEFAULT false,
    is_accounts_contact boolean DEFAULT false,
    preferred_language character varying(50) DEFAULT 'English'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    active boolean DEFAULT true
);


--
-- Name: vendor_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_contacts_id_seq OWNED BY public.vendor_contacts.id;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    tax_id character varying(50),
    industry character varying(50),
    address text,
    city character varying(100),
    state character varying(50),
    country character varying(50),
    postal_code character varying(20),
    region character varying(50),
    phone character varying(30),
    alt_phone character varying(30),
    email character varying(100),
    website character varying(255),
    currency character varying(10),
    payment_terms character varying(50),
    payment_method character varying(50),
    supplier_type character varying(50),
    category character varying(50),
    order_frequency character varying(50),
    minimum_order_value numeric,
    evaluation_score numeric,
    lead_time integer,
    purchasing_group_id integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    blacklisted boolean DEFAULT false,
    blacklist_reason text,
    notes text,
    tags text[],
    company_code_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by integer,
    updated_by integer,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: warehouse_bins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouse_bins (
    id integer NOT NULL,
    bin_code character varying(20) NOT NULL,
    bin_name character varying(100),
    storage_location_id integer,
    bin_type character varying(20) NOT NULL,
    zone character varying(20),
    aisle character varying(20),
    shelf character varying(20),
    capacity_volume numeric(10,3),
    capacity_weight numeric(10,3),
    current_volume numeric(10,3) DEFAULT 0,
    current_weight numeric(10,3) DEFAULT 0,
    status character varying(20) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: warehouse_bins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouse_bins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouse_bins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouse_bins_id_seq OWNED BY public.warehouse_bins.id;


--
-- Name: work_centers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_centers (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    plant_id integer,
    description text,
    capacity numeric(10,2),
    capacity_unit character varying(20),
    cost_rate numeric(15,2),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying,
    cost_center_id integer,
    company_code_id integer,
    active boolean DEFAULT true
);


--
-- Name: work_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_centers_id_seq OWNED BY public.work_centers.id;


--
-- Name: account_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups ALTER COLUMN id SET DEFAULT nextval('public.account_groups_id_seq'::regclass);


--
-- Name: accounts_payable id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payable ALTER COLUMN id SET DEFAULT nextval('public.accounts_payable_id_seq'::regclass);


--
-- Name: accounts_receivable id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_receivable ALTER COLUMN id SET DEFAULT nextval('public.accounts_receivable_id_seq'::regclass);


--
-- Name: activity_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_types ALTER COLUMN id SET DEFAULT nextval('public.activity_types_id_seq'::regclass);


--
-- Name: ai_agent_analytics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_analytics ALTER COLUMN id SET DEFAULT nextval('public.ai_agent_analytics_id_seq'::regclass);


--
-- Name: ai_agent_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_configs ALTER COLUMN id SET DEFAULT nextval('public.ai_agent_configs_id_seq'::regclass);


--
-- Name: ai_agent_health id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_health ALTER COLUMN id SET DEFAULT nextval('public.ai_agent_health_id_seq'::regclass);


--
-- Name: ai_agent_interventions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_interventions ALTER COLUMN id SET DEFAULT nextval('public.ai_agent_interventions_id_seq'::regclass);


--
-- Name: ai_agent_performance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_performance ALTER COLUMN id SET DEFAULT nextval('public.ai_agent_performance_id_seq'::regclass);


--
-- Name: ai_chat_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_messages ALTER COLUMN id SET DEFAULT nextval('public.ai_chat_messages_id_seq'::regclass);


--
-- Name: ai_chat_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_sessions ALTER COLUMN id SET DEFAULT nextval('public.ai_chat_sessions_id_seq'::regclass);


--
-- Name: ai_data_analysis_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_data_analysis_sessions ALTER COLUMN id SET DEFAULT nextval('public.ai_data_analysis_sessions_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: approval_levels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_levels ALTER COLUMN id SET DEFAULT nextval('public.approval_levels_id_seq'::regclass);


--
-- Name: asset_master id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_master ALTER COLUMN id SET DEFAULT nextval('public.asset_master_id_seq'::regclass);


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.assets_id_seq'::regclass);


--
-- Name: bank_statement_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_items ALTER COLUMN id SET DEFAULT nextval('public.bank_statement_items_id_seq'::regclass);


--
-- Name: bank_statements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statements ALTER COLUMN id SET DEFAULT nextval('public.bank_statements_id_seq'::regclass);


--
-- Name: batch_master id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_master ALTER COLUMN id SET DEFAULT nextval('public.batch_master_id_seq'::regclass);


--
-- Name: bill_of_materials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bill_of_materials ALTER COLUMN id SET DEFAULT nextval('public.bill_of_materials_id_seq'::regclass);


--
-- Name: bom_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bom_items ALTER COLUMN id SET DEFAULT nextval('public.bom_items_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: change_document_analytics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_analytics ALTER COLUMN id SET DEFAULT nextval('public.change_document_analytics_id_seq'::regclass);


--
-- Name: change_document_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_approvals ALTER COLUMN id SET DEFAULT nextval('public.change_document_approvals_id_seq'::regclass);


--
-- Name: change_document_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_attachments ALTER COLUMN id SET DEFAULT nextval('public.change_document_attachments_id_seq'::regclass);


--
-- Name: change_document_headers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_headers ALTER COLUMN id SET DEFAULT nextval('public.change_document_headers_id_seq'::regclass);


--
-- Name: change_document_positions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_positions ALTER COLUMN id SET DEFAULT nextval('public.change_document_positions_id_seq'::regclass);


--
-- Name: change_document_relations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_relations ALTER COLUMN id SET DEFAULT nextval('public.change_document_relations_id_seq'::regclass);


--
-- Name: chart_of_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);


--
-- Name: clearing_configurations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clearing_configurations ALTER COLUMN id SET DEFAULT nextval('public.clearing_configurations_id_seq'::regclass);


--
-- Name: clearing_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clearing_items ALTER COLUMN id SET DEFAULT nextval('public.clearing_items_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: company_code_chart_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_code_chart_assignments ALTER COLUMN id SET DEFAULT nextval('public.company_code_chart_assignments_id_seq'::regclass);


--
-- Name: company_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_codes ALTER COLUMN id SET DEFAULT nextval('public.company_codes_id_seq'::regclass);


--
-- Name: comprehensive_issues_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comprehensive_issues_log ALTER COLUMN id SET DEFAULT nextval('public.comprehensive_issues_log_id_seq'::regclass);


--
-- Name: copa_actuals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.copa_actuals ALTER COLUMN id SET DEFAULT nextval('public.copa_actuals_id_seq'::regclass);


--
-- Name: cost_allocations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_allocations ALTER COLUMN id SET DEFAULT nextval('public.cost_allocations_id_seq'::regclass);


--
-- Name: cost_center_actuals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_center_actuals ALTER COLUMN id SET DEFAULT nextval('public.cost_center_actuals_id_seq'::regclass);


--
-- Name: cost_center_planning id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_center_planning ALTER COLUMN id SET DEFAULT nextval('public.cost_center_planning_id_seq'::regclass);


--
-- Name: cost_centers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_centers ALTER COLUMN id SET DEFAULT nextval('public.cost_centers_id_seq'::regclass);


--
-- Name: cost_elements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_elements ALTER COLUMN id SET DEFAULT nextval('public.cost_elements_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: credit_control_areas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_control_areas ALTER COLUMN id SET DEFAULT nextval('public.credit_control_areas_id_seq'::regclass);


--
-- Name: currencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies ALTER COLUMN id SET DEFAULT nextval('public.currencies_id_seq'::regclass);


--
-- Name: currency_valuations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currency_valuations ALTER COLUMN id SET DEFAULT nextval('public.currency_valuations_id_seq'::regclass);


--
-- Name: custom_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_reports ALTER COLUMN id SET DEFAULT nextval('public.custom_reports_id_seq'::regclass);


--
-- Name: customer_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_contacts ALTER COLUMN id SET DEFAULT nextval('public.customer_contacts_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: dashboard_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_configs ALTER COLUMN id SET DEFAULT nextval('public.dashboard_configs_id_seq'::regclass);


--
-- Name: document_posting id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting ALTER COLUMN id SET DEFAULT nextval('public.document_posting_id_seq'::regclass);


--
-- Name: document_posting_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting_items ALTER COLUMN id SET DEFAULT nextval('public.document_posting_items_id_seq'::regclass);


--
-- Name: document_posting_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting_lines ALTER COLUMN id SET DEFAULT nextval('public.document_posting_lines_id_seq'::regclass);


--
-- Name: document_postings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_postings ALTER COLUMN id SET DEFAULT nextval('public.document_postings_id_seq'::regclass);


--
-- Name: down_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.down_payments ALTER COLUMN id SET DEFAULT nextval('public.down_payments_id_seq'::regclass);


--
-- Name: employee_master id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_master ALTER COLUMN id SET DEFAULT nextval('public.employee_master_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: environment_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_config ALTER COLUMN id SET DEFAULT nextval('public.environment_config_id_seq'::regclass);


--
-- Name: erp_customer_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_customer_contacts ALTER COLUMN id SET DEFAULT nextval('public.erp_customer_contacts_id_seq'::regclass);


--
-- Name: erp_customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_customers ALTER COLUMN id SET DEFAULT nextval('public.erp_customers_id_seq'::regclass);


--
-- Name: erp_vendor_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_vendor_contacts ALTER COLUMN id SET DEFAULT nextval('public.erp_vendor_contacts_id_seq'::regclass);


--
-- Name: erp_vendors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_vendors ALTER COLUMN id SET DEFAULT nextval('public.erp_vendors_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: fiscal_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_periods ALTER COLUMN id SET DEFAULT nextval('public.fiscal_periods_id_seq'::regclass);


--
-- Name: fiscal_year_variants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_year_variants ALTER COLUMN id SET DEFAULT nextval('public.fiscal_year_variants_id_seq'::regclass);


--
-- Name: general_ledger_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.general_ledger_accounts ALTER COLUMN id SET DEFAULT nextval('public.general_ledger_accounts_id_seq'::regclass);


--
-- Name: gl_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gl_accounts ALTER COLUMN id SET DEFAULT nextval('public.gl_accounts_id_seq'::regclass);


--
-- Name: goods_receipt id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt ALTER COLUMN id SET DEFAULT nextval('public.goods_receipt_id_seq'::regclass);


--
-- Name: goods_receipt_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items ALTER COLUMN id SET DEFAULT nextval('public.goods_receipt_items_id_seq'::regclass);


--
-- Name: goods_receipt_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_lines ALTER COLUMN id SET DEFAULT nextval('public.goods_receipt_lines_id_seq'::regclass);


--
-- Name: goods_receipts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts ALTER COLUMN id SET DEFAULT nextval('public.goods_receipts_id_seq'::regclass);


--
-- Name: internal_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.internal_orders ALTER COLUMN id SET DEFAULT nextval('public.internal_orders_id_seq'::regclass);


--
-- Name: inventory_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions ALTER COLUMN id SET DEFAULT nextval('public.inventory_transactions_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: issue_analytics_summary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_analytics_summary ALTER COLUMN id SET DEFAULT nextval('public.issue_analytics_summary_id_seq'::regclass);


--
-- Name: issue_patterns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_patterns ALTER COLUMN id SET DEFAULT nextval('public.issue_patterns_id_seq'::regclass);


--
-- Name: issue_resolutions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_resolutions ALTER COLUMN id SET DEFAULT nextval('public.issue_resolutions_id_seq'::regclass);


--
-- Name: journal_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: material_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_categories ALTER COLUMN id SET DEFAULT nextval('public.material_categories_id_seq'::regclass);


--
-- Name: materials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials ALTER COLUMN id SET DEFAULT nextval('public.materials_id_seq'::regclass);


--
-- Name: module_health_status id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_health_status ALTER COLUMN id SET DEFAULT nextval('public.module_health_status_id_seq'::regclass);


--
-- Name: movement_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movement_types ALTER COLUMN id SET DEFAULT nextval('public.movement_types_id_seq'::regclass);


--
-- Name: opportunities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities ALTER COLUMN id SET DEFAULT nextval('public.opportunities_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payment_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_lines ALTER COLUMN id SET DEFAULT nextval('public.payment_lines_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: plants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plants ALTER COLUMN id SET DEFAULT nextval('public.plants_id_seq'::regclass);


--
-- Name: production_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders ALTER COLUMN id SET DEFAULT nextval('public.production_orders_id_seq'::regclass);


--
-- Name: production_work_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_work_orders ALTER COLUMN id SET DEFAULT nextval('public.production_work_orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: profit_centers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profit_centers ALTER COLUMN id SET DEFAULT nextval('public.profit_centers_id_seq'::regclass);


--
-- Name: purchase_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_groups ALTER COLUMN id SET DEFAULT nextval('public.purchase_groups_id_seq'::regclass);


--
-- Name: purchase_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_order_items_id_seq'::regclass);


--
-- Name: purchase_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.purchase_orders_id_seq'::regclass);


--
-- Name: purchase_organizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_organizations ALTER COLUMN id SET DEFAULT nextval('public.purchase_organizations_id_seq'::regclass);


--
-- Name: purchase_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_requests ALTER COLUMN id SET DEFAULT nextval('public.purchase_requests_id_seq'::regclass);


--
-- Name: purchasing_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchasing_groups ALTER COLUMN id SET DEFAULT nextval('public.purchasing_groups_id_seq'::regclass);


--
-- Name: purchasing_organizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchasing_organizations ALTER COLUMN id SET DEFAULT nextval('public.purchasing_organizations_id_seq'::regclass);


--
-- Name: quote_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_approvals ALTER COLUMN id SET DEFAULT nextval('public.quote_approvals_id_seq'::regclass);


--
-- Name: quote_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_items ALTER COLUMN id SET DEFAULT nextval('public.quote_items_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- Name: sales_customer_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_customer_contacts ALTER COLUMN id SET DEFAULT nextval('public.sales_customer_contacts_id_seq'::regclass);


--
-- Name: sales_customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_customers ALTER COLUMN id SET DEFAULT nextval('public.sales_customers_id_seq'::regclass);


--
-- Name: sales_invoice_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.sales_invoice_items_id_seq'::regclass);


--
-- Name: sales_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoices ALTER COLUMN id SET DEFAULT nextval('public.sales_invoices_id_seq'::regclass);


--
-- Name: sales_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_order_items ALTER COLUMN id SET DEFAULT nextval('public.sales_order_items_id_seq'::regclass);


--
-- Name: sales_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders ALTER COLUMN id SET DEFAULT nextval('public.sales_orders_id_seq'::regclass);


--
-- Name: sales_organizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_organizations ALTER COLUMN id SET DEFAULT nextval('public.sales_organizations_id_seq'::regclass);


--
-- Name: sales_quote_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_quote_items ALTER COLUMN id SET DEFAULT nextval('public.sales_quote_items_id_seq'::regclass);


--
-- Name: sales_quotes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_quotes ALTER COLUMN id SET DEFAULT nextval('public.sales_quotes_id_seq'::regclass);


--
-- Name: sales_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_return_items ALTER COLUMN id SET DEFAULT nextval('public.sales_return_items_id_seq'::regclass);


--
-- Name: sales_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns ALTER COLUMN id SET DEFAULT nextval('public.sales_returns_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: storage_locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations ALTER COLUMN id SET DEFAULT nextval('public.storage_locations_id_seq'::regclass);


--
-- Name: supply_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_types ALTER COLUMN id SET DEFAULT nextval('public.supply_types_id_seq'::regclass);


--
-- Name: system_error_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_error_logs ALTER COLUMN id SET DEFAULT nextval('public.system_error_logs_id_seq'::regclass);


--
-- Name: tax_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_codes ALTER COLUMN id SET DEFAULT nextval('public.tax_codes_id_seq'::regclass);


--
-- Name: transport_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_logs ALTER COLUMN id SET DEFAULT nextval('public.transport_logs_id_seq'::regclass);


--
-- Name: transport_number_ranges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_number_ranges ALTER COLUMN id SET DEFAULT nextval('public.transport_number_ranges_id_seq'::regclass);


--
-- Name: transport_objects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_objects ALTER COLUMN id SET DEFAULT nextval('public.transport_objects_id_seq'::regclass);


--
-- Name: transport_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_requests ALTER COLUMN id SET DEFAULT nextval('public.transport_requests_id_seq'::regclass);


--
-- Name: units_of_measure id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure ALTER COLUMN id SET DEFAULT nextval('public.units_of_measure_id_seq'::regclass);


--
-- Name: uom id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom ALTER COLUMN id SET DEFAULT nextval('public.uom_id_seq'::regclass);


--
-- Name: uom_conversions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_conversions ALTER COLUMN id SET DEFAULT nextval('public.uom_conversions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: valuation_classes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.valuation_classes ALTER COLUMN id SET DEFAULT nextval('public.valuation_classes_id_seq'::regclass);


--
-- Name: variance_analysis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.variance_analysis ALTER COLUMN id SET DEFAULT nextval('public.variance_analysis_id_seq'::regclass);


--
-- Name: vendor_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_contacts ALTER COLUMN id SET DEFAULT nextval('public.vendor_contacts_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Name: warehouse_bins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_bins ALTER COLUMN id SET DEFAULT nextval('public.warehouse_bins_id_seq'::regclass);


--
-- Name: work_centers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_centers ALTER COLUMN id SET DEFAULT nextval('public.work_centers_id_seq'::regclass);


--
-- Name: account_groups account_groups_chart_id_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_chart_id_group_name_key UNIQUE (chart_id, group_name);


--
-- Name: account_groups account_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_pkey PRIMARY KEY (id);


--
-- Name: accounts_payable accounts_payable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_pkey PRIMARY KEY (id);


--
-- Name: accounts_receivable accounts_receivable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_pkey PRIMARY KEY (id);


--
-- Name: activity_types activity_types_activity_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_types
    ADD CONSTRAINT activity_types_activity_type_key UNIQUE (activity_type);


--
-- Name: activity_types activity_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_types
    ADD CONSTRAINT activity_types_pkey PRIMARY KEY (id);


--
-- Name: ai_agent_analytics ai_agent_analytics_module_type_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_analytics
    ADD CONSTRAINT ai_agent_analytics_module_type_date_key UNIQUE (module_type, date);


--
-- Name: ai_agent_analytics ai_agent_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_analytics
    ADD CONSTRAINT ai_agent_analytics_pkey PRIMARY KEY (id);


--
-- Name: ai_agent_configs ai_agent_configs_module_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_configs
    ADD CONSTRAINT ai_agent_configs_module_type_key UNIQUE (module_type);


--
-- Name: ai_agent_configs ai_agent_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_configs
    ADD CONSTRAINT ai_agent_configs_pkey PRIMARY KEY (id);


--
-- Name: ai_agent_health ai_agent_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_health
    ADD CONSTRAINT ai_agent_health_pkey PRIMARY KEY (id);


--
-- Name: ai_agent_interventions ai_agent_interventions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_interventions
    ADD CONSTRAINT ai_agent_interventions_pkey PRIMARY KEY (id);


--
-- Name: ai_agent_performance ai_agent_performance_agent_name_agent_type_performance_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_performance
    ADD CONSTRAINT ai_agent_performance_agent_name_agent_type_performance_date_key UNIQUE (agent_name, agent_type, performance_date);


--
-- Name: ai_agent_performance ai_agent_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_performance
    ADD CONSTRAINT ai_agent_performance_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_messages ai_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_sessions ai_chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_sessions ai_chat_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_session_id_key UNIQUE (session_id);


--
-- Name: ai_data_analysis_sessions ai_data_analysis_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_data_analysis_sessions
    ADD CONSTRAINT ai_data_analysis_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_data_analysis_sessions ai_data_analysis_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_data_analysis_sessions
    ADD CONSTRAINT ai_data_analysis_sessions_session_id_key UNIQUE (session_id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_service_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_service_name_key UNIQUE (service_name);


--
-- Name: approval_levels approval_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_levels
    ADD CONSTRAINT approval_levels_pkey PRIMARY KEY (id);


--
-- Name: asset_master asset_master_asset_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_master
    ADD CONSTRAINT asset_master_asset_number_key UNIQUE (asset_number);


--
-- Name: asset_master asset_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_master
    ADD CONSTRAINT asset_master_pkey PRIMARY KEY (id);


--
-- Name: assets assets_asset_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_asset_number_key UNIQUE (asset_number);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: bank_statement_items bank_statement_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_items
    ADD CONSTRAINT bank_statement_items_pkey PRIMARY KEY (id);


--
-- Name: bank_statements bank_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statements
    ADD CONSTRAINT bank_statements_pkey PRIMARY KEY (id);


--
-- Name: bank_statements bank_statements_statement_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statements
    ADD CONSTRAINT bank_statements_statement_number_key UNIQUE (statement_number);


--
-- Name: batch_master batch_master_batch_number_material_id_plant_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_master
    ADD CONSTRAINT batch_master_batch_number_material_id_plant_id_key UNIQUE (batch_number, material_id, plant_id);


--
-- Name: batch_master batch_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_master
    ADD CONSTRAINT batch_master_pkey PRIMARY KEY (id);


--
-- Name: bill_of_materials bill_of_materials_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bill_of_materials
    ADD CONSTRAINT bill_of_materials_code_key UNIQUE (code);


--
-- Name: bill_of_materials bill_of_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bill_of_materials
    ADD CONSTRAINT bill_of_materials_pkey PRIMARY KEY (id);


--
-- Name: bom_items bom_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bom_items
    ADD CONSTRAINT bom_items_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_unique UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: change_document_analytics change_document_analytics_analysis_date_object_class_applic_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_analytics
    ADD CONSTRAINT change_document_analytics_analysis_date_object_class_applic_key UNIQUE (analysis_date, object_class, application_module);


--
-- Name: change_document_analytics change_document_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_analytics
    ADD CONSTRAINT change_document_analytics_pkey PRIMARY KEY (id);


--
-- Name: change_document_approvals change_document_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_approvals
    ADD CONSTRAINT change_document_approvals_pkey PRIMARY KEY (id);


--
-- Name: change_document_attachments change_document_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_attachments
    ADD CONSTRAINT change_document_attachments_pkey PRIMARY KEY (id);


--
-- Name: change_document_headers change_document_headers_change_document_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_headers
    ADD CONSTRAINT change_document_headers_change_document_id_key UNIQUE (change_document_id);


--
-- Name: change_document_headers change_document_headers_change_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_headers
    ADD CONSTRAINT change_document_headers_change_number_key UNIQUE (change_number);


--
-- Name: change_document_headers change_document_headers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_headers
    ADD CONSTRAINT change_document_headers_pkey PRIMARY KEY (id);


--
-- Name: change_document_positions change_document_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_positions
    ADD CONSTRAINT change_document_positions_pkey PRIMARY KEY (id);


--
-- Name: change_document_relations change_document_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_relations
    ADD CONSTRAINT change_document_relations_pkey PRIMARY KEY (id);


--
-- Name: change_document_relations change_document_relations_source_change_id_target_change_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_relations
    ADD CONSTRAINT change_document_relations_source_change_id_target_change_id_key UNIQUE (source_change_id, target_change_id, relation_type);


--
-- Name: chart_of_accounts chart_of_accounts_chart_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_chart_id_key UNIQUE (chart_id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: clearing_configurations clearing_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clearing_configurations
    ADD CONSTRAINT clearing_configurations_pkey PRIMARY KEY (id);


--
-- Name: clearing_items clearing_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clearing_items
    ADD CONSTRAINT clearing_items_pkey PRIMARY KEY (id);


--
-- Name: companies companies_company_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_company_id_key UNIQUE (company_id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_code_chart_assignments company_code_chart_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_code_chart_assignments
    ADD CONSTRAINT company_code_chart_assignments_pkey PRIMARY KEY (id);


--
-- Name: company_codes company_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_codes
    ADD CONSTRAINT company_codes_pkey PRIMARY KEY (id);


--
-- Name: comprehensive_issues_log comprehensive_issues_log_issue_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comprehensive_issues_log
    ADD CONSTRAINT comprehensive_issues_log_issue_id_key UNIQUE (issue_id);


--
-- Name: comprehensive_issues_log comprehensive_issues_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comprehensive_issues_log
    ADD CONSTRAINT comprehensive_issues_log_pkey PRIMARY KEY (id);


--
-- Name: copa_actuals copa_actuals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.copa_actuals
    ADD CONSTRAINT copa_actuals_pkey PRIMARY KEY (id);


--
-- Name: cost_allocations cost_allocations_allocation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_allocations
    ADD CONSTRAINT cost_allocations_allocation_id_key UNIQUE (allocation_id);


--
-- Name: cost_allocations cost_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_allocations
    ADD CONSTRAINT cost_allocations_pkey PRIMARY KEY (id);


--
-- Name: cost_center_actuals cost_center_actuals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_center_actuals
    ADD CONSTRAINT cost_center_actuals_pkey PRIMARY KEY (id);


--
-- Name: cost_center_planning cost_center_planning_cost_center_fiscal_year_period_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_center_planning
    ADD CONSTRAINT cost_center_planning_cost_center_fiscal_year_period_version_key UNIQUE (cost_center, fiscal_year, period, version, account, activity_type);


--
-- Name: cost_center_planning cost_center_planning_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_center_planning
    ADD CONSTRAINT cost_center_planning_pkey PRIMARY KEY (id);


--
-- Name: cost_centers cost_centers_cost_center_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_cost_center_key UNIQUE (cost_center);


--
-- Name: cost_centers cost_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_pkey PRIMARY KEY (id);


--
-- Name: cost_elements cost_elements_cost_element_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_elements
    ADD CONSTRAINT cost_elements_cost_element_code_key UNIQUE (cost_element_code);


--
-- Name: cost_elements cost_elements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_elements
    ADD CONSTRAINT cost_elements_pkey PRIMARY KEY (id);


--
-- Name: countries countries_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_code_key UNIQUE (code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: credit_control_areas credit_control_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_control_areas
    ADD CONSTRAINT credit_control_areas_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_code_key UNIQUE (code);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: currency_valuations currency_valuations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currency_valuations
    ADD CONSTRAINT currency_valuations_pkey PRIMARY KEY (id);


--
-- Name: custom_reports custom_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_reports
    ADD CONSTRAINT custom_reports_pkey PRIMARY KEY (id);


--
-- Name: customer_contacts customer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_contacts
    ADD CONSTRAINT customer_contacts_pkey PRIMARY KEY (id);


--
-- Name: customers customers_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_code_unique UNIQUE (code);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: dashboard_configs dashboard_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_configs
    ADD CONSTRAINT dashboard_configs_pkey PRIMARY KEY (id);


--
-- Name: document_posting document_posting_document_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting
    ADD CONSTRAINT document_posting_document_number_key UNIQUE (document_number);


--
-- Name: document_posting_items document_posting_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting_items
    ADD CONSTRAINT document_posting_items_pkey PRIMARY KEY (id);


--
-- Name: document_posting_lines document_posting_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting_lines
    ADD CONSTRAINT document_posting_lines_pkey PRIMARY KEY (id);


--
-- Name: document_posting document_posting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting
    ADD CONSTRAINT document_posting_pkey PRIMARY KEY (id);


--
-- Name: document_postings document_postings_document_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_postings
    ADD CONSTRAINT document_postings_document_number_key UNIQUE (document_number);


--
-- Name: document_postings document_postings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_postings
    ADD CONSTRAINT document_postings_pkey PRIMARY KEY (id);


--
-- Name: down_payments down_payments_down_payment_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.down_payments
    ADD CONSTRAINT down_payments_down_payment_number_key UNIQUE (down_payment_number);


--
-- Name: down_payments down_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.down_payments
    ADD CONSTRAINT down_payments_pkey PRIMARY KEY (id);


--
-- Name: employee_master employee_master_employee_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_master
    ADD CONSTRAINT employee_master_employee_number_key UNIQUE (employee_number);


--
-- Name: employee_master employee_master_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_master
    ADD CONSTRAINT employee_master_pkey PRIMARY KEY (id);


--
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- Name: employees employees_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_employee_id_key UNIQUE (employee_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: environment_config environment_config_environment_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_config
    ADD CONSTRAINT environment_config_environment_key UNIQUE (environment);


--
-- Name: environment_config environment_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_config
    ADD CONSTRAINT environment_config_pkey PRIMARY KEY (id);


--
-- Name: erp_customer_contacts erp_customer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_customer_contacts
    ADD CONSTRAINT erp_customer_contacts_pkey PRIMARY KEY (id);


--
-- Name: erp_customers erp_customers_customer_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_customers
    ADD CONSTRAINT erp_customers_customer_code_key UNIQUE (customer_code);


--
-- Name: erp_customers erp_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_customers
    ADD CONSTRAINT erp_customers_pkey PRIMARY KEY (id);


--
-- Name: erp_vendor_contacts erp_vendor_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_vendor_contacts
    ADD CONSTRAINT erp_vendor_contacts_pkey PRIMARY KEY (id);


--
-- Name: erp_vendors erp_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_vendors
    ADD CONSTRAINT erp_vendors_pkey PRIMARY KEY (id);


--
-- Name: erp_vendors erp_vendors_vendor_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_vendors
    ADD CONSTRAINT erp_vendors_vendor_code_key UNIQUE (vendor_code);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: fiscal_periods fiscal_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_pkey PRIMARY KEY (id);


--
-- Name: fiscal_periods fiscal_periods_year_period_company_code_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_year_period_company_code_id_key UNIQUE (year, period, company_code_id);


--
-- Name: fiscal_year_variants fiscal_year_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_year_variants
    ADD CONSTRAINT fiscal_year_variants_pkey PRIMARY KEY (id);


--
-- Name: fiscal_year_variants fiscal_year_variants_variant_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_year_variants
    ADD CONSTRAINT fiscal_year_variants_variant_id_key UNIQUE (variant_id);


--
-- Name: general_ledger_accounts general_ledger_accounts_account_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.general_ledger_accounts
    ADD CONSTRAINT general_ledger_accounts_account_number_key UNIQUE (account_number);


--
-- Name: general_ledger_accounts general_ledger_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.general_ledger_accounts
    ADD CONSTRAINT general_ledger_accounts_pkey PRIMARY KEY (id);


--
-- Name: gl_accounts gl_accounts_account_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gl_accounts
    ADD CONSTRAINT gl_accounts_account_number_key UNIQUE (account_number);


--
-- Name: gl_accounts gl_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gl_accounts
    ADD CONSTRAINT gl_accounts_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_items goods_receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_lines goods_receipt_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_lines
    ADD CONSTRAINT goods_receipt_lines_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt goods_receipt_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt
    ADD CONSTRAINT goods_receipt_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt goods_receipt_receipt_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt
    ADD CONSTRAINT goods_receipt_receipt_number_key UNIQUE (receipt_number);


--
-- Name: goods_receipts goods_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_pkey PRIMARY KEY (id);


--
-- Name: goods_receipts goods_receipts_receipt_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_receipt_number_key UNIQUE (receipt_number);


--
-- Name: internal_orders internal_orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.internal_orders
    ADD CONSTRAINT internal_orders_order_number_key UNIQUE (order_number);


--
-- Name: internal_orders internal_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.internal_orders
    ADD CONSTRAINT internal_orders_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_transaction_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_transaction_number_key UNIQUE (transaction_number);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_invoice_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_unique UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: issue_analytics_summary issue_analytics_summary_analysis_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_analytics_summary
    ADD CONSTRAINT issue_analytics_summary_analysis_date_key UNIQUE (analysis_date);


--
-- Name: issue_analytics_summary issue_analytics_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_analytics_summary
    ADD CONSTRAINT issue_analytics_summary_pkey PRIMARY KEY (id);


--
-- Name: issue_patterns issue_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_patterns
    ADD CONSTRAINT issue_patterns_pkey PRIMARY KEY (id);


--
-- Name: issue_resolutions issue_resolutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_resolutions
    ADD CONSTRAINT issue_resolutions_pkey PRIMARY KEY (id);


--
-- Name: issue_resolutions issue_resolutions_resolution_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_resolutions
    ADD CONSTRAINT issue_resolutions_resolution_id_key UNIQUE (resolution_id);


--
-- Name: journal_entries journal_entries_document_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_document_number_key UNIQUE (document_number);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: material_categories material_categories_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_categories
    ADD CONSTRAINT material_categories_code_key UNIQUE (code);


--
-- Name: material_categories material_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_categories
    ADD CONSTRAINT material_categories_pkey PRIMARY KEY (id);


--
-- Name: materials materials_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_code_key UNIQUE (code);


--
-- Name: materials materials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_pkey PRIMARY KEY (id);


--
-- Name: module_health_status module_health_status_module_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_health_status
    ADD CONSTRAINT module_health_status_module_name_key UNIQUE (module_name);


--
-- Name: module_health_status module_health_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_health_status
    ADD CONSTRAINT module_health_status_pkey PRIMARY KEY (id);


--
-- Name: movement_types movement_types_movement_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movement_types
    ADD CONSTRAINT movement_types_movement_code_key UNIQUE (movement_code);


--
-- Name: movement_types movement_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movement_types
    ADD CONSTRAINT movement_types_pkey PRIMARY KEY (id);


--
-- Name: opportunities opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_unique UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_lines payment_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_lines
    ADD CONSTRAINT payment_lines_pkey PRIMARY KEY (id);


--
-- Name: payments payments_payment_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_number_key UNIQUE (payment_number);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: plants plants_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plants
    ADD CONSTRAINT plants_code_key UNIQUE (code);


--
-- Name: plants plants_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plants
    ADD CONSTRAINT plants_code_unique UNIQUE (code);


--
-- Name: plants plants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plants
    ADD CONSTRAINT plants_pkey PRIMARY KEY (id);


--
-- Name: production_orders production_orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_order_number_key UNIQUE (order_number);


--
-- Name: production_orders production_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_pkey PRIMARY KEY (id);


--
-- Name: production_work_orders production_work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_work_orders
    ADD CONSTRAINT production_work_orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_unique UNIQUE (sku);


--
-- Name: profit_centers profit_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profit_centers
    ADD CONSTRAINT profit_centers_pkey PRIMARY KEY (id);


--
-- Name: profit_centers profit_centers_profit_center_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profit_centers
    ADD CONSTRAINT profit_centers_profit_center_key UNIQUE (profit_center);


--
-- Name: purchase_groups purchase_groups_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_groups
    ADD CONSTRAINT purchase_groups_code_key UNIQUE (code);


--
-- Name: purchase_groups purchase_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_groups
    ADD CONSTRAINT purchase_groups_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_order_number_key UNIQUE (order_number);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_organizations purchase_organizations_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_organizations
    ADD CONSTRAINT purchase_organizations_code_key UNIQUE (code);


--
-- Name: purchase_organizations purchase_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_organizations
    ADD CONSTRAINT purchase_organizations_pkey PRIMARY KEY (id);


--
-- Name: purchase_requests purchase_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_pkey PRIMARY KEY (id);


--
-- Name: purchasing_groups purchasing_groups_group_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchasing_groups
    ADD CONSTRAINT purchasing_groups_group_code_key UNIQUE (group_code);


--
-- Name: purchasing_groups purchasing_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchasing_groups
    ADD CONSTRAINT purchasing_groups_pkey PRIMARY KEY (id);


--
-- Name: purchasing_organizations purchasing_organizations_org_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchasing_organizations
    ADD CONSTRAINT purchasing_organizations_org_code_key UNIQUE (org_code);


--
-- Name: purchasing_organizations purchasing_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchasing_organizations
    ADD CONSTRAINT purchasing_organizations_pkey PRIMARY KEY (id);


--
-- Name: quote_approvals quote_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_approvals
    ADD CONSTRAINT quote_approvals_pkey PRIMARY KEY (id);


--
-- Name: quote_items quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_quote_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_quote_number_key UNIQUE (quote_number);


--
-- Name: regions regions_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_code_key UNIQUE (code);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: sales_customer_contacts sales_customer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_customer_contacts
    ADD CONSTRAINT sales_customer_contacts_pkey PRIMARY KEY (id);


--
-- Name: sales_customers sales_customers_customer_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_customers
    ADD CONSTRAINT sales_customers_customer_number_key UNIQUE (customer_number);


--
-- Name: sales_customers sales_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_customers
    ADD CONSTRAINT sales_customers_pkey PRIMARY KEY (id);


--
-- Name: sales_invoice_items sales_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: sales_invoices sales_invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: sales_invoices sales_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_pkey PRIMARY KEY (id);


--
-- Name: sales_order_items sales_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_pkey PRIMARY KEY (id);


--
-- Name: sales_orders sales_orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_order_number_key UNIQUE (order_number);


--
-- Name: sales_orders sales_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_pkey PRIMARY KEY (id);


--
-- Name: sales_organizations sales_organizations_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_organizations
    ADD CONSTRAINT sales_organizations_code_key UNIQUE (code);


--
-- Name: sales_organizations sales_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_organizations
    ADD CONSTRAINT sales_organizations_pkey PRIMARY KEY (id);


--
-- Name: sales_quote_items sales_quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_quote_items
    ADD CONSTRAINT sales_quote_items_pkey PRIMARY KEY (id);


--
-- Name: sales_quotes sales_quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_quotes
    ADD CONSTRAINT sales_quotes_pkey PRIMARY KEY (id);


--
-- Name: sales_quotes sales_quotes_quote_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_quotes
    ADD CONSTRAINT sales_quotes_quote_number_key UNIQUE (quote_number);


--
-- Name: sales_return_items sales_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_return_items
    ADD CONSTRAINT sales_return_items_pkey PRIMARY KEY (id);


--
-- Name: sales_returns sales_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns
    ADD CONSTRAINT sales_returns_pkey PRIMARY KEY (id);


--
-- Name: sales_returns sales_returns_return_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns
    ADD CONSTRAINT sales_returns_return_number_key UNIQUE (return_number);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_code_key UNIQUE (code);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: supply_types supply_types_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_types
    ADD CONSTRAINT supply_types_code_key UNIQUE (code);


--
-- Name: supply_types supply_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_types
    ADD CONSTRAINT supply_types_pkey PRIMARY KEY (id);


--
-- Name: system_error_logs system_error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_error_logs
    ADD CONSTRAINT system_error_logs_pkey PRIMARY KEY (id);


--
-- Name: tax_codes tax_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_codes
    ADD CONSTRAINT tax_codes_code_key UNIQUE (code);


--
-- Name: tax_codes tax_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_codes
    ADD CONSTRAINT tax_codes_pkey PRIMARY KEY (id);


--
-- Name: transport_logs transport_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_logs
    ADD CONSTRAINT transport_logs_pkey PRIMARY KEY (id);


--
-- Name: transport_number_ranges transport_number_ranges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_number_ranges
    ADD CONSTRAINT transport_number_ranges_pkey PRIMARY KEY (id);


--
-- Name: transport_number_ranges transport_number_ranges_range_prefix_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_number_ranges
    ADD CONSTRAINT transport_number_ranges_range_prefix_key UNIQUE (range_prefix);


--
-- Name: transport_objects transport_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_objects
    ADD CONSTRAINT transport_objects_pkey PRIMARY KEY (id);


--
-- Name: transport_requests transport_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_requests
    ADD CONSTRAINT transport_requests_pkey PRIMARY KEY (id);


--
-- Name: transport_requests transport_requests_request_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_requests
    ADD CONSTRAINT transport_requests_request_number_key UNIQUE (request_number);


--
-- Name: document_posting_items unique_document_line; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting_items
    ADD CONSTRAINT unique_document_line UNIQUE (document_id, line_number);


--
-- Name: goods_receipt_items unique_receipt_line; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT unique_receipt_line UNIQUE (receipt_id, line_number);


--
-- Name: bank_statement_items unique_statement_line; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_items
    ADD CONSTRAINT unique_statement_line UNIQUE (statement_id, line_number);


--
-- Name: units_of_measure units_of_measure_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_code_key UNIQUE (code);


--
-- Name: units_of_measure units_of_measure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_pkey PRIMARY KEY (id);


--
-- Name: uom uom_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom
    ADD CONSTRAINT uom_code_key UNIQUE (code);


--
-- Name: uom_conversions uom_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_conversions
    ADD CONSTRAINT uom_conversions_pkey PRIMARY KEY (id);


--
-- Name: uom uom_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom
    ADD CONSTRAINT uom_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: valuation_classes valuation_classes_class_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.valuation_classes
    ADD CONSTRAINT valuation_classes_class_code_key UNIQUE (class_code);


--
-- Name: valuation_classes valuation_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.valuation_classes
    ADD CONSTRAINT valuation_classes_pkey PRIMARY KEY (id);


--
-- Name: variance_analysis variance_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.variance_analysis
    ADD CONSTRAINT variance_analysis_pkey PRIMARY KEY (id);


--
-- Name: vendor_contacts vendor_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_contacts
    ADD CONSTRAINT vendor_contacts_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_code_key UNIQUE (code);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: warehouse_bins warehouse_bins_bin_code_storage_location_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_bins
    ADD CONSTRAINT warehouse_bins_bin_code_storage_location_id_key UNIQUE (bin_code, storage_location_id);


--
-- Name: warehouse_bins warehouse_bins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_bins
    ADD CONSTRAINT warehouse_bins_pkey PRIMARY KEY (id);


--
-- Name: work_centers work_centers_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_centers
    ADD CONSTRAINT work_centers_code_key UNIQUE (code);


--
-- Name: work_centers work_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_centers
    ADD CONSTRAINT work_centers_pkey PRIMARY KEY (id);


--
-- Name: company_codes_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_codes_code_idx ON public.company_codes USING btree (code) WHERE (active = true);


--
-- Name: idx_ai_interventions_agent_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_interventions_agent_type ON public.ai_agent_interventions USING btree (agent_type);


--
-- Name: idx_ai_interventions_confidence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_interventions_confidence ON public.ai_agent_interventions USING btree (confidence_score);


--
-- Name: idx_ai_interventions_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_interventions_issue_id ON public.ai_agent_interventions USING btree (issue_id);


--
-- Name: idx_assets_company; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_company ON public.assets USING btree (company_code);


--
-- Name: idx_bank_statements_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bank_statements_account ON public.bank_statements USING btree (bank_account, statement_date);


--
-- Name: idx_change_headers_business_process; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_headers_business_process ON public.change_document_headers USING btree (business_process);


--
-- Name: idx_change_headers_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_headers_module ON public.change_document_headers USING btree (application_module, change_type);


--
-- Name: idx_change_headers_object; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_headers_object ON public.change_document_headers USING btree (object_class, object_id);


--
-- Name: idx_change_headers_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_headers_timestamp ON public.change_document_headers USING btree (change_timestamp);


--
-- Name: idx_change_headers_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_headers_user ON public.change_document_headers USING btree (user_name, change_date);


--
-- Name: idx_change_positions_change_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_positions_change_id ON public.change_document_positions USING btree (change_document_id);


--
-- Name: idx_change_positions_table_field; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_positions_table_field ON public.change_document_positions USING btree (table_name, field_name);


--
-- Name: idx_change_positions_values; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_positions_values ON public.change_document_positions USING btree (old_value, new_value);


--
-- Name: idx_change_relations_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_relations_source ON public.change_document_relations USING btree (source_change_id);


--
-- Name: idx_change_relations_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_relations_target ON public.change_document_relations USING btree (target_change_id);


--
-- Name: idx_change_relations_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_change_relations_type ON public.change_document_relations USING btree (relation_type);


--
-- Name: idx_custom_reports_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_custom_reports_category ON public.custom_reports USING btree (category);


--
-- Name: idx_custom_reports_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_custom_reports_created_by ON public.custom_reports USING btree (created_by);


--
-- Name: idx_custom_reports_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_custom_reports_name ON public.custom_reports USING btree (name);


--
-- Name: idx_document_postings_company_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_postings_company_date ON public.document_postings USING btree (company_code, posting_date);


--
-- Name: idx_goods_receipts_vendor_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_goods_receipts_vendor_date ON public.goods_receipts USING btree (vendor_code, receipt_date);


--
-- Name: idx_issues_log_category_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_issues_log_category_severity ON public.comprehensive_issues_log USING btree (category, severity);


--
-- Name: idx_issues_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_issues_log_created_at ON public.comprehensive_issues_log USING btree (created_at);


--
-- Name: idx_issues_log_module_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_issues_log_module_status ON public.comprehensive_issues_log USING btree (module, status);


--
-- Name: idx_issues_log_resolved_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_issues_log_resolved_by ON public.comprehensive_issues_log USING btree (resolved_by);


--
-- Name: idx_module_health_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_module_health_module ON public.module_health_status USING btree (module_name);


--
-- Name: idx_module_health_score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_module_health_score ON public.module_health_status USING btree (health_score);


--
-- Name: idx_patterns_auto_resolvable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patterns_auto_resolvable ON public.issue_patterns USING btree (auto_resolvable);


--
-- Name: idx_patterns_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patterns_category ON public.issue_patterns USING btree (category);


--
-- Name: idx_payments_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_customer ON public.payments USING btree (customer_code);


--
-- Name: idx_payments_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_date ON public.payments USING btree (payment_date);


--
-- Name: idx_payments_vendor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_vendor ON public.payments USING btree (vendor_code);


--
-- Name: idx_resolutions_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resolutions_issue_id ON public.issue_resolutions USING btree (issue_id);


--
-- Name: idx_resolutions_resolved_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resolutions_resolved_by ON public.issue_resolutions USING btree (resolved_by);


--
-- Name: idx_resolutions_success; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resolutions_success ON public.issue_resolutions USING btree (success);


--
-- Name: idx_system_error_logs_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_error_logs_level ON public.system_error_logs USING btree (level);


--
-- Name: idx_system_error_logs_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_error_logs_module ON public.system_error_logs USING btree (module);


--
-- Name: idx_system_error_logs_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_error_logs_timestamp ON public.system_error_logs USING btree ("timestamp" DESC);


--
-- Name: comprehensive_issues_log trigger_update_module_health; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_module_health AFTER INSERT OR UPDATE ON public.comprehensive_issues_log FOR EACH ROW EXECUTE FUNCTION public.update_module_health();


--
-- Name: accounts_payable update_accounts_payable_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_accounts_payable_updated_at BEFORE UPDATE ON public.accounts_payable FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: accounts_receivable update_accounts_receivable_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_accounts_receivable_updated_at BEFORE UPDATE ON public.accounts_receivable FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: activity_types update_activity_types_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_activity_types_updated_at BEFORE UPDATE ON public.activity_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_agent_analytics update_ai_agent_analytics_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_ai_agent_analytics_updated_at BEFORE UPDATE ON public.ai_agent_analytics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_agent_configs update_ai_agent_configs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_ai_agent_configs_updated_at BEFORE UPDATE ON public.ai_agent_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_agent_health update_ai_agent_health_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_ai_agent_health_updated_at BEFORE UPDATE ON public.ai_agent_health FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_chat_messages update_ai_chat_messages_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_ai_chat_messages_updated_at BEFORE UPDATE ON public.ai_chat_messages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_chat_sessions update_ai_chat_sessions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_ai_chat_sessions_updated_at BEFORE UPDATE ON public.ai_chat_sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_data_analysis_sessions update_ai_data_analysis_sessions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_ai_data_analysis_sessions_updated_at BEFORE UPDATE ON public.ai_data_analysis_sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: api_keys update_api_keys_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_api_keys_updated_at BEFORE UPDATE ON public.api_keys FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: approval_levels update_approval_levels_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_approval_levels_updated_at BEFORE UPDATE ON public.approval_levels FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: asset_master update_asset_master_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_asset_master_updated_at BEFORE UPDATE ON public.asset_master FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: batch_master update_batch_master_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_batch_master_updated_at BEFORE UPDATE ON public.batch_master FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: bill_of_materials update_bill_of_materials_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_bill_of_materials_updated_at BEFORE UPDATE ON public.bill_of_materials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: bom_items update_bom_items_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_bom_items_updated_at BEFORE UPDATE ON public.bom_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: categories update_categories_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON public.categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: company_code_chart_assignments update_company_code_chart_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_company_code_chart_assignments_updated_at BEFORE UPDATE ON public.company_code_chart_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: copa_actuals update_copa_actuals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_copa_actuals_updated_at BEFORE UPDATE ON public.copa_actuals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cost_allocations update_cost_allocations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cost_allocations_updated_at BEFORE UPDATE ON public.cost_allocations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cost_center_actuals update_cost_center_actuals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cost_center_actuals_updated_at BEFORE UPDATE ON public.cost_center_actuals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cost_center_planning update_cost_center_planning_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cost_center_planning_updated_at BEFORE UPDATE ON public.cost_center_planning FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cost_centers update_cost_centers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cost_centers_updated_at BEFORE UPDATE ON public.cost_centers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: countries update_countries_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_countries_updated_at BEFORE UPDATE ON public.countries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: credit_control_areas update_credit_control_areas_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_credit_control_areas_updated_at BEFORE UPDATE ON public.credit_control_areas FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: currencies update_currencies_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_currencies_updated_at BEFORE UPDATE ON public.currencies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: custom_reports update_custom_reports_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_custom_reports_updated_at BEFORE UPDATE ON public.custom_reports FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: customer_contacts update_customer_contacts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_customer_contacts_updated_at BEFORE UPDATE ON public.customer_contacts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: customers update_customers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: dashboard_configs update_dashboard_configs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_dashboard_configs_updated_at BEFORE UPDATE ON public.dashboard_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: employee_master update_employee_master_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_employee_master_updated_at BEFORE UPDATE ON public.employee_master FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: employees update_employees_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: environment_config update_environment_config_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_environment_config_updated_at BEFORE UPDATE ON public.environment_config FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: erp_customer_contacts update_erp_customer_contacts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_erp_customer_contacts_updated_at BEFORE UPDATE ON public.erp_customer_contacts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: erp_customers update_erp_customers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_erp_customers_updated_at BEFORE UPDATE ON public.erp_customers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: erp_vendor_contacts update_erp_vendor_contacts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_erp_vendor_contacts_updated_at BEFORE UPDATE ON public.erp_vendor_contacts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: erp_vendors update_erp_vendors_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_erp_vendors_updated_at BEFORE UPDATE ON public.erp_vendors FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: comprehensive_issues_log update_issues_log_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_issues_log_updated_at BEFORE UPDATE ON public.comprehensive_issues_log FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: issue_patterns update_patterns_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patterns_updated_at BEFORE UPDATE ON public.issue_patterns FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: accounts_payable accounts_payable_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: accounts_payable accounts_payable_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: accounts_payable accounts_payable_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: accounts_payable accounts_payable_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id);


--
-- Name: accounts_payable accounts_payable_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: accounts_receivable accounts_receivable_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: accounts_receivable accounts_receivable_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: accounts_receivable accounts_receivable_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: accounts_receivable accounts_receivable_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: accounts_receivable accounts_receivable_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts_receivable
    ADD CONSTRAINT accounts_receivable_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_orders(id);


--
-- Name: ai_agent_analytics ai_agent_analytics_module_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_analytics
    ADD CONSTRAINT ai_agent_analytics_module_type_fkey FOREIGN KEY (module_type) REFERENCES public.ai_agent_configs(module_type);


--
-- Name: ai_agent_interventions ai_agent_interventions_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_interventions
    ADD CONSTRAINT ai_agent_interventions_issue_id_fkey FOREIGN KEY (issue_id) REFERENCES public.comprehensive_issues_log(issue_id) ON DELETE CASCADE;


--
-- Name: ai_chat_messages ai_chat_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.ai_chat_sessions(session_id) ON DELETE CASCADE;


--
-- Name: ai_chat_sessions ai_chat_sessions_module_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_module_type_fkey FOREIGN KEY (module_type) REFERENCES public.ai_agent_configs(module_type);


--
-- Name: ai_data_analysis_sessions ai_data_analysis_sessions_module_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_data_analysis_sessions
    ADD CONSTRAINT ai_data_analysis_sessions_module_type_fkey FOREIGN KEY (module_type) REFERENCES public.ai_agent_configs(module_type);


--
-- Name: bank_statement_items bank_statement_items_statement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_items
    ADD CONSTRAINT bank_statement_items_statement_id_fkey FOREIGN KEY (statement_id) REFERENCES public.bank_statements(id) ON DELETE CASCADE;


--
-- Name: batch_master batch_master_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_master
    ADD CONSTRAINT batch_master_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: batch_master batch_master_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_master
    ADD CONSTRAINT batch_master_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: bom_items bom_items_bom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bom_items
    ADD CONSTRAINT bom_items_bom_id_fkey FOREIGN KEY (bom_id) REFERENCES public.bill_of_materials(id);


--
-- Name: categories categories_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: change_document_approvals change_document_approvals_change_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_approvals
    ADD CONSTRAINT change_document_approvals_change_document_id_fkey FOREIGN KEY (change_document_id) REFERENCES public.change_document_headers(change_document_id);


--
-- Name: change_document_attachments change_document_attachments_change_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_attachments
    ADD CONSTRAINT change_document_attachments_change_document_id_fkey FOREIGN KEY (change_document_id) REFERENCES public.change_document_headers(change_document_id);


--
-- Name: change_document_headers change_document_headers_parent_change_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_headers
    ADD CONSTRAINT change_document_headers_parent_change_id_fkey FOREIGN KEY (parent_change_id) REFERENCES public.change_document_headers(change_document_id);


--
-- Name: change_document_headers change_document_headers_reversal_change_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_headers
    ADD CONSTRAINT change_document_headers_reversal_change_id_fkey FOREIGN KEY (reversal_change_id) REFERENCES public.change_document_headers(change_document_id);


--
-- Name: change_document_positions change_document_positions_change_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_positions
    ADD CONSTRAINT change_document_positions_change_document_id_fkey FOREIGN KEY (change_document_id) REFERENCES public.change_document_headers(change_document_id) ON DELETE CASCADE;


--
-- Name: change_document_relations change_document_relations_source_change_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_relations
    ADD CONSTRAINT change_document_relations_source_change_id_fkey FOREIGN KEY (source_change_id) REFERENCES public.change_document_headers(change_document_id);


--
-- Name: change_document_relations change_document_relations_target_change_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_document_relations
    ADD CONSTRAINT change_document_relations_target_change_id_fkey FOREIGN KEY (target_change_id) REFERENCES public.change_document_headers(change_document_id);


--
-- Name: countries countries_region_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_region_id_fkey FOREIGN KEY (region_id) REFERENCES public.regions(id);


--
-- Name: customers customers_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: document_posting_items document_posting_items_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting_items
    ADD CONSTRAINT document_posting_items_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document_postings(id) ON DELETE CASCADE;


--
-- Name: document_posting_lines document_posting_lines_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_posting_lines
    ADD CONSTRAINT document_posting_lines_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document_posting(id) ON DELETE CASCADE;


--
-- Name: employee_master employee_master_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_master
    ADD CONSTRAINT employee_master_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.employee_master(id);


--
-- Name: employees employees_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.employees(id);


--
-- Name: expenses expenses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cost_center_actuals fk_cc_actuals_cost_center; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_center_actuals
    ADD CONSTRAINT fk_cc_actuals_cost_center FOREIGN KEY (cost_center_id) REFERENCES public.cost_centers(id);


--
-- Name: copa_actuals fk_copa_customer; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.copa_actuals
    ADD CONSTRAINT fk_copa_customer FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: copa_actuals fk_copa_material; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.copa_actuals
    ADD CONSTRAINT fk_copa_material FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: copa_actuals fk_copa_profit_center; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.copa_actuals
    ADD CONSTRAINT fk_copa_profit_center FOREIGN KEY (profit_center_id) REFERENCES public.profit_centers(id);


--
-- Name: customer_contacts fk_customer; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_contacts
    ADD CONSTRAINT fk_customer FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: erp_customers fk_customer_company_code; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_customers
    ADD CONSTRAINT fk_customer_company_code FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: erp_customer_contacts fk_erp_customer; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_customer_contacts
    ADD CONSTRAINT fk_erp_customer FOREIGN KEY (customer_id) REFERENCES public.erp_customers(id) ON DELETE CASCADE;


--
-- Name: erp_vendor_contacts fk_erp_vendor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_vendor_contacts
    ADD CONSTRAINT fk_erp_vendor FOREIGN KEY (vendor_id) REFERENCES public.erp_vendors(id) ON DELETE CASCADE;


--
-- Name: opportunities fk_opportunity_customer; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT fk_opportunity_customer FOREIGN KEY (customer_id) REFERENCES public.erp_customers(id);


--
-- Name: erp_customers fk_parent_erp_customer; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_customers
    ADD CONSTRAINT fk_parent_erp_customer FOREIGN KEY (parent_customer_id) REFERENCES public.erp_customers(id);


--
-- Name: quotes fk_quote_customer; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT fk_quote_customer FOREIGN KEY (customer_id) REFERENCES public.erp_customers(id);


--
-- Name: sales_orders fk_sales_order_customer; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT fk_sales_order_customer FOREIGN KEY (customer_id) REFERENCES public.erp_customers(id);


--
-- Name: sales_orders fk_sales_order_plant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT fk_sales_order_plant FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: sales_orders fk_sales_order_sales_org; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT fk_sales_order_sales_org FOREIGN KEY (sales_org_id) REFERENCES public.sales_organizations(id);


--
-- Name: materials fk_uom; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT fk_uom FOREIGN KEY (uom_id) REFERENCES public.uom(id);


--
-- Name: vendor_contacts fk_vendor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_contacts
    ADD CONSTRAINT fk_vendor FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: erp_vendors fk_vendor_company_code; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_vendors
    ADD CONSTRAINT fk_vendor_company_code FOREIGN KEY (company_code_id) REFERENCES public.company_codes(id);


--
-- Name: general_ledger_accounts general_ledger_accounts_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.general_ledger_accounts
    ADD CONSTRAINT general_ledger_accounts_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: general_ledger_accounts general_ledger_accounts_parent_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.general_ledger_accounts
    ADD CONSTRAINT general_ledger_accounts_parent_account_id_fkey FOREIGN KEY (parent_account_id) REFERENCES public.general_ledger_accounts(id);


--
-- Name: goods_receipt_items goods_receipt_items_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_receipt_id_fkey FOREIGN KEY (receipt_id) REFERENCES public.goods_receipts(id) ON DELETE CASCADE;


--
-- Name: goods_receipt_lines goods_receipt_lines_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_lines
    ADD CONSTRAINT goods_receipt_lines_receipt_id_fkey FOREIGN KEY (receipt_id) REFERENCES public.goods_receipt(id) ON DELETE CASCADE;


--
-- Name: inventory_transactions inventory_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inventory_transactions inventory_transactions_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: inventory_transactions inventory_transactions_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: inventory_transactions inventory_transactions_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: invoices invoices_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: invoices invoices_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: issue_resolutions issue_resolutions_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_resolutions
    ADD CONSTRAINT issue_resolutions_issue_id_fkey FOREIGN KEY (issue_id) REFERENCES public.comprehensive_issues_log(issue_id) ON DELETE CASCADE;


--
-- Name: journal_entries journal_entries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: journal_entries journal_entries_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: journal_entries journal_entries_posted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_posted_by_fkey FOREIGN KEY (posted_by) REFERENCES public.users(id);


--
-- Name: material_categories material_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_categories
    ADD CONSTRAINT material_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.material_categories(id);


--
-- Name: opportunities opportunities_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id);


--
-- Name: order_items order_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_items order_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders orders_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payment_lines payment_lines_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_lines
    ADD CONSTRAINT payment_lines_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id) ON DELETE CASCADE;


--
-- Name: production_orders production_orders_bom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_bom_id_fkey FOREIGN KEY (bom_id) REFERENCES public.bill_of_materials(id);


--
-- Name: production_orders production_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: production_orders production_orders_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: production_orders production_orders_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: production_orders production_orders_released_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_released_by_fkey FOREIGN KEY (released_by) REFERENCES public.users(id);


--
-- Name: production_orders production_orders_work_center_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_work_center_id_fkey FOREIGN KEY (work_center_id) REFERENCES public.work_centers(id);


--
-- Name: products products_category_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: products products_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: purchase_order_items purchase_order_items_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: purchase_order_items purchase_order_items_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: purchase_order_items purchase_order_items_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id);


--
-- Name: purchase_order_items purchase_order_items_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id);


--
-- Name: purchase_orders purchase_orders_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: purchase_orders purchase_orders_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: purchase_orders purchase_orders_purchase_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_purchase_organization_id_fkey FOREIGN KEY (purchase_organization_id) REFERENCES public.purchase_organizations(id);


--
-- Name: purchase_orders purchase_orders_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: quote_approvals quote_approvals_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_approvals
    ADD CONSTRAINT quote_approvals_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE CASCADE;


--
-- Name: quote_items quote_items_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunities(id);


--
-- Name: sales_customer_contacts sales_customer_contacts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_customer_contacts
    ADD CONSTRAINT sales_customer_contacts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.sales_customers(id) ON DELETE CASCADE;


--
-- Name: sales_invoice_items sales_invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.sales_invoices(id) ON DELETE CASCADE;


--
-- Name: sales_order_items sales_order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.sales_orders(id) ON DELETE CASCADE;


--
-- Name: sales_quote_items sales_quote_items_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_quote_items
    ADD CONSTRAINT sales_quote_items_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.sales_quotes(id) ON DELETE CASCADE;


--
-- Name: sales_return_items sales_return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_return_items
    ADD CONSTRAINT sales_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.sales_returns(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_movements stock_movements_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_locations storage_locations_plant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_plant_id_fkey FOREIGN KEY (plant_id) REFERENCES public.plants(id);


--
-- Name: transport_logs transport_logs_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_logs
    ADD CONSTRAINT transport_logs_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.transport_requests(id);


--
-- Name: transport_objects transport_objects_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transport_objects
    ADD CONSTRAINT transport_objects_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.transport_requests(id);


--
-- Name: units_of_measure units_of_measure_base_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_base_uom_id_fkey FOREIGN KEY (base_uom_id) REFERENCES public.units_of_measure(id);


--
-- Name: uom_conversions uom_conversions_from_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_conversions
    ADD CONSTRAINT uom_conversions_from_uom_id_fkey FOREIGN KEY (from_uom_id) REFERENCES public.uom(id);


--
-- Name: uom_conversions uom_conversions_to_uom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uom_conversions
    ADD CONSTRAINT uom_conversions_to_uom_id_fkey FOREIGN KEY (to_uom_id) REFERENCES public.uom(id);


--
-- Name: warehouse_bins warehouse_bins_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_bins
    ADD CONSTRAINT warehouse_bins_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id);


--
-- PostgreSQL database dump complete
--

