# Complete Database Deployment Package

Generated: 2025-06-05T15:16:22.846Z

## Package Contents

- `complete-schema.sql` - Complete database schema with all table definitions
- `complete-data.sql` - All table data (0 records)
- `sequences.sql` - All database sequences with current values
- `constraints-indexes.sql` - Primary keys, foreign keys, and indexes
- `restore-database.sh` - Unix/Linux restoration script
- `restore-database.ps1` - Windows PowerShell restoration script

## Quick Start

### Prerequisites
- PostgreSQL client (psql) installed
- DATABASE_URL environment variable set

### Unix/Linux/macOS
```bash
export DATABASE_URL="your_database_connection_string"
chmod +x restore-database.sh
./restore-database.sh
```

### Windows (PowerShell)
```powershell
$env:DATABASE_URL = "your_database_connection_string"
.\restore-database.ps1
```

### Manual Restoration
```bash
# 1. Create schema
psql "$DATABASE_URL" -f complete-schema.sql

# 2. Insert data
psql "$DATABASE_URL" -f complete-data.sql

# 3. Create sequences
psql "$DATABASE_URL" -f sequences.sql

# 4. Add constraints and indexes
psql "$DATABASE_URL" -f constraints-indexes.sql
```

## Verification

After restoration, verify the deployment:

```sql
-- Check table count
SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public';

-- Check total records
SELECT schemaname, tablename, n_tup_ins as records 
FROM pg_stat_user_tables 
ORDER BY tablename;

-- Check sequences
SELECT schemaname, sequencename, last_value 
FROM pg_sequences 
WHERE schemaname = 'public';
```

## Database Structure

This is a complete MallyERP database containing:
- Master Data tables (Company Codes, Plants, Materials, etc.)
- Transaction tables (Sales Orders, Purchase Orders, etc.)
- Financial tables (Chart of Accounts, GL Entries, etc.)
- System tables (Change Logs, Transport System, etc.)

## Support

For issues or questions about this deployment package, refer to the main project documentation.
