#!/bin/bash
# Complete Database Restoration Script
# Generated: 2025-06-05T15:16:22.845Z

echo "🚀 Starting complete database restoration..."

# Check if database URL is provided
if [ -z "$DATABASE_URL" ]; then
    echo "❌ ERROR: DATABASE_URL environment variable is required"
    exit 1
fi

# Step 1: Create schema
echo "📋 Creating database schema..."
psql "$DATABASE_URL" -f complete-schema.sql

# Step 2: Insert data
echo "💾 Inserting data..."
psql "$DATABASE_URL" -f complete-data.sql

# Step 3: Create sequences
echo "🔢 Creating sequences..."
psql "$DATABASE_URL" -f sequences.sql

# Step 4: Add constraints and indexes
echo "🔗 Adding constraints and indexes..."
psql "$DATABASE_URL" -f constraints-indexes.sql

echo "✅ Database restoration complete!"
echo "📊 Run 'psql $DATABASE_URL -c "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public';"' to verify"
