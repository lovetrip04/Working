-- Complete Database Data Export
-- Generated: 2025-06-05T15:16:18.372Z
-- Tables: 112

-- Table: account_groups (0 records - empty)

-- Table: accounts_payable (20 records)
INSERT INTO "accounts_payable" ("id", "vendor_id", "invoice_number", "invoice_date", "due_date", "amount", "currency_id", "company_code_id", "plant_id", "purchase_order_id", "payment_terms", "status", "payment_date", "payment_reference", "discount_amount", "tax_amount", "net_amount", "notes", "created_by", "created_at", "updated_at", "active") VALUES
(1, 1, 'AP000001', '2025-05-30T00:00:00.000Z', '2025-06-24T00:00:00.000Z', '47838.36', 1, 1, 1, NULL, 'Net 60', 'Paid', NULL, NULL, '0.00', '0.00', '5567.37', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(2, 1, 'AP000002', '2025-03-31T00:00:00.000Z', '2025-06-22T00:00:00.000Z', '9250.10', 1, 2, 1, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '42812.95', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(3, 1, 'AP000003', '2025-05-22T00:00:00.000Z', '2025-07-01T00:00:00.000Z', '32224.00', 1, 1, 2, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '3820.84', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(4, 1, 'AP000004', '2025-03-22T00:00:00.000Z', '2025-06-24T00:00:00.000Z', '22337.39', 1, 2, 2, NULL, 'Net 60', 'Paid', NULL, NULL, '0.00', '0.00', '13850.49', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(5, 2, 'AP000005', '2025-04-08T00:00:00.000Z', '2025-06-10T00:00:00.000Z', '14588.97', 1, 1, 1, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '20777.60', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(6, 2, 'AP000006', '2025-05-11T00:00:00.000Z', '2025-06-11T00:00:00.000Z', '21228.90', 1, 2, 1, NULL, 'Net 60', 'Open', NULL, NULL, '0.00', '0.00', '5461.03', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(7, 2, 'AP000007', '2025-05-07T00:00:00.000Z', '2025-06-10T00:00:00.000Z', '4409.29', 1, 1, 2, NULL, 'Net 60', 'Paid', NULL, NULL, '0.00', '0.00', '31608.47', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(8, 2, 'AP000008', '2025-06-01T00:00:00.000Z', '2025-06-14T00:00:00.000Z', '35983.42', 1, 2, 2, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '36771.91', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(9, 3, 'AP000009', '2025-03-25T00:00:00.000Z', '2025-06-14T00:00:00.000Z', '13713.36', 1, 1, 1, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '9380.00', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(10, 3, 'AP000010', '2025-05-22T00:00:00.000Z', '2025-06-22T00:00:00.000Z', '17510.14', 1, 2, 1, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '9086.99', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(11, 3, 'AP000011', '2025-03-22T00:00:00.000Z', '2025-06-29T00:00:00.000Z', '12341.88', 1, 1, 2, NULL, '2/10 Net 30', 'Open', NULL, NULL, '0.00', '0.00', '44419.24', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(12, 3, 'AP000012', '2025-05-29T00:00:00.000Z', '2025-06-27T00:00:00.000Z', '6162.53', 1, 2, 2, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '45212.87', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(13, 4, 'AP000013', '2025-05-24T00:00:00.000Z', '2025-06-17T00:00:00.000Z', '6752.22', 1, 1, 1, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '31644.39', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(14, 4, 'AP000014', '2025-05-02T00:00:00.000Z', '2025-06-28T00:00:00.000Z', '45753.24', 1, 2, 1, NULL, '2/10 Net 30', 'Open', NULL, NULL, '0.00', '0.00', '2142.99', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(15, 4, 'AP000015', '2025-05-29T00:00:00.000Z', '2025-06-21T00:00:00.000Z', '27214.71', 1, 1, 2, NULL, 'Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '12299.88', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(16, 4, 'AP000016', '2025-03-26T00:00:00.000Z', '2025-06-30T00:00:00.000Z', '7709.25', 1, 2, 2, NULL, 'Net 60', 'Open', NULL, NULL, '0.00', '0.00', '28709.80', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(17, 5, 'AP000017', '2025-06-03T00:00:00.000Z', '2025-06-16T00:00:00.000Z', '37654.25', 1, 1, 1, NULL, 'Net 60', 'Paid', NULL, NULL, '0.00', '0.00', '1122.16', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(18, 5, 'AP000018', '2025-03-15T00:00:00.000Z', '2025-06-22T00:00:00.000Z', '23692.87', 1, 2, 1, NULL, 'Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '23897.81', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(19, 5, 'AP000019', '2025-03-17T00:00:00.000Z', '2025-06-21T00:00:00.000Z', '20784.48', 1, 1, 2, NULL, 'Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '23198.00', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true),
(20, 5, 'AP000020', '2025-05-29T00:00:00.000Z', '2025-06-26T00:00:00.000Z', '16975.29', 1, 2, 2, NULL, '2/10 Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '3105.77', NULL, 1, '2025-06-04T00:44:42.884Z', '2025-06-04T00:44:42.884Z', true);

-- Table: accounts_receivable (25 records)
INSERT INTO "accounts_receivable" ("id", "customer_id", "invoice_number", "invoice_date", "due_date", "amount", "currency_id", "company_code_id", "plant_id", "sales_order_id", "payment_terms", "status", "payment_date", "payment_reference", "discount_amount", "tax_amount", "net_amount", "notes", "created_by", "created_at", "updated_at", "active") VALUES
(1, 1, 'AR000001', '2025-04-09T00:00:00.000Z', '2025-07-08T00:00:00.000Z', '45565.28', 1, 1, 1, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '96575.56', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(2, 2, 'AR000002', '2025-05-05T00:00:00.000Z', '2025-06-30T00:00:00.000Z', '70579.07', 1, 1, 1, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '53968.12', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(3, 3, 'AR000003', '2025-05-16T00:00:00.000Z', '2025-06-29T00:00:00.000Z', '90806.55', 1, 1, 1, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '7895.64', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(4, 4, 'AR000004', '2025-06-03T00:00:00.000Z', '2025-07-09T00:00:00.000Z', '53773.31', 1, 1, 1, NULL, 'Net 45', 'Paid', NULL, NULL, '0.00', '0.00', '31983.21', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(5, 5, 'AR000005', '2025-04-14T00:00:00.000Z', '2025-06-17T00:00:00.000Z', '14521.86', 1, 1, 1, NULL, 'Net 30', 'Paid', NULL, NULL, '0.00', '0.00', '76067.68', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(6, 1, 'AR000006', '2025-04-27T00:00:00.000Z', '2025-07-09T00:00:00.000Z', '88330.44', 1, 2, 1, NULL, 'Net 60', 'Paid', NULL, NULL, '0.00', '0.00', '72908.98', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(7, 2, 'AR000007', '2025-05-14T00:00:00.000Z', '2025-07-07T00:00:00.000Z', '9146.44', 1, 2, 1, NULL, 'Net 30', 'Overdue', NULL, NULL, '0.00', '0.00', '41336.64', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(8, 3, 'AR000008', '2025-05-28T00:00:00.000Z', '2025-06-16T00:00:00.000Z', '42630.56', 1, 2, 1, NULL, 'Net 45', 'Open', NULL, NULL, '0.00', '0.00', '39717.42', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(9, 4, 'AR000009', '2025-05-24T00:00:00.000Z', '2025-07-04T00:00:00.000Z', '69552.52', 1, 2, 1, NULL, 'Net 60', 'Paid', NULL, NULL, '0.00', '0.00', '48387.89', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(10, 5, 'AR000010', '2025-04-17T00:00:00.000Z', '2025-06-22T00:00:00.000Z', '15146.02', 1, 2, 1, NULL, 'Net 60', 'Open', NULL, NULL, '0.00', '0.00', '97124.72', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(11, 1, 'AR000011', '2025-05-11T00:00:00.000Z', '2025-06-09T00:00:00.000Z', '22085.06', 1, 1, 2, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '65227.88', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(12, 2, 'AR000012', '2025-05-02T00:00:00.000Z', '2025-06-20T00:00:00.000Z', '28185.91', 1, 1, 2, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '74679.11', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(13, 3, 'AR000013', '2025-04-09T00:00:00.000Z', '2025-06-21T00:00:00.000Z', '16533.58', 1, 1, 2, NULL, 'Net 45', 'Overdue', NULL, NULL, '0.00', '0.00', '85472.65', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(14, 4, 'AR000014', '2025-06-02T00:00:00.000Z', '2025-06-26T00:00:00.000Z', '42584.48', 1, 1, 2, NULL, 'Net 45', 'Paid', NULL, NULL, '0.00', '0.00', '14340.11', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(15, 5, 'AR000015', '2025-05-24T00:00:00.000Z', '2025-06-06T00:00:00.000Z', '7901.24', 1, 1, 2, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '81366.85', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(16, 1, 'AR000016', '2025-04-22T00:00:00.000Z', '2025-06-22T00:00:00.000Z', '16068.79', 1, 2, 2, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '15011.23', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(17, 2, 'AR000017', '2025-04-20T00:00:00.000Z', '2025-07-16T00:00:00.000Z', '52841.49', 1, 2, 2, NULL, 'Net 45', 'Paid', NULL, NULL, '0.00', '0.00', '25781.58', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(18, 3, 'AR000018', '2025-05-29T00:00:00.000Z', '2025-06-07T00:00:00.000Z', '9468.52', 1, 2, 2, NULL, 'Net 45', 'Overdue', NULL, NULL, '0.00', '0.00', '86568.69', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(19, 4, 'AR000019', '2025-05-31T00:00:00.000Z', '2025-06-30T00:00:00.000Z', '99156.13', 1, 2, 2, NULL, 'Net 45', 'Open', NULL, NULL, '0.00', '0.00', '31387.58', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(20, 5, 'AR000020', '2025-05-03T00:00:00.000Z', '2025-07-13T00:00:00.000Z', '52978.43', 1, 2, 2, NULL, 'Net 30', 'Open', NULL, NULL, '0.00', '0.00', '16317.79', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(21, 1, 'AR000021', '2025-05-13T00:00:00.000Z', '2025-06-09T00:00:00.000Z', '6883.61', 2, 1, 1, NULL, 'Net 45', 'Paid', NULL, NULL, '0.00', '0.00', '16939.39', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(22, 2, 'AR000022', '2025-05-06T00:00:00.000Z', '2025-07-09T00:00:00.000Z', '63651.40', 2, 1, 1, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '56058.37', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(23, 3, 'AR000023', '2025-04-18T00:00:00.000Z', '2025-06-24T00:00:00.000Z', '88658.27', 2, 1, 1, NULL, 'Net 30', 'Overdue', NULL, NULL, '0.00', '0.00', '25210.15', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(24, 4, 'AR000024', '2025-04-09T00:00:00.000Z', '2025-06-04T00:00:00.000Z', '50958.76', 2, 1, 1, NULL, 'Net 30', 'Overdue', NULL, NULL, '0.00', '0.00', '72221.26', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true),
(25, 5, 'AR000025', '2025-04-06T00:00:00.000Z', '2025-07-06T00:00:00.000Z', '78462.86', 2, 1, 1, NULL, 'Net 60', 'Overdue', NULL, NULL, '0.00', '0.00', '38983.94', NULL, 1, '2025-06-04T00:44:46.291Z', '2025-06-04T00:44:46.291Z', true);

-- Table: activity_types (5 records)
INSERT INTO "activity_types" ("id", "activity_type", "description", "unit_of_measure", "category", "controlling_area", "allocation_method", "created_at", "active", "updated_at") VALUES
(1, 'MACH-HR', 'Machine Hours', 'HR', 'MACHINE', 'US01', NULL, '2025-06-03T17:58:50.654Z', true, '2025-06-04T18:39:27.006Z'),
(2, 'LABOR-HR', 'Labor Hours', 'HR', 'LABOR', 'US01', NULL, '2025-06-03T17:58:50.654Z', true, '2025-06-04T18:39:27.006Z'),
(3, 'SETUP-HR', 'Setup Hours', 'HR', 'SETUP', 'US01', NULL, '2025-06-03T17:58:50.654Z', true, '2025-06-04T18:39:27.006Z'),
(4, 'QC-HR', 'Quality Control Hours', 'HR', 'QUALITY', 'US01', NULL, '2025-06-03T17:58:50.654Z', true, '2025-06-04T18:39:27.006Z'),
(5, 'MAINT-HR', 'Maintenance Hours', 'HR', 'MAINTENANCE', 'US01', NULL, '2025-06-03T17:58:50.654Z', true, '2025-06-04T18:39:27.006Z');

-- Table: ai_agent_analytics (0 records - empty)

-- Table: ai_agent_configs (7 records)
INSERT INTO "ai_agent_configs" ("id", "module_type", "module_name", "agent_name", "role_description", "system_prompt", "expertise_areas", "capabilities", "is_active", "created_at", "updated_at", "active") VALUES
(1, 'masterData', 'Master Data Management', 'Master Data Specialist', 'Expert in organizational structures, material management, customer/vendor data, and reference data maintenance', 'You are a Master Data Management specialist with deep expertise in SAP-standard organizational structures and reference data. You help users navigate complex master data relationships, ensure data integrity, and optimize organizational hierarchies. You understand the critical importance of accurate master data for all business processes.', '["Organizational Structures","Material Master","Customer Master","Vendor Master","Chart of Accounts","Cost Centers","Profit Centers","Plant Maintenance","Units of Measure","Number Ranges","Data Governance"]', '["Data Structure Analysis","Master Data Creation Guidance","Organizational Hierarchy Design","Data Quality Assessment","Reference Data Management","Integration Mapping","Compliance Checking","Migration Planning"]', true, '2025-06-04T04:33:55.202Z', '2025-06-04T04:33:55.202Z', true),
(2, 'sales', 'Sales Management', 'Sales Operations Expert', 'Specialist in sales processes, customer relationship management, pricing strategies, and revenue optimization', 'You are a Sales Operations expert with comprehensive knowledge of sales processes, customer lifecycle management, and revenue optimization strategies. You help users maximize sales performance, improve customer relationships, and streamline sales operations from lead generation to order fulfillment.', '["Lead Management","Opportunity Tracking","Quote Generation","Order Processing","Customer Relationship Management","Sales Analytics","Pricing Strategies","Sales Forecasting","Territory Management","Commission Management"]', '["Sales Process Optimization","Lead Qualification","Revenue Analysis","Customer Segmentation","Sales Performance Metrics","Pipeline Management","Pricing Strategy","Sales Forecasting"]', true, '2025-06-04T04:34:02.737Z', '2025-06-04T04:34:02.737Z', true),
(3, 'inventory', 'Inventory Management', 'Inventory Control Specialist', 'Expert in stock management, warehouse operations, material movements, and inventory optimization', 'You are an Inventory Management specialist with deep knowledge of stock control, warehouse operations, and supply chain optimization. You help users maintain optimal inventory levels, reduce carrying costs, and ensure material availability for production and sales.', '["Stock Management","Warehouse Operations","Material Movements","Inventory Valuation","ABC Analysis","Cycle Counting","Safety Stock Planning","Demand Forecasting","Supplier Management","Inventory Optimization"]', '["Stock Level Analysis","Inventory Turnover Optimization","Demand Planning","Warehouse Layout Design","Material Flow Analysis","Cost Reduction Strategies","Supply Chain Optimization","Inventory Reporting"]', true, '2025-06-04T04:34:14.229Z', '2025-06-04T04:34:14.229Z', true),
(4, 'purchase', 'Purchase Management', 'Procurement Specialist', 'Expert in procurement processes, vendor management, sourcing strategies, and purchase optimization', 'You are a Procurement specialist with extensive experience in strategic sourcing, vendor management, and purchase process optimization. You help users achieve cost savings, ensure supply security, and maintain high-quality supplier relationships.', '["Strategic Sourcing","Vendor Management","Purchase Requisitions","Purchase Orders","Contract Management","Supplier Evaluation","Cost Analysis","Procurement Analytics","Risk Management","Compliance"]', '["Sourcing Strategy Development","Vendor Performance Analysis","Cost Optimization","Contract Negotiation Support","Supplier Risk Assessment","Procurement Process Improvement","Spend Analysis","Market Research"]', true, '2025-06-04T04:34:14.229Z', '2025-06-04T04:34:14.229Z', true),
(5, 'production', 'Production Management', 'Manufacturing Operations Expert', 'Specialist in production planning, manufacturing execution, quality control, and operational efficiency', 'You are a Manufacturing Operations expert with comprehensive knowledge of production planning, shop floor management, and manufacturing excellence. You help users optimize production processes, improve quality, and maximize operational efficiency.', '["Production Planning","Manufacturing Execution","Quality Control","Capacity Planning","Bill of Materials","Work Center Management","Shop Floor Control","Lean Manufacturing","Equipment Maintenance","Performance Monitoring"]', '["Production Schedule Optimization","Capacity Analysis","Quality Improvement","Process Optimization","Equipment Efficiency","Bottleneck Analysis","Cost Reduction","Performance Metrics"]', true, '2025-06-04T04:34:14.229Z', '2025-06-04T04:34:14.229Z', true),
(6, 'finance', 'Finance Management', 'Financial Operations Expert', 'Expert in financial accounting, treasury management, accounts payable/receivable, and financial reporting', 'You are a Financial Operations expert with deep knowledge of accounting principles, financial processes, and regulatory compliance. You help users manage financial transactions, optimize cash flow, and ensure accurate financial reporting.', '["General Ledger","Accounts Payable","Accounts Receivable","Asset Accounting","Bank Management","Financial Reporting","Tax Management","Compliance","Cash Flow Management","Financial Analysis"]', '["Financial Process Optimization","Cash Flow Analysis","Financial Reporting","Compliance Monitoring","Risk Assessment","Budget Analysis","Financial Performance Metrics","Audit Support"]', true, '2025-06-04T04:34:23.866Z', '2025-06-04T04:34:23.866Z', true),
(7, 'controlling', 'Controlling', 'Management Accounting Specialist', 'Specialist in cost accounting, profitability analysis, budgeting, and management reporting', 'You are a Management Accounting specialist with expertise in cost control, profitability analysis, and performance management. You help users understand cost structures, analyze profitability, and make data-driven business decisions.', '["Cost Center Accounting","Profit Center Accounting","Product Costing","Profitability Analysis","Budget Planning","Variance Analysis","Activity-Based Costing","Performance Management","Management Reporting","Business Intelligence"]', '["Cost Analysis","Profitability Assessment","Budget Planning","Variance Analysis","Performance Monitoring","Cost Optimization","Management Reporting","Business Intelligence"]', true, '2025-06-04T04:34:23.866Z', '2025-06-04T04:34:23.866Z', true);

-- Table: ai_agent_health (0 records - empty)

-- Table: ai_agent_interventions (0 records - empty)

-- Table: ai_agent_performance (9 records)
INSERT INTO "ai_agent_performance" ("id", "agent_name", "agent_type", "performance_date", "total_interventions", "successful_interventions", "failed_interventions", "avg_confidence_score", "avg_resolution_time", "success_rate", "pattern_matches", "new_patterns_learned", "accuracy_improvement", "created_at") VALUES
('1', 'Master Data Specialist Agent', 'MODULE_SPECIALIST', '2025-06-05T00:00:00.000Z', 45, 42, 3, '0.85', 75, '0.93', 15, 5, '0.08', '2025-06-05T00:05:35.279Z'),
('2', 'Sales Operations Expert Agent', 'MODULE_SPECIALIST', '2025-06-05T00:00:00.000Z', 38, 34, 4, '0.80', 65, '0.89', 12, 4, '0.06', '2025-06-05T00:05:35.279Z'),
('3', 'Inventory Control Specialist Agent', 'MODULE_SPECIALIST', '2025-06-05T00:00:00.000Z', 52, 48, 4, '0.88', 55, '0.92', 18, 6, '0.09', '2025-06-05T00:05:35.279Z'),
('4', 'Procurement Specialist Agent', 'MODULE_SPECIALIST', '2025-06-05T00:00:00.000Z', 41, 36, 5, '0.82', 70, '0.88', 14, 5, '0.07', '2025-06-05T00:05:35.279Z'),
('5', 'Manufacturing Operations Expert Agent', 'MODULE_SPECIALIST', '2025-06-05T00:00:00.000Z', 47, 43, 4, '0.86', 60, '0.91', 16, 5, '0.08', '2025-06-05T00:05:35.279Z'),
('6', 'Financial Operations Expert Agent', 'MODULE_SPECIALIST', '2025-06-05T00:00:00.000Z', 39, 37, 2, '0.90', 45, '0.95', 13, 4, '0.10', '2025-06-05T00:05:35.279Z'),
('7', 'Management Accounting Specialist Agent', 'MODULE_SPECIALIST', '2025-06-05T00:00:00.000Z', 44, 40, 4, '0.87', 50, '0.91', 15, 5, '0.09', '2025-06-05T00:05:35.279Z'),
('8', 'Data Integrity Guardian Agent', 'DATA_INTEGRITY', '2025-06-05T00:00:00.000Z', 63, 60, 3, '0.95', 35, '0.95', 22, 7, '0.12', '2025-06-05T00:05:35.279Z'),
('9', 'Auto-Recovery Agent', 'SYSTEM_RECOVERY', '2025-06-05T00:00:00.000Z', 58, 54, 4, '0.92', 40, '0.93', 20, 6, '0.11', '2025-06-05T00:05:35.279Z');

-- Table: ai_chat_messages (0 records - empty)

-- Table: ai_chat_sessions (0 records - empty)

-- Table: ai_data_analysis_sessions (0 records - empty)

-- Table: api_keys (1 records)
INSERT INTO "api_keys" ("id", "service_name", "key_name", "key_value", "description", "is_active", "created_at", "updated_at", "last_used", "active") VALUES
(1, 'openai', 'OPENAI_API_KEY', 'c2stcHJvai0ybVVsOVJleFQ4Z3B2TXAtSkJLMXI3RTlhR0xyd050RXk1Wk41V3YwYWNPX1h0eURfY3B4WU1rWWwzUFh3Y3MybmwxQ0hFYnRuMFQzQmxia0ZKQUM1QWV1OFZjXzFHb3R5bEh3aHY0TjBfTXMyLTc2ZHFtMVV5T3BHSFh1d1RWdVVZS0F4Y2lEcGljb0d0RDlnZGJ4TEtDV25Gc0E=', 'OpenAI API key for AI agent functionality', true, '2025-06-04T13:29:59.562Z', '2025-06-04T13:34:44.013Z', NULL, true);

-- Table: approval_levels (11 records)
INSERT INTO "approval_levels" ("id", "level", "name", "description", "value_limit", "created_at", "updated_at", "active") VALUES
(1, 1, 'Team Lead', 'First level approval - up to $5,000', '5000.00', '2025-05-20T22:09:21.912Z', '2025-05-20T22:09:21.912Z', true),
(2, 2, 'Department Manager', 'Second level approval - up to $25,000', '25000.00', '2025-05-20T22:09:21.912Z', '2025-05-20T22:09:21.912Z', true),
(3, 3, 'Director', 'Third level approval - up to $100,000', '100000.00', '2025-05-20T22:09:21.912Z', '2025-05-20T22:09:21.912Z', true),
(4, 4, 'VP', 'Fourth level approval - up to $500,000', '500000.00', '2025-05-20T22:09:21.912Z', '2025-05-20T22:09:21.912Z', true),
(5, 5, 'CFO', 'Fifth level approval - unlimited', NULL, '2025-05-20T22:09:21.912Z', '2025-05-20T22:09:21.912Z', true),
(6, 1, 'Solutions', '', '500.00', '2025-05-21T01:42:12.929Z', '2025-05-21T01:42:12.929Z', true),
(7, 1, 'Team Lead Approval', 'First level approval for small purchases', '1000.00', '2025-05-21T15:12:43.075Z', '2025-05-21T15:12:43.075Z', true),
(8, 2, 'Manager Approval', 'Second level approval for medium purchases', '10000.00', '2025-05-21T15:12:43.075Z', '2025-05-21T15:12:43.075Z', true),
(9, 3, 'Director Approval', 'Third level approval for large purchases', '50000.00', '2025-05-21T15:12:43.075Z', '2025-05-21T15:12:43.075Z', true),
(10, 4, 'Executive Approval', 'Fourth level approval for very large purchases', '250000.00', '2025-05-21T15:12:43.075Z', '2025-05-21T15:12:43.075Z', true),
(11, 5, 'Board Approval', 'Highest level approval for major expenditures', '1000000.00', '2025-05-21T15:12:43.075Z', '2025-05-21T15:12:43.075Z', true);

-- Table: asset_master (15 records)
INSERT INTO "asset_master" ("id", "asset_number", "name", "description", "asset_class", "acquisition_date", "acquisition_cost", "current_value", "depreciation_method", "useful_life_years", "company_code_id", "cost_center_id", "location", "status", "is_active", "created_at", "updated_at", "active") VALUES
(1, 'A10001', 'CNC Machine - Haas VF-2', 'Vertical machining center', 'MACHINERY', '2019-03-15T00:00:00.000Z', '85000.00', '65000.00', 'STRAIGHT_LINE', 10, 1, NULL, 'Plant NY - Building A', 'ACTIVE', true, '2025-05-20T22:11:02.428Z', '2025-05-20T22:11:02.428Z', true),
(2, 'A10002', 'Forklift - Toyota 8FGCU25', 'Material handling equipment', 'EQUIPMENT', '2019-05-01T00:00:00.000Z', '28000.00', '21000.00', 'STRAIGHT_LINE', 7, 1, NULL, 'Plant NY - Warehouse', 'ACTIVE', true, '2025-05-20T22:11:02.428Z', '2025-05-20T22:11:02.428Z', true),
(3, 'A10003', 'Injection Molding Machine - Engel', 'Plastic injection molding', 'MACHINERY', '2019-08-15T00:00:00.000Z', '120000.00', '96000.00', 'STRAIGHT_LINE', 12, 1, NULL, 'Plant NY - Building B', 'ACTIVE', true, '2025-05-20T22:11:02.428Z', '2025-05-20T22:11:02.428Z', true),
(4, 'A10004', 'Server System - Dell PowerEdge', 'Data center servers', 'IT_EQUIPMENT', '2020-01-10T00:00:00.000Z', '45000.00', '27000.00', 'ACCELERATED', 5, 1, NULL, 'NY Headquarters - Server Room', 'ACTIVE', true, '2025-05-20T22:11:02.428Z', '2025-05-20T22:11:02.428Z', true),
(5, 'A10005', 'Office Building - NY HQ', 'Main office building', 'REAL_ESTATE', '2015-11-30T00:00:00.000Z', '3500000.00', '3200000.00', 'STRAIGHT_LINE', 40, 1, NULL, 'Manhattan, NY', 'ACTIVE', true, '2025-05-20T22:11:02.428Z', '2025-05-20T22:11:02.428Z', true),
(6, 'CN01-AST001', 'Production Machinery #1', 'Heavy-duty manufacturing equipment for main production line', 'MACHINERY', '2022-05-15T00:00:00.000Z', '125000.00', '110000.00', 'STRAIGHT_LINE', 10, 10, 9, 'Main Factory Floor', 'ACTIVE', true, '2025-05-21T15:11:52.062Z', '2025-05-21T15:11:52.062Z', true),
(7, 'DE01-AST001', 'Production Machinery #1', 'Heavy-duty manufacturing equipment for main production line', 'MACHINERY', '2022-05-15T00:00:00.000Z', '125000.00', '110000.00', 'STRAIGHT_LINE', 10, 9, 5, 'Main Factory Floor', 'ACTIVE', true, '2025-05-21T15:11:52.062Z', '2025-05-21T15:11:52.062Z', true),
(8, 'IN01-AST001', 'Production Machinery #1', 'Heavy-duty manufacturing equipment for main production line', 'MACHINERY', '2022-05-15T00:00:00.000Z', '125000.00', '110000.00', 'STRAIGHT_LINE', 10, 6, 14, 'Main Factory Floor', 'ACTIVE', true, '2025-05-21T15:11:52.062Z', '2025-05-21T15:11:52.062Z', true),
(9, 'GA01-AST001', 'Production Machinery #1', 'Heavy-duty manufacturing equipment for main production line', 'MACHINERY', '2022-05-15T00:00:00.000Z', '125000.00', '110000.00', 'STRAIGHT_LINE', 10, 7, 15, 'Main Factory Floor', 'ACTIVE', true, '2025-05-21T15:11:52.062Z', '2025-05-21T15:11:52.062Z', true),
(10, 'UK01-AST001', 'Production Machinery #1', 'Heavy-duty manufacturing equipment for main production line', 'MACHINERY', '2022-05-15T00:00:00.000Z', '125000.00', '110000.00', 'STRAIGHT_LINE', 10, 11, 6, 'Main Factory Floor', 'ACTIVE', true, '2025-05-21T15:11:52.062Z', '2025-05-21T15:11:52.062Z', true),
(11, 'TEST02-AST002', 'Company Vehicle #1', 'Executive transportation vehicle', 'VEHICLES', '2021-10-01T00:00:00.000Z', '45000.00', '33750.00', 'DECLINING_BALANCE', 5, 4, 8, 'Corporate Garage', 'ACTIVE', true, '2025-05-21T15:12:00.813Z', '2025-05-21T15:12:00.813Z', true),
(12, 'DE01-AST002', 'Company Vehicle #1', 'Executive transportation vehicle', 'VEHICLES', '2021-10-01T00:00:00.000Z', '45000.00', '33750.00', 'DECLINING_BALANCE', 5, 9, 5, 'Corporate Garage', 'ACTIVE', true, '2025-05-21T15:12:00.813Z', '2025-05-21T15:12:00.813Z', true),
(13, 'CA01-AST002', 'Company Vehicle #1', 'Executive transportation vehicle', 'VEHICLES', '2021-10-01T00:00:00.000Z', '45000.00', '33750.00', 'DECLINING_BALANCE', 5, 5, 13, 'Corporate Garage', 'ACTIVE', true, '2025-05-21T15:12:00.813Z', '2025-05-21T15:12:00.813Z', true),
(14, 'US01-AST002', 'Company Vehicle #1', 'Executive transportation vehicle', 'VEHICLES', '2021-10-01T00:00:00.000Z', '45000.00', '33750.00', 'DECLINING_BALANCE', 5, 1, 1, 'Corporate Garage', 'ACTIVE', true, '2025-05-21T15:12:00.813Z', '2025-05-21T15:12:00.813Z', true),
(15, 'EU01-AST002', 'Company Vehicle #1', 'Executive transportation vehicle', 'VEHICLES', '2021-10-01T00:00:00.000Z', '45000.00', '33750.00', 'DECLINING_BALANCE', 5, 2, 10, 'Corporate Garage', 'ACTIVE', true, '2025-05-21T15:12:00.813Z', '2025-05-21T15:12:00.813Z', true);

-- Table: batch_master (0 records - empty)

-- Table: bill_of_materials (8 records)
INSERT INTO "bill_of_materials" ("id", "code", "name", "material_id", "description", "version", "is_active", "created_at", "updated_at", "active") VALUES
(1, 'BOM-FG-3001', 'BOM for Smart Thermostat', 9, 'Bill of Materials for Smart Thermostat', '1.0', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(2, 'BOM-FG-3002', 'BOM for Industrial Control Panel', 10, 'Bill of Materials for Industrial Control Panel', '1.0', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(3, 'BOM-FG-3003', 'BOM for LED Light Fixture', 11, 'Bill of Materials for LED Light Fixture', '1.0', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(4, 'BOM-PM-4001', 'BOM for Cardboard Box - Small', 14, 'Bill of materials for manufacturing Cardboard Box - Small', '1.0', true, '2025-05-21T15:13:02.975Z', '2025-05-21T15:13:02.975Z', true),
(5, 'BOM-FG-3004', 'BOM for Wireless Router', 12, 'Bill of materials for manufacturing Wireless Router', '1.0', true, '2025-05-21T15:13:02.975Z', '2025-05-21T15:13:02.975Z', true),
(6, 'BOM-SF-2003', 'BOM for Injection Molded Housing', 8, 'Bill of materials for manufacturing Injection Molded Housing', '1.0', true, '2025-05-21T15:13:02.975Z', '2025-05-21T15:13:02.975Z', true),
(7, 'BOM-FG-3005', 'BOM for Electric Motor', 13, 'Bill of materials for manufacturing Electric Motor', '1.0', true, '2025-05-21T15:13:02.975Z', '2025-05-21T15:13:02.975Z', true),
(8, 'BOM-SF-2001', 'BOM for Aluminum Frame', 6, 'Bill of materials for manufacturing Aluminum Frame', '1.0', true, '2025-05-21T15:13:02.975Z', '2025-05-21T15:13:02.975Z', true);

-- Table: bom_items (18 records)
INSERT INTO "bom_items" ("id", "bom_id", "material_id", "quantity", "unit_cost", "is_active", "created_at", "updated_at", "active") VALUES
(1, 1, 1, '5.850', '24.95', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(2, 2, 1, '13.890', '12.59', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(3, 3, 1, '10.720', '12.07', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(4, 1, 2, '11.780', '38.61', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(5, 2, 2, '14.810', '58.75', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(6, 3, 2, '5.700', '36.81', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(7, 1, 3, '11.460', '12.73', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(8, 2, 3, '5.100', '36.66', true, '2025-05-20T22:09:48.919Z', '2025-05-20T22:09:48.919Z', true),
(9, 1, 4, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(10, 1, 5, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(11, 1, 6, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(12, 1, 7, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(13, 1, 8, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(14, 1, 10, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(15, 1, 11, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(16, 1, 12, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(17, 1, 13, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true),
(18, 1, 14, '3.500', '12.50', true, '2025-05-21T15:13:22.453Z', '2025-05-21T15:13:22.453Z', true);

-- Table: categories (1 records)
INSERT INTO "categories" ("id", "name", "description", "user_id", "created_at", "updated_at", "active") VALUES
(1, 'General', 'General category for materials', NULL, '2025-05-20T14:35:23.847Z', '2025-05-20T14:35:23.847Z', true);

-- Table: change_document_analytics (5 records)
INSERT INTO "change_document_analytics" ("id", "analysis_date", "object_class", "application_module", "total_changes", "creates_count", "updates_count", "deletes_count", "avg_fields_changed", "avg_approval_time", "avg_processing_time", "error_count", "reversal_count", "quality_score", "high_impact_changes", "compliance_changes", "emergency_changes", "created_at") VALUES
('1', '2025-06-03T00:00:00.000Z', 'COMPANY_CODE', 'MASTER_DATA', 0, 0, 0, 0, '0.00', NULL, NULL, 0, 0, '100.00', 0, 0, 0, '2025-06-04T23:31:25.028Z'),
('2', '2025-06-03T00:00:00.000Z', 'CUSTOMER', 'MASTER_DATA', 0, 0, 0, 0, '0.00', NULL, NULL, 0, 0, '100.00', 0, 0, 0, '2025-06-04T23:31:25.028Z'),
('3', '2025-06-03T00:00:00.000Z', 'MATERIAL', 'MASTER_DATA', 0, 0, 0, 0, '0.00', NULL, NULL, 0, 0, '100.00', 0, 0, 0, '2025-06-04T23:31:25.028Z'),
('4', '2025-06-03T00:00:00.000Z', 'SALES_ORDER', 'SALES', 0, 0, 0, 0, '0.00', NULL, NULL, 0, 0, '100.00', 0, 0, 0, '2025-06-04T23:31:25.028Z'),
('5', '2025-06-03T00:00:00.000Z', 'PURCHASE_ORDER', 'PURCHASE', 0, 0, 0, 0, '0.00', NULL, NULL, 0, 0, '100.00', 0, 0, 0, '2025-06-04T23:31:25.028Z');

-- Table: change_document_approvals (0 records - empty)

-- Table: change_document_attachments (0 records - empty)

-- Table: change_document_headers (0 records - empty)

-- Table: change_document_positions (0 records - empty)

-- Table: change_document_relations (0 records - empty)

-- Table: chart_of_accounts (0 records - empty)

-- Table: companies (1 records)
INSERT INTO "companies" ("id", "company_id", "name", "address", "country", "currency", "language", "active", "created_at", "updated_at") VALUES
(1, 'GLOBL', 'Global Holdings', '123 Business Center, New York, NY 10001', 'US', 'USD', 'EN', true, '2025-06-04T19:55:50.088Z', '2025-06-04T19:55:50.088Z');

-- Table: company_code_chart_assignments (1 records)
INSERT INTO "company_code_chart_assignments" ("id", "company_code_id", "chart_of_accounts_id", "fiscal_year_variant_id", "assigned_date", "is_active", "created_at", "active", "updated_at") VALUES
(1, 1, 39, 1, '2025-06-04T02:39:58.298Z', true, '2025-06-04T02:39:58.298Z', true, '2025-06-04T18:39:27.994Z');

-- Table: company_codes (19 records)
INSERT INTO "company_codes" ("id", "code", "name", "city", "country", "currency", "language", "active", "created_at", "updated_at") VALUES
(1, '1000', 'Global Manufacturing Inc.', 'New York', 'US', 'USD', 'EN', true, '2025-06-04T19:55:59.524Z', '2025-06-04T19:55:59.524Z'),
(2, '2000', 'Default Company Code', 'Default City', 'US', 'USD', 'EN', true, '2025-06-04T20:05:08.192Z', '2025-06-04T20:05:08.192Z'),
(3, 'TEST01', 'Test Company with Zero Errors', 'New York', 'United States', 'USD', 'English', true, '2025-06-04T23:15:35.999Z', '2025-06-04T23:15:35.999Z'),
(4, '4000', 'Pr 0004', NULL, 'United States', 'USD', NULL, true, '2025-06-04T23:42:48.367Z', '2025-06-04T23:42:48.367Z'),
(5, 'TEST', 'Test Company', NULL, 'United States', 'USD', NULL, true, '2025-06-05T00:41:23.716Z', '2025-06-05T00:41:23.716Z'),
(6, 'PROD1', 'Production Company 1', NULL, 'US', 'USD', NULL, true, '2025-06-05T00:46:55.856Z', '2025-06-05T00:46:55.856Z'),
(7, 'CC563', 'Test Company', NULL, 'US', 'USD', NULL, true, '2025-06-05T00:51:53.384Z', '2025-06-05T00:51:53.384Z'),
(8, 'TC571891', 'Test Company', NULL, 'US', 'USD', NULL, true, '2025-06-05T01:56:11.932Z', '2025-06-05T01:56:11.932Z'),
(9, 'TC716672', 'Test Company', NULL, 'US', 'USD', NULL, true, '2025-06-05T01:58:36.705Z', '2025-06-05T01:58:36.705Z'),
(10, 'TC772239', 'Test Company', NULL, 'US', 'USD', NULL, true, '2025-06-05T01:59:32.277Z', '2025-06-05T01:59:32.277Z'),
(11, 'TC792967', 'Test Company', NULL, 'US', 'USD', NULL, true, '2025-06-05T01:59:52.992Z', '2025-06-05T01:59:52.992Z'),
(12, 'TC853374', 'Test Company', NULL, 'US', 'USD', NULL, true, '2025-06-05T02:00:53.413Z', '2025-06-05T02:00:53.413Z'),
(13, 'STAB001', 'Stability Test Co', NULL, NULL, NULL, NULL, true, '2025-06-05T02:04:10.695Z', '2025-06-05T02:04:10.695Z'),
(15, 'TEST001', 'Test Company 001', NULL, 'USA', 'USD', NULL, true, '2025-06-05T02:10:54.946Z', '2025-06-05T02:10:54.946Z'),
(16, 'TST1749089', 'Test Company 1749089635928', NULL, 'USA', 'USD', NULL, true, '2025-06-05T02:13:57.487Z', '2025-06-05T02:13:57.487Z'),
(17, 'T174908976', 'Test Company 1749089769754', NULL, 'USA', 'USD', NULL, true, '2025-06-05T02:16:08.981Z', '2025-06-05T02:16:08.981Z'),
(18, 'T174908979', 'Test Company 1749089793928', NULL, 'USA', 'USD', NULL, true, '2025-06-05T02:16:33.856Z', '2025-06-05T02:16:33.856Z'),
(19, 'Test0101', 'Company PR 0101', NULL, 'United States', 'USD', NULL, true, '2025-06-05T02:20:37.126Z', '2025-06-05T02:20:37.126Z'),
(20, 'GW01', 'GW 001', NULL, 'United States', 'USD', NULL, true, '2025-06-05T13:54:06.773Z', '2025-06-05T13:54:06.773Z');

-- Table: comprehensive_issues_log (137 records)
INSERT INTO "comprehensive_issues_log" ("id", "issue_id", "error_message", "stack_trace", "module", "operation", "user_id", "session_id", "request_data", "severity", "category", "status", "resolved_at", "resolved_by", "additional_data", "created_at", "updated_at", "auto_resolvable", "confidence_score", "pattern_matched", "recommended_actions", "ai_analysis", "business_context", "user_impact", "resolution_status") VALUES
('1', 'fddf2f6b-be73-4084-a03c-6230f222fdea', 'Test issue for system validation', NULL, 'MASTER_DATA', 'SYSTEM_INITIALIZATION', 'SYSTEM', NULL, NULL, 'LOW', 'SYSTEM', 'OPEN', NULL, NULL, [object Object], '2025-06-04T23:48:09.969Z', '2025-06-04T23:48:09.969Z', false, '0.00', NULL, NULL, NULL, NULL, NULL, 'PENDING'),
('2', 'c8e62dd6-93d4-4129-8ef7-aa164a55ec07', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:46:55.963Z', '2025-06-05T00:46:55.963Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('3', 'eaec68a3-95bd-41bf-a96d-2e152a99ffcc', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:46:55.973Z', '2025-06-05T00:46:55.973Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('4', '1c7fe1d5-a040-48c3-9303-16ffeb4ee39c', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:46:56.064Z', '2025-06-05T00:46:56.064Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('5', '07cbce98-0f63-47fa-b8db-ea9cf8196b01', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:46:56.064Z', '2025-06-05T00:46:56.064Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('6', 'b2813e11-a51c-4da1-a4a5-1ed0037df025', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/customer', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:46:56.141Z', '2025-06-05T00:46:56.141Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('7', '9197218e-2892-4f2a-b3ea-42924b854767', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/customer', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:46:56.142Z', '2025-06-05T00:46:56.142Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('8', 'a9ed4692-42d0-47e9-a88f-68ab678c0a4d', 'HTTP 500 Error', NULL, 'SALES', 'POST /api/sales/orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:46:56.309Z', '2025-06-05T00:46:56.309Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('9', 'f8f3cf28-45d3-43c0-a9d5-01d1ef871e1b', 'HTTP 500 Error', NULL, 'SALES', 'POST /api/sales/orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:46:56.311Z', '2025-06-05T00:46:56.311Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('10', '926c619c-1788-4d06-9e9c-7b42487bf806', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:17.532Z', '2025-06-05T00:48:17.532Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('11', '1791d772-3eb2-4b31-b9e3-21884b982376', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:17.534Z', '2025-06-05T00:48:17.534Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('12', '649ffee7-50d8-4dd9-8012-c21e83d05e4e', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.297Z', '2025-06-05T00:48:18.297Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('13', 'c0ce74ed-fb91-4e20-b9ff-8c7240f5211d', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.298Z', '2025-06-05T00:48:18.298Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('14', 'f0024b49-2b9e-4e12-a97d-da1fd7681126', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/customer', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.383Z', '2025-06-05T00:48:18.383Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('15', '11fdb125-712d-474a-b893-d3a708c7f2b6', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/customer', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.384Z', '2025-06-05T00:48:18.384Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('16', 'e7f739f3-a142-4ac6-bf6e-39b93b0e6505', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/vendor', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.468Z', '2025-06-05T00:48:18.468Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('17', '3d96c707-909e-4746-80d7-a6a5d2fd4d55', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/vendor', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.468Z', '2025-06-05T00:48:18.468Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('18', '38886055-fbf9-40f1-a198-a2d353583686', 'HTTP 500 Error', NULL, 'SALES', 'POST /api/sales/orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.618Z', '2025-06-05T00:48:18.618Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('19', '44019d04-bdd0-4b7c-bb4c-5d8d913400f0', 'HTTP 500 Error', NULL, 'SALES', 'POST /api/sales/orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.620Z', '2025-06-05T00:48:18.620Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('20', '52644392-fb1f-4554-937c-0e6dc03dd66a', 'HTTP 500 Error', NULL, 'SYSTEM', 'POST /orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.711Z', '2025-06-05T00:48:18.711Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('21', 'cc5daa4f-f3a5-4c1b-b61f-c597c540bdea', 'HTTP 500 Error', NULL, 'SYSTEM', 'POST /orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:48:18.719Z', '2025-06-05T00:48:18.719Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('22', '5781ee13-b00e-49d6-9838-aa1388645320', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:22.360Z', '2025-06-05T00:49:22.360Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('23', '30b0d495-cba0-4b2a-9f54-8f600904583e', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:22.361Z', '2025-06-05T00:49:22.361Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('24', '28d75bfc-b020-406a-9039-f7d921628d1c', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:22.993Z', '2025-06-05T00:49:22.993Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('25', 'e7b3e1e3-f2e8-4ec5-83c7-536b4af0577f', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:22.994Z', '2025-06-05T00:49:22.994Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('27', 'a168f917-e970-4e80-8052-f5c469160215', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:23.436Z', '2025-06-05T00:49:23.436Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('29', '056ad0c3-198b-4de1-9ebb-3937ded5909f', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/customer', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:23.893Z', '2025-06-05T00:49:23.893Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('31', 'db998a89-8eec-4910-8566-a2de9a3d8c70', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/vendor', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:23.978Z', '2025-06-05T00:49:23.978Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('33', '53ddefc8-b0d6-4f07-9ad5-a0cdf906fb17', 'HTTP 500 Error', NULL, 'SALES', 'POST /api/sales/orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:24.110Z', '2025-06-05T00:49:24.110Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('35', '2b78a0bd-f7a6-46e5-a7b5-47b0a694cacc', 'HTTP 500 Error', NULL, 'SYSTEM', 'POST /orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:24.203Z', '2025-06-05T00:49:24.203Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('26', '18a1163a-96dd-4811-a982-0f52e9b70120', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:23.435Z', '2025-06-05T00:49:23.435Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('28', '16291d8d-52ac-4f43-92f2-46a2974a2bc6', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/customer', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:23.890Z', '2025-06-05T00:49:23.890Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('30', 'f077e548-a498-4912-be9c-f8972776b8ec', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/vendor', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:23.977Z', '2025-06-05T00:49:23.977Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('32', 'bd811d74-de9d-4a85-8096-f36c7f72c69d', 'HTTP 500 Error', NULL, 'SALES', 'POST /api/sales/orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:24.109Z', '2025-06-05T00:49:24.109Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('34', '6fe46dbc-2c09-4f48-afdf-ba27c60f13c1', 'HTTP 500 Error', NULL, 'SYSTEM', 'POST /orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:49:24.202Z', '2025-06-05T00:49:24.202Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('36', '70cd4c43-6597-4a1c-8a8f-6c336401c1dd', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:50:30.959Z', '2025-06-05T00:50:30.959Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('37', '0072aee9-feed-47ff-83d6-3422f385f596', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:50:30.959Z', '2025-06-05T00:50:30.959Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('38', '328dcd82-fc04-4aa9-864e-8a0c94d4e260', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:50:31.012Z', '2025-06-05T00:50:31.012Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('39', '2828adda-3f7c-41a2-88ea-610bc007cfa6', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:50:31.013Z', '2025-06-05T00:50:31.013Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('40', 'b62869ac-7fe2-4896-b350-c9921987290e', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:51:00.251Z', '2025-06-05T00:51:00.251Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('41', '77a95b6a-7c0c-4c2d-9075-fc83ac9a983b', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:51:00.251Z', '2025-06-05T00:51:00.251Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('42', '3349000a-4e2d-481f-bbfc-f26722c9caae', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:51:00.377Z', '2025-06-05T00:51:00.377Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('43', '6c592f9b-7784-46a4-91ad-ebc00511587e', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T00:51:00.378Z', '2025-06-05T00:51:00.378Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('45', 'ec88b444-f434-4d02-9502-04c4ad39ea99', 'HTTP 500 Error', NULL, 'SALES', 'GET /api/sales/opportunities/export', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:53:33.791Z', '2025-06-05T01:53:33.791Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('44', 'dfcbc680-53e1-4c74-b82e-2911f28f8cc4', 'HTTP 500 Error', NULL, 'SALES', 'GET /api/sales/opportunities/export', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:53:33.799Z', '2025-06-05T01:53:33.799Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('47', '8ef25092-0d6a-428e-8f26-1f2cf9388298', 'HTTP 500 Error', NULL, 'SALES', 'GET /api/sales/opportunities/export', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:56:14.472Z', '2025-06-05T01:56:14.472Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('46', 'e14ad7a9-dae7-45e4-a960-05661913d9b2', 'HTTP 500 Error', NULL, 'SALES', 'GET /api/sales/opportunities/export', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:56:14.467Z', '2025-06-05T01:56:14.467Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('48', 'fcea03a0-b2b6-4882-bdc1-5f5eb2e187f2', 'HTTP 500 Error', NULL, 'PURCHASE', 'GET /api/purchase/requests', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:58:36.147Z', '2025-06-05T01:58:36.147Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('49', 'c2521fbf-4656-4a35-8f43-7958f7edd0ed', 'HTTP 500 Error', NULL, 'PURCHASE', 'GET /api/purchase/requests', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:58:36.150Z', '2025-06-05T01:58:36.150Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('50', '979fcc27-4d43-4780-be89-e59e83e69fd5', 'HTTP 500 Error', NULL, 'PRODUCTION', 'GET /api/production/work-orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:58:36.312Z', '2025-06-05T01:58:36.312Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('51', 'd3338aca-cd40-4f4e-b1d0-b6e8a75140ee', 'HTTP 500 Error', NULL, 'PRODUCTION', 'GET /api/production/work-orders', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:58:36.317Z', '2025-06-05T01:58:36.317Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('52', '9891912e-d07b-4bc6-97e9-774702724414', 'HTTP 500 Error', NULL, 'CONTROLLING', 'GET /api/controlling/profit-centers', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:58:36.679Z', '2025-06-05T01:58:36.679Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('53', 'c3e1c459-7b92-4158-acd9-81129763201c', 'HTTP 500 Error', NULL, 'CONTROLLING', 'GET /api/controlling/profit-centers', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:58:36.681Z', '2025-06-05T01:58:36.681Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('54', '1ca1cf18-c55b-4aa2-941b-1b9129a2866e', 'HTTP 500 Error', NULL, 'PURCHASE', 'GET /api/purchase/requests', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:59:31.664Z', '2025-06-05T01:59:31.664Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('55', '3a0c3ef1-7a21-4d34-911a-f7b626d3634f', 'HTTP 500 Error', NULL, 'PURCHASE', 'GET /api/purchase/requests', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:59:31.665Z', '2025-06-05T01:59:31.665Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('56', 'f2e9fa03-8fec-4ba9-92dd-3c509441ac3a', 'HTTP 500 Error', NULL, 'CONTROLLING', 'GET /api/controlling/profit-centers', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:59:32.246Z', '2025-06-05T01:59:32.246Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('57', '32e5f4be-29f5-410a-a2d2-403a0bf25e6b', 'HTTP 500 Error', NULL, 'CONTROLLING', 'GET /api/controlling/profit-centers', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:59:32.246Z', '2025-06-05T01:59:32.246Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('58', 'cbd6abb2-191f-4c64-bc19-245ec9d3ec92', 'HTTP 500 Error', NULL, 'PURCHASE', 'GET /api/purchase/requests', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:59:52.425Z', '2025-06-05T01:59:52.425Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('59', '3f523ada-93a8-40ea-a0e3-ffa189891425', 'HTTP 500 Error', NULL, 'PURCHASE', 'GET /api/purchase/requests', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:59:52.428Z', '2025-06-05T01:59:52.428Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('60', 'f56904e2-dddf-4188-93bc-1313088880dd', 'HTTP 500 Error', NULL, 'CONTROLLING', 'GET /api/controlling/profit-centers', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:59:52.976Z', '2025-06-05T01:59:52.976Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('61', 'b2f8a8a4-b173-446c-bca7-0fdec6928331', 'HTTP 500 Error', NULL, 'CONTROLLING', 'GET /api/controlling/profit-centers', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T01:59:52.978Z', '2025-06-05T01:59:52.978Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('62', '2c240c63-a71c-493c-b2ec-a20afdf988c8', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:04:10.812Z', '2025-06-05T02:04:10.812Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('63', '77ac3c3f-08ae-40d7-967e-c075eb058abc', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:04:10.820Z', '2025-06-05T02:04:10.820Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('64', '41e5dfd0-60ec-4909-9b18-5780da4e29ae', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:04:11.131Z', '2025-06-05T02:04:11.131Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('65', 'ba9256b6-3a3f-406b-bbed-d43ab2a776e0', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:04:11.134Z', '2025-06-05T02:04:11.134Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('66', 'c5312edd-f898-40cd-addc-6b9b0c8ac52c', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:05:58.542Z', '2025-06-05T02:05:58.542Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('67', 'bb19ff4c-35e3-4a22-b1c9-8841dd44754b', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:05:58.550Z', '2025-06-05T02:05:58.550Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('68', '7f601957-3ffa-4b1d-9c42-4699f1e07fd7', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:03.667Z', '2025-06-05T02:06:03.667Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('69', '47f09fb1-a282-4697-afe1-04d0bbcdb9af', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:03.668Z', '2025-06-05T02:06:03.668Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('70', '768aa547-e092-4451-b38a-046c656c8f6a', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:03.695Z', '2025-06-05T02:06:03.695Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('71', '4da5cfc8-d1f9-4015-935a-4ad3767ec1d9', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:03.696Z', '2025-06-05T02:06:03.696Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('72', '74589c0d-d18a-47ec-ba82-209d0c3ddc77', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:03.770Z', '2025-06-05T02:06:03.770Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('73', '45646726-7ebd-49a0-b5d2-4f70a80e8001', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:03.771Z', '2025-06-05T02:06:03.771Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('74', '770b12ce-976d-49e6-b41d-88fe312a1c8b', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:03.997Z', '2025-06-05T02:06:03.997Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('75', '8b181bad-139b-4a84-b075-6c6160b3fe2a', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:03.999Z', '2025-06-05T02:06:03.999Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('76', 'a102cc9a-7467-42cf-888b-98b38d1ff1f0', 'HTTP 400 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:04.027Z', '2025-06-05T02:06:04.027Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('77', '4695af90-1b7c-4fde-a23f-4dadfdc8e676', 'HTTP 400 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:04.028Z', '2025-06-05T02:06:04.028Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('78', 'ccc58a65-4458-4f67-96dc-c9a0dbeb6191', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:29.575Z', '2025-06-05T02:06:29.575Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('79', '6086a1a8-9aaf-45ed-ab43-4d79b4621d7f', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:29.642Z', '2025-06-05T02:06:29.642Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('80', 'f07a9380-babb-45e2-ae29-4bbef3f31643', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:29.742Z', '2025-06-05T02:06:29.742Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('81', 'e71df478-ecd6-426e-af7c-ca076a33dbb9', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:29.743Z', '2025-06-05T02:06:29.743Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('82', '1d94a101-e3fe-4e1b-bc78-637860b62180', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:29.841Z', '2025-06-05T02:06:29.841Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('83', 'c98f45bc-b1ac-4861-94d0-0a67f2df434f', 'HTTP 404 Error', NULL, 'SYSTEM', 'GET /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:06:29.841Z', '2025-06-05T02:06:29.841Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('84', '6907a5f2-652d-4050-9137-0a9df5ef5733', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:09:13.563Z', '2025-06-05T02:09:13.563Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('85', 'f7085298-cb0d-491b-82f9-52e5cdbf7a6e', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:09:13.565Z', '2025-06-05T02:09:13.565Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('87', 'fa6ea030-ccd6-439d-8f16-f1fd81314ad1', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:10:57.807Z', '2025-06-05T02:10:57.807Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('86', 'ab7e7d89-98b5-4112-9360-1952e442332a', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:10:57.105Z', '2025-06-05T02:10:57.105Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('88', '10cd6468-6472-4fb7-a8ee-4abc7c5d41d9', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:10:58.420Z', '2025-06-05T02:10:58.420Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('89', '624afa90-fd81-41fa-857d-d5df1a1639d9', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:10:58.421Z', '2025-06-05T02:10:58.421Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('90', '9164e579-e113-4b82-b781-1398dc480c2d', 'HTTP 404 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:10:58.444Z', '2025-06-05T02:10:58.444Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('91', '59a604c8-1619-420a-b983-c140b25c8a73', 'HTTP 404 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:00.282Z', '2025-06-05T02:11:00.282Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('92', '4739c580-815d-425e-ae27-206ac4e987b5', 'HTTP 404 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:00.285Z', '2025-06-05T02:11:00.285Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('93', '3eac7f50-06ea-4e9f-9f62-58a0dcf520ee', 'HTTP 404 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:00.287Z', '2025-06-05T02:11:00.287Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('94', 'ec90e0f4-1426-4325-85f4-b6e460e1de43', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.618Z', '2025-06-05T02:11:57.618Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('95', '1b1e9677-934b-4fee-bfc2-52ca8110bcfd', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.672Z', '2025-06-05T02:11:57.672Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('96', 'bc645731-d5b1-4d5e-bc5b-96bf25029ec4', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.738Z', '2025-06-05T02:11:57.738Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('97', '83328509-12bc-4c9e-930d-5993ca6367bc', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.741Z', '2025-06-05T02:11:57.741Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('98', '838a1a79-22fd-4988-a6b8-78dcc3b89973', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.780Z', '2025-06-05T02:11:57.780Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('99', 'a3559022-31be-4649-80b2-b098a264e8e4', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/plant', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.781Z', '2025-06-05T02:11:57.781Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('100', '4f9c5971-46bf-483c-a9e2-5049c822bf3e', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.826Z', '2025-06-05T02:11:57.826Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('101', '547dd7bb-ad25-4c2c-b242-01d12d9ba83a', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/material', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.829Z', '2025-06-05T02:11:57.829Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('102', '28beb971-105b-4b6a-9de5-025077923d38', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/vendor', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.954Z', '2025-06-05T02:11:57.954Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('103', 'a967fe0f-8480-48f0-b365-bf88661277da', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/vendor', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:57.975Z', '2025-06-05T02:11:57.975Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('104', '805d5be4-7b37-4a26-9e76-67ece0b6f2a8', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:58.042Z', '2025-06-05T02:11:58.042Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('105', '1b598742-7b4e-4c8a-acf8-99498c1eebbe', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:58.044Z', '2025-06-05T02:11:58.044Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('106', 'a712c7db-9ae6-45b1-8309-14e2b9a12d0f', 'HTTP 404 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:58.102Z', '2025-06-05T02:11:58.102Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('107', '6fa7d387-c42c-44eb-a388-6f92f4a87bd8', 'HTTP 404 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:58.110Z', '2025-06-05T02:11:58.110Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('108', '5f54b2ed-559e-4ef0-bc01-b9a1ec9b5192', 'HTTP 404 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:58.118Z', '2025-06-05T02:11:58.118Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('109', '1434626a-dc41-4740-8427-bc6cf5b31748', 'HTTP 404 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:58.122Z', '2025-06-05T02:11:58.122Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('110', 'dad39bb4-931c-4c93-bbbc-3d1ed4a17f98', 'HTTP 400 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:58.163Z', '2025-06-05T02:11:58.163Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('111', '81e582dd-67c7-4d0f-a20a-942d5a84584f', 'HTTP 400 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:11:58.166Z', '2025-06-05T02:11:58.166Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('112', 'f42ac51e-32e1-46cc-83cc-72aa54a298bd', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:13:57.916Z', '2025-06-05T02:13:57.916Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('113', '2c7d6f1a-19d4-4f80-a289-4c0f5ebe69e4', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:13:59.913Z', '2025-06-05T02:13:59.913Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('114', '4c5dbe59-7c46-4225-af3b-b7e65ef46f77', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:14:00.007Z', '2025-06-05T02:14:00.007Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('115', 'a3cc65c6-267a-41d4-a455-634ce99705a7', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:14:00.010Z', '2025-06-05T02:14:00.010Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('116', '421a1a1f-05fa-43fd-8011-5c6c64d36ff4', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:08.285Z', '2025-06-05T02:15:08.285Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('117', '9cc67a0c-32f4-438c-bdcc-f337d966f4d4', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:08.286Z', '2025-06-05T02:15:08.286Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('118', '10f1dcde-c407-44c5-b866-b82360af84b5', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:08.536Z', '2025-06-05T02:15:08.536Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('119', 'b203a650-34ee-427c-8d6d-496ebfacf500', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:08.537Z', '2025-06-05T02:15:08.537Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('120', 'c83b3677-40ad-48a2-9c53-6adf7e1d9a9d', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:31.766Z', '2025-06-05T02:15:31.766Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('121', '1e3bdeeb-0f36-4612-8663-10cbd77f91c3', 'HTTP 409 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/company-code', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:31.768Z', '2025-06-05T02:15:31.768Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('122', 'dc111ee9-c619-4f07-934b-5f196b9d6cf1', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:31.950Z', '2025-06-05T02:15:31.950Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('123', 'd4337ea0-ad20-43a9-bc2d-da8cd3e67bd2', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:31.953Z', '2025-06-05T02:15:31.953Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('124', '8c8fa5c0-d138-4a26-b101-a880a4f081f9', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:32.085Z', '2025-06-05T02:15:32.085Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('125', 'a1c74e0b-2855-4167-acd0-7b2682106d4e', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:15:32.087Z', '2025-06-05T02:15:32.087Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('126', 'bfc46d96-6e6b-439f-8e7e-61bef7cc073e', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:09.707Z', '2025-06-05T02:16:09.707Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('127', '6ac3baf1-d63a-4c30-b138-2994263b34c6', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:09.724Z', '2025-06-05T02:16:09.724Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('128', '331a513e-3d06-4bd8-a343-f7d2558a5686', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:09.902Z', '2025-06-05T02:16:09.902Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('129', '01a49fc6-0220-4b6d-b913-c4829661bb75', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:09.971Z', '2025-06-05T02:16:09.971Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('130', '9bfde589-34bf-4f08-8df4-a4abd17f2c65', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:34.543Z', '2025-06-05T02:16:34.543Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('131', 'a8750c26-5437-4637-be94-8be1ee480d3d', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/purchase-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:34.599Z', '2025-06-05T02:16:34.599Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('132', '75a04f22-9e1b-471c-aeb7-58541f68ce26', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/sales-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:34.674Z', '2025-06-05T02:16:34.674Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('133', '9fd05d16-e74f-47f1-8fb7-fa145aaaa1bf', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/sales-organization', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:34.726Z', '2025-06-05T02:16:34.726Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('134', '5823ccbf-9af5-4aa2-9705-f4bbed545980', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:34.793Z', '2025-06-05T02:16:34.793Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('135', '760d43ef-e057-467b-b69a-1ad4ef24abab', 'HTTP 500 Error', NULL, 'MASTER_DATA', 'POST /api/master-data/cost-center', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:34.848Z', '2025-06-05T02:16:34.848Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('136', 'fd87d9e3-3fdf-4448-afe3-42b8650cbd25', 'HTTP 400 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:34.956Z', '2025-06-05T02:16:34.956Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING'),
('137', '0c938d87-c1af-4a38-8a9b-27ff8d0f510c', 'HTTP 400 Error', NULL, 'SYSTEM', 'POST /', NULL, NULL, [object Object], 'HIGH', 'SYSTEM', 'OPEN', NULL, NULL, NULL, '2025-06-05T02:16:34.999Z', '2025-06-05T02:16:34.999Z', false, '0.00', NULL, NULL, NULL, NULL, 'User operation failed', 'PENDING');

-- Table: copa_actuals (0 records - empty)

-- Table: cost_allocations (0 records - empty)

-- Table: cost_center_actuals (63 records)
INSERT INTO "cost_center_actuals" ("id", "cost_center", "fiscal_year", "period", "account", "activity_type", "actual_amount", "actual_quantity", "currency", "unit_of_measure", "posting_date", "document_number", "reference", "created_at", "cost_center_id", "company_code_id", "currency_id", "active", "updated_at") VALUES
(73, 'CC001', 2025, 6, '400000', NULL, '15458.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.655Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(74, 'CC001', 2025, 6, '410000', NULL, '6496.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.655Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(75, 'CC001', 2025, 6, '420000', NULL, '4239.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.655Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(76, 'CC002', 2025, 6, '400000', NULL, '12745.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.681Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(77, 'CC002', 2025, 6, '410000', NULL, '5217.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.681Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(78, 'CC002', 2025, 6, '420000', NULL, '4493.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.681Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(79, 'CC003', 2025, 6, '400000', NULL, '12433.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.700Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(80, 'CC003', 2025, 6, '410000', NULL, '5814.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.700Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(81, 'CC003', 2025, 6, '420000', NULL, '4665.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.700Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(82, 'CC101', 2025, 6, '400000', NULL, '12661.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.719Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(83, 'CC101', 2025, 6, '410000', NULL, '5950.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.719Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(84, 'CC101', 2025, 6, '420000', NULL, '3854.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.719Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(85, 'CC102', 2025, 6, '400000', NULL, '11254.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.738Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(86, 'CC102', 2025, 6, '410000', NULL, '5562.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.738Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(87, 'CC102', 2025, 6, '420000', NULL, '4225.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.738Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(88, 'CC103', 2025, 6, '400000', NULL, '12331.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.757Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(89, 'CC103', 2025, 6, '410000', NULL, '5990.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.757Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(90, 'CC103', 2025, 6, '420000', NULL, '3248.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.757Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(91, 'CC201', 2025, 6, '400000', NULL, '13570.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.776Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(92, 'CC201', 2025, 6, '410000', NULL, '5203.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.776Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(93, 'CC201', 2025, 6, '420000', NULL, '3285.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.776Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(94, 'CC202', 2025, 6, '400000', NULL, '13551.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.796Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(95, 'CC202', 2025, 6, '410000', NULL, '6018.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.796Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(96, 'CC202', 2025, 6, '420000', NULL, '4622.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.796Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(97, 'CC203', 2025, 6, '400000', NULL, '13779.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.815Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(98, 'CC203', 2025, 6, '410000', NULL, '5969.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.815Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(99, 'CC203', 2025, 6, '420000', NULL, '4124.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.815Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(100, 'PROD001', 2025, 6, '400000', NULL, '14128.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.834Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(101, 'PROD001', 2025, 6, '410000', NULL, '6719.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.834Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(102, 'PROD001', 2025, 6, '420000', NULL, '4275.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.834Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(103, 'PROD002', 2025, 6, '400000', NULL, '11436.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.854Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(104, 'PROD002', 2025, 6, '410000', NULL, '4838.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.854Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(105, 'PROD002', 2025, 6, '420000', NULL, '3207.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.854Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(106, 'QC001', 2025, 6, '400000', NULL, '17617.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.872Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(107, 'QC001', 2025, 6, '410000', NULL, '5227.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.872Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(108, 'QC001', 2025, 6, '420000', NULL, '4378.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.872Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(109, 'MAINT001', 2025, 6, '400000', NULL, '14777.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.892Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(110, 'MAINT001', 2025, 6, '410000', NULL, '4942.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.892Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(111, 'MAINT001', 2025, 6, '420000', NULL, '4167.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.892Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(112, 'ADMIN001', 2025, 6, '400000', NULL, '16667.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.911Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(113, 'ADMIN001', 2025, 6, '410000', NULL, '5882.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.911Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(114, 'ADMIN001', 2025, 6, '420000', NULL, '3381.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.911Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(115, 'SALES001', 2025, 6, '400000', NULL, '11242.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.930Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(116, 'SALES001', 2025, 6, '410000', NULL, '4897.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.930Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(117, 'SALES001', 2025, 6, '420000', NULL, '4373.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.930Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(118, 'MKTG001', 2025, 6, '400000', NULL, '14653.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.949Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(119, 'MKTG001', 2025, 6, '410000', NULL, '5983.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.949Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(120, 'MKTG001', 2025, 6, '420000', NULL, '4271.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.949Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(121, 'HR001', 2025, 6, '400000', NULL, '16021.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.968Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(122, 'HR001', 2025, 6, '410000', NULL, '6506.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.968Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(123, 'HR001', 2025, 6, '420000', NULL, '4061.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.968Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(124, 'IT001', 2025, 6, '400000', NULL, '12825.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.988Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(125, 'IT001', 2025, 6, '410000', NULL, '4983.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.988Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(126, 'IT001', 2025, 6, '420000', NULL, '3086.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:46.988Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(127, 'WHSE001', 2025, 6, '400000', NULL, '12759.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.007Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(128, 'WHSE001', 2025, 6, '410000', NULL, '5878.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.007Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(129, 'WHSE001', 2025, 6, '420000', NULL, '3668.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.007Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(130, 'PURCH001', 2025, 6, '400000', NULL, '12884.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.027Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(131, 'PURCH001', 2025, 6, '410000', NULL, '6815.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.027Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(132, 'PURCH001', 2025, 6, '420000', NULL, '3939.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.027Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(133, 'FIN001', 2025, 6, '400000', NULL, '16354.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.046Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(134, 'FIN001', 2025, 6, '410000', NULL, '6939.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.046Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z'),
(135, 'FIN001', 2025, 6, '420000', NULL, '4041.00', '0.000', 'USD', NULL, '2025-06-01T00:00:00.000Z', NULL, NULL, '2025-06-04T03:47:47.046Z', NULL, NULL, NULL, true, '2025-06-04T18:39:28.246Z');

-- Table: cost_center_planning (63 records)
INSERT INTO "cost_center_planning" ("id", "cost_center", "fiscal_year", "period", "version", "account", "activity_type", "planned_amount", "planned_quantity", "currency", "unit_of_measure", "created_by", "created_at", "active", "updated_at") VALUES
(76, 'CC001', 2025, 6, '000', '400000', NULL, '17842.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.209Z', true, '2025-06-04T18:39:28.306Z'),
(77, 'CC001', 2025, 6, '000', '410000', NULL, '5563.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.209Z', true, '2025-06-04T18:39:28.306Z'),
(78, 'CC001', 2025, 6, '000', '420000', NULL, '4055.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.209Z', true, '2025-06-04T18:39:28.306Z'),
(79, 'CC002', 2025, 6, '000', '400000', NULL, '18925.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.230Z', true, '2025-06-04T18:39:28.306Z'),
(80, 'CC002', 2025, 6, '000', '410000', NULL, '5017.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.230Z', true, '2025-06-04T18:39:28.306Z'),
(81, 'CC002', 2025, 6, '000', '420000', NULL, '3302.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.230Z', true, '2025-06-04T18:39:28.306Z'),
(82, 'CC003', 2025, 6, '000', '400000', NULL, '18392.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.249Z', true, '2025-06-04T18:39:28.306Z'),
(83, 'CC003', 2025, 6, '000', '410000', NULL, '6902.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.249Z', true, '2025-06-04T18:39:28.306Z'),
(84, 'CC003', 2025, 6, '000', '420000', NULL, '3241.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.249Z', true, '2025-06-04T18:39:28.306Z'),
(85, 'CC101', 2025, 6, '000', '400000', NULL, '14712.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.268Z', true, '2025-06-04T18:39:28.306Z'),
(86, 'CC101', 2025, 6, '000', '410000', NULL, '5501.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.268Z', true, '2025-06-04T18:39:28.306Z'),
(87, 'CC101', 2025, 6, '000', '420000', NULL, '3737.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.268Z', true, '2025-06-04T18:39:28.306Z'),
(88, 'CC102', 2025, 6, '000', '400000', NULL, '13910.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.288Z', true, '2025-06-04T18:39:28.306Z'),
(89, 'CC102', 2025, 6, '000', '410000', NULL, '5501.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.288Z', true, '2025-06-04T18:39:28.306Z'),
(90, 'CC102', 2025, 6, '000', '420000', NULL, '3805.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.288Z', true, '2025-06-04T18:39:28.306Z'),
(91, 'CC103', 2025, 6, '000', '400000', NULL, '12115.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.307Z', true, '2025-06-04T18:39:28.306Z'),
(92, 'CC103', 2025, 6, '000', '410000', NULL, '5136.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.307Z', true, '2025-06-04T18:39:28.306Z'),
(93, 'CC103', 2025, 6, '000', '420000', NULL, '4658.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.307Z', true, '2025-06-04T18:39:28.306Z'),
(94, 'CC201', 2025, 6, '000', '400000', NULL, '15398.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.328Z', true, '2025-06-04T18:39:28.306Z'),
(95, 'CC201', 2025, 6, '000', '410000', NULL, '7382.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.328Z', true, '2025-06-04T18:39:28.306Z'),
(96, 'CC201', 2025, 6, '000', '420000', NULL, '4363.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.328Z', true, '2025-06-04T18:39:28.306Z'),
(97, 'CC202', 2025, 6, '000', '400000', NULL, '14957.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.351Z', true, '2025-06-04T18:39:28.306Z'),
(98, 'CC202', 2025, 6, '000', '410000', NULL, '5501.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.351Z', true, '2025-06-04T18:39:28.306Z'),
(99, 'CC202', 2025, 6, '000', '420000', NULL, '3547.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.351Z', true, '2025-06-04T18:39:28.306Z'),
(100, 'CC203', 2025, 6, '000', '400000', NULL, '18233.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.370Z', true, '2025-06-04T18:39:28.306Z'),
(101, 'CC203', 2025, 6, '000', '410000', NULL, '7605.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.370Z', true, '2025-06-04T18:39:28.306Z'),
(102, 'CC203', 2025, 6, '000', '420000', NULL, '4669.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.370Z', true, '2025-06-04T18:39:28.306Z'),
(103, 'PROD001', 2025, 6, '000', '400000', NULL, '13597.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.389Z', true, '2025-06-04T18:39:28.306Z'),
(104, 'PROD001', 2025, 6, '000', '410000', NULL, '5406.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.389Z', true, '2025-06-04T18:39:28.306Z'),
(105, 'PROD001', 2025, 6, '000', '420000', NULL, '4078.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.389Z', true, '2025-06-04T18:39:28.306Z'),
(106, 'PROD002', 2025, 6, '000', '400000', NULL, '15111.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.408Z', true, '2025-06-04T18:39:28.306Z'),
(107, 'PROD002', 2025, 6, '000', '410000', NULL, '6545.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.408Z', true, '2025-06-04T18:39:28.306Z'),
(108, 'PROD002', 2025, 6, '000', '420000', NULL, '4268.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.408Z', true, '2025-06-04T18:39:28.306Z'),
(109, 'QC001', 2025, 6, '000', '400000', NULL, '18547.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.427Z', true, '2025-06-04T18:39:28.306Z'),
(110, 'QC001', 2025, 6, '000', '410000', NULL, '7379.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.427Z', true, '2025-06-04T18:39:28.306Z'),
(111, 'QC001', 2025, 6, '000', '420000', NULL, '4779.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.427Z', true, '2025-06-04T18:39:28.306Z'),
(112, 'MAINT001', 2025, 6, '000', '400000', NULL, '14610.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.446Z', true, '2025-06-04T18:39:28.306Z'),
(113, 'MAINT001', 2025, 6, '000', '410000', NULL, '5918.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.446Z', true, '2025-06-04T18:39:28.306Z'),
(114, 'MAINT001', 2025, 6, '000', '420000', NULL, '4384.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.446Z', true, '2025-06-04T18:39:28.306Z'),
(115, 'ADMIN001', 2025, 6, '000', '400000', NULL, '14995.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.465Z', true, '2025-06-04T18:39:28.306Z'),
(116, 'ADMIN001', 2025, 6, '000', '410000', NULL, '5449.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.465Z', true, '2025-06-04T18:39:28.306Z'),
(117, 'ADMIN001', 2025, 6, '000', '420000', NULL, '3547.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.465Z', true, '2025-06-04T18:39:28.306Z'),
(118, 'SALES001', 2025, 6, '000', '400000', NULL, '15655.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.484Z', true, '2025-06-04T18:39:28.306Z'),
(119, 'SALES001', 2025, 6, '000', '410000', NULL, '5067.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.484Z', true, '2025-06-04T18:39:28.306Z'),
(120, 'SALES001', 2025, 6, '000', '420000', NULL, '3466.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.484Z', true, '2025-06-04T18:39:28.306Z'),
(121, 'MKTG001', 2025, 6, '000', '400000', NULL, '16753.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.503Z', true, '2025-06-04T18:39:28.306Z'),
(122, 'MKTG001', 2025, 6, '000', '410000', NULL, '5081.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.503Z', true, '2025-06-04T18:39:28.306Z'),
(123, 'MKTG001', 2025, 6, '000', '420000', NULL, '4975.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.503Z', true, '2025-06-04T18:39:28.306Z'),
(124, 'HR001', 2025, 6, '000', '400000', NULL, '17167.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.522Z', true, '2025-06-04T18:39:28.306Z'),
(125, 'HR001', 2025, 6, '000', '410000', NULL, '6228.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.522Z', true, '2025-06-04T18:39:28.306Z'),
(126, 'HR001', 2025, 6, '000', '420000', NULL, '3479.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.522Z', true, '2025-06-04T18:39:28.306Z'),
(127, 'IT001', 2025, 6, '000', '400000', NULL, '12315.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.542Z', true, '2025-06-04T18:39:28.306Z'),
(128, 'IT001', 2025, 6, '000', '410000', NULL, '6723.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.542Z', true, '2025-06-04T18:39:28.306Z'),
(129, 'IT001', 2025, 6, '000', '420000', NULL, '3600.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.542Z', true, '2025-06-04T18:39:28.306Z'),
(130, 'WHSE001', 2025, 6, '000', '400000', NULL, '17339.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.561Z', true, '2025-06-04T18:39:28.306Z'),
(131, 'WHSE001', 2025, 6, '000', '410000', NULL, '6535.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.561Z', true, '2025-06-04T18:39:28.306Z'),
(132, 'WHSE001', 2025, 6, '000', '420000', NULL, '4338.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.561Z', true, '2025-06-04T18:39:28.306Z'),
(133, 'PURCH001', 2025, 6, '000', '400000', NULL, '17253.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.580Z', true, '2025-06-04T18:39:28.306Z'),
(134, 'PURCH001', 2025, 6, '000', '410000', NULL, '6565.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.580Z', true, '2025-06-04T18:39:28.306Z'),
(135, 'PURCH001', 2025, 6, '000', '420000', NULL, '3441.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.580Z', true, '2025-06-04T18:39:28.306Z'),
(136, 'FIN001', 2025, 6, '000', '400000', NULL, '16024.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.600Z', true, '2025-06-04T18:39:28.306Z'),
(137, 'FIN001', 2025, 6, '000', '410000', NULL, '5831.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.600Z', true, '2025-06-04T18:39:28.306Z'),
(138, 'FIN001', 2025, 6, '000', '420000', NULL, '3808.00', '0.000', 'USD', NULL, NULL, '2025-06-04T03:47:46.600Z', true, '2025-06-04T18:39:28.306Z');

-- Table: cost_centers (21 records)
INSERT INTO "cost_centers" ("id", "cost_center", "description", "cost_center_category", "company_code", "controlling_area", "hierarchy_area", "responsible_person", "valid_from", "valid_to", "created_at", "updated_at", "company_code_id", "plant_id", "responsible_person_id", "active") VALUES
(1, 'CC001', 'Manufacturing Line 1', 'PRODUCTION', 'US01', 'US01', 'PRODUCTION', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(2, 'CC002', 'Manufacturing Line 2', 'PRODUCTION', 'US01', 'US01', 'PRODUCTION', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(3, 'CC003', 'Quality Control', 'PRODUCTION', 'US01', 'US01', 'PRODUCTION', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(4, 'CC101', 'Human Resources', 'ADMINISTRATIVE', 'US01', 'US01', 'ADMIN', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(5, 'CC102', 'IT Department', 'SERVICE', 'US01', 'US01', 'ADMIN', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(6, 'CC103', 'Finance Department', 'ADMINISTRATIVE', 'US01', 'US01', 'ADMIN', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(7, 'CC201', 'Sales North', 'SALES', 'US01', 'US01', 'SALES', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(8, 'CC202', 'Sales South', 'SALES', 'US01', 'US01', 'SALES', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(9, 'CC203', 'Sales International', 'SALES', 'US01', 'US01', 'SALES', NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true),
(11, 'PROD001', 'Production Line 1 - Manufacturing line for main products', 'PRODUCTION', 'US01', 'US01', NULL, 'John Smith', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(12, 'PROD002', 'Production Line 2 - Secondary manufacturing line', 'PRODUCTION', 'US01', 'US01', NULL, 'Jane Doe', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(13, 'QC001', 'Quality Control - Quality assurance and testing', 'QUALITY', 'US01', 'US01', NULL, 'Mike Johnson', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(14, 'MAINT001', 'Maintenance - Equipment maintenance and repairs', 'MAINTENANCE', 'US01', 'US01', NULL, 'Bob Wilson', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(15, 'ADMIN001', 'Administration - General administrative functions', 'ADMIN', 'US01', 'US01', NULL, 'Sarah Davis', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(16, 'SALES001', 'Sales Department - Sales and customer relations', 'SALES', 'US01', 'US01', NULL, 'Tom Brown', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(17, 'MKTG001', 'Marketing - Marketing and advertising', 'MARKETING', 'US01', 'US01', NULL, 'Lisa Garcia', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(18, 'HR001', 'Human Resources - HR administration and payroll', 'HR', 'US01', 'US01', NULL, 'David Miller', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(19, 'IT001', 'Information Technology - IT support and infrastructure', 'IT', 'US01', 'US01', NULL, 'Chris Lee', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(20, 'WHSE001', 'Warehouse Operations - Inventory and logistics', 'WAREHOUSE', 'US01', 'US01', NULL, 'Emily Chen', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(21, 'PURCH001', 'Purchasing Department - Procurement and vendor management', 'PURCHASING', 'US01', 'US01', NULL, 'Mark Wilson', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true),
(22, 'FIN001', 'Finance Department - Financial planning and accounting', 'FINANCE', 'US01', 'US01', NULL, 'Jennifer Brown', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:01.679Z', '2025-06-04T02:39:01.679Z', 1, NULL, NULL, true);

-- Table: countries (12 records)
INSERT INTO "countries" ("id", "code", "name", "region_id", "currency_code", "language_code", "is_active", "created_at", "updated_at", "active") VALUES
(1, 'MX', 'Mexico', 1, 'MXN', 'es-MX', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(2, 'CA', 'Canada', 1, 'CAD', 'en-CA', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(3, 'US', 'United States', 1, 'USD', 'en-US', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(4, 'AR', 'Argentina', 2, 'ARS', 'es-AR', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(5, 'BR', 'Brazil', 2, 'BRL', 'pt-BR', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(6, 'FR', 'France', 3, 'EUR', 'fr-FR', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(7, 'DE', 'Germany', 3, 'EUR', 'de-DE', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(8, 'GB', 'United Kingdom', 3, 'GBP', 'en-GB', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(9, 'AU', 'Australia', 4, 'AUD', 'en-AU', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(10, 'IN', 'India', 4, 'INR', 'en-IN', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(11, 'CN', 'China', 4, 'CNY', 'zh-CN', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(12, 'JP', 'Japan', 4, 'JPY', 'ja-JP', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true);

-- Table: credit_control_areas (5 records)
INSERT INTO "credit_control_areas" ("id", "code", "name", "description", "company_code_id", "credit_checking_group", "credit_period", "grace_percentage", "blocking_reason", "review_frequency", "currency", "credit_approver", "status", "is_active", "notes", "created_at", "updated_at", "created_by", "updated_by", "active") VALUES
(1, 'CC001', 'North America Credit', 'Credit control for North American customers', 2, 'medium_risk', 30, '15', NULL, 'monthly', 'USD', 'Michael Brown', 'active', true, NULL, '2025-05-17T14:59:22.779Z', '2025-05-17T14:59:22.779Z', NULL, NULL, true),
(2, 'CC002', 'EMEA Credit', 'Credit control for European, Middle Eastern, and African customers', 2, 'high_risk', 45, '10', NULL, 'monthly', 'EUR', 'Emma Schmidt', 'active', true, NULL, '2025-05-17T14:59:22.779Z', '2025-05-17T14:59:22.779Z', NULL, NULL, true),
(3, 'CC003', 'APAC Credit', 'Credit control for Asia-Pacific customers', 2, 'low_risk', 60, '5', NULL, 'monthly', 'USD', 'James Wong', 'active', true, NULL, '2025-05-17T14:59:22.779Z', '2025-05-17T14:59:22.779Z', NULL, NULL, true),
(4, 'CC004', 'Strategic Customers', 'Strategic Customers - Credit control for VIP customers', 1, 'VIP', 60, '15', NULL, 'monthly', 'USD', NULL, 'active', true, NULL, '2025-05-20T04:52:27.962Z', '2025-05-20T04:52:27.962Z', NULL, NULL, true),
(5, 'CC005', 'UK Credit Management', 'UK Credit Management - Credit control for standard customers', 11, 'standard', 30, '5', NULL, 'monthly', 'GBP', NULL, 'active', true, NULL, '2025-05-20T04:52:28.006Z', '2025-05-20T04:52:28.006Z', NULL, NULL, true);

-- Table: currencies (5 records)
INSERT INTO "currencies" ("id", "code", "name", "symbol", "decimal_places", "conversion_rate", "base_currency", "is_active", "created_at", "updated_at", "notes", "active") VALUES
(1, 'USD', 'US Dollar', '$', '2', '1.0', true, true, '2025-05-17T14:16:12.170Z', '2025-05-17T14:16:12.170Z', NULL, true),
(2, 'EUR', 'Euro', '€', '2', '1.08', false, true, '2025-05-17T14:16:12.170Z', '2025-05-17T14:16:12.170Z', NULL, true),
(3, 'GBP', 'British Pound', '£', '2', '1.27', false, true, '2025-05-17T14:16:12.170Z', '2025-05-17T14:16:12.170Z', NULL, true),
(4, 'JPY', 'Japanese Yen', '¥', '0', '0.0067', false, true, '2025-05-17T14:16:12.170Z', '2025-05-17T14:16:12.170Z', NULL, true),
(5, 'CNY', 'Chinese Yuan', '¥', '2', '0.138', false, true, '2025-05-17T14:16:12.170Z', '2025-05-17T14:16:12.170Z', NULL, true);

-- Table: custom_reports (5 records)
INSERT INTO "custom_reports" ("id", "name", "description", "sql_query", "chart_config", "parameters", "category", "is_shared", "created_by", "created_at", "updated_at", "active") VALUES
(1, 'Sales by Month', 'Monthly sales revenue analysis', 'SELECT DATE_TRUNC(''month'', order_date) as month, SUM(total_amount) as revenue FROM sales_orders WHERE order_date >= NOW() - INTERVAL ''12 months'' GROUP BY month ORDER BY month', [object Object], '[]', 'sales', false, 'system', '2025-06-04T15:23:51.126Z', '2025-06-04T15:23:51.126Z', true),
(2, 'Top Customers by Revenue', 'Customers with highest revenue contribution', 'SELECT c.name as customer_name, SUM(so.total_amount) as total_revenue FROM customers c JOIN sales_orders so ON c.id = so.customer_id GROUP BY c.id, c.name ORDER BY total_revenue DESC LIMIT 10', [object Object], '[]', 'sales', false, 'system', '2025-06-04T15:23:51.126Z', '2025-06-04T15:23:51.126Z', true),
(3, 'Inventory Levels by Category', 'Current inventory levels grouped by material category', 'SELECT cat.name as category, SUM(inv.quantity) as total_quantity FROM inventory inv JOIN materials m ON inv.material_id = m.id JOIN categories cat ON m.category_id = cat.id GROUP BY cat.id, cat.name ORDER BY total_quantity DESC', [object Object], '[]', 'inventory', false, 'system', '2025-06-04T15:23:51.126Z', '2025-06-04T15:23:51.126Z', true),
(4, 'Cost Center Expenses', 'Expenses by cost center for current year', 'SELECT cc.name as cost_center, SUM(e.amount) as total_expenses FROM cost_centers cc LEFT JOIN expenses e ON cc.id = e.cost_center_id WHERE EXTRACT(YEAR FROM e.expense_date) = EXTRACT(YEAR FROM NOW()) GROUP BY cc.id, cc.name ORDER BY total_expenses DESC', [object Object], '[]', 'finance', false, 'system', '2025-06-04T15:23:51.126Z', '2025-06-04T15:23:51.126Z', true),
(5, 'Purchase Orders by Vendor', 'Purchase order volumes by vendor', 'SELECT v.name as vendor_name, COUNT(po.id) as order_count, SUM(po.total_amount) as total_amount FROM vendors v JOIN purchase_orders po ON v.id = po.vendor_id GROUP BY v.id, v.name ORDER BY total_amount DESC LIMIT 15', [object Object], '[]', 'purchase', false, 'system', '2025-06-04T15:23:51.126Z', '2025-06-04T15:23:51.126Z', true);

-- Table: customer_contacts (12 records)
INSERT INTO "customer_contacts" ("id", "customer_id", "first_name", "last_name", "position", "department", "email", "phone", "mobile", "is_primary", "is_billing", "is_shipping", "is_technical", "is_marketing", "preferred_language", "notes", "is_active", "created_at", "updated_at", "created_by", "updated_by", "active") VALUES
(1, 1, 'Jessica', 'Brown', 'Operations Manager', 'Operations', 'jessica.brown@example.com', '(555) 456-7890', '(555) 654-3210', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:12.979Z', '2025-05-22T13:33:12.979Z', NULL, NULL, true),
(2, 1, 'John', 'Smith', 'Purchasing Manager', 'Procurement', 'john.smith@example.com', '(555) 123-4567', '(555) 987-6543', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.026Z', '2025-05-22T13:33:13.026Z', NULL, NULL, true),
(3, 1, 'Michael', 'Williams', 'CEO', 'Executive', 'michael.williams@example.com', '(555) 345-6789', '(555) 765-4321', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.069Z', '2025-05-22T13:33:13.069Z', NULL, NULL, true),
(4, 2, 'Jessica', 'Brown', 'Operations Manager', 'Operations', 'jessica.brown@example.com', '(555) 456-7890', '(555) 654-3210', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.123Z', '2025-05-22T13:33:13.123Z', NULL, NULL, true),
(5, 3, 'Michael', 'Williams', 'CEO', 'Executive', 'michael.williams@example.com', '(555) 345-6789', '(555) 765-4321', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.176Z', '2025-05-22T13:33:13.176Z', NULL, NULL, true),
(6, 3, 'Jessica', 'Brown', 'Operations Manager', 'Operations', 'jessica.brown@example.com', '(555) 456-7890', '(555) 654-3210', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.229Z', '2025-05-22T13:33:13.229Z', NULL, NULL, true),
(7, 3, 'John', 'Smith', 'Purchasing Manager', 'Procurement', 'john.smith@example.com', '(555) 123-4567', '(555) 987-6543', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.269Z', '2025-05-22T13:33:13.269Z', NULL, NULL, true),
(8, 4, 'Sarah', 'Johnson', 'Finance Director', 'Finance', 'sarah.johnson@example.com', '(555) 234-5678', '(555) 876-5432', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.306Z', '2025-05-22T13:33:13.306Z', NULL, NULL, true),
(9, 4, 'Sarah', 'Johnson', 'Finance Director', 'Finance', 'sarah.johnson@example.com', '(555) 234-5678', '(555) 876-5432', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.354Z', '2025-05-22T13:33:13.354Z', NULL, NULL, true),
(10, 5, 'Michael', 'Williams', 'CEO', 'Executive', 'michael.williams@example.com', '(555) 345-6789', '(555) 765-4321', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.393Z', '2025-05-22T13:33:13.393Z', NULL, NULL, true),
(11, 5, 'Michael', 'Williams', 'CEO', 'Executive', 'michael.williams@example.com', '(555) 345-6789', '(555) 765-4321', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.437Z', '2025-05-22T13:33:13.437Z', NULL, NULL, true),
(12, 5, 'Michael', 'Williams', 'CEO', 'Executive', 'michael.williams@example.com', '(555) 345-6789', '(555) 765-4321', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.473Z', '2025-05-22T13:33:13.473Z', NULL, NULL, true);

-- Table: customers (20 records)
INSERT INTO "customers" ("id", "name", "email", "phone", "address", "notes", "user_id", "created_at", "updated_at", "active", "code", "type") VALUES
(1, 'Acme Corporation', 'orders@acme.example.com', '+1-212-555-0123', '123 Main Street, New York, NY 10001', 'Key account - has special pricing agreement', NULL, '2025-05-20T18:17:22.106Z', '2025-05-20T18:17:22.106Z', true, NULL, 'Regular'),
(2, 'Global Enterprises', 'procurement@globalent.example.com', '+1-312-555-0456', '456 Park Avenue, Chicago, IL 60601', 'High volume customer', NULL, '2025-05-20T18:17:22.140Z', '2025-05-20T18:17:22.140Z', true, NULL, 'Regular'),
(3, 'European Distributors Ltd', 'orders@eurodist.example.com', '+44-20-7123-4567', '1 Oxford Street, London, W1D 1BS', 'European distribution partner', NULL, '2025-05-20T18:17:22.160Z', '2025-05-20T18:17:22.160Z', true, NULL, 'Regular'),
(4, 'Tech Solutions GmbH', 'einkauf@techsolutions.example.de', '+49-30-1234-5678', 'Hauptstraße 1, Berlin, 10115', 'German tech industry client', NULL, '2025-05-20T18:17:22.179Z', '2025-05-20T18:17:22.179Z', true, NULL, 'Regular'),
(5, 'Japan Manufacturing Co.', 'orders@japanmfg.example.jp', '+81-3-1234-5678', '1-1 Marunouchi, Tokyo, 100-0005', 'Japanese manufacturing partner', NULL, '2025-05-20T18:17:22.197Z', '2025-05-20T18:17:22.197Z', true, NULL, 'Regular'),
(8, 'Test Customer', 'test@customer.com', '123-456-7890', '123 Test Street, Test City, Test State', NULL, NULL, '2025-06-05T00:50:31.071Z', '2025-06-05T00:50:31.071Z', true, 'CUST1749084630761', 'Regular'),
(9, 'Test Customer', 'test@customer.com', '123-456-7890', '123 Test Street, Test City, Test State', NULL, NULL, '2025-06-05T00:51:00.443Z', '2025-06-05T00:51:00.443Z', true, 'CUST1749084660178', 'Regular'),
(10, 'Test Customer', 'test@customer.com', '123-456-7890', '123 Test Street, Test City, Test State', NULL, NULL, '2025-06-05T00:51:53.505Z', '2025-06-05T00:51:53.505Z', true, 'C5447', 'Regular'),
(11, 'Test Customer', 'test@example.com', '123-456-7890', 'Test Address', NULL, NULL, '2025-06-05T01:56:12.039Z', '2025-06-05T01:56:12.039Z', true, 'TC571891', 'Regular'),
(12, 'Test Customer', 'test@example.com', '123-456-7890', 'Test Address', NULL, NULL, '2025-06-05T01:58:36.790Z', '2025-06-05T01:58:36.790Z', true, 'TC716672', 'Regular'),
(13, 'Test Customer', 'test@example.com', '123-456-7890', 'Test Address', NULL, NULL, '2025-06-05T01:59:32.362Z', '2025-06-05T01:59:32.362Z', true, 'TC772239', 'Regular'),
(14, 'Test Customer', 'test@example.com', '123-456-7890', 'Test Address', NULL, NULL, '2025-06-05T01:59:53.058Z', '2025-06-05T01:59:53.058Z', true, 'TC792967', 'Regular'),
(15, 'Test Customer', 'test@example.com', '123-456-7890', 'Test Address', NULL, NULL, '2025-06-05T02:00:53.508Z', '2025-06-05T02:00:53.508Z', true, 'TC853374', 'Regular'),
(16, 'Test Customer 001', 'test@customer.com', '123-456-7890', '123 Test St', NULL, NULL, '2025-06-05T02:10:58.117Z', '2025-06-05T02:10:58.117Z', true, NULL, 'Regular'),
(17, 'Test Customer 001', 'test@customer.com', '123-456-7890', '123 Test St', NULL, NULL, '2025-06-05T02:11:57.903Z', '2025-06-05T02:11:57.903Z', true, NULL, 'Regular'),
(18, 'Test Customer 1749089635928', 'test1749089635928@customer.com', '123-456-7890', '123 Test St', NULL, NULL, '2025-06-05T02:13:57.717Z', '2025-06-05T02:13:57.717Z', true, NULL, 'Regular'),
(19, 'Test Customer 1749089708190', 'test1749089708190@customer.com', '123-456-7890', '123 Test St', NULL, NULL, '2025-06-05T02:15:08.406Z', '2025-06-05T02:15:08.406Z', true, NULL, 'Regular'),
(20, 'Test Customer 1749089731713', 'test1749089731713@customer.com', '123-456-7890', '123 Test St', NULL, NULL, '2025-06-05T02:15:31.876Z', '2025-06-05T02:15:31.876Z', true, NULL, 'Regular'),
(21, 'Test Customer 1749089769754', 'test1749089769754@customer.com', '123-456-7890', '123 Test St', NULL, NULL, '2025-06-05T02:16:09.380Z', '2025-06-05T02:16:09.380Z', true, NULL, 'Regular'),
(22, 'Test Customer 1749089793928', 'test1749089793928@customer.com', '123-456-7890', '123 Test St', NULL, NULL, '2025-06-05T02:16:34.268Z', '2025-06-05T02:16:34.268Z', true, NULL, 'Regular');

-- Table: dashboard_configs (29 records)
INSERT INTO "dashboard_configs" ("id", "user_id", "config", "created_at", "active", "updated_at") VALUES
(1, 1, [object Object], '2025-05-23T13:47:27.063Z', true, '2025-06-04T18:39:28.805Z'),
(2, 1, [object Object], '2025-05-23T13:47:51.571Z', true, '2025-06-04T18:39:28.805Z'),
(3, 1, [object Object], '2025-05-23T13:48:12.006Z', true, '2025-06-04T18:39:28.805Z'),
(4, 1, [object Object], '2025-05-23T13:52:34.618Z', true, '2025-06-04T18:39:28.805Z'),
(5, 1, [object Object], '2025-05-23T13:52:55.991Z', true, '2025-06-04T18:39:28.805Z'),
(6, 1, [object Object], '2025-05-23T13:53:36.644Z', true, '2025-06-04T18:39:28.805Z'),
(7, 1, [object Object], '2025-05-23T14:54:12.045Z', true, '2025-06-04T18:39:28.805Z'),
(8, 1, [object Object], '2025-05-23T14:54:27.164Z', true, '2025-06-04T18:39:28.805Z'),
(9, 1, [object Object], '2025-05-23T15:22:53.397Z', true, '2025-06-04T18:39:28.805Z'),
(10, 1, [object Object], '2025-05-23T15:22:58.232Z', true, '2025-06-04T18:39:28.805Z'),
(11, 1, [object Object], '2025-05-23T15:23:52.777Z', true, '2025-06-04T18:39:28.805Z'),
(12, 1, [object Object], '2025-05-23T15:24:12.051Z', true, '2025-06-04T18:39:28.805Z'),
(13, 1, [object Object], '2025-05-23T15:28:50.914Z', true, '2025-06-04T18:39:28.805Z'),
(14, 1, [object Object], '2025-05-23T15:34:35.768Z', true, '2025-06-04T18:39:28.805Z'),
(15, 1, [object Object], '2025-05-23T15:35:09.742Z', true, '2025-06-04T18:39:28.805Z'),
(16, 1, [object Object], '2025-05-23T15:37:10.877Z', true, '2025-06-04T18:39:28.805Z'),
(17, 1, [object Object], '2025-05-23T15:37:11.153Z', true, '2025-06-04T18:39:28.805Z'),
(18, 1, [object Object], '2025-05-23T15:37:12.008Z', true, '2025-06-04T18:39:28.805Z'),
(19, 1, [object Object], '2025-05-23T17:57:03.304Z', true, '2025-06-04T18:39:28.805Z'),
(20, 1, [object Object], '2025-05-23T17:57:12.171Z', true, '2025-06-04T18:39:28.805Z'),
(21, 1, [object Object], '2025-05-24T01:45:18.720Z', true, '2025-06-04T18:39:28.805Z'),
(22, 1, [object Object], '2025-05-24T01:45:43.473Z', true, '2025-06-04T18:39:28.805Z'),
(23, 1, [object Object], '2025-05-24T02:15:56.310Z', true, '2025-06-04T18:39:28.805Z'),
(24, 1, [object Object], '2025-05-26T13:07:16.942Z', true, '2025-06-04T18:39:28.805Z'),
(25, 1, [object Object], '2025-05-26T13:07:19.817Z', true, '2025-06-04T18:39:28.805Z'),
(26, 1, [object Object], '2025-05-26T13:07:33.498Z', true, '2025-06-04T18:39:28.805Z'),
(27, 1, [object Object], '2025-05-26T13:39:00.668Z', true, '2025-06-04T18:39:28.805Z'),
(28, 1, [object Object], '2025-05-26T13:39:27.580Z', true, '2025-06-04T18:39:28.805Z'),
(29, 1, [object Object], '2025-05-26T13:39:36.825Z', true, '2025-06-04T18:39:28.805Z');

-- Table: employee_master (0 records - empty)

-- Table: employees (10 records)
INSERT INTO "employees" ("id", "employee_id", "first_name", "last_name", "email", "phone", "department", "position", "company_code_id", "cost_center_id", "join_date", "manager_id", "is_active", "created_at", "updated_at", "active") VALUES
(1, 'E1001', 'John', 'Smith', 'john.smith@minierp.com', '212-555-1234', 'Executive', 'CEO', 1, NULL, '2018-01-15T00:00:00.000Z', NULL, true, '2025-05-20T22:10:30.210Z', '2025-05-20T22:10:30.210Z', true),
(2, 'E1002', 'Sarah', 'Johnson', 'sarah.johnson@minierp.com', '212-555-2345', 'Finance', 'CFO', 1, NULL, '2018-02-01T00:00:00.000Z', NULL, true, '2025-05-20T22:10:30.210Z', '2025-05-20T22:10:30.210Z', true),
(3, 'E1003', 'Michael', 'Williams', 'michael.williams@minierp.com', '212-555-3456', 'Operations', 'COO', 1, NULL, '2018-03-15T00:00:00.000Z', NULL, true, '2025-05-20T22:10:30.210Z', '2025-05-20T22:10:30.210Z', true),
(4, 'E1004', 'David', 'Brown', 'david.brown@minierp.com', '212-555-4567', 'Manufacturing', 'VP Manufacturing', 1, NULL, '2018-06-01T00:00:00.000Z', NULL, true, '2025-05-20T22:10:30.210Z', '2025-05-20T22:10:30.210Z', true),
(5, 'E1005', 'Jennifer', 'Davis', 'jennifer.davis@minierp.com', '212-555-5678', 'Sales', 'VP Sales', 1, NULL, '2018-07-15T00:00:00.000Z', NULL, true, '2025-05-20T22:10:30.210Z', '2025-05-20T22:10:30.210Z', true),
(8, 'US01-EMP2769', 'Emma', 'Johnson', 'emma.johnson1@example.com', '+1-555-987-8217', 'Sales', 'Sales Manager', 1, 3, '2019-07-22T00:00:00.000Z', NULL, true, '2025-05-21T14:58:58.925Z', '2025-05-21T14:58:58.925Z', true),
(9, 'EU01-EMP9748', 'Emma', 'Johnson', 'emma.johnson2@example.com', '+1-555-987-8928', 'Sales', 'Sales Manager', 2, NULL, '2019-07-22T00:00:00.000Z', NULL, true, '2025-05-21T14:58:58.925Z', '2025-05-21T14:58:58.925Z', true),
(10, 'TEST02-EMP9857', 'Emma', 'Johnson', 'emma.johnson4@example.com', '+1-555-987-1855', 'Sales', 'Sales Manager', 4, NULL, '2019-07-22T00:00:00.000Z', NULL, true, '2025-05-21T14:58:58.925Z', '2025-05-21T14:58:58.925Z', true),
(11, 'CA01-EMP8109', 'Emma', 'Johnson', 'emma.johnson5@example.com', '+1-555-987-5968', 'Sales', 'Sales Manager', 5, 13, '2019-07-22T00:00:00.000Z', NULL, true, '2025-05-21T14:58:58.925Z', '2025-05-21T14:58:58.925Z', true),
(12, 'GA01-EMP6705', 'Emma', 'Johnson', 'emma.johnson7@example.com', '+1-555-987-5673', 'Sales', 'Sales Manager', 7, 15, '2019-07-22T00:00:00.000Z', NULL, true, '2025-05-21T14:58:58.925Z', '2025-05-21T14:58:58.925Z', true);

-- Table: environment_config (0 records - empty)

-- Table: erp_customer_contacts (10 records)
INSERT INTO "erp_customer_contacts" ("id", "customer_id", "first_name", "last_name", "position", "department", "email", "phone", "mobile", "is_primary", "is_billing", "is_shipping", "is_technical", "is_marketing", "preferred_language", "notes", "is_active", "created_at", "updated_at", "created_by", "updated_by", "active") VALUES
(1, 1, 'James', 'Wilson', 'Purchasing Manager', 'Procurement', 'james.wilson@acmecorp.com', '+1-312-555-1235', NULL, true, false, false, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(2, 1, 'Sarah', 'Johnson', 'Accounts Payable Manager', 'Finance', 'sarah.johnson@acmecorp.com', '+1-312-555-1236', NULL, false, true, false, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(3, 1, 'Robert', 'Davis', 'Logistics Coordinator', 'Operations', 'robert.davis@acmecorp.com', '+1-312-555-1237', NULL, false, false, true, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(4, 2, 'Michael', 'Brown', 'Director of Merchandising', 'Purchasing', 'michael.brown@globalretail.com', '+1-212-555-2346', NULL, true, true, false, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(5, 2, 'Emily', 'Taylor', 'Supply Chain Manager', 'Operations', 'emily.taylor@globalretail.com', '+1-212-555-2347', NULL, false, false, true, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(6, 3, 'David', 'Martinez', 'Head of Procurement', 'Administration', 'david.martinez@cityhospital.org', '+1-617-555-3457', NULL, true, true, true, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(7, 4, 'Lisa', 'Anderson', 'Operations Director', 'Operations', 'lisa.anderson@techinnovate.com', '+1-415-555-4568', NULL, true, true, true, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(8, 6, 'Thomas', 'Washington', 'Procurement Officer', 'Acquisitions', 'thomas.washington@gov.agency.gov', '+1-202-555-6790', NULL, true, false, false, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(9, 6, 'Jennifer', 'Adams', 'Financial Officer', 'Finance', 'jennifer.adams@gov.agency.gov', '+1-202-555-6791', NULL, false, true, false, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true),
(10, 7, 'Klaus', 'Schmidt', 'International Sales Director', 'Sales', 'klaus.schmidt@eurodist.eu', '+49-30-555-7891', NULL, true, true, true, false, false, 'English', NULL, true, '2025-05-17T15:46:05.273Z', '2025-05-17T15:46:05.273Z', NULL, NULL, true);

-- Table: erp_customers (10 records)
INSERT INTO "erp_customers" ("id", "customer_code", "name", "type", "description", "tax_id", "industry", "segment", "address", "city", "state", "country", "postal_code", "region", "phone", "alt_phone", "email", "website", "currency", "payment_terms", "payment_method", "credit_limit", "credit_rating", "discount_group", "price_group", "incoterms", "shipping_method", "delivery_terms", "delivery_route", "sales_rep_id", "parent_customer_id", "status", "is_b2b", "is_b2c", "is_vip", "notes", "tags", "company_code_id", "is_active", "created_at", "updated_at", "created_by", "updated_by", "version", "active") VALUES
(1, 'C1001', 'Acme Corporation', 'corporate', 'Large manufacturing client', '123-45-6789', 'manufacturing', 'enterprise', '123 Main Street', 'Chicago', 'IL', 'US', '60601', NULL, '+1-312-555-1234', NULL, 'contact@acmecorp.com', NULL, 'USD', 'net_30', NULL, '50000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, true, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(2, 'C1002', 'Global Retailers', 'corporate', 'International retail chain', '987-65-4321', 'retail', 'key_account', '456 Market Ave', 'New York', 'NY', 'US', '10001', NULL, '+1-212-555-2345', NULL, 'orders@globalretail.com', NULL, 'USD', 'net_45', NULL, '100000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, true, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(3, 'C1003', 'City Hospital', 'corporate', 'Regional medical center', '456-78-9012', 'healthcare', 'mid_market', '789 Health Blvd', 'Boston', 'MA', 'US', '02110', NULL, '+1-617-555-3456', NULL, 'procurement@cityhospital.org', NULL, 'USD', 'net_60', NULL, '75000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, false, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(4, 'C1004', 'Tech Innovations', 'corporate', 'Technology startup', '789-01-2345', 'technology', 'small_business', '321 Tech Park', 'San Francisco', 'CA', 'US', '94105', NULL, '+1-415-555-4567', NULL, 'orders@techinnovate.com', NULL, 'USD', 'net_30', NULL, '25000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, false, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(5, 'C1005', 'John Smith', 'individual', 'Regular customer', NULL, NULL, 'consumer', '555 Residential St', 'Los Angeles', 'CA', 'US', '90001', NULL, '+1-213-555-5678', NULL, 'john.smith@email.com', NULL, 'USD', 'prepaid', NULL, '1000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, true, false, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(6, 'C1006', 'Government Agency', 'government', 'Federal procurement office', 'GOV-123456', 'government', 'enterprise', '1 Federal Plaza', 'Washington', 'DC', 'US', '20001', NULL, '+1-202-555-6789', NULL, 'procurement@gov.agency.gov', NULL, 'USD', 'net_60', NULL, '500000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, false, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(7, 'C1007', 'European Distributors', 'corporate', 'European distribution partner', 'EU-8765432', 'distribution', 'strategic', '10 International Blvd', 'Berlin', NULL, 'DE', '10115', NULL, '+49-30-555-7890', NULL, 'orders@eurodist.eu', NULL, 'EUR', 'net_45', NULL, '200000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, true, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(8, 'C1008', 'Education Foundation', 'non_profit', 'Educational institution', 'TAX-EXEMPT-123', 'education', 'mid_market', '200 Learning Way', 'Atlanta', 'GA', 'US', '30301', NULL, '+1-404-555-8901', NULL, 'purchases@edufoundation.org', NULL, 'USD', 'net_30', NULL, '30000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, false, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(9, 'C1009', 'Local Restaurant', 'corporate', 'Small business customer', 'BUS-987654', 'food_service', 'small_business', '75 Culinary Lane', 'Miami', 'FL', 'US', '33101', NULL, '+1-305-555-9012', NULL, 'orders@localrestaurant.com', NULL, 'USD', 'cod', NULL, '5000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, false, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true),
(10, 'C1010', 'Industrial Supplies', 'corporate', 'Industrial equipment supplier', 'IND-456789', 'industrial', 'mid_market', '800 Factory Road', 'Detroit', 'MI', 'US', '48201', NULL, '+1-313-555-0123', NULL, 'sales@industrialsupplies.com', NULL, 'USD', 'net_30', NULL, '150000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, false, false, NULL, NULL, 2, true, '2025-05-17T15:45:52.538Z', '2025-05-17T15:45:52.538Z', NULL, NULL, 1, true);

-- Table: erp_vendor_contacts (12 records)
INSERT INTO "erp_vendor_contacts" ("id", "vendor_id", "first_name", "last_name", "position", "department", "email", "phone", "mobile", "is_primary", "is_order_contact", "is_purchase_contact", "is_quality_contact", "is_accounts_contact", "preferred_language", "notes", "is_active", "created_at", "updated_at", "created_by", "updated_by", "active") VALUES
(1, 1, 'Richard', 'Steel', 'Sales Director', 'Sales', 'richard.steel@primesteelsupply.com', '+1-412-555-1112', NULL, true, true, false, false, false, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(2, 1, 'Patricia', 'Miller', 'Accounts Manager', 'Finance', 'patricia.miller@primesteelsupply.com', '+1-412-555-1113', NULL, false, false, false, false, true, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(3, 2, 'Edward', 'Johnson', 'VP of Sales', 'Sales', 'edward.johnson@qualityelectronics.com', '+1-408-555-2223', NULL, true, true, false, false, false, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(4, 2, 'Michelle', 'Lee', 'Customer Relations', 'Customer Service', 'michelle.lee@qualityelectronics.com', '+1-408-555-2224', NULL, false, false, false, false, true, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(5, 3, 'Carlos', 'Rodriguez', 'Operations Manager', 'Operations', 'carlos.rodriguez@globallogistics.com', '+1-562-555-3334', NULL, true, true, false, false, true, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(6, 4, 'Stephanie', 'Clark', 'Sales Representative', 'Sales', 'stephanie.clark@advancedmaterials.com', '+1-919-555-4445', NULL, true, true, false, false, false, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(7, 4, 'Mark', 'Williams', 'Technical Support', 'Engineering', 'mark.williams@advancedmaterials.com', '+1-919-555-4446', NULL, false, false, false, false, false, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(8, 5, 'Gregory', 'Phillips', 'Owner', 'Management', 'gregory.phillips@precisionengineering.com', '+1-513-555-5556', NULL, true, true, false, false, true, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(9, 8, 'Mei', 'Chen', 'Export Manager', 'International Sales', 'mei.chen@asianmanufacturing.com', '+86-755-5558889', NULL, true, true, false, false, false, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(10, 8, 'Jian', 'Zhang', 'Quality Control Manager', 'Quality', 'jian.zhang@asianmanufacturing.com', '+86-755-5558890', NULL, false, false, false, false, true, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(11, 12, 'Brian', 'Davis', 'Account Executive', 'Sales', 'brian.davis@softwaresolutions.com', '+1-206-555-2223', NULL, true, true, false, false, false, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true),
(12, 12, 'Amanda', 'Wilson', 'Support Manager', 'Technical Support', 'amanda.wilson@softwaresolutions.com', '+1-206-555-2224', NULL, false, false, false, false, true, 'English', NULL, true, '2025-05-17T15:46:49.348Z', '2025-05-17T15:46:49.348Z', NULL, NULL, true);

-- Table: erp_vendors (12 records)
INSERT INTO "erp_vendors" ("id", "vendor_code", "name", "type", "description", "tax_id", "industry", "address", "city", "state", "country", "postal_code", "region", "phone", "alt_phone", "email", "website", "currency", "payment_terms", "payment_method", "supplier_type", "category", "order_frequency", "minimum_order_value", "evaluation_score", "lead_time", "purchasing_group_id", "status", "blacklisted", "blacklist_reason", "notes", "tags", "company_code_id", "is_active", "created_at", "updated_at", "created_by", "updated_by", "version", "active") VALUES
(1, 'V1001', 'Prime Steel Supply', 'supplier', 'Steel and metal supplier', 'PS-12345', 'manufacturing', '100 Industrial Road', 'Pittsburgh', 'PA', 'US', '15222', NULL, '+1-412-555-1111', NULL, 'orders@primesteelsupply.com', NULL, 'USD', 'net_30', NULL, 'manufacturer', 'strategic', NULL, NULL, '92', 14, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(2, 'V1002', 'Quality Electronics', 'supplier', 'Electronic components supplier', 'QE-67890', 'electronics', '200 Tech Avenue', 'San Jose', 'CA', 'US', '95110', NULL, '+1-408-555-2222', NULL, 'sales@qualityelectronics.com', NULL, 'USD', 'net_45', NULL, 'distributor', 'preferred', NULL, NULL, '88', 21, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(3, 'V1003', 'Global Logistics', 'service_provider', 'International shipping and logistics', 'GL-34567', 'transportation', '300 Harbor Blvd', 'Long Beach', 'CA', 'US', '90802', NULL, '+1-562-555-3333', NULL, 'operations@globallogistics.com', NULL, 'USD', 'net_30', NULL, 'service', 'approved', NULL, NULL, '95', 7, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(4, 'V1004', 'Advanced Materials', 'supplier', 'Specialized manufacturing materials', 'AM-89012', 'chemicals', '400 Research Parkway', 'Raleigh', 'NC', 'US', '27601', NULL, '+1-919-555-4444', NULL, 'orders@advancedmaterials.com', NULL, 'USD', 'net_60', NULL, 'manufacturer', 'strategic', NULL, NULL, '90', 28, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(5, 'V1005', 'Precision Engineering', 'contractor', 'Custom tooling and machining services', 'PE-45678', 'manufacturing', '500 Precision Way', 'Cincinnati', 'OH', 'US', '45202', NULL, '+1-513-555-5555', NULL, 'info@precisionengineering.com', NULL, 'USD', 'net_30', NULL, 'service', 'preferred', NULL, NULL, '87', 35, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(6, 'V1006', 'Packaging Solutions', 'supplier', 'Industrial packaging materials', 'PS-90123', 'packaging', '600 Box Street', 'Memphis', 'TN', 'US', '38101', NULL, '+1-901-555-6666', NULL, 'sales@packagingsolutions.com', NULL, 'USD', 'net_30', NULL, 'manufacturer', 'approved', NULL, NULL, '83', 10, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(7, 'V1007', 'Machinery Maintenance', 'service_provider', 'Equipment maintenance and repair', 'MM-56789', 'services', '700 Service Road', 'Cleveland', 'OH', 'US', '44101', NULL, '+1-216-555-7777', NULL, 'service@machinerymaintenance.com', NULL, 'USD', 'net_15', NULL, 'service', 'approved', NULL, NULL, '79', 3, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(8, 'V1008', 'Asian Manufacturing', 'supplier', 'Overseas manufacturing partner', 'AM-901234', 'manufacturing', '800 Export Zone', 'Shenzhen', NULL, 'CN', '518000', NULL, '+86-755-5558888', NULL, 'exports@asianmanufacturing.com', NULL, 'USD', 'letter_of_credit', NULL, 'manufacturer', 'strategic', NULL, NULL, '85', 45, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(9, 'V1009', 'Office Supplies Co', 'supplier', 'General office and facility supplies', 'OSC-12345', 'retail', '900 Retail Row', 'Chicago', 'IL', 'US', '60602', NULL, '+1-312-555-9999', NULL, 'orders@officesupplies.com', NULL, 'USD', 'net_30', NULL, 'distributor', 'approved', NULL, NULL, '82', 5, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(10, 'V1010', 'Unreliable Vendor', 'supplier', 'Problematic supplier with quality issues', 'UV-99999', 'manufacturing', '1000 Problem Street', 'Phoenix', 'AZ', 'US', '85001', NULL, '+1-602-555-0000', NULL, 'orders@unreliablevendor.com', NULL, 'USD', 'advance', NULL, 'manufacturer', 'one_time', NULL, NULL, '30', 60, NULL, 'inactive', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(11, 'V1011', 'Blacklisted Supply', 'supplier', 'Blacklisted due to contract violations', 'BS-00000', 'manufacturing', '1100 Violation Road', 'Denver', 'CO', 'US', '80201', NULL, '+1-303-555-1111', NULL, 'info@blacklistedsupply.com', NULL, 'USD', 'cod', NULL, 'manufacturer', 'one_time', NULL, NULL, '10', 90, NULL, 'blocked', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true),
(12, 'V1012', 'Software Solutions', 'service_provider', 'Software and IT services provider', 'SS-12345', 'technology', '1200 Code Boulevard', 'Seattle', 'WA', 'US', '98101', NULL, '+1-206-555-2222', NULL, 'services@softwaresolutions.com', NULL, 'USD', 'net_30', NULL, 'service', 'strategic', NULL, NULL, '91', 14, NULL, 'active', false, NULL, NULL, NULL, 2, true, '2025-05-17T15:46:35.531Z', '2025-05-17T15:46:35.531Z', NULL, NULL, 1, true);

-- Table: expenses (15 records)
INSERT INTO "expenses" ("id", "date", "amount", "category", "description", "payment_method", "reference", "user_id", "created_at", "updated_at", "active") VALUES
(4, '2025-04-07T13:40:07.532Z', 4497.31, 'Professional Services', 'Consulting and professional fees', 'Credit Card', 'EXP-7870', 1, '2025-05-22T13:40:07.533Z', '2025-05-22T13:40:07.533Z', true),
(5, '2025-03-02T13:40:07.532Z', 4652.64, 'Software', 'Software licenses and subscriptions', 'Petty Cash', 'EXP-7268', 1, '2025-05-22T13:40:07.575Z', '2025-05-22T13:40:07.575Z', true),
(6, '2025-03-18T13:40:07.532Z', 1942.11, 'Training', 'Employee training and development', 'Credit Card', 'EXP-0984', 1, '2025-05-22T13:40:07.599Z', '2025-05-22T13:40:07.599Z', true),
(7, '2025-05-06T13:40:07.532Z', 2303.66, 'Marketing', 'Marketing campaign expenses', 'Credit Card', 'EXP-3024', 1, '2025-05-22T13:40:07.617Z', '2025-05-22T13:40:07.617Z', true),
(8, '2025-05-14T13:40:07.532Z', 4140.1, 'Utilities', 'Monthly utility bills', 'Petty Cash', 'EXP-7523', 1, '2025-05-22T13:40:07.635Z', '2025-05-22T13:40:07.635Z', true),
(9, '2025-05-14T13:40:07.532Z', 3782.49, 'Maintenance', 'Equipment and building maintenance', 'Cash', 'EXP-0422', 1, '2025-05-22T13:40:07.654Z', '2025-05-22T13:40:07.654Z', true),
(10, '2025-03-02T13:40:07.532Z', 3939.37, 'Hardware', 'Computer and office equipment', 'Corporate Card', 'EXP-1328', 1, '2025-05-22T13:40:07.680Z', '2025-05-22T13:40:07.680Z', true),
(11, '2025-02-27T13:40:07.532Z', 2907.45, 'Office Supplies', 'Office stationery and supplies', 'PayPal', 'EXP-6739', 1, '2025-05-22T13:40:07.710Z', '2025-05-22T13:40:07.710Z', true),
(12, '2025-04-11T13:40:07.532Z', 4389.24, 'Office Supplies', 'Office stationery and supplies', 'PayPal', 'EXP-4371', 1, '2025-05-22T13:40:07.731Z', '2025-05-22T13:40:07.731Z', true),
(13, '2025-04-21T13:40:07.532Z', 2628.29, 'Marketing', 'Marketing campaign expenses', 'Bank Transfer', 'EXP-1703', 1, '2025-05-22T13:40:07.750Z', '2025-05-22T13:40:07.750Z', true),
(14, '2025-05-16T13:40:07.532Z', 1210.63, 'Office Supplies', 'Office stationery and supplies', 'Corporate Card', 'EXP-5873', 1, '2025-05-22T13:40:07.768Z', '2025-05-22T13:40:07.768Z', true),
(15, '2025-03-15T13:40:07.532Z', 2723.74, 'Software', 'Software licenses and subscriptions', 'Check', 'EXP-6857', 1, '2025-05-22T13:40:07.788Z', '2025-05-22T13:40:07.788Z', true),
(16, '2025-03-26T13:40:07.532Z', 1338.37, 'Software', 'Software licenses and subscriptions', 'PayPal', 'EXP-4754', 1, '2025-05-22T13:40:07.808Z', '2025-05-22T13:40:07.808Z', true),
(17, '2025-05-07T13:40:07.532Z', 1939.2, 'Professional Services', 'Consulting and professional fees', 'Bank Transfer', 'EXP-5327', 1, '2025-05-22T13:40:07.826Z', '2025-05-22T13:40:07.826Z', true),
(18, '2025-03-22T13:40:07.532Z', 1458.69, 'Office Supplies', 'Office stationery and supplies', 'Cash', 'EXP-7187', 1, '2025-05-22T13:40:07.857Z', '2025-05-22T13:40:07.857Z', true);

-- Table: fiscal_periods (12 records)
INSERT INTO "fiscal_periods" ("id", "created_at", "updated_at", "version", "year", "period", "name", "start_date", "end_date", "status", "company_code_id", "active") VALUES
(1, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 1, '2025-01', '2025-01-01T00:00:00.000Z', '2025-01-31T00:00:00.000Z', 'CLOSED', 1, true),
(2, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 2, '2025-02', '2025-02-01T00:00:00.000Z', '2025-02-28T00:00:00.000Z', 'CLOSED', 1, true),
(3, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 3, '2025-03', '2025-03-01T00:00:00.000Z', '2025-03-31T00:00:00.000Z', 'CLOSED', 1, true),
(4, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 4, '2025-04', '2025-04-01T00:00:00.000Z', '2025-04-30T00:00:00.000Z', 'CLOSED', 1, true),
(5, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 5, '2025-05', '2025-05-01T00:00:00.000Z', '2025-05-31T00:00:00.000Z', 'CLOSED', 1, true),
(6, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 6, '2025-06', '2025-06-01T00:00:00.000Z', '2025-06-30T00:00:00.000Z', 'OPEN', 1, true),
(7, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 7, '2025-07', '2025-07-01T00:00:00.000Z', '2025-07-31T00:00:00.000Z', 'OPEN', 1, true),
(8, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 8, '2025-08', '2025-08-01T00:00:00.000Z', '2025-08-31T00:00:00.000Z', 'OPEN', 1, true),
(9, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 9, '2025-09', '2025-09-01T00:00:00.000Z', '2025-09-30T00:00:00.000Z', 'OPEN', 1, true),
(10, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 10, '2025-10', '2025-10-01T00:00:00.000Z', '2025-10-31T00:00:00.000Z', 'OPEN', 1, true),
(11, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 11, '2025-11', '2025-11-01T00:00:00.000Z', '2025-11-30T00:00:00.000Z', 'OPEN', 1, true),
(12, '2025-05-20T22:11:27.296Z', '2025-05-20T22:11:27.296Z', 1, 2025, 12, '2025-12', '2025-12-01T00:00:00.000Z', '2025-12-31T00:00:00.000Z', 'OPEN', 1, true);

-- Table: fiscal_year_variants (0 records - empty)

-- Table: general_ledger_accounts (0 records - empty)

-- Table: gl_accounts (35 records)
INSERT INTO "gl_accounts" ("id", "account_number", "account_name", "chart_of_accounts_id", "account_type", "account_group", "balance_sheet_account", "pl_account", "block_posting", "reconciliation_account", "is_active", "created_at", "updated_at", "active") VALUES
(1, '1000', 'Cash and Cash Equivalents', 39, 'ASSETS', 'CURRENT_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(2, '1100', 'Accounts Receivable', 39, 'ASSETS', 'CURRENT_ASSETS', true, false, false, true, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(3, '1110', 'Allowance for Doubtful Accounts', 39, 'ASSETS', 'CURRENT_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(4, '1200', 'Inventory - Raw Materials', 39, 'ASSETS', 'CURRENT_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(5, '1210', 'Inventory - Work in Process', 39, 'ASSETS', 'CURRENT_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(6, '1220', 'Inventory - Finished Goods', 39, 'ASSETS', 'CURRENT_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(7, '1300', 'Prepaid Expenses', 39, 'ASSETS', 'CURRENT_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(8, '1500', 'Property, Plant & Equipment', 39, 'ASSETS', 'FIXED_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(9, '1510', 'Accumulated Depreciation - PPE', 39, 'ASSETS', 'FIXED_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(10, '1600', 'Intangible Assets', 39, 'ASSETS', 'FIXED_ASSETS', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(11, '2000', 'Accounts Payable', 39, 'LIABILITIES', 'CURRENT_LIABILITIES', true, false, false, true, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(12, '2100', 'Accrued Expenses', 39, 'LIABILITIES', 'CURRENT_LIABILITIES', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(13, '2110', 'Accrued Payroll', 39, 'LIABILITIES', 'CURRENT_LIABILITIES', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(14, '2200', 'Short-term Debt', 39, 'LIABILITIES', 'CURRENT_LIABILITIES', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(15, '2300', 'Income Tax Payable', 39, 'LIABILITIES', 'CURRENT_LIABILITIES', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(16, '2500', 'Long-term Debt', 39, 'LIABILITIES', 'LONG_TERM_LIABILITIES', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(17, '3000', 'Common Stock', 39, 'EQUITY', 'STOCKHOLDERS_EQUITY', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(18, '3100', 'Retained Earnings', 39, 'EQUITY', 'STOCKHOLDERS_EQUITY', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(19, '3200', 'Additional Paid-in Capital', 39, 'EQUITY', 'STOCKHOLDERS_EQUITY', true, false, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(20, '4000', 'Sales Revenue - Products', 39, 'REVENUE', 'OPERATING_REVENUE', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(21, '4100', 'Service Revenue', 39, 'REVENUE', 'OPERATING_REVENUE', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(22, '4200', 'Other Operating Revenue', 39, 'REVENUE', 'OTHER_REVENUE', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(23, '5000', 'Cost of Goods Sold - Materials', 39, 'EXPENSES', 'COST_OF_SALES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(24, '5100', 'Cost of Goods Sold - Labor', 39, 'EXPENSES', 'COST_OF_SALES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(25, '5200', 'Cost of Goods Sold - Overhead', 39, 'EXPENSES', 'COST_OF_SALES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(26, '6000', 'Salaries and Wages', 39, 'EXPENSES', 'OPERATING_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(27, '6100', 'Rent Expense', 39, 'EXPENSES', 'OPERATING_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(28, '6200', 'Utilities Expense', 39, 'EXPENSES', 'OPERATING_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(29, '6300', 'Depreciation Expense', 39, 'EXPENSES', 'OPERATING_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(30, '6400', 'Insurance Expense', 39, 'EXPENSES', 'OPERATING_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(31, '6500', 'Marketing and Advertising', 39, 'EXPENSES', 'OPERATING_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(32, '6600', 'Research and Development', 39, 'EXPENSES', 'OPERATING_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(33, '7000', 'Interest Expense', 39, 'EXPENSES', 'NON_OPERATING_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(34, '7100', 'Interest Income', 39, 'REVENUE', 'NON_OPERATING_REVENUE', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true),
(35, '8000', 'Income Tax Expense', 39, 'EXPENSES', 'TAX_EXPENSES', false, true, false, false, true, '2025-06-04T02:38:20.681Z', '2025-06-04T02:38:20.681Z', true);

-- Table: internal_orders (0 records - empty)

-- Table: inventory_transactions (0 records - empty)

-- Table: invoices (10 records)
INSERT INTO "invoices" ("id", "invoice_number", "order_id", "issue_date", "due_date", "amount", "status", "paid_date", "user_id", "created_at", "updated_at", "active") VALUES
(1, 'INV-10000', 3, '2025-02-14T07:25:12.502Z', '2025-03-16T07:25:12.502Z', 7469.740000000001, 'PAID', '2025-03-05T07:25:12.502Z', 1, '2025-05-21T16:29:36.095Z', '2025-05-21T16:29:36.095Z', true),
(2, 'INV-10017', 20, '2025-05-01T21:09:29.634Z', '2025-05-31T21:09:29.634Z', 11439.71, 'PAID', '2025-05-09T21:09:29.634Z', 1, '2025-05-21T16:29:37.327Z', '2025-05-21T16:29:37.327Z', true),
(3, 'INV-10023', 26, '2024-12-29T18:43:15.488Z', '2025-01-28T18:43:15.488Z', 2289.85, 'PAID', '2025-01-14T18:43:15.488Z', 1, '2025-05-21T16:29:37.785Z', '2025-05-21T16:29:37.785Z', true),
(4, 'INV-10024', 27, '2025-04-02T03:12:19.304Z', '2025-05-02T03:12:19.304Z', 5399.91, 'ISSUED', NULL, 1, '2025-05-21T16:29:37.848Z', '2025-05-21T16:29:37.848Z', true),
(5, 'INV-10028', 31, '2025-01-24T22:23:11.444Z', '2025-02-23T22:23:11.444Z', 5069.94, 'ISSUED', NULL, 1, '2025-05-21T16:29:38.129Z', '2025-05-21T16:29:38.129Z', true),
(6, 'INV-10033', 36, '2025-04-02T18:15:28.827Z', '2025-05-02T18:15:28.827Z', 4029.66, 'PAID', '2025-04-25T18:15:28.827Z', 1, '2025-05-21T16:29:38.506Z', '2025-05-21T16:29:38.506Z', true),
(7, 'INV-10036', 39, '2024-12-18T11:36:51.500Z', '2025-01-17T11:36:51.500Z', 9339.75, 'PAID', '2025-01-07T11:36:51.500Z', 1, '2025-05-21T16:29:38.739Z', '2025-05-21T16:29:38.739Z', true),
(8, 'INV-10037', 40, '2024-12-16T07:21:42.349Z', '2025-01-15T07:21:42.349Z', 5749.83, 'ISSUED', NULL, 1, '2025-05-21T16:29:38.837Z', '2025-05-21T16:29:38.837Z', true),
(9, 'INV-10045', 48, '2025-04-19T12:23:00.681Z', '2025-05-19T12:23:00.681Z', 869.9300000000001, 'ISSUED', NULL, 1, '2025-05-21T16:29:39.511Z', '2025-05-21T16:29:39.511Z', true),
(10, 'INV-10046', 49, '2025-03-30T13:28:24.852Z', '2025-04-29T13:28:24.852Z', 1199.98, 'ISSUED', NULL, 1, '2025-05-21T16:29:39.574Z', '2025-05-21T16:29:39.574Z', true);

-- Table: issue_analytics_summary (1 records)
INSERT INTO "issue_analytics_summary" ("id", "analysis_date", "total_issues", "critical_issues", "high_issues", "medium_issues", "low_issues", "ai_resolved", "auto_resolved", "manual_resolved", "unresolved", "avg_resolution_time", "median_resolution_time", "fastest_resolution", "slowest_resolution", "master_data_issues", "transaction_issues", "system_issues", "api_issues", "database_issues", "validation_issues", "created_at") VALUES
('1', '2025-06-04T00:00:00.000Z', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2025-06-04T23:48:09.610Z');

-- Table: issue_patterns (5 records)
INSERT INTO "issue_patterns" ("id", "pattern_name", "pattern_regex", "category", "match_count", "success_rate", "avg_resolution_time", "auto_resolvable", "resolution_template", "confidence_threshold", "created_at", "updated_at") VALUES
('1', 'Database Constraint Violation', 'violates.*constraint|unique.*constraint|foreign key', 'DATABASE', 0, '0.00', 0, true, [object Object], '0.90', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z'),
('2', 'Data Validation Error', 'validation.*failed|invalid.*format|required.*field', 'VALIDATION', 0, '0.00', 0, true, [object Object], '0.85', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z'),
('3', 'Master Data Reference Missing', 'does not exist|not found.*reference|missing.*master', 'MASTER_DATA', 0, '0.00', 0, true, [object Object], '0.88', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z'),
('4', 'API Connection Error', 'connection.*refused|timeout|network.*error|service.*unavailable', 'API', 0, '0.00', 0, false, [object Object], '0.70', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z'),
('5', 'Authorization Error', 'unauthorized|forbidden|access.*denied|permission.*denied', 'SYSTEM', 0, '0.00', 0, false, [object Object], '0.75', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z');

-- Table: issue_resolutions (0 records - empty)

-- Table: journal_entries (5 records)
INSERT INTO "journal_entries" ("id", "document_number", "company_code_id", "document_type", "posting_date", "document_date", "fiscal_period", "fiscal_year", "currency_id", "exchange_rate", "reference_document", "header_text", "total_debit_amount", "total_credit_amount", "created_by", "posted_by", "posting_time", "status", "created_at", "entry_date", "active", "updated_at") VALUES
(1, 'JE-2025-001', NULL, 'SA', '2025-06-01T00:00:00.000Z', '2025-06-01T00:00:00.000Z', '06', 2025, NULL, '1.0000', NULL, 'Monthly depreciation expense', '5000.00', '5000.00', NULL, NULL, NULL, 'Posted', '2025-06-04T01:15:51.540Z', NULL, true, '2025-06-04T18:39:29.727Z'),
(2, 'JE-2025-002', NULL, 'SA', '2025-06-02T00:00:00.000Z', '2025-06-02T00:00:00.000Z', '06', 2025, NULL, '1.0000', NULL, 'Accrued salaries payable', '15000.00', '15000.00', NULL, NULL, NULL, 'Posted', '2025-06-04T01:15:51.540Z', NULL, true, '2025-06-04T18:39:29.727Z'),
(3, 'JE-2025-003', NULL, 'SA', '2025-06-03T00:00:00.000Z', '2025-06-03T00:00:00.000Z', '06', 2025, NULL, '1.0000', NULL, 'Purchase of office supplies', '2500.00', '2500.00', NULL, NULL, NULL, 'Posted', '2025-06-04T01:15:51.540Z', NULL, true, '2025-06-04T18:39:29.727Z'),
(4, 'JE-2025-004', NULL, 'SA', '2025-06-04T00:00:00.000Z', '2025-06-04T00:00:00.000Z', '06', 2025, NULL, '1.0000', NULL, 'Bank loan interest expense', '1200.00', '1200.00', NULL, NULL, NULL, 'Draft', '2025-06-04T01:15:51.540Z', NULL, true, '2025-06-04T18:39:29.727Z'),
(5, 'JE-2025-005', NULL, 'SA', '2025-06-05T00:00:00.000Z', '2025-06-05T00:00:00.000Z', '06', 2025, NULL, '1.0000', NULL, 'Inventory adjustment', '3200.00', '3200.00', NULL, NULL, NULL, 'Posted', '2025-06-04T01:15:51.540Z', NULL, true, '2025-06-04T18:39:29.727Z');

-- Table: leads (24 records)
INSERT INTO "leads" ("id", "first_name", "last_name", "company_name", "job_title", "email", "phone", "status", "source", "industry", "annual_revenue", "employee_count", "website", "address", "city", "state", "country", "postal_code", "description", "last_contacted", "next_followup", "assigned_to", "lead_score", "is_converted", "notes", "created_at", "updated_at", "active") VALUES
(1, 'John', 'Smith', 'Tech Innovations', 'CTO', 'john.smith@techinnovations.com', '(555) 123-4567', 'New', 'Website', 'Technology', '5000000.00', 50, 'www.techinnovations.com', NULL, NULL, NULL, NULL, NULL, 'Interested in ERP solutions for tech startups', NULL, NULL, NULL, NULL, false, NULL, '2025-05-21T23:38:46.934Z', '2025-05-21T23:38:46.934Z', true),
(2, 'Emma', 'Johnson', 'Healthcare Solutions', 'Director of Operations', 'emma.johnson@healthcaresolutions.com', '(555) 234-5678', 'New', 'Trade Show', 'Healthcare', '12000000.00', 120, 'www.healthcaresolutions.com', NULL, NULL, NULL, NULL, NULL, 'Looking for inventory management solutions', NULL, NULL, NULL, NULL, false, NULL, '2025-05-21T23:38:46.957Z', '2025-05-21T23:38:46.957Z', true),
(3, 'Michael', 'Davis', 'Davis Manufacturing', 'CEO', 'michael.davis@davismanufacturing.com', '(555) 345-6789', 'New', 'Referral', 'Manufacturing', '8500000.00', 75, 'www.davismanufacturing.com', NULL, NULL, NULL, NULL, NULL, 'Needs a complete ERP system', NULL, NULL, NULL, NULL, false, NULL, '2025-05-21T23:38:46.975Z', '2025-05-21T23:38:46.975Z', true),
(4, 'Sarah', 'Wilson', 'Wilson Retail Group', 'Procurement Manager', 'sarah.wilson@wilsonretail.com', '(555) 456-7890', 'New', 'Email Campaign', 'Retail', '20000000.00', 200, 'www.wilsonretail.com', NULL, NULL, NULL, NULL, NULL, 'Interested in inventory and POS integration', NULL, NULL, NULL, NULL, false, NULL, '2025-05-21T23:38:46.993Z', '2025-05-21T23:38:46.993Z', true),
(5, 'Robert', 'Brown', 'Brown Financial', 'CFO', 'robert.brown@brownfinancial.com', '(555) 567-8901', 'New', 'Webinar', 'Financial Services', '15000000.00', 65, 'www.brownfinancial.com', NULL, NULL, NULL, NULL, NULL, 'Looking for financial management modules', NULL, NULL, NULL, NULL, false, NULL, '2025-05-21T23:38:47.012Z', '2025-05-21T23:38:47.012Z', true),
(6, 'Jennifer', 'Lee', 'Lee Education Services', 'Director', 'jennifer.lee@leeeducation.com', '(555) 678-9012', 'Contacted', 'Website', 'Education', '3000000.00', 30, 'www.leeeducation.com', NULL, NULL, NULL, NULL, NULL, 'Initial call completed, requested demo', '2025-05-18T23:38:46.923Z', '2025-05-28T23:38:46.924Z', NULL, NULL, false, NULL, '2025-05-21T23:38:47.034Z', '2025-05-21T23:38:47.034Z', true),
(7, 'David', 'Miller', 'Miller Tech Solutions', 'COO', 'david.miller@millertech.com', '(555) 789-0123', 'Contacted', 'Social Media', 'Technology', '7500000.00', 45, 'www.millertech.com', NULL, NULL, NULL, NULL, NULL, 'Spoke about inventory needs, follow up with pricing', '2025-05-16T23:38:46.924Z', '2025-05-26T23:38:46.924Z', NULL, NULL, false, NULL, '2025-05-21T23:38:47.051Z', '2025-05-21T23:38:47.051Z', true),
(8, 'Patricia', 'Garcia', 'Garcia Manufacturing', 'Operations Manager', 'patricia.garcia@garciamanufacturing.com', '(555) 890-1234', 'Contacted', 'Trade Show', 'Manufacturing', '10000000.00', 90, 'www.garciamanufacturing.com', NULL, NULL, NULL, NULL, NULL, 'Initial discussion about production modules', '2025-05-19T23:38:46.924Z', '2025-05-31T23:38:46.924Z', NULL, NULL, false, NULL, '2025-05-21T23:38:47.068Z', '2025-05-21T23:38:47.068Z', true),
(9, 'James', 'Taylor', 'Taylor Consulting', 'Managing Partner', 'james.taylor@taylorconsulting.com', '(555) 901-2345', 'Contacted', 'Referral', 'Professional Services', '2500000.00', 15, 'www.taylorconsulting.com', NULL, NULL, NULL, NULL, NULL, 'Had intro call, wants demo next week', '2025-05-20T23:38:46.924Z', '2025-05-27T23:38:46.924Z', NULL, NULL, false, NULL, '2025-05-21T23:38:47.086Z', '2025-05-21T23:38:47.086Z', true),
(10, 'Elizabeth', 'Moore', 'Moore Health Systems', 'CIO', 'elizabeth.moore@moorehealth.com', '(555) 012-3456', 'Qualified', 'Webinar', 'Healthcare', '18000000.00', 150, 'www.moorehealth.com', NULL, NULL, NULL, NULL, NULL, 'Completed needs assessment, high potential', '2025-05-13T23:38:46.924Z', '2025-05-24T23:38:46.924Z', NULL, 85, false, NULL, '2025-05-21T23:38:47.104Z', '2025-05-21T23:38:47.104Z', true),
(11, 'William', 'White', 'White Industries', 'VP of Operations', 'william.white@whiteindustries.com', '(555) 123-4567', 'Qualified', 'Partner', 'Manufacturing', '25000000.00', 200, 'www.whiteindustries.com', NULL, NULL, NULL, NULL, NULL, 'Ready for detailed proposal, budget approved', '2025-05-17T23:38:46.924Z', '2025-05-23T23:38:46.924Z', NULL, 90, false, NULL, '2025-05-21T23:38:47.121Z', '2025-05-21T23:38:47.121Z', true),
(12, 'Barbara', 'Jones', 'Jones Retail', 'CEO', 'barbara.jones@jonesretail.com', '(555) 234-5678', 'Qualified', 'Website', 'Retail', '12000000.00', 120, 'www.jonesretail.com', NULL, NULL, NULL, NULL, NULL, 'Completed requirements gathering, good fit', '2025-05-15T23:38:46.924Z', '2025-05-25T23:38:46.924Z', NULL, 80, false, NULL, '2025-05-21T23:38:47.139Z', '2025-05-21T23:38:47.139Z', true),
(13, 'Richard', 'Clark', 'Clark Financial', 'Director of IT', 'richard.clark@clarkfinancial.com', '(555) 345-6789', 'Qualified', 'Email Campaign', 'Financial Services', '30000000.00', 80, 'www.clarkfinancial.com', NULL, NULL, NULL, NULL, NULL, 'Has specific requirements, ready for formal quote', '2025-05-11T23:38:46.924Z', '2025-05-22T23:38:46.924Z', NULL, 95, false, NULL, '2025-05-21T23:38:47.158Z', '2025-05-21T23:38:47.158Z', true),
(14, 'Susan', 'Anderson', 'Anderson Academy', 'President', 'susan.anderson@andersonacademy.edu', '(555) 456-7890', 'Nurturing', 'Trade Show', 'Education', '5000000.00', 75, 'www.andersonacademy.edu', NULL, NULL, NULL, NULL, NULL, 'Interested but no budget until next quarter', '2025-05-06T23:38:46.924Z', '2025-06-20T23:38:46.924Z', NULL, 60, false, NULL, '2025-05-21T23:38:47.178Z', '2025-05-21T23:38:47.178Z', true),
(15, 'Thomas', 'Martinez', 'Martinez Technologies', 'CTO', 'thomas.martinez@martineztech.com', '(555) 567-8901', 'Nurturing', 'Webinar', 'Technology', '8000000.00', 40, 'www.martineztech.com', NULL, NULL, NULL, NULL, NULL, 'Needs more education about solution benefits', '2025-05-01T23:38:46.924Z', '2025-06-05T23:38:46.924Z', NULL, 45, false, NULL, '2025-05-21T23:38:47.195Z', '2025-05-21T23:38:47.195Z', true),
(16, 'Mary', 'Robinson', 'Robinson Healthcare', 'Procurement Director', 'mary.robinson@robinsonhealth.com', '(555) 678-9012', 'Nurturing', 'Social Media', 'Healthcare', '15000000.00', 130, 'www.robinsonhealth.com', NULL, NULL, NULL, NULL, NULL, 'Still researching options, send case studies', '2025-05-09T23:38:46.924Z', '2025-06-10T23:38:46.924Z', NULL, 55, false, NULL, '2025-05-21T23:38:47.215Z', '2025-05-21T23:38:47.215Z', true),
(17, 'Charles', 'Lewis', 'Lewis Manufacturing', 'Operations Director', 'charles.lewis@lewismanufacturing.com', '(555) 789-0123', 'Nurturing', 'Email Campaign', 'Manufacturing', '20000000.00', 180, 'www.lewismanufacturing.com', NULL, NULL, NULL, NULL, NULL, 'Implementing another system now, revisit later', '2025-04-26T23:38:46.924Z', '2025-07-20T23:38:46.924Z', NULL, 40, false, NULL, '2025-05-21T23:38:47.233Z', '2025-05-21T23:38:47.233Z', true),
(18, 'Lisa', 'Walker', 'Walker Group', 'CFO', 'lisa.walker@walkergroup.com', '(555) 890-1234', 'Disqualified', 'Website', 'Professional Services', '1000000.00', 8, 'www.walkergroup.com', NULL, NULL, NULL, NULL, NULL, 'Too small for our solution, not a good fit', '2025-04-21T23:38:46.924Z', NULL, NULL, 10, false, NULL, '2025-05-21T23:38:47.251Z', '2025-05-21T23:38:47.251Z', true),
(19, 'Daniel', 'Hall', 'Hall Tech', 'CEO', 'daniel.hall@halltech.com', '(555) 901-2345', 'Disqualified', 'Cold Call', 'Technology', '500000.00', 5, 'www.halltech.com', NULL, NULL, NULL, NULL, NULL, 'No budget, using free alternatives', '2025-04-06T23:38:46.924Z', NULL, NULL, 5, false, NULL, '2025-05-21T23:38:47.268Z', '2025-05-21T23:38:47.268Z', true),
(20, 'Nancy', 'Allen', 'Allen Consulting', 'Principal', 'nancy.allen@allenconsulting.com', '(555) 012-3456', 'Disqualified', 'Partner', 'Professional Services', '750000.00', 4, 'www.allenconsulting.com', NULL, NULL, NULL, NULL, NULL, 'Outside our target market segment', '2025-03-22T23:38:46.924Z', NULL, NULL, 15, false, NULL, '2025-05-21T23:38:47.286Z', '2025-05-21T23:38:47.286Z', true),
(21, 'Paul', 'Young', 'Young Enterprises', 'Owner', 'paul.young@youngenterprises.com', '(555) 123-4567', 'Disqualified', 'Trade Show', 'Retail', '300000.00', 3, 'www.youngenterprises.com', NULL, NULL, NULL, NULL, NULL, 'Selected competitor solution', '2025-05-06T23:38:46.924Z', NULL, NULL, 20, false, NULL, '2025-05-21T23:38:47.303Z', '2025-05-21T23:38:47.303Z', true),
(22, 'Sam', 'Josh', 'samJ', NULL, 'samj@gmail.com', '', 'Contacted', 'Website', 'Technology', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, '2025-05-22T19:00:33.604Z', '2025-05-22T19:00:33.604Z', true),
(23, 'aF', '', 'TES', NULL, 'sapbdc1@mail.com', '22', 'Qualified', 'Website', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, '2025-05-23T01:53:09.735Z', '2025-05-23T01:53:09.735Z', true),
(24, 'Rita', '', 'May23', NULL, 'Rita12@mail.com', '', 'New', 'Website', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, '2025-05-23T04:51:05.225Z', '2025-05-23T04:51:05.225Z', true);

-- Table: material_categories (11 records)
INSERT INTO "material_categories" ("id", "code", "name", "description", "parent_id", "created_at", "updated_at", "active") VALUES
(1, 'RM', 'Raw Materials', 'Base materials used in production', NULL, '2025-05-21T15:12:13.362Z', '2025-05-21T15:12:13.362Z', true),
(2, 'FG', 'Finished Goods', 'Products ready for sale', NULL, '2025-05-21T15:12:13.362Z', '2025-05-21T15:12:13.362Z', true),
(3, 'SFG', 'Semi-finished', 'Intermediate products', NULL, '2025-05-21T15:12:13.362Z', '2025-05-21T15:12:13.362Z', true),
(4, 'SPRT', 'Spare Parts', 'Components for maintenance and repair', NULL, '2025-05-21T15:12:13.362Z', '2025-05-21T15:12:13.362Z', true),
(5, 'PKG', 'Packaging', 'Materials used for packaging products', NULL, '2025-05-21T15:12:13.362Z', '2025-05-21T15:12:13.362Z', true),
(6, 'CONS', 'Consumables', 'Materials consumed during production', NULL, '2025-05-21T15:12:13.362Z', '2025-05-21T15:12:13.362Z', true),
(7, 'RM-MET', 'Metals', 'Metal raw materials', 1, '2025-05-21T15:12:24.470Z', '2025-05-21T15:12:24.470Z', true),
(8, 'RM-PLST', 'Plastics', 'Plastic raw materials', 1, '2025-05-21T15:12:24.470Z', '2025-05-21T15:12:24.470Z', true),
(9, 'FG-ELEC', 'Electronics', 'Electronic finished products', 2, '2025-05-21T15:12:24.470Z', '2025-05-21T15:12:24.470Z', true),
(10, 'FG-TOOL', 'Tools', 'Hand and power tools', 2, '2025-05-21T15:12:24.470Z', '2025-05-21T15:12:24.470Z', true),
(11, 'PKG-BOX', 'Boxes', 'Cardboard and corrugated boxes', 5, '2025-05-21T15:12:24.470Z', '2025-05-21T15:12:24.470Z', true);

-- Table: materials (29 records)
INSERT INTO "materials" ("id", "code", "name", "description", "long_description", "type", "uom_id", "category_id", "weight", "weight_uom_id", "dimensions", "base_unit_price", "cost", "min_order_qty", "order_multiple", "procurement_type", "min_stock", "max_stock", "reorder_point", "lead_time", "shelf_life", "lot_size", "mrp_type", "planning_policy", "is_active", "is_sellable", "is_purchasable", "is_manufactured", "is_stockable", "created_at", "updated_at", "created_by", "updated_by", "version", "active", "base_uom", "status") VALUES
(1, 'RM-1001', 'Aluminum Sheet', 'High-grade aluminum sheet for industrial use', NULL, 'RAW', 1, 1, '1', 1, [object Object], '7.5', '5.25', '10', '5', 'external', '20', '100', '30', 7, 0, 'EX', 'reorder_point', 'standard', true, true, true, false, true, '2025-05-20T14:36:38.689Z', '2025-05-20T14:36:38.689Z', NULL, NULL, 1, true, 'PC', 'active'),
(2, 'RM-1002', 'Steel Rod', 'Carbon steel rod for structural applications', NULL, 'RAW', 1, 1, '2.5', 1, [object Object], '8.75', '6.5', '10', '5', 'external', '15', '80', '20', 5, 0, 'EX', 'reorder_point', 'standard', true, true, true, false, true, '2025-05-20T14:36:38.705Z', '2025-05-20T14:36:38.705Z', NULL, NULL, 1, true, 'PC', 'active'),
(3, 'RM-1003', 'Plastic Granulate', 'ABS plastic granulate for injection molding', NULL, 'RAW', 1, 1, '1', 1, [object Object], '3.25', '2.1', '25', '25', 'external', '50', '300', '75', 10, 730, 'EX', 'reorder_point', 'lot_for_lot', true, false, true, false, true, '2025-05-20T14:36:38.720Z', '2025-05-20T14:36:38.720Z', NULL, NULL, 1, true, 'PC', 'active'),
(4, 'RM-1004', 'Copper Wire', 'Industrial grade copper wire', NULL, 'RAW', 4, 1, '0.05', 1, [object Object], '6.5', '4.2', '100', '50', 'external', '200', '1000', '300', 15, 0, 'EX', 'reorder_point', 'standard', true, false, true, false, true, '2025-05-20T14:36:38.735Z', '2025-05-20T14:36:38.735Z', NULL, NULL, 1, true, 'PC', 'active'),
(5, 'RM-1005', 'Cotton Fabric', 'Premium cotton fabric for textile manufacturing', NULL, 'RAW', 5, 1, '0.2', 1, [object Object], '4.25', '3', '50', '10', 'external', '100', '500', '150', 12, 365, 'EX', 'reorder_point', 'standard', true, false, true, false, true, '2025-05-20T14:36:38.750Z', '2025-05-20T14:36:38.750Z', NULL, NULL, 1, true, 'PC', 'active'),
(6, 'SF-2001', 'Aluminum Frame', 'Partially assembled aluminum frame', NULL, 'SEMI', 10, 1, '3.2', 1, [object Object], '35', '22.5', '5', '5', 'in-house', '10', '50', '15', 3, 0, 'EX', 'make_to_stock', 'lot_for_lot', true, false, false, true, true, '2025-05-20T14:36:38.765Z', '2025-05-20T14:36:38.765Z', NULL, NULL, 1, true, 'PC', 'active'),
(7, 'SF-2002', 'PCB Assembly', 'Partially assembled printed circuit board', NULL, 'SEMI', 10, 1, '0.15', 1, [object Object], '28.5', '18', '10', '5', 'in-house', '20', '100', '30', 5, 365, 'EX', 'make_to_stock', 'lot_for_lot', true, false, false, true, true, '2025-05-20T14:36:38.779Z', '2025-05-20T14:36:38.779Z', NULL, NULL, 1, true, 'PC', 'active'),
(8, 'SF-2003', 'Injection Molded Housing', 'Plastic housing for electronic devices', NULL, 'SEMI', 10, 1, '0.45', 1, [object Object], '12.75', '8.5', '25', '25', 'in-house', '50', '250', '75', 2, 0, 'EX', 'make_to_stock', 'lot_for_lot', true, false, false, true, true, '2025-05-20T14:36:38.794Z', '2025-05-20T14:36:38.794Z', NULL, NULL, 1, true, 'PC', 'active'),
(9, 'FG-3001', 'Smart Thermostat', 'IoT-enabled smart thermostat for home automation', NULL, 'FINI', 10, 1, '0.85', 1, [object Object], '85', '45', '1', '1', 'in-house', '10', '50', '15', 7, 730, 'EX', 'make_to_stock', 'lot_for_lot', true, true, false, true, true, '2025-05-20T14:36:38.808Z', '2025-05-20T14:36:38.808Z', NULL, NULL, 1, true, 'PC', 'active'),
(10, 'FG-3002', 'Industrial Control Panel', 'Advanced control panel for manufacturing equipment', NULL, 'FINI', 10, 1, '12.5', 1, [object Object], '1250', '750', '1', '1', 'in-house', '2', '10', '3', 15, 1825, 'EX', 'make_to_order', 'lot_for_lot', true, true, false, true, true, '2025-05-20T14:36:38.822Z', '2025-05-20T14:36:38.822Z', NULL, NULL, 1, true, 'PC', 'active'),
(11, 'FG-3003', 'LED Light Fixture', 'Energy-efficient LED ceiling light fixture', NULL, 'FINI', 10, 1, '1.8', 1, [object Object], '65', '38', '1', '1', 'in-house', '15', '75', '25', 5, 1825, 'EX', 'make_to_stock', 'lot_for_lot', true, true, false, true, true, '2025-05-20T14:36:38.837Z', '2025-05-20T14:36:38.837Z', NULL, NULL, 1, true, 'PC', 'active'),
(12, 'FG-3004', 'Wireless Router', 'High-speed wireless router for home and office', NULL, 'FINI', 10, 1, '0.9', 1, [object Object], '120', '75', '1', '1', 'external', '20', '100', '30', 7, 1095, 'EX', 'make_to_stock', 'standard', true, true, true, false, true, '2025-05-20T14:36:38.851Z', '2025-05-20T14:36:38.851Z', NULL, NULL, 1, true, 'PC', 'active'),
(13, 'FG-3005', 'Electric Motor', 'Industrial electric motor for manufacturing equipment', NULL, 'FINI', 10, 1, '35', 1, [object Object], '890', '650', '1', '1', 'external', '3', '15', '5', 21, 3650, 'EX', 'make_to_order', 'standard', true, true, true, false, true, '2025-05-20T14:36:38.866Z', '2025-05-20T14:36:38.866Z', NULL, NULL, 1, true, 'PC', 'active'),
(14, 'PM-4001', 'Cardboard Box - Small', 'Corrugated cardboard box for shipping small items', NULL, 'PACK', 10, 1, '0.15', 1, [object Object], '1.25', '0.85', '100', '100', 'external', '250', '1000', '350', 3, 365, 'EX', 'reorder_point', 'lot_for_lot', true, false, true, false, true, '2025-05-20T14:36:38.885Z', '2025-05-20T14:36:38.885Z', NULL, NULL, 1, true, 'PC', 'active'),
(16, 'CHEM-001', 'Industrial Cleaning Solution', 'Multi-purpose industrial cleaning solution', NULL, 'RAW', 1, 1, NULL, NULL, NULL, '25.5', '15.75', NULL, NULL, NULL, '10', '50', NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-05-20T16:14:07.491Z', '2025-05-20T16:14:07.491Z', NULL, NULL, 1, true, 'PC', 'active'),
(17, 'TOOL-001', 'Precision Measurement Tool', 'High-accuracy digital measurement tool', NULL, 'FINI', 1, 1, NULL, NULL, NULL, '199.99', '125', NULL, NULL, NULL, '2', '10', NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-05-20T16:14:07.580Z', '2025-05-20T16:14:07.580Z', NULL, NULL, 1, true, 'PC', 'active'),
(20, 'M8334', 'Test Material', NULL, NULL, 'Raw Material', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T00:51:53.472Z', '2025-06-05T00:51:53.472Z', NULL, NULL, 1, true, 'PC', 'active'),
(21, 'TM571891', 'Test Material', NULL, NULL, 'Raw Material', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T01:56:12.008Z', '2025-06-05T01:56:12.008Z', NULL, NULL, 1, true, 'PC', 'active'),
(22, 'TM716672', 'Test Material', NULL, NULL, 'Raw Material', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T01:58:36.771Z', '2025-06-05T01:58:36.771Z', NULL, NULL, 1, true, 'PC', 'active'),
(23, 'TM772239', 'Test Material', NULL, NULL, 'Raw Material', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T01:59:32.340Z', '2025-06-05T01:59:32.340Z', NULL, NULL, 1, true, 'PC', 'active'),
(24, 'TM792967', 'Test Material', NULL, NULL, 'Raw Material', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T01:59:53.041Z', '2025-06-05T01:59:53.041Z', NULL, NULL, 1, true, 'PC', 'active'),
(25, 'TM853374', 'Test Material', NULL, NULL, 'Raw Material', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T02:00:53.486Z', '2025-06-05T02:00:53.486Z', NULL, NULL, 1, true, 'PC', 'active'),
(26, 'STAB001', 'Stability Test Material', NULL, NULL, 'Raw Material', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T02:04:10.847Z', '2025-06-05T02:04:10.847Z', NULL, NULL, 1, true, 'PC', 'active'),
(28, 'MAT001', 'Test Material 001', NULL, NULL, 'RAW', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T02:10:57.914Z', '2025-06-05T02:10:57.914Z', NULL, NULL, 1, true, 'PC', 'active'),
(30, 'MAT1749089635928', 'Test Material 1749089635928', NULL, NULL, 'RAW', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T02:13:57.661Z', '2025-06-05T02:13:57.661Z', NULL, NULL, 1, true, 'PC', 'active'),
(31, 'MAT1749089708190', 'Test Material 1749089708190', NULL, NULL, 'RAW', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T02:15:08.373Z', '2025-06-05T02:15:08.373Z', NULL, NULL, 1, true, 'PC', 'active'),
(32, 'MAT1749089731713', 'Test Material 1749089731713', NULL, NULL, 'RAW', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T02:15:31.851Z', '2025-06-05T02:15:31.851Z', NULL, NULL, 1, true, 'PC', 'active'),
(33, 'M1749089769754', 'Test Material 1749089769754', NULL, NULL, 'RAW', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T02:16:09.258Z', '2025-06-05T02:16:09.258Z', NULL, NULL, 1, true, 'PC', 'active'),
(34, 'M1749089793928', 'Test Material 1749089793928', NULL, NULL, 'RAW', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, true, false, false, false, true, '2025-06-05T02:16:34.142Z', '2025-06-05T02:16:34.142Z', NULL, NULL, 1, true, 'PC', 'active');

-- Table: module_health_status (10 records)
INSERT INTO "module_health_status" ("id", "module_name", "health_score", "total_issues", "critical_issues", "resolved_issues", "avg_resolution_time", "response_time_avg", "error_rate", "availability_score", "ai_intervention_count", "ai_success_rate", "last_check", "created_at") VALUES
('4', 'INVENTORY', '100.00', 0, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z'),
('6', 'FINANCE', '100.00', 0, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z'),
('8', 'TRANSPORT', '100.00', 0, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z'),
('9', 'REPORTS', '100.00', 0, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-04T23:48:09.610Z', '2025-06-04T23:48:09.610Z'),
('1', 'MASTER_DATA', '50.00', 87, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-05T02:16:34.848Z', '2025-06-04T23:48:09.610Z'),
('29', 'SYSTEM', '50.00', 26, 0, 0, 0, 0, '0.00', '100.00', 0, '0.00', '2025-06-05T02:16:34.999Z', '2025-06-05T00:48:18.711Z'),
('2', 'SALES', '50.00', 9, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-05T01:56:14.467Z', '2025-06-04T23:48:09.610Z'),
('5', 'PRODUCTION', '100.00', 1, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-05T01:58:36.317Z', '2025-06-04T23:48:09.610Z'),
('3', 'PURCHASE', '50.00', 6, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-05T01:59:52.428Z', '2025-06-04T23:48:09.610Z'),
('7', 'CONTROLLING', '100.00', 5, 0, 0, 0, 50, '0.00', '100.00', 0, '0.00', '2025-06-05T01:59:52.978Z', '2025-06-04T23:48:09.610Z');

-- Table: opportunities (17 records)
INSERT INTO "opportunities" ("id", "name", "lead_id", "customer_id", "status", "stage", "amount", "expected_revenue", "probability", "close_date", "next_step", "type", "source", "campaign_source", "description", "assigned_to", "is_closed", "is_won", "notes", "created_at", "updated_at", "active") VALUES
(1, 'Lee Education Services - Education Solution', 6, NULL, 'Open', 'Prospecting', '98612.00', '9861.20', 10, '2025-08-23T23:38:47.376Z', 'Follow up with Jennifer', 'Upgrade', 'Lead Conversion', NULL, 'Opportunity for Lee Education Services in the Education industry', NULL, false, false, NULL, '2025-05-21T23:38:47.386Z', '2025-05-21T23:38:47.386Z', true),
(2, 'Miller Tech Solutions - Technology Solution', 7, NULL, 'Open', 'Qualification', '67801.00', '13560.20', 20, '2025-09-01T23:38:47.376Z', 'Follow up with David', 'Existing Business', 'Lead Conversion', NULL, 'Opportunity for Miller Tech Solutions in the Technology industry', NULL, false, false, NULL, '2025-05-21T23:38:47.405Z', '2025-05-21T23:38:47.405Z', true),
(3, 'Garcia Manufacturing - Manufacturing Solution', 8, NULL, 'Open', 'Needs Analysis', '38398.00', '11519.40', 30, '2025-10-23T23:38:47.376Z', 'Follow up with Patricia', 'New Business', 'Lead Conversion', NULL, 'Opportunity for Garcia Manufacturing in the Manufacturing industry', NULL, false, false, NULL, '2025-05-21T23:38:47.423Z', '2025-05-21T23:38:47.423Z', true),
(4, 'Taylor Consulting - Professional Services Solution', 9, NULL, 'Open', 'Value Proposition', '30785.00', '12314.00', 40, '2025-10-05T23:38:47.376Z', 'Follow up with James', 'Existing Business', 'Lead Conversion', NULL, 'Opportunity for Taylor Consulting in the Professional Services industry', NULL, false, false, NULL, '2025-05-21T23:38:47.440Z', '2025-05-21T23:38:47.440Z', true),
(5, 'Moore Health Systems - Healthcare Solution', 10, NULL, 'Open', 'Identify Decision Makers', '59384.00', '29692.00', 50, '2025-08-24T23:38:47.376Z', 'Follow up with Elizabeth', 'New Business', 'Lead Conversion', NULL, 'Opportunity for Moore Health Systems in the Healthcare industry', NULL, false, false, NULL, '2025-05-21T23:38:47.459Z', '2025-05-21T23:38:47.459Z', true),
(6, 'White Industries - Manufacturing Solution', 11, NULL, 'Open', 'Proposal/Price Quote', '34939.00', '20963.40', 60, '2025-09-06T23:38:47.376Z', 'Follow up with William', 'Upgrade', 'Lead Conversion', NULL, 'Opportunity for White Industries in the Manufacturing industry', NULL, false, false, NULL, '2025-05-21T23:38:47.476Z', '2025-05-21T23:38:47.476Z', true),
(7, 'Jones Retail - Retail Solution', 12, NULL, 'Open', 'Negotiation/Review', '63504.00', '47628.00', 75, '2025-07-04T23:38:47.376Z', 'Follow up with Barbara', 'Upgrade', 'Lead Conversion', NULL, 'Opportunity for Jones Retail in the Retail industry', NULL, false, false, NULL, '2025-05-21T23:38:47.494Z', '2025-05-21T23:38:47.494Z', true),
(8, 'Clark Financial - Financial Services Solution', 13, NULL, 'Closed Won', 'Closed Won', '89097.00', '89097.00', 100, '2025-05-21T23:38:47.376Z', 'None', 'Existing Business', 'Lead Conversion', NULL, 'Opportunity for Clark Financial in the Financial Services industry', NULL, true, true, NULL, '2025-05-21T23:38:47.512Z', '2025-05-21T23:38:47.512Z', true),
(9, 'Lee Education Services - Education Solution', 6, NULL, 'Closed Lost', 'Closed Lost', '90911.00', '0.00', 0, '2025-05-11T23:38:47.376Z', 'None', 'New Business', 'Lead Conversion', NULL, 'Opportunity for Lee Education Services in the Education industry', NULL, true, false, NULL, '2025-05-21T23:38:47.532Z', '2025-05-21T23:38:47.532Z', true),
(10, 'Jones Retail - Additional Retail Project', 12, NULL, 'Open', 'Qualification', '28807.00', '5761.40', 20, '2025-06-02T23:38:47.376Z', 'Schedule meeting with Barbara', 'Upgrade', 'Lead Conversion', NULL, 'Additional opportunity for Jones Retail in the Retail industry', NULL, false, false, NULL, '2025-05-21T23:38:47.550Z', '2025-05-21T23:38:47.550Z', true),
(11, 'Clark Financial - Additional Financial Services Project', 13, NULL, 'Open', 'Needs Analysis', '43756.00', '13126.80', 30, '2025-05-31T23:38:47.376Z', 'Schedule meeting with Richard', 'Upgrade', 'Lead Conversion', NULL, 'Additional opportunity for Clark Financial in the Financial Services industry', NULL, false, false, NULL, '2025-05-21T23:38:47.568Z', '2025-05-21T23:38:47.568Z', true),
(12, 'Jones Retail - Additional Retail Project', 12, NULL, 'Open', 'Identify Decision Makers', '75321.00', '37660.50', 50, '2025-08-06T23:38:47.376Z', 'Schedule meeting with Barbara', 'New Business', 'Lead Conversion', NULL, 'Additional opportunity for Jones Retail in the Retail industry', NULL, false, false, NULL, '2025-05-21T23:38:47.585Z', '2025-05-21T23:38:47.585Z', true),
(13, 'Taylor Consulting - Additional Professional Services Project', 9, NULL, 'Open', 'Proposal/Price Quote', '26130.00', '15678.00', 60, '2025-06-15T23:38:47.376Z', 'Schedule meeting with James', 'Upgrade', 'Lead Conversion', NULL, 'Additional opportunity for Taylor Consulting in the Professional Services industry', NULL, false, false, NULL, '2025-05-21T23:38:47.603Z', '2025-05-21T23:38:47.603Z', true),
(14, 'Lee Education Services - Additional Education Project', 6, NULL, 'Open', 'Negotiation/Review', '15916.00', '11937.00', 75, '2025-07-09T23:38:47.376Z', 'Schedule meeting with Jennifer', 'Existing Business', 'Lead Conversion', NULL, 'Additional opportunity for Lee Education Services in the Education industry', NULL, false, false, NULL, '2025-05-21T23:38:47.620Z', '2025-05-21T23:38:47.620Z', true),
(15, 'Jones Retail - Additional Retail Project', 12, NULL, 'Open', 'Prospecting', '18557.00', '1855.70', 10, '2025-07-02T23:38:47.376Z', 'Schedule meeting with Barbara', 'New Business', 'Lead Conversion', NULL, 'Additional opportunity for Jones Retail in the Retail industry', NULL, false, false, NULL, '2025-05-21T23:38:47.637Z', '2025-05-21T23:38:47.637Z', true),
(16, 'Miller Tech Solutions - Additional Technology Project', 7, NULL, 'Open', 'Value Proposition', '14051.00', '5620.40', 40, '2025-06-16T23:38:47.376Z', 'Schedule meeting with David', 'Existing Business', 'Lead Conversion', NULL, 'Additional opportunity for Miller Tech Solutions in the Technology industry', NULL, false, false, NULL, '2025-05-21T23:38:47.655Z', '2025-05-21T23:38:47.655Z', true),
(17, 'NewOpportunity', 2, NULL, 'Open', 'Needs Analysis', '200.00', '0.00', 10, '2025-05-23T00:00:00.000Z', '', 'New Business', 'Manual Entry', NULL, '', NULL, false, false, NULL, '2025-05-23T01:33:26.916Z', '2025-05-23T01:33:26.916Z', true);

-- Table: order_items (130 records)
INSERT INTO "order_items" ("id", "order_id", "product_id", "quantity", "unit_price", "total", "created_at", "updated_at", "active") VALUES
(2, 3, 15, 7, 39.99, 279.93, '2025-05-21T16:29:36.011Z', '2025-05-21T16:29:36.011Z', true),
(3, 3, 17, 3, 129.99, 389.97, '2025-05-21T16:29:36.028Z', '2025-05-21T16:29:36.028Z', true),
(4, 3, 8, 10, 79.99, 799.9, '2025-05-21T16:29:36.045Z', '2025-05-21T16:29:36.045Z', true),
(5, 3, 13, 6, 999.99, 5999.9400000000005, '2025-05-21T16:29:36.061Z', '2025-05-21T16:29:36.061Z', true),
(6, 4, 5, 7, 349.99, 2449.9300000000003, '2025-05-21T16:29:36.146Z', '2025-05-21T16:29:36.146Z', true),
(7, 5, 13, 10, 999.99, 9999.9, '2025-05-21T16:29:36.193Z', '2025-05-21T16:29:36.193Z', true),
(8, 6, 7, 4, 49.99, 199.96, '2025-05-21T16:29:36.241Z', '2025-05-21T16:29:36.241Z', true),
(9, 6, 17, 7, 129.99, 909.9300000000001, '2025-05-21T16:29:36.257Z', '2025-05-21T16:29:36.257Z', true),
(10, 6, 18, 8, 149.99, 1199.92, '2025-05-21T16:29:36.272Z', '2025-05-21T16:29:36.272Z', true),
(11, 7, 5, 10, 349.99, 3499.9, '2025-05-21T16:29:36.320Z', '2025-05-21T16:29:36.320Z', true),
(12, 8, 16, 10, 59.99, 599.9, '2025-05-21T16:29:36.367Z', '2025-05-21T16:29:36.367Z', true),
(13, 8, 2, 7, 249.99, 1749.93, '2025-05-21T16:29:36.383Z', '2025-05-21T16:29:36.383Z', true),
(14, 8, 18, 2, 149.99, 299.98, '2025-05-21T16:29:36.399Z', '2025-05-21T16:29:36.399Z', true),
(15, 9, 13, 1, 999.99, 999.99, '2025-05-21T16:29:36.447Z', '2025-05-21T16:29:36.447Z', true),
(16, 9, 10, 6, 179.99, 1079.94, '2025-05-21T16:29:36.462Z', '2025-05-21T16:29:36.462Z', true),
(17, 10, 4, 3, 129.99, 389.97, '2025-05-21T16:29:36.509Z', '2025-05-21T16:29:36.509Z', true),
(18, 11, 14, 2, 69.99, 139.98, '2025-05-21T16:29:36.559Z', '2025-05-21T16:29:36.559Z', true),
(19, 11, 18, 7, 149.99, 1049.93, '2025-05-21T16:29:36.575Z', '2025-05-21T16:29:36.575Z', true),
(20, 11, 5, 10, 349.99, 3499.9, '2025-05-21T16:29:36.590Z', '2025-05-21T16:29:36.590Z', true),
(21, 12, 19, 10, 49.99, 499.90000000000003, '2025-05-21T16:29:36.638Z', '2025-05-21T16:29:36.638Z', true),
(22, 12, 8, 9, 79.99, 719.91, '2025-05-21T16:29:36.657Z', '2025-05-21T16:29:36.657Z', true),
(23, 12, 20, 1, 399.99, 399.99, '2025-05-21T16:29:36.673Z', '2025-05-21T16:29:36.673Z', true),
(24, 12, 5, 10, 349.99, 3499.9, '2025-05-21T16:29:36.689Z', '2025-05-21T16:29:36.689Z', true),
(25, 13, 4, 6, 129.99, 779.94, '2025-05-21T16:29:36.742Z', '2025-05-21T16:29:36.742Z', true),
(26, 14, 8, 2, 79.99, 159.98, '2025-05-21T16:29:36.790Z', '2025-05-21T16:29:36.790Z', true),
(27, 14, 5, 9, 349.99, 3149.91, '2025-05-21T16:29:36.806Z', '2025-05-21T16:29:36.806Z', true),
(28, 14, 16, 6, 59.99, 359.94, '2025-05-21T16:29:36.822Z', '2025-05-21T16:29:36.822Z', true),
(29, 15, 13, 2, 999.99, 1999.98, '2025-05-21T16:29:36.870Z', '2025-05-21T16:29:36.870Z', true),
(30, 15, 4, 5, 129.99, 649.95, '2025-05-21T16:29:36.885Z', '2025-05-21T16:29:36.885Z', true),
(31, 16, 1, 1, 1299.99, 1299.99, '2025-05-21T16:29:36.932Z', '2025-05-21T16:29:36.932Z', true),
(32, 16, 20, 10, 399.99, 3999.9, '2025-05-21T16:29:36.948Z', '2025-05-21T16:29:36.948Z', true),
(33, 17, 17, 5, 129.99, 649.95, '2025-05-21T16:29:36.995Z', '2025-05-21T16:29:36.995Z', true),
(34, 17, 19, 4, 49.99, 199.96, '2025-05-21T16:29:37.010Z', '2025-05-21T16:29:37.010Z', true),
(35, 18, 1, 3, 1299.99, 3899.9700000000003, '2025-05-21T16:29:37.058Z', '2025-05-21T16:29:37.058Z', true),
(36, 18, 19, 3, 49.99, 149.97, '2025-05-21T16:29:37.074Z', '2025-05-21T16:29:37.074Z', true),
(37, 18, 2, 1, 249.99, 249.99, '2025-05-21T16:29:37.090Z', '2025-05-21T16:29:37.090Z', true),
(38, 19, 9, 3, 299.99, 899.97, '2025-05-21T16:29:37.137Z', '2025-05-21T16:29:37.137Z', true),
(39, 19, 16, 6, 59.99, 359.94, '2025-05-21T16:29:37.153Z', '2025-05-21T16:29:37.153Z', true),
(40, 19, 14, 4, 69.99, 279.96, '2025-05-21T16:29:37.169Z', '2025-05-21T16:29:37.169Z', true),
(41, 19, 10, 9, 179.99, 1619.91, '2025-05-21T16:29:37.185Z', '2025-05-21T16:29:37.185Z', true),
(42, 20, 9, 5, 299.99, 1499.95, '2025-05-21T16:29:37.233Z', '2025-05-21T16:29:37.233Z', true),
(43, 20, 12, 10, 499.99, 4999.9, '2025-05-21T16:29:37.249Z', '2025-05-21T16:29:37.249Z', true),
(44, 20, 1, 1, 1299.99, 1299.99, '2025-05-21T16:29:37.265Z', '2025-05-21T16:29:37.265Z', true),
(45, 20, 8, 8, 79.99, 639.92, '2025-05-21T16:29:37.280Z', '2025-05-21T16:29:37.280Z', true),
(46, 20, 3, 5, 599.99, 2999.95, '2025-05-21T16:29:37.296Z', '2025-05-21T16:29:37.296Z', true),
(47, 21, 6, 8, 89.99, 719.92, '2025-05-21T16:29:37.367Z', '2025-05-21T16:29:37.367Z', true),
(48, 21, 2, 9, 249.99, 2249.91, '2025-05-21T16:29:37.383Z', '2025-05-21T16:29:37.383Z', true),
(49, 22, 3, 3, 599.99, 1799.97, '2025-05-21T16:29:37.437Z', '2025-05-21T16:29:37.437Z', true),
(50, 22, 5, 4, 349.99, 1399.96, '2025-05-21T16:29:37.453Z', '2025-05-21T16:29:37.453Z', true),
(51, 23, 3, 9, 599.99, 5399.91, '2025-05-21T16:29:37.499Z', '2025-05-21T16:29:37.499Z', true),
(52, 23, 13, 9, 999.99, 8999.91, '2025-05-21T16:29:37.515Z', '2025-05-21T16:29:37.515Z', true),
(53, 23, 12, 10, 499.99, 4999.9, '2025-05-21T16:29:37.531Z', '2025-05-21T16:29:37.531Z', true),
(54, 24, 4, 8, 129.99, 1039.92, '2025-05-21T16:29:37.578Z', '2025-05-21T16:29:37.578Z', true),
(55, 25, 15, 8, 39.99, 319.92, '2025-05-21T16:29:37.625Z', '2025-05-21T16:29:37.625Z', true),
(56, 25, 5, 6, 349.99, 2099.94, '2025-05-21T16:29:37.641Z', '2025-05-21T16:29:37.641Z', true),
(57, 25, 4, 4, 129.99, 519.96, '2025-05-21T16:29:37.657Z', '2025-05-21T16:29:37.657Z', true),
(58, 26, 20, 2, 399.99, 799.98, '2025-05-21T16:29:37.705Z', '2025-05-21T16:29:37.705Z', true),
(59, 26, 4, 5, 129.99, 649.95, '2025-05-21T16:29:37.721Z', '2025-05-21T16:29:37.721Z', true),
(60, 26, 9, 2, 299.99, 599.98, '2025-05-21T16:29:37.737Z', '2025-05-21T16:29:37.737Z', true),
(61, 26, 15, 6, 39.99, 239.94, '2025-05-21T16:29:37.752Z', '2025-05-21T16:29:37.752Z', true),
(62, 27, 3, 9, 599.99, 5399.91, '2025-05-21T16:29:37.816Z', '2025-05-21T16:29:37.816Z', true),
(63, 28, 5, 1, 349.99, 349.99, '2025-05-21T16:29:37.879Z', '2025-05-21T16:29:37.879Z', true),
(64, 28, 9, 5, 299.99, 1499.95, '2025-05-21T16:29:37.894Z', '2025-05-21T16:29:37.894Z', true),
(65, 28, 15, 1, 39.99, 39.99, '2025-05-21T16:29:37.910Z', '2025-05-21T16:29:37.910Z', true),
(66, 29, 15, 1, 39.99, 39.99, '2025-05-21T16:29:37.957Z', '2025-05-21T16:29:37.957Z', true),
(67, 29, 12, 10, 499.99, 4999.9, '2025-05-21T16:29:37.972Z', '2025-05-21T16:29:37.972Z', true),
(68, 30, 12, 4, 499.99, 1999.96, '2025-05-21T16:29:38.019Z', '2025-05-21T16:29:38.019Z', true),
(69, 30, 5, 4, 349.99, 1399.96, '2025-05-21T16:29:38.034Z', '2025-05-21T16:29:38.034Z', true),
(70, 31, 13, 5, 999.99, 4999.95, '2025-05-21T16:29:38.082Z', '2025-05-21T16:29:38.082Z', true),
(71, 31, 14, 1, 69.99, 69.99, '2025-05-21T16:29:38.097Z', '2025-05-21T16:29:38.097Z', true),
(72, 32, 8, 3, 79.99, 239.96999999999997, '2025-05-21T16:29:38.160Z', '2025-05-21T16:29:38.160Z', true),
(73, 33, 12, 9, 499.99, 4499.91, '2025-05-21T16:29:38.208Z', '2025-05-21T16:29:38.208Z', true),
(74, 34, 18, 8, 149.99, 1199.92, '2025-05-21T16:29:38.255Z', '2025-05-21T16:29:38.255Z', true),
(75, 34, 13, 8, 999.99, 7999.92, '2025-05-21T16:29:38.271Z', '2025-05-21T16:29:38.271Z', true),
(76, 34, 14, 10, 69.99, 699.9, '2025-05-21T16:29:38.286Z', '2025-05-21T16:29:38.286Z', true),
(77, 34, 9, 5, 299.99, 1499.95, '2025-05-21T16:29:38.302Z', '2025-05-21T16:29:38.302Z', true),
(78, 35, 19, 3, 49.99, 149.97, '2025-05-21T16:29:38.349Z', '2025-05-21T16:29:38.349Z', true),
(79, 35, 9, 3, 299.99, 899.97, '2025-05-21T16:29:38.365Z', '2025-05-21T16:29:38.365Z', true),
(80, 36, 7, 7, 49.99, 349.93, '2025-05-21T16:29:38.412Z', '2025-05-21T16:29:38.412Z', true),
(81, 36, 8, 10, 79.99, 799.9, '2025-05-21T16:29:38.428Z', '2025-05-21T16:29:38.428Z', true),
(82, 36, 5, 1, 349.99, 349.99, '2025-05-21T16:29:38.443Z', '2025-05-21T16:29:38.443Z', true),
(83, 36, 17, 7, 129.99, 909.9300000000001, '2025-05-21T16:29:38.459Z', '2025-05-21T16:29:38.459Z', true),
(84, 36, 10, 9, 179.99, 1619.91, '2025-05-21T16:29:38.475Z', '2025-05-21T16:29:38.475Z', true),
(85, 37, 8, 4, 79.99, 319.96, '2025-05-21T16:29:38.539Z', '2025-05-21T16:29:38.539Z', true),
(86, 38, 2, 1, 249.99, 249.99, '2025-05-21T16:29:38.586Z', '2025-05-21T16:29:38.586Z', true),
(87, 38, 1, 7, 1299.99, 9099.93, '2025-05-21T16:29:38.611Z', '2025-05-21T16:29:38.611Z', true),
(88, 39, 9, 1, 299.99, 299.99, '2025-05-21T16:29:38.659Z', '2025-05-21T16:29:38.659Z', true),
(89, 39, 5, 8, 349.99, 2799.92, '2025-05-21T16:29:38.676Z', '2025-05-21T16:29:38.676Z', true),
(90, 39, 10, 8, 179.99, 1439.92, '2025-05-21T16:29:38.692Z', '2025-05-21T16:29:38.692Z', true),
(91, 39, 3, 8, 599.99, 4799.92, '2025-05-21T16:29:38.708Z', '2025-05-21T16:29:38.708Z', true),
(92, 40, 7, 8, 49.99, 399.92, '2025-05-21T16:29:38.771Z', '2025-05-21T16:29:38.771Z', true),
(93, 40, 5, 5, 349.99, 1749.95, '2025-05-21T16:29:38.787Z', '2025-05-21T16:29:38.787Z', true),
(94, 40, 11, 4, 899.99, 3599.96, '2025-05-21T16:29:38.805Z', '2025-05-21T16:29:38.805Z', true),
(95, 41, 10, 6, 179.99, 1079.94, '2025-05-21T16:29:38.869Z', '2025-05-21T16:29:38.869Z', true),
(96, 41, 9, 8, 299.99, 2399.92, '2025-05-21T16:29:38.885Z', '2025-05-21T16:29:38.885Z', true),
(97, 42, 4, 1, 129.99, 129.99, '2025-05-21T16:29:38.933Z', '2025-05-21T16:29:38.933Z', true),
(98, 42, 3, 8, 599.99, 4799.92, '2025-05-21T16:29:38.949Z', '2025-05-21T16:29:38.949Z', true),
(99, 42, 14, 8, 69.99, 559.92, '2025-05-21T16:29:38.965Z', '2025-05-21T16:29:38.965Z', true),
(100, 42, 17, 2, 129.99, 259.98, '2025-05-21T16:29:38.981Z', '2025-05-21T16:29:38.981Z', true),
(101, 43, 2, 7, 249.99, 1749.93, '2025-05-21T16:29:39.028Z', '2025-05-21T16:29:39.028Z', true),
(102, 43, 18, 6, 149.99, 899.94, '2025-05-21T16:29:39.044Z', '2025-05-21T16:29:39.044Z', true),
(103, 43, 14, 8, 69.99, 559.92, '2025-05-21T16:29:39.060Z', '2025-05-21T16:29:39.060Z', true),
(104, 44, 1, 4, 1299.99, 5199.96, '2025-05-21T16:29:39.108Z', '2025-05-21T16:29:39.108Z', true),
(105, 44, 6, 3, 89.99, 269.96999999999997, '2025-05-21T16:29:39.124Z', '2025-05-21T16:29:39.124Z', true),
(106, 44, 13, 6, 999.99, 5999.9400000000005, '2025-05-21T16:29:39.139Z', '2025-05-21T16:29:39.139Z', true),
(107, 45, 15, 2, 39.99, 79.98, '2025-05-21T16:29:39.187Z', '2025-05-21T16:29:39.187Z', true),
(108, 45, 9, 3, 299.99, 899.97, '2025-05-21T16:29:39.202Z', '2025-05-21T16:29:39.202Z', true),
(109, 45, 13, 1, 999.99, 999.99, '2025-05-21T16:29:39.224Z', '2025-05-21T16:29:39.224Z', true),
(110, 45, 12, 8, 499.99, 3999.92, '2025-05-21T16:29:39.240Z', '2025-05-21T16:29:39.240Z', true),
(111, 45, 18, 1, 149.99, 149.99, '2025-05-21T16:29:39.256Z', '2025-05-21T16:29:39.256Z', true),
(112, 46, 17, 8, 129.99, 1039.92, '2025-05-21T16:29:39.305Z', '2025-05-21T16:29:39.305Z', true),
(113, 46, 18, 2, 149.99, 299.98, '2025-05-21T16:29:39.322Z', '2025-05-21T16:29:39.322Z', true),
(114, 46, 10, 5, 179.99, 899.95, '2025-05-21T16:29:39.338Z', '2025-05-21T16:29:39.338Z', true),
(115, 47, 1, 8, 1299.99, 10399.92, '2025-05-21T16:29:39.386Z', '2025-05-21T16:29:39.386Z', true),
(116, 47, 6, 5, 89.99, 449.95, '2025-05-21T16:29:39.401Z', '2025-05-21T16:29:39.401Z', true),
(117, 48, 6, 5, 89.99, 449.95, '2025-05-21T16:29:39.448Z', '2025-05-21T16:29:39.448Z', true),
(118, 48, 5, 1, 349.99, 349.99, '2025-05-21T16:29:39.464Z', '2025-05-21T16:29:39.464Z', true),
(119, 48, 14, 1, 69.99, 69.99, '2025-05-21T16:29:39.480Z', '2025-05-21T16:29:39.480Z', true),
(120, 49, 3, 2, 599.99, 1199.98, '2025-05-21T16:29:39.543Z', '2025-05-21T16:29:39.543Z', true),
(121, 50, 3, 7, 599.99, 4199.93, '2025-05-21T16:29:39.605Z', '2025-05-21T16:29:39.605Z', true),
(122, 50, 16, 10, 59.99, 599.9, '2025-05-21T16:29:39.622Z', '2025-05-21T16:29:39.622Z', true),
(123, 51, 17, 10, 129.99, 1299.9, '2025-05-21T16:29:39.669Z', '2025-05-21T16:29:39.669Z', true),
(124, 51, 4, 9, 129.99, 1169.91, '2025-05-21T16:29:39.685Z', '2025-05-21T16:29:39.685Z', true),
(125, 51, 8, 4, 79.99, 319.96, '2025-05-21T16:29:39.701Z', '2025-05-21T16:29:39.701Z', true),
(126, 51, 9, 3, 299.99, 899.97, '2025-05-21T16:29:39.718Z', '2025-05-21T16:29:39.718Z', true),
(127, 51, 3, 5, 599.99, 2999.95, '2025-05-21T16:29:39.733Z', '2025-05-21T16:29:39.733Z', true),
(128, 52, 14, 8, 69.99, 559.92, '2025-05-21T16:29:39.781Z', '2025-05-21T16:29:39.781Z', true),
(129, 52, 1, 4, 1299.99, 5199.96, '2025-05-21T16:29:39.796Z', '2025-05-21T16:29:39.796Z', true),
(130, 52, 20, 10, 399.99, 3999.9, '2025-05-21T16:29:39.812Z', '2025-05-21T16:29:39.812Z', true),
(131, 52, 3, 9, 599.99, 5399.91, '2025-05-21T16:29:39.828Z', '2025-05-21T16:29:39.828Z', true);

-- Table: orders (50 records)
INSERT INTO "orders" ("id", "order_number", "customer_id", "date", "status", "total", "notes", "shipping_address", "user_id", "created_at", "updated_at", "active") VALUES
(3, 'SO-10000', 5, '2025-02-11T07:25:12.502Z', 'DELIVERED', 7469.740000000001, 'Sample order 1 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:35.988Z', '2025-05-21T16:29:35.988Z', true),
(4, 'SO-10001', 1, '2025-05-13T05:02:26.310Z', 'CONFIRMED', 2449.9300000000003, 'Sample order 2 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:36.130Z', '2025-05-21T16:29:36.130Z', true),
(5, 'SO-10002', 5, '2025-04-24T07:05:56.360Z', 'DRAFT', 9999.9, 'Sample order 3 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:36.178Z', '2025-05-21T16:29:36.178Z', true),
(6, 'SO-10003', 3, '2025-03-01T02:13:26.649Z', 'DRAFT', 2309.8100000000004, 'Sample order 4 for European Distributors Ltd', 'Shipping to European Distributors Ltd at their registered address', NULL, '2025-05-21T16:29:36.225Z', '2025-05-21T16:29:36.225Z', true),
(7, 'SO-10004', 2, '2025-02-04T03:01:03.697Z', 'CONFIRMED', 3499.9, 'Sample order 5 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:36.304Z', '2025-05-21T16:29:36.304Z', true),
(8, 'SO-10005', 5, '2025-02-11T09:32:58.133Z', 'DRAFT', 2649.81, 'Sample order 6 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:36.352Z', '2025-05-21T16:29:36.352Z', true),
(9, 'SO-10006', 1, '2024-12-31T19:00:58.283Z', 'DRAFT', 2079.9300000000003, 'Sample order 7 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:36.431Z', '2025-05-21T16:29:36.431Z', true),
(10, 'SO-10007', 3, '2025-05-13T13:56:33.214Z', 'PROCESSING', 389.97, 'Sample order 8 for European Distributors Ltd', 'Shipping to European Distributors Ltd at their registered address', NULL, '2025-05-21T16:29:36.493Z', '2025-05-21T16:29:36.493Z', true),
(11, 'SO-10008', 5, '2025-04-02T01:46:56.499Z', 'DRAFT', 4689.81, 'Sample order 9 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:36.541Z', '2025-05-21T16:29:36.541Z', true),
(12, 'SO-10009', 1, '2025-05-17T16:51:54.190Z', 'DRAFT', 5119.7, 'Sample order 10 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:36.622Z', '2025-05-21T16:29:36.622Z', true),
(13, 'SO-10010', 1, '2025-02-08T11:36:41.019Z', 'CONFIRMED', 779.94, 'Sample order 11 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:36.727Z', '2025-05-21T16:29:36.727Z', true),
(14, 'SO-10011', 1, '2025-03-25T04:45:53.561Z', 'CONFIRMED', 3669.83, 'Sample order 12 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:36.774Z', '2025-05-21T16:29:36.774Z', true),
(15, 'SO-10012', 2, '2025-04-25T09:54:02.310Z', 'DRAFT', 2649.9300000000003, 'Sample order 13 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:36.854Z', '2025-05-21T16:29:36.854Z', true),
(16, 'SO-10013', 2, '2025-02-26T11:17:58.421Z', 'CONFIRMED', 5299.89, 'Sample order 14 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:36.917Z', '2025-05-21T16:29:36.917Z', true),
(17, 'SO-10014', 5, '2024-12-31T20:35:27.996Z', 'DRAFT', 849.9100000000001, 'Sample order 15 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:36.979Z', '2025-05-21T16:29:36.979Z', true),
(18, 'SO-10015', 5, '2025-05-12T17:12:33.098Z', 'CONFIRMED', 4299.93, 'Sample order 16 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:37.042Z', '2025-05-21T16:29:37.042Z', true),
(19, 'SO-10016', 3, '2025-05-13T20:10:12.347Z', 'DRAFT', 3159.78, 'Sample order 17 for European Distributors Ltd', 'Shipping to European Distributors Ltd at their registered address', NULL, '2025-05-21T16:29:37.121Z', '2025-05-21T16:29:37.121Z', true),
(20, 'SO-10017', 4, '2025-05-01T21:09:29.634Z', 'DELIVERED', 11439.71, 'Sample order 18 for Tech Solutions GmbH', 'Shipping to Tech Solutions GmbH at their registered address', NULL, '2025-05-21T16:29:37.218Z', '2025-05-21T16:29:37.218Z', true),
(21, 'SO-10018', 4, '2024-11-22T16:16:12.929Z', 'DRAFT', 2969.83, 'Sample order 19 for Tech Solutions GmbH', 'Shipping to Tech Solutions GmbH at their registered address', NULL, '2025-05-21T16:29:37.344Z', '2025-05-21T16:29:37.344Z', true),
(22, 'SO-10019', 1, '2025-05-14T07:41:52.633Z', 'DRAFT', 3199.9300000000003, 'Sample order 20 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:37.416Z', '2025-05-21T16:29:37.416Z', true),
(23, 'SO-10020', 3, '2024-11-23T20:26:31.944Z', 'DRAFT', 19399.72, 'Sample order 21 for European Distributors Ltd', 'Shipping to European Distributors Ltd at their registered address', NULL, '2025-05-21T16:29:37.484Z', '2025-05-21T16:29:37.484Z', true),
(24, 'SO-10021', 2, '2025-04-06T06:02:00.824Z', 'PROCESSING', 1039.92, 'Sample order 22 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:37.562Z', '2025-05-21T16:29:37.562Z', true),
(25, 'SO-10022', 3, '2025-04-18T03:56:30.454Z', 'DRAFT', 2939.82, 'Sample order 23 for European Distributors Ltd', 'Shipping to European Distributors Ltd at their registered address', NULL, '2025-05-21T16:29:37.609Z', '2025-05-21T16:29:37.609Z', true),
(26, 'SO-10023', 1, '2024-12-28T18:43:15.488Z', 'DELIVERED', 2289.85, 'Sample order 24 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:37.689Z', '2025-05-21T16:29:37.689Z', true),
(27, 'SO-10024', 4, '2025-04-01T03:12:19.304Z', 'SHIPPED', 5399.91, 'Sample order 25 for Tech Solutions GmbH', 'Shipping to Tech Solutions GmbH at their registered address', NULL, '2025-05-21T16:29:37.801Z', '2025-05-21T16:29:37.801Z', true),
(28, 'SO-10025', 1, '2024-12-17T00:56:14.765Z', 'PROCESSING', 1889.93, 'Sample order 26 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:37.863Z', '2025-05-21T16:29:37.863Z', true),
(29, 'SO-10026', 1, '2025-04-09T15:27:28.084Z', 'PROCESSING', 5039.889999999999, 'Sample order 27 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:37.941Z', '2025-05-21T16:29:37.941Z', true),
(30, 'SO-10027', 1, '2025-03-05T08:43:30.987Z', 'PROCESSING', 3399.92, 'Sample order 28 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:38.003Z', '2025-05-21T16:29:38.003Z', true),
(31, 'SO-10028', 2, '2025-01-21T22:23:11.444Z', 'SHIPPED', 5069.94, 'Sample order 29 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:38.066Z', '2025-05-21T16:29:38.066Z', true),
(32, 'SO-10029', 3, '2025-04-27T22:45:20.308Z', 'DRAFT', 239.96999999999997, 'Sample order 30 for European Distributors Ltd', 'Shipping to European Distributors Ltd at their registered address', NULL, '2025-05-21T16:29:38.145Z', '2025-05-21T16:29:38.145Z', true),
(33, 'SO-10030', 3, '2025-03-22T08:01:44.102Z', 'DRAFT', 4499.91, 'Sample order 31 for European Distributors Ltd', 'Shipping to European Distributors Ltd at their registered address', NULL, '2025-05-21T16:29:38.192Z', '2025-05-21T16:29:38.192Z', true),
(34, 'SO-10031', 5, '2025-05-15T11:21:24.615Z', 'CONFIRMED', 11399.69, 'Sample order 32 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:38.239Z', '2025-05-21T16:29:38.239Z', true),
(35, 'SO-10032', 5, '2025-03-02T04:57:18.132Z', 'CONFIRMED', 1049.94, 'Sample order 33 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:38.333Z', '2025-05-21T16:29:38.333Z', true),
(36, 'SO-10033', 2, '2025-04-02T18:15:28.827Z', 'DELIVERED', 4029.66, 'Sample order 34 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:38.397Z', '2025-05-21T16:29:38.397Z', true),
(37, 'SO-10034', 2, '2024-12-30T02:51:24.050Z', 'CONFIRMED', 319.96, 'Sample order 35 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:38.523Z', '2025-05-21T16:29:38.523Z', true),
(38, 'SO-10035', 4, '2025-02-20T15:40:35.692Z', 'CONFIRMED', 9349.92, 'Sample order 36 for Tech Solutions GmbH', 'Shipping to Tech Solutions GmbH at their registered address', NULL, '2025-05-21T16:29:38.571Z', '2025-05-21T16:29:38.571Z', true),
(39, 'SO-10036', 1, '2024-12-18T11:36:51.500Z', 'DELIVERED', 9339.75, 'Sample order 37 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:38.644Z', '2025-05-21T16:29:38.644Z', true),
(40, 'SO-10037', 1, '2024-12-12T07:21:42.349Z', 'SHIPPED', 5749.83, 'Sample order 38 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:38.756Z', '2025-05-21T16:29:38.756Z', true),
(41, 'SO-10038', 1, '2024-12-17T22:48:02.894Z', 'CONFIRMED', 3479.86, 'Sample order 39 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:38.853Z', '2025-05-21T16:29:38.853Z', true),
(42, 'SO-10039', 2, '2025-04-26T05:01:08.069Z', 'CONFIRMED', 5749.8099999999995, 'Sample order 40 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:38.917Z', '2025-05-21T16:29:38.917Z', true),
(43, 'SO-10040', 1, '2025-03-29T04:54:40.334Z', 'PROCESSING', 3209.79, 'Sample order 41 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:39.012Z', '2025-05-21T16:29:39.012Z', true),
(44, 'SO-10041', 1, '2025-03-09T00:25:18.663Z', 'DRAFT', 11469.87, 'Sample order 42 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:39.092Z', '2025-05-21T16:29:39.092Z', true),
(45, 'SO-10042', 2, '2025-02-16T07:37:27.292Z', 'CONFIRMED', 6129.85, 'Sample order 43 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:39.170Z', '2025-05-21T16:29:39.170Z', true),
(46, 'SO-10043', 5, '2025-02-16T07:23:13.799Z', 'DRAFT', 2239.8500000000004, 'Sample order 44 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:39.289Z', '2025-05-21T16:29:39.289Z', true),
(47, 'SO-10044', 2, '2025-02-12T01:25:13.831Z', 'DRAFT', 10849.87, 'Sample order 45 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:39.370Z', '2025-05-21T16:29:39.370Z', true),
(48, 'SO-10045', 5, '2025-04-18T12:23:00.681Z', 'SHIPPED', 869.9300000000001, 'Sample order 46 for Japan Manufacturing Co.', 'Shipping to Japan Manufacturing Co. at their registered address', NULL, '2025-05-21T16:29:39.433Z', '2025-05-21T16:29:39.433Z', true),
(49, 'SO-10046', 4, '2025-03-29T13:28:24.852Z', 'SHIPPED', 1199.98, 'Sample order 47 for Tech Solutions GmbH', 'Shipping to Tech Solutions GmbH at their registered address', NULL, '2025-05-21T16:29:39.527Z', '2025-05-21T16:29:39.527Z', true),
(50, 'SO-10047', 2, '2024-12-13T18:44:12.340Z', 'DRAFT', 4799.83, 'Sample order 48 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:39.590Z', '2025-05-21T16:29:39.590Z', true),
(51, 'SO-10048', 1, '2024-11-21T17:19:52.771Z', 'CONFIRMED', 6689.6900000000005, 'Sample order 49 for Acme Corporation', 'Shipping to Acme Corporation at their registered address', NULL, '2025-05-21T16:29:39.653Z', '2025-05-21T16:29:39.653Z', true),
(52, 'SO-10049', 2, '2025-03-22T10:52:52.984Z', 'DRAFT', 15159.69, 'Sample order 50 for Global Enterprises', 'Shipping to Global Enterprises at their registered address', NULL, '2025-05-21T16:29:39.765Z', '2025-05-21T16:29:39.765Z', true);

-- Table: plants (26 records)
INSERT INTO "plants" ("id", "code", "name", "description", "company_code_id", "type", "category", "address", "city", "state", "country", "postal_code", "phone", "email", "manager", "timezone", "operating_hours", "coordinates", "status", "is_active", "created_at", "created_by", "updated_at", "updated_by", "version", "notes", "active", "company_code") VALUES
(34, 'PLT17490897317131', 'Test Plant 1749089731713 1', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:15:31.782Z', 1, '2025-06-05T02:15:31.782Z', 1, 1, NULL, true, NULL),
(35, 'PLT17490897317132', 'Test Plant 1749089731713 2', NULL, 1, 'Warehouse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:15:31.808Z', 1, '2025-06-05T02:15:31.808Z', 1, 1, NULL, true, NULL),
(36, 'P174908976', 'Test Plant 1749089769754', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:16:09.119Z', 1, '2025-06-05T02:16:09.119Z', 1, 1, NULL, true, NULL),
(37, 'P174908979', 'Test Plant 1749089793928', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:16:33.993Z', 1, '2025-06-05T02:16:33.993Z', 1, 1, NULL, true, NULL),
(1, 'P001', 'Main Factory', NULL, 1, 'Manufacturing', 'Production', NULL, 'Chicago', NULL, 'United States', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-05-17T13:44:11.172Z', 1, '2025-05-17T13:44:11.172Z', 1, 1, NULL, true, NULL),
(2, 'W001', 'East Coast Warehouse', NULL, 1, 'Warehouse', 'Storage', NULL, 'Newark', NULL, 'United States', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-05-17T13:44:11.172Z', 1, '2025-05-17T13:44:11.172Z', 1, 1, NULL, true, NULL),
(3, 'P002', 'European Production', NULL, 2, 'Manufacturing', 'Production', NULL, 'Munich', NULL, 'Germany', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-05-17T13:44:11.172Z', 1, '2025-05-17T13:44:11.172Z', 1, 1, NULL, true, NULL),
(5, 'P003', 'Berlin Production', 'Berlin Production - manufacturing facility', 2, 'manufacturing', 'production', 'Fabrikstraße 25, Berlin, 10115', NULL, NULL, 'Germany', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-05-20T04:52:26.251Z', 1, '2025-05-20T04:52:26.251Z', 1, 1, NULL, true, NULL),
(6, 'P004', 'Shanghai Facility', 'Shanghai Facility - manufacturing facility', 10, 'manufacturing', 'production', '100 Industrial Zone, Shanghai, 200000', NULL, NULL, 'China', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-05-20T04:52:26.305Z', 1, '2025-05-20T04:52:26.305Z', 1, 1, NULL, true, NULL),
(7, 'W002', 'European Warehouse', 'European Warehouse - warehouse facility', 2, 'warehouse', 'distribution', 'Logistikweg 10, Hamburg, 20095', NULL, NULL, 'Germany', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-05-20T04:52:26.370Z', 1, '2025-05-20T04:52:26.370Z', 1, 1, NULL, true, NULL),
(8, 'W003', 'Asian Distribution Hub', 'Asian Distribution Hub - warehouse facility', 10, 'warehouse', 'distribution', '200 Export Center, Shenzhen, 518000', NULL, NULL, 'China', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-05-20T04:52:26.417Z', 1, '2025-05-20T04:52:26.417Z', 1, 1, NULL, true, NULL),
(9, 'W004', 'UK Warehouse', 'UK Warehouse - warehouse facility', 11, 'warehouse', 'distribution', '15 Logistics Way, Manchester, M1 1AA', NULL, NULL, 'United Kingdom', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-05-20T04:52:26.461Z', 1, '2025-05-20T04:52:26.461Z', 1, 1, NULL, true, NULL),
(13, 'TST1', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T00:48:17.624Z', 1, '2025-06-05T00:48:17.624Z', 1, 1, NULL, true, NULL),
(15, 'PLT1749084630761', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T00:50:30.959Z', 1, '2025-06-05T00:50:30.959Z', 1, 1, NULL, true, NULL),
(16, 'PLT1749084660178', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T00:51:00.322Z', 1, '2025-06-05T00:51:00.322Z', 1, 1, NULL, true, NULL),
(17, 'P4162', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T00:51:53.417Z', 1, '2025-06-05T00:51:53.417Z', 1, 1, NULL, true, NULL),
(18, 'TP571891', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T01:56:11.962Z', 1, '2025-06-05T01:56:11.962Z', 1, 1, NULL, true, NULL),
(19, 'TP716672', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T01:58:36.728Z', 1, '2025-06-05T01:58:36.728Z', 1, 1, NULL, true, NULL),
(20, 'TP772239', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T01:59:32.302Z', 1, '2025-06-05T01:59:32.302Z', 1, 1, NULL, true, NULL),
(21, 'TP792967', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T01:59:53.009Z', 1, '2025-06-05T01:59:53.009Z', 1, 1, NULL, true, NULL),
(22, 'TP853374', 'Test Plant', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:00:53.445Z', 1, '2025-06-05T02:00:53.445Z', 1, 1, NULL, true, NULL),
(27, 'PLT002', 'Test Plant 002', NULL, 1, 'Warehouse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:10:57.800Z', 1, '2025-06-05T02:10:57.800Z', 1, 1, NULL, true, NULL),
(30, 'PLT17490896359281', 'Test Plant 1749089635928 1', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:13:57.550Z', 1, '2025-06-05T02:13:57.550Z', 1, 1, NULL, true, NULL),
(31, 'PLT17490896359282', 'Test Plant 1749089635928 2', NULL, 1, 'Warehouse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:13:57.608Z', 1, '2025-06-05T02:13:57.608Z', 1, 1, NULL, true, NULL),
(32, 'PLT17490897081901', 'Test Plant 1749089708190 1', NULL, 1, 'Manufacturing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:15:08.299Z', 1, '2025-06-05T02:15:08.299Z', 1, 1, NULL, true, NULL),
(33, 'PLT17490897081902', 'Test Plant 1749089708190 2', NULL, 1, 'Warehouse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, '2025-06-05T02:15:08.328Z', 1, '2025-06-05T02:15:08.328Z', 1, 1, NULL, true, NULL);

-- Table: production_orders (5 records)
INSERT INTO "production_orders" ("id", "order_number", "material_id", "bom_id", "plant_id", "work_center_id", "order_type", "planned_quantity", "actual_quantity", "scrap_quantity", "unit_of_measure", "planned_start_date", "planned_end_date", "actual_start_date", "actual_end_date", "priority", "status", "cost_center_id", "created_by", "released_by", "release_date", "notes", "created_at", "active", "updated_at") VALUES
(1, 'PROD-2025-001', 1, NULL, NULL, 1, 'Production', '100.000', '85.000', '0.000', NULL, '2025-06-01T00:00:00.000Z', '2025-06-15T00:00:00.000Z', NULL, NULL, 'NORMAL', 'In Progress', NULL, NULL, NULL, NULL, NULL, '2025-06-04T01:16:16.078Z', true, '2025-06-04T18:39:30.207Z'),
(2, 'PROD-2025-002', 2, NULL, NULL, 2, 'Production', '250.000', '250.000', '0.000', NULL, '2025-05-20T00:00:00.000Z', '2025-06-10T00:00:00.000Z', NULL, NULL, 'NORMAL', 'Completed', NULL, NULL, NULL, NULL, NULL, '2025-06-04T01:16:16.078Z', true, '2025-06-04T18:39:30.207Z'),
(3, 'PROD-2025-003', 3, NULL, NULL, 3, 'Production', '150.000', '0.000', '0.000', NULL, '2025-06-10T00:00:00.000Z', '2025-06-25T00:00:00.000Z', NULL, NULL, 'NORMAL', 'Planned', NULL, NULL, NULL, NULL, NULL, '2025-06-04T01:16:16.078Z', true, '2025-06-04T18:39:30.207Z'),
(4, 'PROD-2025-004', 4, NULL, NULL, 1, 'Production', '300.000', '180.000', '0.000', NULL, '2025-06-05T00:00:00.000Z', '2025-06-20T00:00:00.000Z', NULL, NULL, 'NORMAL', 'In Progress', NULL, NULL, NULL, NULL, NULL, '2025-06-04T01:16:16.078Z', true, '2025-06-04T18:39:30.207Z'),
(5, 'PROD-2025-005', 5, NULL, NULL, 2, 'Production', '75.000', '75.000', '0.000', NULL, '2025-05-25T00:00:00.000Z', '2025-06-08T00:00:00.000Z', NULL, NULL, 'NORMAL', 'Completed', NULL, NULL, NULL, NULL, NULL, '2025-06-04T01:16:16.078Z', true, '2025-06-04T18:39:30.207Z');

-- Table: production_work_orders (0 records - empty)

-- Table: products (20 records)
INSERT INTO "products" ("id", "name", "sku", "description", "price", "cost", "stock", "min_stock", "category_id", "user_id", "created_at", "updated_at", "active") VALUES
(1, 'Premium Laptop', 'TECH-001', 'High-quality premium laptop for professional use', 1299.99, 950, 25, 5, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(2, 'Office Chair', 'FURN-001', 'High-quality office chair for professional use', 249.99, 150, 50, 10, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(3, 'Standing Desk', 'FURN-002', 'High-quality standing desk for professional use', 599.99, 350, 15, 3, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(4, 'Wireless Earbuds', 'TECH-002', 'High-quality wireless earbuds for professional use', 129.99, 65, 100, 20, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(5, 'Smart Watch', 'TECH-003', 'High-quality smart watch for professional use', 349.99, 200, 30, 8, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(6, 'External Hard Drive', 'TECH-004', 'High-quality external hard drive for professional use', 89.99, 45, 40, 10, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(7, 'Wireless Mouse', 'TECH-005', 'High-quality wireless mouse for professional use', 49.99, 25, 75, 15, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(8, 'Bluetooth Speaker', 'TECH-006', 'High-quality bluetooth speaker for professional use', 79.99, 40, 60, 12, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(9, 'Monitor', 'TECH-007', 'High-quality monitor for professional use', 299.99, 180, 35, 7, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(10, 'Printer', 'TECH-008', 'High-quality printer for professional use', 179.99, 120, 20, 5, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(11, 'Smartphone', 'TECH-009', 'High-quality smartphone for professional use', 899.99, 650, 40, 8, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(12, 'Tablet', 'TECH-010', 'High-quality tablet for professional use', 499.99, 350, 30, 6, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(13, 'Desktop PC', 'TECH-011', 'High-quality desktop pc for professional use', 999.99, 750, 15, 3, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(14, 'Keyboard', 'TECH-012', 'High-quality keyboard for professional use', 69.99, 35, 50, 10, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(15, 'USB-C Hub', 'TECH-013', 'High-quality usb-c hub for professional use', 39.99, 18, 80, 20, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(16, 'Webcam', 'TECH-014', 'High-quality webcam for professional use', 59.99, 30, 45, 10, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(17, 'Microphone', 'TECH-015', 'High-quality microphone for professional use', 129.99, 65, 25, 5, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(18, 'Router', 'TECH-016', 'High-quality router for professional use', 149.99, 80, 20, 5, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(19, 'Power Bank', 'TECH-017', 'High-quality power bank for professional use', 49.99, 25, 60, 15, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true),
(20, 'VR Headset', 'TECH-018', 'High-quality vr headset for professional use', 399.99, 250, 10, 2, 1, NULL, '2025-05-21T16:28:39.279Z', '2025-05-21T16:28:39.279Z', true);

-- Table: profit_centers (20 records)
INSERT INTO "profit_centers" ("id", "profit_center", "description", "profit_center_group", "company_code", "controlling_area", "segment", "hierarchy_area", "responsible_person", "valid_from", "valid_to", "created_at", "company_code_id", "plant_id", "responsible_person_id", "active", "updated_at") VALUES
(1, 'PC001', 'Manufacturing Division', 'PRODUCTION', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(2, 'PC001-01', 'Product Line A', 'PRODUCTION', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(3, 'PC001-02', 'Product Line B', 'PRODUCTION', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(4, 'PC001-03', 'Custom Products', 'PRODUCTION', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(5, 'PC002', 'Sales Division', 'SALES', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(6, 'PC002-01', 'Domestic Sales', 'SALES', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(7, 'PC002-02', 'Export Sales', 'SALES', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(8, 'PC002-03', 'Online Sales', 'SALES', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(9, 'PC003', 'Service Division', 'SERVICE', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(10, 'PC003-01', 'Maintenance Services', 'SERVICE', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(11, 'PC003-02', 'Consulting Services', 'SERVICE', 'US01', 'US01', NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', NULL, '2025-06-03T17:58:50.654Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(12, 'PC-PROD-A', 'Product Line A - Main product profitability', 'PRODUCT_LINE', 'US01', 'US01', NULL, NULL, 'John Smith', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(13, 'PC-PROD-B', 'Product Line B - Secondary product line', 'PRODUCT_LINE', 'US01', 'US01', NULL, NULL, 'Jane Doe', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(14, 'PC-SERV', 'Service Division - Service and maintenance revenue', 'DIVISION', 'US01', 'US01', NULL, NULL, 'Mike Johnson', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(15, 'PC-REG-E', 'Eastern Region - East coast sales region', 'REGION', 'US01', 'US01', NULL, NULL, 'Sarah Davis', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(16, 'PC-REG-W', 'Western Region - West coast sales region', 'REGION', 'US01', 'US01', NULL, NULL, 'Tom Brown', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(17, 'PC-REG-C', 'Central Region - Central US sales region', 'REGION', 'US01', 'US01', NULL, NULL, 'Lisa Garcia', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(18, 'PC-EXPORT', 'Export Division - International sales and exports', 'DIVISION', 'US01', 'US01', NULL, NULL, 'David Miller', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(19, 'PC-RETAIL', 'Retail Channel - Direct retail sales', 'CHANNEL', 'US01', 'US01', NULL, NULL, 'Chris Lee', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z'),
(20, 'PC-WHSALE', 'Wholesale Channel - Wholesale and distribution', 'CHANNEL', 'US01', 'US01', NULL, NULL, 'Emily Chen', '2025-01-01T00:00:00.000Z', NULL, '2025-06-04T02:39:51.210Z', 1, NULL, NULL, true, '2025-06-04T18:39:30.325Z');

-- Table: purchase_groups (12 records)
INSERT INTO "purchase_groups" ("id", "code", "name", "description", "is_active", "created_at", "updated_at", "created_by", "updated_by", "version", "valid_from", "valid_to", "active") VALUES
(1, 'MECH', 'Mechanical Parts', 'Procurement group for mechanical components and parts', true, '2025-05-20T03:25:48.010Z', '2025-05-20T03:25:48.010Z', NULL, NULL, 1, '2025-05-20T03:25:48.010Z', NULL, true),
(2, 'ELEC', 'Electrical Components', 'Procurement group for electrical components and supplies', true, '2025-05-20T03:25:48.010Z', '2025-05-20T03:25:48.010Z', NULL, NULL, 1, '2025-05-20T03:25:48.010Z', NULL, true),
(3, 'RAW', 'Raw Materials', 'Basic raw materials used in manufacturing processes', true, '2025-05-20T03:25:48.010Z', '2025-05-20T03:25:48.010Z', NULL, NULL, 1, '2025-05-20T03:25:48.010Z', NULL, true),
(4, 'PACK', 'Packaging Materials', 'Materials used for packaging finished products', true, '2025-05-20T03:25:48.010Z', '2025-05-20T03:25:48.010Z', NULL, NULL, 1, '2025-05-20T03:25:48.010Z', NULL, true),
(5, 'TOOL', 'Tools & Equipment', 'Tools and equipment for maintenance and operations', true, '2025-05-20T03:25:48.010Z', '2025-05-20T03:25:48.010Z', NULL, NULL, 1, '2025-05-20T03:25:48.010Z', NULL, true),
(6, 'PG001', 'Raw Materials', 'Purchasing group for raw materials procurement', true, '2025-05-20T04:52:27.386Z', '2025-05-20T04:52:27.386Z', NULL, NULL, 1, '2025-05-20T04:52:27.386Z', NULL, true),
(7, 'PG002', 'Production Equipment', 'Purchasing group for manufacturing equipment', true, '2025-05-20T04:52:27.427Z', '2025-05-20T04:52:27.427Z', NULL, NULL, 1, '2025-05-20T04:52:27.427Z', NULL, true),
(8, 'PG003', 'Office Supplies', 'Purchasing group for office and administrative supplies', true, '2025-05-20T04:52:27.459Z', '2025-05-20T04:52:27.459Z', NULL, NULL, 1, '2025-05-20T04:52:27.459Z', NULL, true),
(9, 'PG004', 'IT Hardware', 'Purchasing group for computers and IT equipment', true, '2025-05-20T04:52:27.490Z', '2025-05-20T04:52:27.490Z', NULL, NULL, 1, '2025-05-20T04:52:27.490Z', NULL, true),
(10, 'PG005', 'Packaging Materials', 'Purchasing group for packaging supplies', true, '2025-05-20T04:52:27.526Z', '2025-05-20T04:52:27.526Z', NULL, NULL, 1, '2025-05-20T04:52:27.526Z', NULL, true),
(11, 'PG006', 'Services', 'Purchasing group for third-party services', true, '2025-05-20T04:52:27.560Z', '2025-05-20T04:52:27.560Z', NULL, NULL, 1, '2025-05-20T04:52:27.560Z', NULL, true),
(12, 'PG007', 'Maintenance', 'Purchasing group for maintenance supplies and services', true, '2025-05-20T04:52:27.592Z', '2025-05-20T04:52:27.592Z', NULL, NULL, 1, '2025-05-20T04:52:27.592Z', NULL, true);

-- Table: purchase_order_items (0 records - empty)

-- Table: purchase_orders (5 records)
INSERT INTO "purchase_orders" ("id", "order_number", "vendor_id", "purchase_organization_id", "company_code_id", "plant_id", "order_date", "delivery_date", "payment_terms", "currency_id", "exchange_rate", "total_amount", "tax_amount", "discount_amount", "net_amount", "status", "created_by", "approved_by", "approval_date", "notes", "created_at", "updated_at", "active", "vendor_name") VALUES
(1, 'PO-2025-001', 1, NULL, NULL, NULL, '2025-06-01T00:00:00.000Z', '2025-06-15T00:00:00.000Z', NULL, NULL, '1.0000', '25000.00', NULL, NULL, NULL, 'Approved', 1, NULL, NULL, NULL, '2025-06-04T01:15:06.542Z', '2025-06-04T01:15:06.542Z', true, NULL),
(2, 'PO-2025-002', 2, NULL, NULL, NULL, '2025-06-02T00:00:00.000Z', '2025-06-20T00:00:00.000Z', NULL, NULL, '1.0000', '18500.00', NULL, NULL, NULL, 'Pending', 1, NULL, NULL, NULL, '2025-06-04T01:15:06.542Z', '2025-06-04T01:15:06.542Z', true, NULL),
(3, 'PO-2025-003', 3, NULL, NULL, NULL, '2025-06-03T00:00:00.000Z', '2025-06-25T00:00:00.000Z', NULL, NULL, '1.0000', '42000.00', NULL, NULL, NULL, 'Draft', 1, NULL, NULL, NULL, '2025-06-04T01:15:06.542Z', '2025-06-04T01:15:06.542Z', true, NULL),
(4, 'PO-2025-004', 1, NULL, NULL, NULL, '2025-06-04T00:00:00.000Z', '2025-06-30T00:00:00.000Z', NULL, NULL, '1.0000', '15750.00', NULL, NULL, NULL, 'Approved', 1, NULL, NULL, NULL, '2025-06-04T01:15:06.542Z', '2025-06-04T01:15:06.542Z', true, NULL),
(5, 'PO-2025-005', 2, NULL, NULL, NULL, '2025-06-05T00:00:00.000Z', '2025-07-05T00:00:00.000Z', NULL, NULL, '1.0000', '33200.00', NULL, NULL, NULL, 'Pending', 1, NULL, NULL, NULL, '2025-06-04T01:15:06.542Z', '2025-06-04T01:15:06.542Z', true, NULL);

-- Table: purchase_organizations (20 records)
INSERT INTO "purchase_organizations" ("id", "code", "name", "description", "company_code_id", "currency", "purchasing_manager", "email", "phone", "address", "is_active", "created_at", "updated_at", "created_by", "updated_by", "version", "valid_from", "valid_to", "purchasing_group", "supply_type", "approval_level", "city", "state", "country", "postal_code", "status", "notes", "manager", "active") VALUES
(9, 'PO01', 'US Raw Materials Procurement', 'Purchases raw materials for US manufacturing', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-05-20T05:01:13.627Z', '2025-05-20T05:01:13.627Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, 'direct', 'production', NULL, NULL, NULL, 'USA', NULL, 'active', NULL, NULL, true),
(10, 'PO02', 'US MRO Procurement', 'Purchases maintenance supplies for US operations', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-05-20T05:01:13.677Z', '2025-05-20T05:01:13.677Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, 'indirect', 'maintenance', NULL, NULL, NULL, 'USA', NULL, 'active', NULL, NULL, true),
(11, 'PO03', 'European Raw Materials', 'Purchases raw materials for European manufacturing', 2, 'EUR', NULL, NULL, NULL, NULL, true, '2025-05-20T05:01:13.705Z', '2025-05-20T05:01:13.705Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, 'direct', 'production', NULL, NULL, NULL, 'Germany', NULL, 'active', NULL, NULL, true),
(12, 'PO04', 'European Services', 'Purchases services for European operations', 2, 'EUR', NULL, NULL, NULL, NULL, true, '2025-05-20T05:01:13.730Z', '2025-05-20T05:01:13.730Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, 'indirect', 'services', NULL, NULL, NULL, 'Germany', NULL, 'active', NULL, NULL, true),
(13, 'PO05', 'Asia Pacific Procurement', 'Handles all purchasing activities in APAC region', 10, 'CNY', NULL, NULL, NULL, NULL, true, '2025-05-20T05:01:13.754Z', '2025-05-20T05:01:13.754Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, 'direct', 'production', NULL, NULL, NULL, 'China', NULL, 'active', NULL, NULL, true),
(14, 'PO06', 'Global Capital Purchases', 'Handles all major capital expenditures globally', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-05-20T05:01:13.782Z', '2025-05-20T05:01:13.782Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, 'capital', 'equipment', NULL, NULL, NULL, 'USA', NULL, 'active', NULL, NULL, true),
(15, 'PO07', 'UK Procurement', 'Manages all procurement for UK operations', 11, 'GBP', NULL, NULL, NULL, NULL, true, '2025-05-20T05:01:13.801Z', '2025-05-20T05:01:13.801Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, 'direct', 'production', NULL, NULL, NULL, 'United Kingdom', NULL, 'active', NULL, NULL, true),
(16, 'PO08', 'Canada Procurement', 'Handles all purchasing for Canadian operations', 5, 'CAD', NULL, NULL, NULL, NULL, true, '2025-05-20T05:01:13.825Z', '2025-05-20T05:01:13.825Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, 'direct', 'production', NULL, NULL, NULL, 'Canada', NULL, 'active', NULL, NULL, true),
(17, 'NA01', 'North America Procurement', NULL, 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-05-20T21:43:20.089Z', '2025-05-20T21:43:20.089Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(18, 'EU01', 'European Procurement', NULL, 9, 'EUR', NULL, NULL, NULL, NULL, true, '2025-05-20T21:43:20.111Z', '2025-05-20T21:43:20.111Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(19, 'UK01', 'UK Procurement', NULL, 11, 'GBP', NULL, NULL, NULL, NULL, true, '2025-05-20T21:43:20.128Z', '2025-05-20T21:43:20.128Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(22, 'IN01', 'India Purchasing', NULL, 6, 'INR', NULL, NULL, NULL, NULL, true, '2025-05-20T21:43:20.460Z', '2025-05-20T21:43:20.460Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(24, 'GLOB', 'Global Procurement', NULL, 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-05-20T21:43:20.621Z', '2025-05-20T21:43:20.621Z', NULL, NULL, 1, '2025-05-20T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(25, 'TEST001', 'Test Purchase Org', 'Test purchase organization', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-06-05T01:50:39.933Z', '2025-06-05T01:50:39.933Z', NULL, NULL, 1, '2025-06-05T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', 'Test notes', NULL, true),
(26, 'PO571891', 'Test Purchase Org', 'Test', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-06-05T01:56:12.089Z', '2025-06-05T01:56:12.089Z', NULL, NULL, 1, '2025-06-05T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(27, 'PO716672', 'Test Purchase Org', 'Test', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-06-05T01:58:36.826Z', '2025-06-05T01:58:36.826Z', NULL, NULL, 1, '2025-06-05T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(28, 'PO772239', 'Test Purchase Org', 'Test', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-06-05T01:59:32.407Z', '2025-06-05T01:59:32.407Z', NULL, NULL, 1, '2025-06-05T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(29, 'PO792967', 'Test Purchase Org', 'Test', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-06-05T01:59:53.093Z', '2025-06-05T01:59:53.093Z', NULL, NULL, 1, '2025-06-05T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(30, 'PO853374', 'Test Purchase Org', 'Test', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-06-05T02:00:53.558Z', '2025-06-05T02:00:53.558Z', NULL, NULL, 1, '2025-06-05T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true),
(33, 'PO17490897', 'Test Purchase Org 1749089708190', 'Test purchase organization', 1, 'USD', NULL, NULL, NULL, NULL, true, '2025-06-05T02:15:08.459Z', '2025-06-05T02:15:08.459Z', NULL, NULL, 1, '2025-06-05T00:00:00.000Z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', NULL, NULL, true);

-- Table: purchase_requests (0 records - empty)

-- Table: quote_approvals (10 records)
INSERT INTO "quote_approvals" ("id", "quote_id", "requested_by", "requested_at", "status", "current_approver", "approved_by", "approved_at", "rejected_by", "rejected_at", "rejection_reason", "comments", "approval_level", "created_at", "updated_at", "active") VALUES
(7, 7, 2, '2025-04-25T13:35:46.205Z', 'Rejected', NULL, NULL, NULL, 1, '2025-04-28T13:35:46.205Z', 'Price is too high or terms need adjustment.', 'Quote needs revision.', 'Level 3', '2025-05-22T13:35:46.206Z', '2025-05-22T13:35:46.206Z', true),
(8, 5, 1, '2025-05-12T13:35:46.235Z', 'Rejected', NULL, NULL, NULL, 2, '2025-05-17T13:35:46.235Z', 'Price is too high or terms need adjustment.', 'Quote needs revision.', 'Level 2', '2025-05-22T13:35:46.235Z', '2025-05-22T13:35:46.235Z', true),
(9, 7, 2, '2025-05-15T13:35:46.254Z', 'In Review', 2, NULL, NULL, NULL, NULL, NULL, 'Currently reviewing details.', 'Level 2', '2025-05-22T13:35:46.254Z', '2025-05-22T13:35:46.254Z', true),
(10, 7, 1, '2025-04-25T13:35:46.271Z', 'In Review', 1, NULL, NULL, NULL, NULL, NULL, 'Currently reviewing details.', 'Level 3', '2025-05-22T13:35:46.271Z', '2025-05-22T13:35:46.271Z', true),
(11, 6, 2, '2025-05-17T13:35:46.293Z', 'Rejected', NULL, NULL, NULL, 3, '2025-05-21T13:35:46.293Z', 'Price is too high or terms need adjustment.', 'Quote needs revision.', 'Level 2', '2025-05-22T13:35:46.293Z', '2025-05-22T13:35:46.293Z', true),
(12, 1, 1, '2025-05-22T13:35:46.329Z', 'Approved', NULL, 1, '2025-05-23T13:35:46.329Z', NULL, NULL, NULL, 'Quote looks good, approved.', 'Level 2', '2025-05-22T13:35:46.329Z', '2025-05-22T13:35:46.329Z', true),
(13, 7, 2, '2025-05-05T13:35:46.346Z', 'Approved', NULL, 3, '2025-05-08T13:35:46.346Z', NULL, NULL, NULL, 'Quote looks good, approved.', 'Level 1', '2025-05-22T13:35:46.346Z', '2025-05-22T13:35:46.346Z', true),
(14, 2, 1, '2025-04-27T13:35:46.363Z', 'In Review', 2, NULL, NULL, NULL, NULL, NULL, 'Currently reviewing details.', 'Level 2', '2025-05-22T13:35:46.363Z', '2025-05-22T13:35:46.363Z', true),
(15, 1, 2, '2025-05-04T13:35:46.385Z', 'Pending', 2, NULL, NULL, NULL, NULL, NULL, 'Awaiting review', 'Level 2', '2025-05-22T13:35:46.385Z', '2025-05-22T13:35:46.385Z', true),
(16, 2, 1, '2025-04-23T13:35:46.404Z', 'In Review', 2, NULL, NULL, NULL, NULL, NULL, 'Currently reviewing details.', 'Level 3', '2025-05-22T13:35:46.404Z', '2025-05-22T13:35:46.404Z', true);

-- Table: quote_items (10 records)
INSERT INTO "quote_items" ("id", "quote_id", "product_id", "description", "quantity", "unit_price", "discount_percent", "tax_percent", "line_total", "created_at", "updated_at", "active") VALUES
(1, 1, 13, 'Desktop PC', 4, '999.99', '1.00', '7.00', '4237.16', '2025-05-21T23:38:47.755Z', '2025-05-21T23:38:47.755Z', true),
(2, 1, 11, 'Smartphone', 4, '899.99', '2.00', '7.00', '3774.92', '2025-05-21T23:38:47.774Z', '2025-05-21T23:38:47.774Z', true),
(3, 2, 1, 'Premium Laptop', 4, '1299.99', '8.00', '7.00', '5118.84', '2025-05-21T23:38:47.809Z', '2025-05-21T23:38:47.809Z', true),
(4, 3, 18, 'Router', 1, '149.99', '0.00', '7.00', '160.49', '2025-05-21T23:38:47.844Z', '2025-05-21T23:38:47.844Z', true),
(5, 4, 8, 'Bluetooth Speaker', 1, '79.99', '7.00', '7.00', '79.60', '2025-05-21T23:38:47.880Z', '2025-05-21T23:38:47.880Z', true),
(6, 5, 1, 'Premium Laptop', 2, '1299.99', '6.00', '7.00', '2615.06', '2025-05-21T23:38:47.917Z', '2025-05-21T23:38:47.917Z', true),
(7, 5, 16, 'Webcam', 4, '59.99', '7.00', '7.00', '238.78', '2025-05-21T23:38:47.935Z', '2025-05-21T23:38:47.935Z', true),
(8, 6, 5, 'Smart Watch', 1, '349.99', '8.00', '7.00', '344.53', '2025-05-21T23:38:47.970Z', '2025-05-21T23:38:47.970Z', true),
(9, 7, 18, 'Router', 1, '149.99', '8.00', '7.00', '147.65', '2025-05-21T23:38:48.005Z', '2025-05-21T23:38:48.005Z', true),
(10, 7, 16, 'Webcam', 1, '59.99', '4.00', '7.00', '61.62', '2025-05-21T23:38:48.023Z', '2025-05-21T23:38:48.023Z', true);

-- Table: quotes (7 records)
INSERT INTO "quotes" ("id", "quote_number", "opportunity_id", "customer_id", "status", "valid_until", "total_amount", "discount_amount", "tax_amount", "grand_total", "terms", "notes", "assigned_to", "approval_status", "approved_by", "approved_at", "rejected_reason", "created_at", "updated_at", "active") VALUES
(1, 'Q-10000', 4, NULL, 'Draft', '2025-07-20T23:38:47.725Z', '31422.69', '123.42', '2190.95', '33490.22', 'Net 30 days from invoice date', 'Quote for Taylor Consulting - Professional Services Solution', NULL, 'Pending', NULL, NULL, NULL, '2025-05-21T23:38:47.735Z', '2025-05-21T23:38:47.735Z', true),
(2, 'Q-10001', 6, NULL, 'Draft', '2025-07-20T23:38:47.725Z', '36841.54', '2387.72', '2411.77', '36865.58', 'Net 30 days from invoice date', 'Quote for White Industries - Manufacturing Solution', NULL, 'Pending', NULL, NULL, NULL, '2025-05-21T23:38:47.791Z', '2025-05-21T23:38:47.791Z', true),
(3, 'Q-10002', 7, NULL, 'Draft', '2025-07-20T23:38:47.725Z', '69242.43', '2302.19', '4685.82', '71626.05', 'Net 30 days from invoice date', 'Quote for Jones Retail - Retail Solution', NULL, 'Pending', NULL, NULL, NULL, '2025-05-21T23:38:47.827Z', '2025-05-21T23:38:47.827Z', true),
(4, 'Q-10003', 8, NULL, 'Draft', '2025-07-20T23:38:47.725Z', '86299.49', '7798.41', '5495.08', '83996.15', 'Net 30 days from invoice date', 'Quote for Clark Financial - Financial Services Solution', NULL, 'Pending', NULL, NULL, NULL, '2025-05-21T23:38:47.862Z', '2025-05-21T23:38:47.862Z', true),
(5, 'Q-10004', 13, NULL, 'Draft', '2025-07-20T23:38:47.725Z', '24764.53', '1062.54', '1659.14', '25361.13', 'Net 30 days from invoice date', 'Quote for Taylor Consulting - Additional Professional Services Project', NULL, 'Pending', NULL, NULL, NULL, '2025-05-21T23:38:47.899Z', '2025-05-21T23:38:47.899Z', true),
(6, 'Q-10005', 14, NULL, 'Draft', '2025-07-20T23:38:47.725Z', '14741.10', '1285.18', '941.92', '14397.84', 'Net 30 days from invoice date', 'Quote for Lee Education Services - Additional Education Project', NULL, 'Pending', NULL, NULL, NULL, '2025-05-21T23:38:47.952Z', '2025-05-21T23:38:47.952Z', true),
(7, 'Q-10006', 16, NULL, 'Draft', '2025-07-20T23:38:47.725Z', '14007.43', '1287.56', '890.39', '13610.26', 'Net 30 days from invoice date', 'Quote for Miller Tech Solutions - Additional Technology Project', NULL, 'Pending', NULL, NULL, NULL, '2025-05-21T23:38:47.988Z', '2025-05-21T23:38:47.988Z', true);

-- Table: regions (4 records)
INSERT INTO "regions" ("id", "code", "name", "description", "is_active", "created_at", "updated_at", "active") VALUES
(1, 'NA', 'North America', 'United States, Canada, and Mexico', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(2, 'SA', 'South America', 'South American countries', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(3, 'EMEA', 'Europe, Middle East, and Africa', 'Europe, Middle East, and Africa regions', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true),
(4, 'APAC', 'Asia Pacific', 'Asia, Australia, and Pacific Islands', true, '2025-05-20T22:09:35.140Z', '2025-05-20T22:09:35.140Z', true);

-- Table: reports (5 records)
INSERT INTO "reports" ("id", "name", "description", "sql_query", "chart_config", "category", "created_at", "updated_at", "active") VALUES
(1, 'Sales by Month', 'Monthly sales revenue analysis', 'SELECT 
        DATE_TRUNC(''month'', order_date) as month,
        COUNT(*) as order_count,
        SUM(total_amount) as total_revenue
    FROM sales_orders 
    WHERE order_date >= CURRENT_DATE - INTERVAL ''12 months''
    GROUP BY DATE_TRUNC(''month'', order_date)
    ORDER BY month', [object Object], 'sales', '2025-06-04T17:17:13.453Z', '2025-06-04T17:17:13.453Z', true),
(2, 'Top Customers by Revenue', 'Customers with highest revenue contribution', 'SELECT 
        c.name as customer_name,
        COUNT(so.id) as order_count,
        SUM(so.total_amount) as total_revenue
    FROM customers c
    JOIN sales_orders so ON c.id = so.customer_id
    GROUP BY c.id, c.name
    ORDER BY total_revenue DESC
    LIMIT 10', [object Object], 'sales', '2025-06-04T17:17:13.453Z', '2025-06-04T17:17:13.453Z', true),
(3, 'Inventory Levels by Category', 'Current inventory levels grouped by material category', 'SELECT 
        cat.name as category_name,
        COUNT(m.id) as material_count,
        SUM(inv.quantity) as total_quantity
    FROM categories cat
    JOIN materials m ON cat.id = m.category_id
    JOIN inventory inv ON m.id = inv.material_id
    GROUP BY cat.id, cat.name
    ORDER BY total_quantity DESC', [object Object], 'inventory', '2025-06-04T17:17:13.453Z', '2025-06-04T17:17:13.453Z', true),
(4, 'Cost Center Expenses', 'Expenses by cost center for current year', 'SELECT 
        cc.name as cost_center,
        SUM(e.amount) as total_expenses
    FROM cost_centers cc
    LEFT JOIN expenses e ON cc.id = e.cost_center_id
    WHERE e.expense_date >= DATE_TRUNC(''year'', CURRENT_DATE)
    GROUP BY cc.id, cc.name
    ORDER BY total_expenses DESC', [object Object], 'finance', '2025-06-04T17:17:13.453Z', '2025-06-04T17:17:13.453Z', true),
(5, 'Purchase Orders by Vendor', 'Purchase order volumes by vendor', 'SELECT 
        v.name as vendor_name,
        COUNT(po.id) as order_count,
        SUM(po.total_amount) as total_amount
    FROM vendors v
    JOIN purchase_orders po ON v.id = po.vendor_id
    WHERE po.order_date >= CURRENT_DATE - INTERVAL ''6 months''
    GROUP BY v.id, v.name
    ORDER BY total_amount DESC
    LIMIT 10', [object Object], 'purchase', '2025-06-04T17:17:13.453Z', '2025-06-04T17:17:13.453Z', true);

-- Table: sales_customer_contacts (11 records)
INSERT INTO "sales_customer_contacts" ("id", "customer_id", "name", "position", "email", "phone", "is_primary", "notes", "created_at", "updated_at", "active") VALUES
(1, 1, 'John Smith', 'Primary Contact', 'john.smith@technova.com', '(555) 123-4567', true, NULL, '2025-05-23T02:20:10.142Z', '2025-05-23T02:20:10.142Z', true),
(2, 2, 'Sarah Johnson', 'Primary Contact', 'sarah@elevatesolutions.com', '(555) 234-5678', true, NULL, '2025-05-23T02:20:10.160Z', '2025-05-23T02:20:10.160Z', true),
(3, 2, 'Tom Baker', 'Finance Director', 'tom@elevatesolutions.com', '(555) 541-3019', false, NULL, '2025-05-23T02:20:10.176Z', '2025-05-23T02:20:10.176Z', true),
(4, 3, 'Michael Chen', 'Primary Contact', 'michael@datawave.com', '(555) 345-6789', true, NULL, '2025-05-23T02:20:10.192Z', '2025-05-23T02:20:10.192Z', true),
(5, 3, 'Tom Baker', 'Technical Lead', 'tom@datawave.com', '(555) 736-3307', false, NULL, '2025-05-23T02:20:10.207Z', '2025-05-23T02:20:10.207Z', true),
(6, 4, 'Emily Rodriguez', 'Primary Contact', 'emily@quantumsystems.com', '(555) 456-7890', true, NULL, '2025-05-23T02:20:10.223Z', '2025-05-23T02:20:10.223Z', true),
(7, 4, 'Jessica Lee', 'Technical Lead', 'jessica@quantumsystems.com', '(555) 464-2074', false, NULL, '2025-05-23T02:20:10.240Z', '2025-05-23T02:20:10.240Z', true),
(8, 5, 'David Wilson', 'Primary Contact', 'david@arcticinnovations.com', '(555) 567-8901', true, NULL, '2025-05-23T02:20:10.257Z', '2025-05-23T02:20:10.257Z', true),
(9, 5, 'Jessica Lee', 'Technical Lead', 'jessica@arcticinnovations.com', '(555) 186-3388', false, NULL, '2025-05-23T02:20:10.273Z', '2025-05-23T02:20:10.273Z', true),
(10, 6, 'Lisa Morgan', 'Primary Contact', 'lisa@sunrisehealthcare.com', '(555) 678-9012', true, NULL, '2025-05-23T02:20:10.289Z', '2025-05-23T02:20:10.289Z', true),
(11, 7, 'Robert Brown', 'Primary Contact', 'robert@velocitylogistics.com', '(555) 789-0123', true, NULL, '2025-05-23T02:20:10.305Z', '2025-05-23T02:20:10.305Z', true);

-- Table: sales_customers (7 records)
INSERT INTO "sales_customers" ("id", "customer_number", "company_name", "contact_person", "email", "phone", "website", "industry", "customer_type", "billing_address", "shipping_address", "tax_id", "payment_terms", "credit_limit", "status", "notes", "created_at", "updated_at", "active") VALUES
(1, 'CUST-1001', 'TechNova Inc', 'John Smith', 'john.smith@technova.com', '(555) 123-4567', 'www.technova.com', 'Technology', 'Business', NULL, NULL, NULL, NULL, '50000.00', 'Active', NULL, '2025-05-23T02:20:10.071Z', '2025-05-23T02:20:10.071Z', true),
(2, 'CUST-1002', 'Elevate Solutions', 'Sarah Johnson', 'sarah@elevatesolutions.com', '(555) 234-5678', 'www.elevatesolutions.com', 'Consulting', 'Business', NULL, NULL, NULL, NULL, '35000.00', 'Active', NULL, '2025-05-23T02:20:10.071Z', '2025-05-23T02:20:10.071Z', true),
(3, 'CUST-1003', 'DataWave Analytics', 'Michael Chen', 'michael@datawave.com', '(555) 345-6789', 'www.datawave.com', 'Data Services', 'Business', NULL, NULL, NULL, NULL, '75000.00', 'Active', NULL, '2025-05-23T02:20:10.071Z', '2025-05-23T02:20:10.071Z', true),
(4, 'CUST-1004', 'Quantum Systems', 'Emily Rodriguez', 'emily@quantumsystems.com', '(555) 456-7890', 'www.quantumsystems.com', 'Manufacturing', 'Business', NULL, NULL, NULL, NULL, '100000.00', 'Active', NULL, '2025-05-23T02:20:10.071Z', '2025-05-23T02:20:10.071Z', true),
(5, 'CUST-1005', 'Arctic Innovations', 'David Wilson', 'david@arcticinnovations.com', '(555) 567-8901', 'www.arcticinnovations.com', 'Research', 'Business', NULL, NULL, NULL, NULL, '25000.00', 'Active', NULL, '2025-05-23T02:20:10.071Z', '2025-05-23T02:20:10.071Z', true),
(6, 'CUST-1006', 'Sunrise Healthcare', 'Lisa Morgan', 'lisa@sunrisehealthcare.com', '(555) 678-9012', 'www.sunrisehealthcare.com', 'Healthcare', 'Business', NULL, NULL, NULL, NULL, '40000.00', 'Inactive', NULL, '2025-05-23T02:20:10.071Z', '2025-05-23T02:20:10.071Z', true),
(7, 'CUST-1007', 'Velocity Logistics', 'Robert Brown', 'robert@velocitylogistics.com', '(555) 789-0123', 'www.velocitylogistics.com', 'Transportation', 'Business', NULL, NULL, NULL, NULL, '60000.00', 'Active', NULL, '2025-05-23T02:20:10.071Z', '2025-05-23T02:20:10.071Z', true);

-- Table: sales_invoice_items (9 records)
INSERT INTO "sales_invoice_items" ("id", "invoice_id", "product_name", "description", "quantity", "unit_price", "discount_percent", "tax_percent", "subtotal", "created_at", "updated_at", "active") VALUES
(1, 1, 'Enterprise SaaS License', 'Annual subscription', 5, '1299.99', '0.00', '0.00', '6499.95', '2025-05-23T02:20:07.133Z', '2025-05-23T02:20:07.133Z', true),
(2, 2, 'Network Infrastructure', 'Network hardware and setup', 2, '2499.50', '0.00', '0.00', '4999.00', '2025-05-23T02:20:07.151Z', '2025-05-23T02:20:07.151Z', true),
(3, 3, 'Data Analytics Platform', 'Business intelligence tools', 1, '1499.75', '0.00', '0.00', '1499.75', '2025-05-23T02:20:07.167Z', '2025-05-23T02:20:07.167Z', true),
(4, 3, 'Data Analytics Platform', 'Business intelligence tools', 3, '1499.75', '0.00', '0.00', '4499.25', '2025-05-23T02:20:07.183Z', '2025-05-23T02:20:07.183Z', true),
(5, 3, 'Cloud Security Package', 'Advanced security suite', 4, '899.50', '0.00', '0.00', '3598.00', '2025-05-23T02:20:07.198Z', '2025-05-23T02:20:07.198Z', true),
(6, 4, 'Cloud Security Package', 'Advanced security suite', 5, '899.50', '0.00', '0.00', '4497.50', '2025-05-23T02:20:07.214Z', '2025-05-23T02:20:07.214Z', true),
(7, 4, 'Cloud Security Package', 'Advanced security suite', 4, '899.50', '0.00', '0.00', '3598.00', '2025-05-23T02:20:07.230Z', '2025-05-23T02:20:07.230Z', true),
(8, 5, 'Mobile Device Management', 'Enterprise mobility solution', 1, '699.99', '0.00', '0.00', '699.99', '2025-05-23T02:20:07.246Z', '2025-05-23T02:20:07.246Z', true),
(9, 5, 'Mobile Device Management', 'Enterprise mobility solution', 3, '699.99', '0.00', '0.00', '2099.97', '2025-05-23T02:20:07.262Z', '2025-05-23T02:20:07.262Z', true);

-- Table: sales_invoices (5 records)
INSERT INTO "sales_invoices" ("id", "invoice_number", "order_id", "customer_name", "invoice_date", "due_date", "status", "total_amount", "discount_amount", "tax_amount", "grand_total", "paid_amount", "payment_method", "payment_date", "notes", "created_by", "created_at", "updated_at", "active") VALUES
(1, 'INV-2025-1001', NULL, 'TechNova Inc', '2025-05-03T02:20:07.072Z', '2025-05-18T02:20:07.072Z', 'Paid', '5649.75', '0.00', '0.00', '5932.24', '5932.24', 'Credit Card', '2025-05-16T02:20:07.072Z', NULL, NULL, '2025-05-23T02:20:07.072Z', '2025-05-23T02:20:07.072Z', true),
(2, 'INV-2025-1002', NULL, 'Elevate Solutions', '2025-05-05T02:20:07.072Z', '2025-05-20T02:20:07.072Z', 'Paid', '2375.50', '0.00', '0.00', '2494.28', '2494.28', 'Bank Transfer', '2025-05-17T02:20:07.072Z', NULL, NULL, '2025-05-23T02:20:07.072Z', '2025-05-23T02:20:07.072Z', true),
(3, 'INV-2025-1003', NULL, 'DataWave Analytics', '2025-05-08T02:20:07.072Z', '2025-06-07T02:20:07.072Z', 'Partially Paid', '8925.33', '0.00', '0.00', '9371.60', '4000.00', 'Bank Transfer', '2025-05-13T02:20:07.072Z', NULL, NULL, '2025-05-23T02:20:07.072Z', '2025-05-23T02:20:07.072Z', true),
(4, 'INV-2025-1004', NULL, 'Quantum Systems', '2025-05-13T02:20:07.072Z', '2025-06-12T02:20:07.072Z', 'Unpaid', '3450.20', '0.00', '0.00', '3622.71', '0.00', NULL, NULL, NULL, NULL, '2025-05-23T02:20:07.072Z', '2025-05-23T02:20:07.072Z', true),
(5, 'INV-2025-1005', NULL, 'Arctic Innovations', '2025-05-16T02:20:07.072Z', '2025-06-15T02:20:07.072Z', 'Unpaid', '1875.60', '0.00', '0.00', '1969.38', '0.00', NULL, NULL, NULL, NULL, '2025-05-23T02:20:07.072Z', '2025-05-23T02:20:07.072Z', true);

-- Table: sales_order_items (11 records)
INSERT INTO "sales_order_items" ("id", "order_id", "product_id", "product_name", "quantity", "unit_price", "discount_percent", "tax_percent", "subtotal", "created_at", "updated_at", "active") VALUES
(1, 1, NULL, 'Network Infrastructure', 4, '2499.50', '0.00', '0.00', '9998.00', '2025-05-23T02:19:58.997Z', '2025-05-23T02:19:58.997Z', true),
(2, 1, NULL, 'Enterprise SaaS License', 4, '1299.99', '0.00', '0.00', '5199.96', '2025-05-23T02:19:59.015Z', '2025-05-23T02:19:59.015Z', true),
(3, 2, NULL, 'Cloud Security Package', 5, '899.50', '0.00', '0.00', '4497.50', '2025-05-23T02:19:59.031Z', '2025-05-23T02:19:59.031Z', true),
(4, 3, NULL, 'Enterprise SaaS License', 5, '1299.99', '0.00', '0.00', '6499.95', '2025-05-23T02:19:59.047Z', '2025-05-23T02:19:59.047Z', true),
(5, 3, NULL, 'Enterprise SaaS License', 5, '1299.99', '0.00', '0.00', '6499.95', '2025-05-23T02:19:59.063Z', '2025-05-23T02:19:59.063Z', true),
(6, 4, NULL, 'Cloud Security Package', 3, '899.50', '0.00', '0.00', '2698.50', '2025-05-23T02:19:59.079Z', '2025-05-23T02:19:59.079Z', true),
(7, 4, NULL, 'Cloud Security Package', 5, '899.50', '0.00', '0.00', '4497.50', '2025-05-23T02:19:59.094Z', '2025-05-23T02:19:59.094Z', true),
(8, 4, NULL, 'Data Analytics Platform', 5, '1499.75', '0.00', '0.00', '7498.75', '2025-05-23T02:19:59.110Z', '2025-05-23T02:19:59.110Z', true),
(9, 5, NULL, 'Data Analytics Platform', 4, '1499.75', '0.00', '0.00', '5999.00', '2025-05-23T02:19:59.126Z', '2025-05-23T02:19:59.126Z', true),
(10, 5, NULL, 'Enterprise SaaS License', 3, '1299.99', '0.00', '0.00', '3899.97', '2025-05-23T02:19:59.142Z', '2025-05-23T02:19:59.142Z', true),
(11, 5, NULL, 'Enterprise SaaS License', 5, '1299.99', '0.00', '0.00', '6499.95', '2025-05-23T02:19:59.158Z', '2025-05-23T02:19:59.158Z', true);

-- Table: sales_orders (10 records)
INSERT INTO "sales_orders" ("id", "order_number", "customer_id", "customer_name", "order_date", "delivery_date", "status", "total_amount", "payment_status", "shipping_address", "billing_address", "notes", "created_by", "created_at", "updated_at", "plant_id", "sales_org_id", "company_code_id", "currency_id", "active") VALUES
(1, 'SO-2025-1001', 1, 'TechNova Inc', '2025-05-10T02:19:58.867Z', '2025-05-30T02:19:58.867Z', 'Confirmed', '5649.75', 'Paid', '123 Tech Park, San Francisco, CA', '123 Tech Park, San Francisco, CA', NULL, NULL, '2025-05-23T02:19:58.867Z', '2025-05-23T02:19:58.867Z', 1, 8, 1, NULL, true),
(2, 'SO-2025-1002', 2, 'Elevate Solutions', '2025-05-12T02:19:58.867Z', '2025-05-28T02:19:58.867Z', 'Processing', '2375.50', 'Paid', '456 Business Ave, Seattle, WA', '456 Business Ave, Seattle, WA', NULL, NULL, '2025-05-23T02:19:58.867Z', '2025-05-23T02:19:58.867Z', 1, 8, 1, NULL, true),
(3, 'SO-2025-1003', 3, 'DataWave Analytics', '2025-05-15T02:19:58.867Z', '2025-06-02T02:19:58.867Z', 'Processing', '8925.33', 'Partial', '789 Data Drive, Boston, MA', '789 Data Drive, Boston, MA', NULL, NULL, '2025-05-23T02:19:58.867Z', '2025-05-23T02:19:58.867Z', 1, 8, 1, NULL, true),
(4, 'SO-2025-1004', 4, 'Quantum Systems', '2025-05-18T02:19:58.867Z', '2025-06-06T02:19:58.867Z', 'Pending', '3450.20', 'Unpaid', '101 Quantum Blvd, Austin, TX', '101 Quantum Blvd, Austin, TX', NULL, NULL, '2025-05-23T02:19:58.867Z', '2025-05-23T02:19:58.867Z', 1, 8, 1, NULL, true),
(5, 'SO-2025-1005', 5, 'Arctic Innovations', '2025-05-20T02:19:58.867Z', '2025-05-30T02:19:58.867Z', 'Confirmed', '1875.60', 'Paid', '202 Ice Street, Chicago, IL', '202 Ice Street, Chicago, IL', NULL, NULL, '2025-05-23T02:19:58.867Z', '2025-05-23T02:19:58.867Z', 1, 8, 1, NULL, true),
(7, 'SO-2025-0006', NULL, 'CUST001', '2025-06-05T00:43:35.922Z', NULL, 'open', '0.00', 'Unpaid', NULL, NULL, NULL, NULL, '2025-06-05T00:43:35.922Z', '2025-06-05T00:43:35.922Z', NULL, NULL, NULL, NULL, true),
(8, 'SO-2025-0007', NULL, 'CUST001', '2025-06-05T00:46:19.478Z', NULL, 'open', '0.00', 'Unpaid', NULL, NULL, NULL, NULL, '2025-06-05T00:46:19.478Z', '2025-06-05T00:46:19.478Z', NULL, NULL, NULL, NULL, true),
(9, 'SO-2025-0008', NULL, 'Production Customer 1', '2025-06-05T00:46:56.266Z', NULL, 'open', '1000.00', 'Unpaid', NULL, NULL, NULL, NULL, '2025-06-05T00:46:56.266Z', '2025-06-05T00:46:56.266Z', NULL, NULL, NULL, NULL, true),
(10, 'SO-2025-0009', NULL, 'CUST001', '2025-06-05T00:48:18.572Z', NULL, 'open', '0.00', 'Unpaid', NULL, NULL, NULL, NULL, '2025-06-05T00:48:18.572Z', '2025-06-05T00:48:18.572Z', NULL, NULL, NULL, NULL, true),
(11, 'SO-2025-0010', NULL, 'CUST001', '2025-06-05T00:49:24.064Z', NULL, 'open', '0.00', 'Unpaid', NULL, NULL, NULL, NULL, '2025-06-05T00:49:24.064Z', '2025-06-05T00:49:24.064Z', NULL, NULL, NULL, NULL, true);

-- Table: sales_organizations (19 records)
INSERT INTO "sales_organizations" ("id", "code", "name", "description", "company_code_id", "currency", "region", "distribution_channel", "industry", "address", "city", "state", "country", "postal_code", "phone", "email", "manager", "status", "is_active", "notes", "created_at", "created_by", "updated_at", "updated_by", "version", "active") VALUES
(8, 'SO01', 'US Consumer Retail', 'Manages US retail consumer sales', 1, 'USD', 'North America', 'retail', 'consumer', NULL, NULL, NULL, 'USA', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:13.871Z', NULL, '2025-05-20T05:01:13.871Z', NULL, 1, true),
(9, 'SO02', 'US B2B Sales', 'Handles direct business-to-business sales in US', 1, 'USD', 'North America', 'direct', 'industrial', NULL, NULL, NULL, 'USA', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:13.903Z', NULL, '2025-05-20T05:01:13.903Z', NULL, 1, true),
(10, 'SO03', 'US eCommerce', 'Manages all online sales channels in US', 1, 'USD', 'North America', 'online', 'consumer', NULL, NULL, NULL, 'USA', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:13.923Z', NULL, '2025-05-20T05:01:13.923Z', NULL, 1, true),
(11, 'SO04', 'European Retail', 'Manages European retail sales operations', 2, 'EUR', 'EMEA', 'retail', 'consumer', NULL, NULL, NULL, 'Germany', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:13.949Z', NULL, '2025-05-20T05:01:13.949Z', NULL, 1, true),
(12, 'SO05', 'European Wholesale', 'Handles wholesale distribution in Europe', 2, 'EUR', 'EMEA', 'wholesale', 'industrial', NULL, NULL, NULL, 'Germany', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:13.967Z', NULL, '2025-05-20T05:01:13.967Z', NULL, 1, true),
(13, 'SO06', 'China Retail', 'Manages retail sales operations in China', 10, 'CNY', 'APAC', 'retail', 'consumer', NULL, NULL, NULL, 'China', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:13.985Z', NULL, '2025-05-20T05:01:13.985Z', NULL, 1, true),
(14, 'SO07', 'APAC Distribution', 'Handles distribution across Asia Pacific region', 10, 'CNY', 'APAC', 'wholesale', 'mixed', NULL, NULL, NULL, 'China', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:14.008Z', NULL, '2025-05-20T05:01:14.008Z', NULL, 1, true),
(15, 'SO08', 'UK Consumer Sales', 'Manages retail consumer sales in UK', 11, 'GBP', 'EMEA', 'retail', 'consumer', NULL, NULL, NULL, 'United Kingdom', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:14.030Z', NULL, '2025-05-20T05:01:14.030Z', NULL, 1, true),
(16, 'SO09', 'Canada Sales', 'Handles all sales operations in Canada', 5, 'CAD', 'North America', 'mixed', 'mixed', NULL, NULL, NULL, 'Canada', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T05:01:14.049Z', NULL, '2025-05-20T05:01:14.049Z', NULL, 1, true),
(17, 'US01', 'US East Sales', NULL, 1, 'USD', NULL, NULL, NULL, NULL, NULL, NULL, 'US', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T21:43:19.296Z', NULL, '2025-05-20T21:43:19.296Z', NULL, 1, true),
(19, 'CA01', 'Canada Sales', NULL, 5, 'CAD', NULL, NULL, NULL, NULL, NULL, NULL, 'CA', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T21:43:19.477Z', NULL, '2025-05-20T21:43:19.477Z', NULL, 1, true),
(20, 'UK01', 'UK Sales Division', NULL, 11, 'GBP', NULL, NULL, NULL, NULL, NULL, NULL, 'GB', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T21:43:19.499Z', NULL, '2025-05-20T21:43:19.499Z', NULL, 1, true),
(21, 'EU01', 'European Sales', NULL, 9, 'EUR', NULL, NULL, NULL, NULL, NULL, NULL, 'EU', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T21:43:19.516Z', NULL, '2025-05-20T21:43:19.516Z', NULL, 1, true),
(24, 'IN01', 'India Sales Division', NULL, 6, 'INR', NULL, NULL, NULL, NULL, NULL, NULL, 'IN', NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-05-20T21:43:19.889Z', NULL, '2025-05-20T21:43:19.889Z', NULL, 1, true),
(26, 'SO1749089635928', 'Test Sales Org 1749089635928', 'Test sales organization', 1, 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-06-05T02:13:59.925Z', NULL, '2025-06-05T02:13:59.925Z', NULL, 1, true),
(27, 'SO1749089708190', 'Test Sales Org 1749089708190', 'Test sales organization', 1, 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-06-05T02:15:08.488Z', NULL, '2025-06-05T02:15:08.488Z', NULL, 1, true),
(28, 'SO1749089731713', 'Test Sales Org 1749089731713', 'Test sales organization', 1, 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-06-05T02:15:32.041Z', NULL, '2025-06-05T02:15:32.041Z', NULL, 1, true),
(29, 'SO17490897', 'Test SO 1749089769754', 'Test sales organization', 1, 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-06-05T02:16:09.752Z', NULL, '2025-06-05T02:16:09.752Z', NULL, 1, true),
(31, 'SP01', 'SP001 test', '', 2, 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', true, NULL, '2025-06-05T02:18:50.819Z', NULL, '2025-06-05T02:18:50.819Z', NULL, 1, true);

-- Table: sales_quote_items (12 records)
INSERT INTO "sales_quote_items" ("id", "quote_id", "product_name", "description", "quantity", "unit_price", "discount_percent", "tax_percent", "subtotal", "created_at", "updated_at", "active") VALUES
(1, 1, 'Technical Support Plan', '24/7 technical support', 2, '499.99', '0.00', '0.00', '999.98', '2025-05-23T02:20:05.446Z', '2025-05-23T02:20:05.446Z', true),
(2, 1, 'Cloud Security Package', 'Advanced security suite', 5, '899.50', '0.00', '0.00', '4497.50', '2025-05-23T02:20:05.464Z', '2025-05-23T02:20:05.464Z', true),
(3, 2, 'Data Analytics Platform', 'Business intelligence tools', 3, '1499.75', '0.00', '0.00', '4499.25', '2025-05-23T02:20:05.481Z', '2025-05-23T02:20:05.481Z', true),
(4, 2, 'Network Infrastructure', 'Network hardware and setup', 3, '2499.50', '0.00', '0.00', '7498.50', '2025-05-23T02:20:05.497Z', '2025-05-23T02:20:05.497Z', true),
(5, 2, 'Data Analytics Platform', 'Business intelligence tools', 3, '1499.75', '0.00', '0.00', '4499.25', '2025-05-23T02:20:05.513Z', '2025-05-23T02:20:05.513Z', true),
(6, 3, 'Enterprise SaaS License', 'Annual subscription', 3, '1299.99', '0.00', '0.00', '3899.97', '2025-05-23T02:20:05.529Z', '2025-05-23T02:20:05.529Z', true),
(7, 4, 'Data Analytics Platform', 'Business intelligence tools', 2, '1499.75', '0.00', '0.00', '2999.50', '2025-05-23T02:20:05.545Z', '2025-05-23T02:20:05.545Z', true),
(8, 4, 'Custom Development', 'Custom software development (hourly)', 5, '150.00', '0.00', '0.00', '750.00', '2025-05-23T02:20:05.561Z', '2025-05-23T02:20:05.561Z', true),
(9, 4, 'Cloud Security Package', 'Advanced security suite', 4, '899.50', '0.00', '0.00', '3598.00', '2025-05-23T02:20:05.576Z', '2025-05-23T02:20:05.576Z', true),
(10, 5, 'Data Analytics Platform', 'Business intelligence tools', 5, '1499.75', '0.00', '0.00', '7498.75', '2025-05-23T02:20:05.592Z', '2025-05-23T02:20:05.592Z', true),
(11, 5, 'Custom Development', 'Custom software development (hourly)', 2, '150.00', '0.00', '0.00', '300.00', '2025-05-23T02:20:05.609Z', '2025-05-23T02:20:05.609Z', true),
(12, 5, 'Network Infrastructure', 'Network hardware and setup', 3, '2499.50', '0.00', '0.00', '7498.50', '2025-05-23T02:20:05.624Z', '2025-05-23T02:20:05.624Z', true);

-- Table: sales_quotes (5 records)
INSERT INTO "sales_quotes" ("id", "quote_number", "opportunity_id", "customer_name", "quote_date", "valid_until", "status", "total_amount", "discount_amount", "tax_amount", "grand_total", "notes", "terms_conditions", "created_by", "created_at", "updated_at", "active") VALUES
(1, 'QT-2025-1001', NULL, 'TechNova Inc', '2025-05-08T02:20:05.381Z', '2025-07-07T02:20:05.381Z', 'Sent', '6200.00', '0.00', '0.00', '6510.00', NULL, 'Net 30 payment terms. Quoted prices valid for 60 days.', NULL, '2025-05-23T02:20:05.381Z', '2025-05-23T02:20:05.381Z', true),
(2, 'QT-2025-1002', NULL, 'Elevate Solutions', '2025-05-11T02:20:05.381Z', '2025-07-10T02:20:05.381Z', 'Draft', '3750.50', '0.00', '0.00', '3938.03', NULL, 'Net 30 payment terms. Quoted prices valid for 60 days.', NULL, '2025-05-23T02:20:05.381Z', '2025-05-23T02:20:05.381Z', true),
(3, 'QT-2025-1003', NULL, 'DataWave Analytics', '2025-05-13T02:20:05.381Z', '2025-07-12T02:20:05.381Z', 'Approved', '9200.00', '0.00', '0.00', '9660.00', NULL, 'Net 30 payment terms. Quoted prices valid for 60 days.', NULL, '2025-05-23T02:20:05.381Z', '2025-05-23T02:20:05.381Z', true),
(4, 'QT-2025-1004', NULL, 'Quantum Systems', '2025-05-16T02:20:05.381Z', '2025-07-15T02:20:05.381Z', 'Rejected', '4800.75', '0.00', '0.00', '5040.79', NULL, 'Net 30 payment terms. Quoted prices valid for 60 days.', NULL, '2025-05-23T02:20:05.381Z', '2025-05-23T02:20:05.381Z', true),
(5, 'QT-2025-1005', NULL, 'Arctic Innovations', '2025-05-18T02:20:05.381Z', '2025-07-17T02:20:05.381Z', 'Sent', '2350.25', '0.00', '0.00', '2467.76', NULL, 'Net 30 payment terms. Quoted prices valid for 60 days.', NULL, '2025-05-23T02:20:05.381Z', '2025-05-23T02:20:05.381Z', true);

-- Table: sales_return_items (7 records)
INSERT INTO "sales_return_items" ("id", "return_id", "product_name", "quantity", "unit_price", "subtotal", "return_reason", "condition", "created_at", "updated_at", "active") VALUES
(1, 1, 'Data Analytics Platform', 2, '1499.75', '2999.50', NULL, 'New', '2025-05-23T02:20:08.524Z', '2025-05-23T02:20:08.524Z', true),
(2, 1, 'Enterprise SaaS License', 1, '1299.99', '1299.99', NULL, 'Like New', '2025-05-23T02:20:08.541Z', '2025-05-23T02:20:08.541Z', true),
(3, 2, 'Cloud Security Package', 2, '899.50', '1799.00', NULL, 'Damaged', '2025-05-23T02:20:08.557Z', '2025-05-23T02:20:08.557Z', true),
(4, 3, 'Enterprise SaaS License', 2, '1299.99', '2599.98', NULL, 'Used', '2025-05-23T02:20:08.573Z', '2025-05-23T02:20:08.573Z', true),
(5, 3, 'Network Infrastructure', 2, '2499.50', '4999.00', NULL, 'Used', '2025-05-23T02:20:08.589Z', '2025-05-23T02:20:08.589Z', true),
(6, 4, 'Data Analytics Platform', 1, '1499.75', '1499.75', NULL, 'Like New', '2025-05-23T02:20:08.606Z', '2025-05-23T02:20:08.606Z', true),
(7, 4, 'Network Infrastructure', 1, '2499.50', '2499.50', NULL, 'New', '2025-05-23T02:20:08.622Z', '2025-05-23T02:20:08.622Z', true);

-- Table: sales_returns (4 records)
INSERT INTO "sales_returns" ("id", "return_number", "order_id", "invoice_id", "customer_name", "return_date", "status", "total_amount", "return_reason", "notes", "created_by", "created_at", "updated_at", "active") VALUES
(1, 'RET-2025-1001', NULL, NULL, 'TechNova Inc', '2025-05-13T02:20:08.463Z', 'Completed', '1299.99', 'Product not needed anymore', NULL, NULL, '2025-05-23T02:20:08.463Z', '2025-05-23T02:20:08.463Z', true),
(2, 'RET-2025-1002', NULL, NULL, 'Elevate Solutions', '2025-05-16T02:20:08.463Z', 'Processing', '899.50', 'Incompatible with current systems', NULL, NULL, '2025-05-23T02:20:08.463Z', '2025-05-23T02:20:08.463Z', true),
(3, 'RET-2025-1003', NULL, NULL, 'DataWave Analytics', '2025-05-18T02:20:08.463Z', 'Approved', '699.99', 'Duplicate order', NULL, NULL, '2025-05-23T02:20:08.463Z', '2025-05-23T02:20:08.463Z', true),
(4, 'RET-2025-1004', NULL, NULL, 'Quantum Systems', '2025-05-20T02:20:08.463Z', 'Pending', '1499.75', 'Wrong product received', NULL, NULL, '2025-05-23T02:20:08.463Z', '2025-05-23T02:20:08.463Z', true);

-- Table: stock_movements (25 records)
INSERT INTO "stock_movements" ("id", "product_id", "type", "quantity", "reason", "date", "user_id", "created_at", "active", "updated_at") VALUES
(4, 2, 'Return', 29, 'Wrong item return', '2025-05-05T13:40:07.915Z', 1, '2025-05-22T13:40:07.915Z', true, '2025-06-04T18:39:31.543Z'),
(5, 5, 'Return', 80, 'Customer order cancellation', '2025-01-24T13:40:07.915Z', 1, '2025-05-22T13:40:07.937Z', true, '2025-06-04T18:39:31.543Z'),
(6, 10, 'Transfer', 78, 'Cross-docking operation', '2025-03-19T13:40:07.915Z', 1, '2025-05-22T13:40:07.954Z', true, '2025-06-04T18:39:31.543Z'),
(7, 7, 'Adjustment', 26, 'System data correction', '2024-12-16T13:40:07.915Z', 1, '2025-05-22T13:40:07.974Z', true, '2025-06-04T18:39:31.543Z'),
(8, 2, 'Receipt', 81, 'Return from customer', '2025-01-19T13:40:07.915Z', 1, '2025-05-22T13:40:07.992Z', true, '2025-06-04T18:39:31.543Z'),
(9, 3, 'Issue', 37, 'Sample issuance', '2025-02-03T13:40:07.915Z', 1, '2025-05-22T13:40:08.018Z', true, '2025-06-04T18:39:31.543Z'),
(10, 8, 'Transfer', 39, 'Relocation optimization', '2025-02-11T13:40:07.915Z', 1, '2025-05-22T13:40:08.038Z', true, '2025-06-04T18:39:31.543Z'),
(11, 5, 'Issue', 95, 'Damaged goods disposal', '2024-12-22T13:40:07.915Z', 1, '2025-05-22T13:40:08.057Z', true, '2025-06-04T18:39:31.543Z'),
(12, 7, 'Receipt', 30, 'Transfer from another location', '2025-02-22T13:40:07.915Z', 1, '2025-05-22T13:40:08.076Z', true, '2025-06-04T18:39:31.543Z'),
(13, 6, 'Receipt', 55, 'Return from customer', '2025-01-11T13:40:07.915Z', 1, '2025-05-22T13:40:08.098Z', true, '2025-06-04T18:39:31.543Z'),
(14, 1, 'Receipt', 72, 'Inventory count adjustment', '2025-02-14T13:40:07.915Z', 1, '2025-05-22T13:40:08.116Z', true, '2025-06-04T18:39:31.543Z'),
(15, 9, 'Receipt', 40, 'Return from customer', '2025-04-20T13:40:07.915Z', 1, '2025-05-22T13:40:08.136Z', true, '2025-06-04T18:39:31.543Z'),
(16, 10, 'Adjustment', 41, 'System data correction', '2025-04-08T13:40:07.915Z', 1, '2025-05-22T13:40:08.154Z', true, '2025-06-04T18:39:31.543Z'),
(17, 2, 'Return', 86, 'Wrong item return', '2025-05-07T13:40:07.915Z', 1, '2025-05-22T13:40:08.176Z', true, '2025-06-04T18:39:31.543Z'),
(18, 4, 'Issue', 27, 'Sales order fulfillment', '2024-11-27T13:40:07.915Z', 1, '2025-05-22T13:40:08.194Z', true, '2025-06-04T18:39:31.543Z'),
(19, 7, 'Transfer', 3, 'Relocation optimization', '2024-12-28T13:40:07.915Z', 1, '2025-05-22T13:40:08.213Z', true, '2025-06-04T18:39:31.543Z'),
(20, 5, 'Issue', 45, 'Damaged goods disposal', '2024-12-05T13:40:07.915Z', 1, '2025-05-22T13:40:08.230Z', true, '2025-06-04T18:39:31.543Z'),
(21, 3, 'Transfer', 35, 'Warehouse rebalancing', '2025-04-08T13:40:07.915Z', 1, '2025-05-22T13:40:08.249Z', true, '2025-06-04T18:39:31.543Z'),
(22, 2, 'Transfer', 22, 'Warehouse rebalancing', '2025-05-04T13:40:07.915Z', 1, '2025-05-22T13:40:08.271Z', true, '2025-06-04T18:39:31.543Z'),
(23, 8, 'Return', 88, 'Customer order cancellation', '2025-01-04T13:40:07.915Z', 1, '2025-05-22T13:40:08.295Z', true, '2025-06-04T18:39:31.543Z'),
(24, 8, 'Receipt', 23, 'Production output', '2025-05-13T13:40:07.915Z', 1, '2025-05-22T13:40:08.326Z', true, '2025-06-04T18:39:31.543Z'),
(25, 10, 'Return', 52, 'Damaged goods return', '2025-03-21T13:40:07.915Z', 1, '2025-05-22T13:40:08.344Z', true, '2025-06-04T18:39:31.543Z'),
(26, 8, 'Issue', 79, 'Sales order fulfillment', '2025-02-05T13:40:07.915Z', 1, '2025-05-22T13:40:08.363Z', true, '2025-06-04T18:39:31.543Z'),
(27, 7, 'Receipt', 24, 'Production output', '2025-02-07T13:40:07.915Z', 1, '2025-05-22T13:40:08.387Z', true, '2025-06-04T18:39:31.543Z'),
(28, 1, 'Transfer', 39, 'Warehouse rebalancing', '2025-03-02T13:40:07.915Z', 1, '2025-05-22T13:40:08.407Z', true, '2025-06-04T18:39:31.543Z');

-- Table: storage_locations (20 records)
INSERT INTO "storage_locations" ("id", "code", "name", "description", "plant_id", "type", "is_mrp_relevant", "is_negative_stock_allowed", "is_goods_receipt_relevant", "is_goods_issue_relevant", "is_interim_storage", "is_transit_storage", "is_restricted_use", "status", "is_active", "created_at", "created_by", "updated_at", "updated_by", "version", "notes", "active") VALUES
(13, 'SL001', 'Raw Materials Warehouse', 'Primary storage for raw materials in main factory', 1, 'raw_material', true, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.094Z', NULL, '2025-05-20T05:01:14.094Z', NULL, 1, NULL, true),
(14, 'SL002', 'Work-in-Progress', 'Temporary storage for work-in-progress items', 1, 'wip', true, false, false, false, false, false, false, 'active', true, '2025-05-20T05:01:14.125Z', NULL, '2025-05-20T05:01:14.125Z', NULL, 1, NULL, true),
(15, 'SL003', 'Finished Goods', 'Storage for completed products ready for shipping', 1, 'finished_goods', true, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.149Z', NULL, '2025-05-20T05:01:14.149Z', NULL, 1, NULL, true),
(16, 'SL004', 'Quality Control Area', 'Area for quality inspection and testing', 1, 'quality_control', false, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.170Z', NULL, '2025-05-20T05:01:14.170Z', NULL, 1, NULL, true),
(17, 'SL005', 'Components Storage', 'Storage for assembly components and parts', 3, 'components', true, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.195Z', NULL, '2025-05-20T05:01:14.195Z', NULL, 1, NULL, true),
(18, 'SL006', 'Assembly WIP', 'Work-in-progress area for assembly operations', 3, 'wip', true, false, false, false, false, false, false, 'active', true, '2025-05-20T05:01:14.215Z', NULL, '2025-05-20T05:01:14.215Z', NULL, 1, NULL, true),
(19, 'SL007', 'Berlin Raw Materials', 'Raw material storage for Berlin plant', 5, 'raw_material', true, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.233Z', NULL, '2025-05-20T05:01:14.233Z', NULL, 1, NULL, true),
(20, 'SL008', 'Berlin Finished Goods', 'Finished product storage for Berlin plant', 5, 'finished_goods', true, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.250Z', NULL, '2025-05-20T05:01:14.250Z', NULL, 1, NULL, true),
(21, 'SL009', 'Shanghai Materials', 'Raw material storage for Shanghai facility', 6, 'raw_material', true, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.273Z', NULL, '2025-05-20T05:01:14.273Z', NULL, 1, NULL, true),
(22, 'SL010', 'Shanghai Finished Goods', 'Finished product storage for Shanghai facility', 6, 'finished_goods', true, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.293Z', NULL, '2025-05-20T05:01:14.293Z', NULL, 1, NULL, true),
(23, 'SL011', 'US Distribution - Zone A', 'High-volume products distribution area', 2, 'distribution', false, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.314Z', NULL, '2025-05-20T05:01:14.314Z', NULL, 1, NULL, true),
(24, 'SL012', 'US Distribution - Zone B', 'Specialty products distribution area', 2, 'distribution', false, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.339Z', NULL, '2025-05-20T05:01:14.339Z', NULL, 1, NULL, true),
(25, 'SL013', 'European Warehouse - General', 'General storage area for European warehouse', 7, 'distribution', false, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.365Z', NULL, '2025-05-20T05:01:14.365Z', NULL, 1, NULL, true),
(26, 'SL014', 'European Warehouse - Cold Storage', 'Temperature-controlled storage area', 7, 'special_handling', false, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.386Z', NULL, '2025-05-20T05:01:14.386Z', NULL, 1, NULL, true),
(27, 'SL015', 'Asia Distribution - General', 'General storage area for Asian distribution hub', 8, 'distribution', false, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.408Z', NULL, '2025-05-20T05:01:14.408Z', NULL, 1, NULL, true),
(28, 'SL016', 'UK Warehouse - Main', 'Main storage area for UK warehouse', 9, 'distribution', false, false, false, true, false, false, false, 'active', true, '2025-05-20T05:01:14.426Z', NULL, '2025-05-20T05:01:14.426Z', NULL, 1, NULL, true),
(29, 'SL017', 'Hazardous Materials', 'Special storage for hazardous materials', 1, 'hazardous', true, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.444Z', NULL, '2025-05-20T05:01:14.444Z', NULL, 1, NULL, true),
(30, 'SL018', 'Returns Processing', 'Area for processing customer returns', 2, 'returns', false, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.465Z', NULL, '2025-05-20T05:01:14.465Z', NULL, 1, NULL, true),
(31, 'SL019', 'Maintenance Supplies', 'Storage for maintenance tools and supplies', 1, 'maintenance', false, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.484Z', NULL, '2025-05-20T05:01:14.484Z', NULL, 1, NULL, true),
(32, 'SL020', 'Packaging Materials', 'Storage for packaging materials and supplies', 1, 'packaging', true, false, true, false, false, false, false, 'active', true, '2025-05-20T05:01:14.506Z', NULL, '2025-05-20T05:01:14.506Z', NULL, 1, NULL, true);

-- Table: supply_types (11 records)
INSERT INTO "supply_types" ("id", "code", "name", "description", "is_active", "created_at", "updated_at", "created_by", "updated_by", "version", "valid_from", "valid_to", "active") VALUES
(1, 'DIR', 'Direct Materials', 'Materials directly used in manufacturing products', true, '2025-05-20T03:25:53.979Z', '2025-05-20T03:25:53.979Z', NULL, NULL, 1, '2025-05-20T03:25:53.979Z', NULL, true),
(2, 'IND', 'Indirect Materials', 'Materials indirectly used in manufacturing', true, '2025-05-20T03:25:53.979Z', '2025-05-20T03:25:53.979Z', NULL, NULL, 1, '2025-05-20T03:25:53.979Z', NULL, true),
(3, 'SERV', 'Services', 'Service-related procurement', true, '2025-05-20T03:25:53.979Z', '2025-05-20T03:25:53.979Z', NULL, NULL, 1, '2025-05-20T03:25:53.979Z', NULL, true),
(4, 'CAPEX', 'Capital Expenditure', 'Large equipment and capital investments', true, '2025-05-20T03:25:53.979Z', '2025-05-20T03:25:53.979Z', NULL, NULL, 1, '2025-05-20T03:25:53.979Z', NULL, true),
(5, 'MRO', 'Maintenance & Repair', 'Maintenance, repair, and operations supplies', true, '2025-05-20T03:25:53.979Z', '2025-05-20T03:25:53.979Z', NULL, NULL, 1, '2025-05-20T03:25:53.979Z', NULL, true),
(6, 'ST001', 'Direct Materials', 'Materials directly used in manufacturing', true, '2025-05-20T04:52:27.648Z', '2025-05-20T04:52:27.648Z', NULL, NULL, 1, '2025-05-20T04:52:27.648Z', NULL, true),
(7, 'ST002', 'Indirect Materials', 'Materials not directly used in manufacturing', true, '2025-05-20T04:52:27.683Z', '2025-05-20T04:52:27.683Z', NULL, NULL, 1, '2025-05-20T04:52:27.683Z', NULL, true),
(8, 'ST003', 'Capital Equipment', 'Long-term assets and equipment', true, '2025-05-20T04:52:27.715Z', '2025-05-20T04:52:27.715Z', NULL, NULL, 1, '2025-05-20T04:52:27.715Z', NULL, true),
(9, 'ST004', 'Services', 'External services and contracted work', true, '2025-05-20T04:52:27.751Z', '2025-05-20T04:52:27.751Z', NULL, NULL, 1, '2025-05-20T04:52:27.751Z', NULL, true),
(10, 'ST005', 'Trading Goods', 'Finished goods purchased for resale', true, '2025-05-20T04:52:27.788Z', '2025-05-20T04:52:27.788Z', NULL, NULL, 1, '2025-05-20T04:52:27.788Z', NULL, true),
(11, 'ST006', 'MRO Supplies', 'Maintenance, repair, and operations supplies', true, '2025-05-20T04:52:27.831Z', '2025-05-20T04:52:27.831Z', NULL, NULL, 1, '2025-05-20T04:52:27.831Z', NULL, true);

-- Table: system_error_logs (20 records)
INSERT INTO "system_error_logs" ("id", "timestamp", "level", "module", "message", "stack", "additional_data", "created_at") VALUES
(1, '2025-06-04T22:52:27.680Z', 'ERROR', 'DemoModule', 'Testing dual storage system', NULL, [object Object], '2025-06-04T22:52:30.152Z'),
(2, '2025-06-04T23:01:05.997Z', 'INFO', 'CompanyCode', 'Creating new company code', NULL, [object Object], '2025-06-04T23:01:06.086Z'),
(3, '2025-06-04T23:01:06.130Z', 'ERROR', 'CompanyCode', 'Failed to create company code', 'error: value too long for type character varying(2)
    at file:///home/runner/workspace/node_modules/@neondatabase/serverless/index.mjs:1345:74
    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)
    at async <anonymous> (/home/runner/workspace/server/routes.ts:197:22)', [object Object], '2025-06-04T23:01:06.214Z'),
(4, '2025-06-04T23:02:37.867Z', 'INFO', 'CompanyCode', 'Creating new company code', NULL, [object Object], '2025-06-04T23:02:37.939Z'),
(5, '2025-06-04T23:02:37.969Z', 'ERROR', 'CompanyCode', 'Failed to create company code', 'error: duplicate key value violates unique constraint "company_codes_pkey"
    at file:///home/runner/workspace/node_modules/@neondatabase/serverless/index.mjs:1345:74
    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)
    at async <anonymous> (/home/runner/workspace/server/routes.ts:197:22)', [object Object], '2025-06-04T23:02:37.979Z'),
(6, '2025-06-04T23:15:32.132Z', 'INFO', 'CompanyCode', 'Creating new company code', NULL, [object Object], '2025-06-04T23:15:35.920Z'),
(7, '2025-06-04T23:15:36.016Z', 'INFO', 'CompanyCode', 'Company code created successfully', NULL, [object Object], '2025-06-04T23:15:36.025Z'),
(8, '2025-06-04T23:42:48.382Z', 'INFO', 'ZeroErrorDataHandler', 'Successfully saved data to company_codes on attempt 1', NULL, [object Object], '2025-06-04T23:42:48.394Z'),
(9, '2025-06-04T23:42:48.303Z', 'INFO', 'CompanyCode', 'Creating new company code', NULL, [object Object], '2025-06-04T23:42:50.371Z'),
(10, '2025-06-04T23:42:48.383Z', 'INFO', 'CompanyCode', 'Company code created successfully', NULL, [object Object], '2025-06-04T23:42:50.445Z'),
(11, '2025-06-05T00:41:21.570Z', 'INFO', 'CompanyCode', 'Creating new company code', NULL, [object Object], '2025-06-05T00:41:22.003Z'),
(13, '2025-06-05T00:41:23.733Z', 'INFO', 'CompanyCode', 'Company code created successfully', NULL, [object Object], '2025-06-05T00:41:23.743Z'),
(12, '2025-06-05T00:41:23.732Z', 'INFO', 'ZeroErrorDataHandler', 'Successfully saved data to company_codes on attempt 1', NULL, [object Object], '2025-06-05T00:41:23.743Z'),
(14, '2025-06-05T00:43:32.622Z', 'INFO', 'CompanyCode', 'Creating new company code', NULL, [object Object], '2025-06-05T00:43:32.907Z'),
(15, '2025-06-05T00:43:33.171Z', 'WARN', 'CompanyCode', 'Attempted to create duplicate company code', NULL, [object Object], '2025-06-05T00:43:33.885Z'),
(16, '2025-06-05T00:46:18.875Z', 'INFO', 'CompanyCode', 'Creating new company code', NULL, [object Object], '2025-06-05T00:46:18.940Z'),
(17, '2025-06-05T00:46:18.959Z', 'WARN', 'CompanyCode', 'Attempted to create duplicate company code', NULL, [object Object], '2025-06-05T00:46:19.045Z'),
(18, '2025-06-05T00:46:55.758Z', 'INFO', 'CompanyCode', 'Creating new company code', NULL, [object Object], '2025-06-05T00:46:55.842Z'),
(19, '2025-06-05T00:46:55.873Z', 'INFO', 'ZeroErrorDataHandler', 'Successfully saved data to company_codes on attempt 1', NULL, [object Object], '2025-06-05T00:46:55.883Z'),
(20, '2025-06-05T00:46:55.873Z', 'INFO', 'CompanyCode', 'Company code created successfully', NULL, [object Object], '2025-06-05T00:46:55.886Z');

-- Table: tax_codes (16 records)
INSERT INTO "tax_codes" ("id", "code", "name", "country", "tax_type", "percentage", "description", "is_active", "created_at", "updated_at", "active") VALUES
(1, 'US-EX', 'US Exempt', 'US', 'SALES', '0.00', 'Tax exempt sales in US', true, '2025-05-20T22:10:47.493Z', '2025-05-20T22:10:47.493Z', true),
(2, 'US-STD', 'US Standard', 'US', 'SALES', '6.00', 'Standard US sales tax', true, '2025-05-20T22:10:47.493Z', '2025-05-20T22:10:47.493Z', true),
(3, 'US-NY', 'New York', 'US', 'SALES', '8.88', 'New York City sales tax', true, '2025-05-20T22:10:47.493Z', '2025-05-20T22:10:47.493Z', true),
(4, 'DE-STD', 'Germany Standard', 'DE', 'VAT', '19.00', 'Standard German VAT', true, '2025-05-20T22:10:47.493Z', '2025-05-20T22:10:47.493Z', true),
(5, 'DE-RED', 'Germany Reduced', 'DE', 'VAT', '7.00', 'Reduced German VAT', true, '2025-05-20T22:10:47.493Z', '2025-05-20T22:10:47.493Z', true),
(6, 'UK-STD', 'UK Standard', 'GB', 'VAT', '20.00', 'Standard UK VAT', true, '2025-05-20T22:10:47.493Z', '2025-05-20T22:10:47.493Z', true),
(7, 'JP-STD', 'Japan Standard', 'JP', 'CONSUMPTION', '10.00', 'Standard Japanese consumption tax', true, '2025-05-20T22:10:47.493Z', '2025-05-20T22:10:47.493Z', true),
(10, 'US-RED', 'US Reduced Tax', 'US', 'SALES', '2.50', 'United States reduced sales tax rate', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true),
(11, 'US-EXE', 'US Tax Exempt', 'US', 'EXEMPT', '0.00', 'United States tax exempt status', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true),
(12, 'CA-GST', 'Canada GST', 'CA', 'SALES', '5.00', 'Canada Goods and Services Tax', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true),
(13, 'CA-HST', 'Canada HST', 'CA', 'SALES', '13.00', 'Canada Harmonized Sales Tax', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true),
(14, 'UK-VAT', 'UK Standard VAT', 'UK', 'VAT', '20.00', 'United Kingdom standard Value Added Tax', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true),
(15, 'UK-RED', 'UK Reduced VAT', 'UK', 'VAT', '5.00', 'United Kingdom reduced Value Added Tax', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true),
(16, 'UK-ZER', 'UK Zero VAT', 'UK', 'VAT', '0.00', 'United Kingdom zero-rated Value Added Tax', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true),
(17, 'EU-STD', 'EU Standard VAT', 'EU', 'VAT', '21.00', 'European Union standard Value Added Tax', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true),
(18, 'EU-RED', 'EU Reduced VAT', 'EU', 'VAT', '10.00', 'European Union reduced Value Added Tax', true, '2025-05-21T15:11:30.587Z', '2025-05-21T15:11:30.587Z', true);

-- Table: transport_logs (9 records)
INSERT INTO "transport_logs" ("id", "request_id", "environment", "action", "status", "message", "executed_by", "executed_at", "active", "created_at", "updated_at") VALUES
(1, 1, 'DEV', 'TRANSPORT_CREATED', 'SUCCESS', 'Transport request MDK395986 created', 'DEVELOPER_001', '2025-06-03T05:09:56.088Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z'),
(2, 2, 'DEV', 'TRANSPORT_CREATED', 'SUCCESS', 'Transport request MDK434665 created', 'SYSTEM_ADMIN', '2025-06-03T05:10:34.710Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z'),
(3, 2, 'DEV', 'TRANSPORT_RELEASED', 'SUCCESS', 'Transport MDK434665 released for QA', 'SYSTEM', '2025-06-03T05:10:54.196Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z'),
(4, 2, 'QA', 'TRANSPORT_IMPORTED', 'FAILED', 'Transport MDK434665 imported to QA', 'QA_ADMIN', '2025-06-03T05:10:57.717Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z'),
(5, 3, 'DEV', 'TRANSPORT_CREATED', 'SUCCESS', 'Transport request MDK494346 created', 'SYSTEM_ADMIN', '2025-06-03T05:11:34.379Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z'),
(6, 4, 'DEV', 'TRANSPORT_CREATED', 'SUCCESS', 'Transport request MDK557474 created', 'ERP_ADMIN', '2025-06-03T05:12:37.509Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z'),
(7, 4, 'DEV', 'TRANSPORT_RELEASED', 'SUCCESS', 'Transport MDK557474 released for QA', 'SYSTEM', '2025-06-03T05:12:47.036Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z'),
(8, 4, 'QA', 'TRANSPORT_IMPORTED', 'FAILED', 'Transport MDK557474 imported to QA', 'QA_ADMIN', '2025-06-03T05:12:51.277Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z'),
(9, 5, 'DEV', 'CREATE', 'SUCCESS', 'Transport request A1100003 created with 1 objects', 'SYSTEM_USER', '2025-06-03T16:34:14.749Z', true, '2025-06-04T18:39:31.773Z', '2025-06-04T18:39:31.773Z');

-- Table: transport_number_ranges (3 records)
INSERT INTO "transport_number_ranges" ("id", "range_prefix", "range_type", "description", "current_number", "max_number", "is_active", "created_at", "updated_at", "active") VALUES
(2, 'Y1', 'CUSTOM_DEV', 'Custom Development Objects - Level 1', 100000, 999999, true, '2025-06-03T16:19:15.360Z', '2025-06-03T16:19:15.360Z', true),
(3, 'Z1', 'CUSTOMER', 'Customer Customization Objects - Level 1', 100000, 999999, true, '2025-06-03T16:19:15.379Z', '2025-06-03T16:19:15.379Z', true),
(1, 'A1', 'STANDARD', 'Standard ERP Objects - Level 1', 100003, 999999, true, '2025-06-03T16:19:15.319Z', '2025-06-03T16:34:14.437Z', true);

-- Table: transport_objects (12 records)
INSERT INTO "transport_objects" ("id", "request_id", "object_type", "object_name", "table_name", "record_id", "action", "data_snapshot", "created_at", "active", "updated_at") VALUES
(1, 1, 'COMPANY_CODE', 'US01', 'company_codes', 1, 'INSERT', [object Object], '2025-06-03T05:10:04.045Z', true, '2025-06-04T18:39:31.889Z'),
(2, 1, 'PLANT', 'P001', 'plants', 1, 'INSERT', [object Object], '2025-06-03T05:10:10.185Z', true, '2025-06-04T18:39:31.889Z'),
(3, 2, 'COMPANY_CODE', 'US01', 'company_codes', 1, 'INSERT', [object Object], '2025-06-03T05:10:38.682Z', true, '2025-06-04T18:39:31.889Z'),
(4, 2, 'PLANT', 'P001', 'plants', 1, 'INSERT', [object Object], '2025-06-03T05:10:38.725Z', true, '2025-06-04T18:39:31.889Z'),
(5, 2, 'PLANT', 'W001', 'plants', 2, 'INSERT', [object Object], '2025-06-03T05:10:38.761Z', true, '2025-06-04T18:39:31.889Z'),
(6, 3, 'COMPANY_CODE', 'US01', 'company_codes', 1, 'INSERT', [object Object], '2025-06-03T05:11:38.890Z', true, '2025-06-04T18:39:31.889Z'),
(7, 3, 'PLANT', 'P001', 'plants', 1, 'INSERT', [object Object], '2025-06-03T05:11:38.923Z', true, '2025-06-04T18:39:31.889Z'),
(8, 3, 'PLANT', 'W001', 'plants', 2, 'INSERT', [object Object], '2025-06-03T05:11:38.957Z', true, '2025-06-04T18:39:31.889Z'),
(9, 4, 'COMPANY_CODE', 'US01', 'company_codes', 1, 'INSERT', [object Object], '2025-06-03T05:12:42.300Z', true, '2025-06-04T18:39:31.889Z'),
(10, 4, 'PLANT', 'P001', 'plants', 1, 'INSERT', [object Object], '2025-06-03T05:12:42.337Z', true, '2025-06-04T18:39:31.889Z'),
(11, 4, 'PLANT', 'W001', 'plants', 2, 'INSERT', [object Object], '2025-06-03T05:12:42.371Z', true, '2025-06-04T18:39:31.889Z'),
(12, 5, 'Master Data', 'UK01', 'company_codes', NULL, 'CREATE', [object Object], '2025-06-03T16:34:14.698Z', true, '2025-06-04T18:39:31.889Z');

-- Table: transport_requests (5 records)
INSERT INTO "transport_requests" ("id", "request_number", "request_type", "description", "owner", "status", "source_environment", "target_environment", "created_at", "released_at", "imported_at", "release_notes", "active", "updated_at") VALUES
(1, 'MDK395986', 'MD', 'Transport Company Code with dependent master data', 'DEVELOPER_001', 'CREATED', 'DEV', 'QA', '2025-06-03T05:09:56.056Z', NULL, NULL, NULL, true, '2025-06-04T18:39:31.949Z'),
(2, 'MDK434665', 'MD', 'Complete organizational structure transport with referential integrity', 'SYSTEM_ADMIN', 'FAILED', 'DEV', 'QA', '2025-06-03T05:10:34.676Z', '2025-06-03T05:10:54.159Z', '2025-06-03T05:10:57.699Z', 'Organizational structure ready for QA testing - includes Company Code US01 with dependent plants P001 and W001. All referential integrity validated.', true, '2025-06-04T18:39:31.949Z'),
(3, 'MDK494346', 'MD', 'Complete CI/CD demonstration - organizational master data with referential integrity', 'SYSTEM_ADMIN', 'CREATED', 'DEV', 'QA', '2025-06-03T05:11:34.355Z', NULL, NULL, NULL, true, '2025-06-04T18:39:31.949Z'),
(4, 'MDK557474', 'MD', 'Final CI/CD demonstration - SAP-style master data transport with referential integrity', 'ERP_ADMIN', 'FAILED', 'DEV', 'QA', '2025-06-03T05:12:37.485Z', '2025-06-03T05:12:47.003Z', '2025-06-03T05:12:51.258Z', 'SAP-style CI/CD transport ready for QA - Company Code US01 with dependent Plants P001 and W001. Complete referential integrity validation passed.', true, '2025-06-04T18:39:31.949Z'),
(5, 'A1100003', 'MANUAL', 'MD - Company Code UK01', 'SYSTEM_USER', 'MODIFIABLE', 'DEV', 'QA', '2025-06-03T16:34:14.606Z', NULL, NULL, NULL, true, '2025-06-04T18:39:31.949Z');

-- Table: units_of_measure (30 records)
INSERT INTO "units_of_measure" ("id", "code", "name", "description", "is_active", "dimension", "conversion_factor", "base_uom_id", "created_at", "updated_at", "version", "active") VALUES
(21, 'BOX', 'Box', 'Standard shipping box', true, 'Count', '1.00000', 1, '2025-05-20T14:35:23.427Z', '2025-05-20T14:35:23.427Z', 1, true),
(22, 'PK', 'Pack', 'Standard package unit', true, 'Count', '1.00000', 1, '2025-05-20T14:35:23.450Z', '2025-05-20T14:35:23.450Z', 1, true),
(23, 'CS', 'Case', 'Standard shipping case', true, 'Count', '1.00000', 1, '2025-05-20T14:35:23.469Z', '2025-05-20T14:35:23.469Z', 1, true),
(24, 'PAL', 'Pallet', 'Standard shipping pallet', true, 'Count', '1.00000', 1, '2025-05-20T14:35:23.487Z', '2025-05-20T14:35:23.487Z', 1, true),
(25, 'BDL', 'Bundle', 'Bundled items', true, 'Count', '1.00000', 1, '2025-05-20T14:35:23.504Z', '2025-05-20T14:35:23.504Z', 1, true),
(26, 'ROL', 'Roll', 'Material in roll form', true, 'Count', '1.00000', 1, '2025-05-20T14:35:23.523Z', '2025-05-20T14:35:23.523Z', 1, true),
(1, 'EA', 'Each', 'Individual units/pieces', true, 'Count', '1.00000', NULL, '2025-05-20T14:35:22.972Z', '2025-05-20T14:35:22.972Z', 1, true),
(2, 'KG', 'Kilogram', 'Standard weight measure', true, 'Weight', '1.00000', NULL, '2025-05-20T14:35:22.993Z', '2025-05-20T14:35:22.993Z', 1, true),
(3, 'L', 'Liter', 'Standard volume measure', true, 'Volume', '1.00000', NULL, '2025-05-20T14:35:23.012Z', '2025-05-20T14:35:23.012Z', 1, true),
(4, 'M', 'Meter', 'Standard length measure', true, 'Length', '1.00000', NULL, '2025-05-20T14:35:23.031Z', '2025-05-20T14:35:23.031Z', 1, true),
(5, 'M2', 'Square Meter', 'Standard area measure', true, 'Area', '1.00000', NULL, '2025-05-20T14:35:23.051Z', '2025-05-20T14:35:23.051Z', 1, true),
(6, 'M3', 'Cubic Meter', 'Standard cubic measure', true, 'Volume', '1.00000', NULL, '2025-05-20T14:35:23.091Z', '2025-05-20T14:35:23.091Z', 1, true),
(7, 'HR', 'Hour', 'Time duration in hours', true, 'Time', '1.00000', NULL, '2025-05-20T14:35:23.126Z', '2025-05-20T14:35:23.126Z', 1, true),
(8, 'DZ', 'Dozen', '12 pieces', true, 'Count', '12.00000', 1, '2025-05-20T14:35:23.149Z', '2025-05-20T14:35:23.149Z', 1, true),
(18, 'LB', 'Pound', 'Imperial weight unit', true, 'Weight', '0.45359', 2, '2025-05-20T14:35:23.360Z', '2025-05-20T14:35:23.360Z', 1, true),
(19, 'OZ', 'Ounce', 'Imperial weight unit', true, 'Weight', '0.02835', 2, '2025-05-20T14:35:23.380Z', '2025-05-20T14:35:23.380Z', 1, true),
(9, 'G', 'Gram', '1/1000 of a kilogram', true, 'Weight', '0.00100', 2, '2025-05-20T14:35:23.167Z', '2025-05-20T14:35:23.167Z', 1, true),
(10, 'TON', 'Metric Ton', '1000 kilograms', true, 'Weight', '1000.00000', 2, '2025-05-20T14:35:23.188Z', '2025-05-20T14:35:23.188Z', 1, true),
(20, 'GAL', 'Gallon', 'Imperial volume unit', true, 'Volume', '3.78541', 3, '2025-05-20T14:35:23.407Z', '2025-05-20T14:35:23.407Z', 1, true),
(11, 'ML', 'Milliliter', '1/1000 of a liter', true, 'Volume', '0.00100', 3, '2025-05-20T14:35:23.211Z', '2025-05-20T14:35:23.211Z', 1, true),
(14, 'KM', 'Kilometer', '1000 meters', true, 'Length', '1000.00000', 4, '2025-05-20T14:35:23.278Z', '2025-05-20T14:35:23.278Z', 1, true),
(15, 'FT', 'Feet', 'Imperial length unit', true, 'Length', '0.30480', 4, '2025-05-20T14:35:23.296Z', '2025-05-20T14:35:23.296Z', 1, true),
(16, 'IN', 'Inch', 'Imperial length unit', true, 'Length', '0.02540', 4, '2025-05-20T14:35:23.318Z', '2025-05-20T14:35:23.318Z', 1, true),
(17, 'YD', 'Yard', 'Imperial length unit', true, 'Length', '0.91440', 4, '2025-05-20T14:35:23.338Z', '2025-05-20T14:35:23.338Z', 1, true),
(12, 'CM', 'Centimeter', '1/100 of a meter', true, 'Length', '0.01000', 4, '2025-05-20T14:35:23.240Z', '2025-05-20T14:35:23.240Z', 1, true),
(13, 'MM', 'Millimeter', '1/1000 of a meter', true, 'Length', '0.00100', 4, '2025-05-20T14:35:23.260Z', '2025-05-20T14:35:23.260Z', 1, true),
(27, 'MIN', 'Minute', 'Time duration in minutes', true, 'Time', '0.01667', 7, '2025-05-20T14:35:23.542Z', '2025-05-20T14:35:23.542Z', 1, true),
(28, 'DAY', 'Day', 'Time duration in days', true, 'Time', '24.00000', 7, '2025-05-20T14:35:23.562Z', '2025-05-20T14:35:23.562Z', 1, true),
(29, 'WK', 'Week', 'Time duration in weeks', true, 'Time', '168.00000', 7, '2025-05-20T14:35:23.581Z', '2025-05-20T14:35:23.581Z', 1, true),
(30, 'MO', 'Month', 'Time duration in months', true, 'Time', '730.00000', 7, '2025-05-20T14:35:23.601Z', '2025-05-20T14:35:23.601Z', 1, true);

-- Table: uom (14 records)
INSERT INTO "uom" ("id", "code", "name", "description", "category", "is_base", "created_at", "created_by", "updated_at", "updated_by", "version", "is_active", "notes", "active") VALUES
(1, 'KG', 'Kilogram', NULL, 'weight', true, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(2, 'G', 'Gram', NULL, 'weight', false, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(3, 'LB', 'Pound', NULL, 'weight', false, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(4, 'M', 'Meter', NULL, 'length', true, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(5, 'CM', 'Centimeter', NULL, 'length', false, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(6, 'INCH', 'Inch', NULL, 'length', false, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(7, 'L', 'Liter', NULL, 'volume', true, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(8, 'ML', 'Milliliter', NULL, 'volume', false, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(9, 'GAL', 'Gallon', NULL, 'volume', false, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(10, 'EA', 'Each', NULL, 'unit', true, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(11, 'PCS', 'Pieces', NULL, 'unit', false, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(12, 'BOX', 'Box', NULL, 'package', true, '2025-05-17T05:55:13.089Z', 1, '2025-05-17T05:55:13.089Z', 1, 1, true, NULL, true),
(13, 'Oz', 'OZ', 'OZ', 'Weight', false, '2025-05-17T12:34:16.642Z', 1, '2025-05-17T12:34:16.642Z', 1, 1, true, NULL, true),
(14, 'PC', 'Piece', 'Standard Piece', 'Count', true, '2025-05-20T16:12:26.384Z', NULL, '2025-05-20T16:12:26.384Z', NULL, 1, true, NULL, true);

-- Table: uom_conversions (6 records)
INSERT INTO "uom_conversions" ("id", "from_uom_id", "to_uom_id", "conversion_factor", "created_at", "created_by", "updated_at", "updated_by", "version", "is_active", "notes", "active") VALUES
(1, 1, 2, '1000', '2025-05-17T05:55:19.590Z', 1, '2025-05-17T05:55:19.590Z', 1, 1, true, NULL, true),
(2, 1, 3, '2.20462', '2025-05-17T05:55:19.590Z', 1, '2025-05-17T05:55:19.590Z', 1, 1, true, NULL, true),
(3, 4, 5, '100', '2025-05-17T05:55:19.590Z', 1, '2025-05-17T05:55:19.590Z', 1, 1, true, NULL, true),
(4, 4, 6, '39.3701', '2025-05-17T05:55:19.590Z', 1, '2025-05-17T05:55:19.590Z', 1, 1, true, NULL, true),
(5, 7, 8, '1000', '2025-05-17T05:55:19.590Z', 1, '2025-05-17T05:55:19.590Z', 1, 1, true, NULL, true),
(6, 7, 9, '0.264172', '2025-05-17T05:55:19.590Z', 1, '2025-05-17T05:55:19.590Z', 1, 1, true, NULL, true);

-- Table: users (1 records)
INSERT INTO "users" ("id", "username", "password", "name", "email", "role", "created_at", "updated_at", "active") VALUES
(1, 'admin', 'admin123', 'Administrator', 'admin@example.com', 'admin', '2025-05-17T05:55:13.089Z', '2025-05-17T05:55:13.089Z', true);

-- Table: variance_analysis (0 records - empty)

-- Table: vendor_contacts (10 records)
INSERT INTO "vendor_contacts" ("id", "vendor_id", "first_name", "last_name", "position", "department", "email", "phone", "mobile", "is_primary", "is_order_contact", "is_purchase_contact", "is_quality_contact", "is_accounts_contact", "preferred_language", "notes", "is_active", "created_at", "updated_at", "created_by", "updated_by", "active") VALUES
(1, 1, 'Thomas', 'Anderson', 'Technical Support', 'Support', 'thomas.anderson@supplier.com', '(555) 333-4444', '(555) 555-6666', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.574Z', '2025-05-22T13:33:13.574Z', NULL, NULL, true),
(2, 1, 'Jennifer', 'Taylor', 'Account Manager', 'Customer Relations', 'jennifer.taylor@supplier.com', '(555) 222-3333', '(555) 444-5555', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.615Z', '2025-05-22T13:33:13.615Z', NULL, NULL, true),
(3, 2, 'Robert', 'Wilson', 'Sales Representative', 'Sales', 'robert.wilson@supplier.com', '(555) 111-2222', '(555) 333-4444', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.655Z', '2025-05-22T13:33:13.655Z', NULL, NULL, true),
(4, 3, 'William', 'Thompson', 'Logistics Coordinator', 'Logistics', 'william.thompson@supplier.com', '(555) 555-6666', '(555) 777-8888', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.692Z', '2025-05-22T13:33:13.692Z', NULL, NULL, true),
(5, 3, 'William', 'Thompson', 'Logistics Coordinator', 'Logistics', 'william.thompson@supplier.com', '(555) 555-6666', '(555) 777-8888', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.729Z', '2025-05-22T13:33:13.729Z', NULL, NULL, true),
(6, 3, 'Elizabeth', 'Martin', 'VP of Sales', 'Executive', 'elizabeth.martin@supplier.com', '(555) 444-5555', '(555) 666-7777', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.767Z', '2025-05-22T13:33:13.767Z', NULL, NULL, true),
(7, 4, 'Robert', 'Wilson', 'Sales Representative', 'Sales', 'robert.wilson@supplier.com', '(555) 111-2222', '(555) 333-4444', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.807Z', '2025-05-22T13:33:13.807Z', NULL, NULL, true),
(8, 5, 'Elizabeth', 'Martin', 'VP of Sales', 'Executive', 'elizabeth.martin@supplier.com', '(555) 444-5555', '(555) 666-7777', true, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.864Z', '2025-05-22T13:33:13.864Z', NULL, NULL, true),
(9, 5, 'Robert', 'Wilson', 'Sales Representative', 'Sales', 'robert.wilson@supplier.com', '(555) 111-2222', '(555) 333-4444', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.905Z', '2025-05-22T13:33:13.905Z', NULL, NULL, true),
(10, 5, 'William', 'Thompson', 'Logistics Coordinator', 'Logistics', 'william.thompson@supplier.com', '(555) 555-6666', '(555) 777-8888', false, false, false, false, false, 'English', NULL, true, '2025-05-22T13:33:13.944Z', '2025-05-22T13:33:13.944Z', NULL, NULL, true);

-- Table: vendors (20 records)
INSERT INTO "vendors" ("id", "code", "name", "type", "description", "tax_id", "industry", "address", "city", "state", "country", "postal_code", "region", "phone", "alt_phone", "email", "website", "currency", "payment_terms", "payment_method", "supplier_type", "category", "order_frequency", "minimum_order_value", "evaluation_score", "lead_time", "purchasing_group_id", "status", "blacklisted", "blacklist_reason", "notes", "tags", "company_code_id", "is_active", "created_at", "updated_at", "created_by", "updated_by", "version", "active") VALUES
(1, 'VEND001', 'Global Raw Materials Inc', 'SUPPLIER', NULL, '123-45-6789', NULL, '100 Supplier Road, Chicago, IL 60601', NULL, NULL, 'US', NULL, NULL, '+1-312-555-1234', NULL, 'sales@grm.example.com', NULL, NULL, 'NET30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, 'Primary raw material supplier', NULL, NULL, true, '2025-05-20T18:17:22.279Z', '2025-05-20T18:17:22.279Z', NULL, NULL, 1, true),
(2, 'VEND002', 'European Components GmbH', 'MANUFACTURER', NULL, 'DE123456789', NULL, 'Industrieweg 10, Munich, 80331', NULL, NULL, 'DE', NULL, NULL, '+49-89-1234-5678', NULL, 'orders@eurocomponents.example.de', NULL, NULL, 'NET45', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, 'European electronics components supplier', NULL, NULL, true, '2025-05-20T18:17:22.301Z', '2025-05-20T18:17:22.301Z', NULL, NULL, 1, true),
(3, 'VEND003', 'Asian Electronics Ltd', 'MANUFACTURER', NULL, 'SG987654321', NULL, '1 Electronics Way, Singapore, 618989', NULL, NULL, 'SG', NULL, NULL, '+65-6789-1234', NULL, 'sales@asianelec.example.sg', NULL, NULL, 'NET30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, 'Electronics components supplier', NULL, NULL, true, '2025-05-20T18:17:22.320Z', '2025-05-20T18:17:22.320Z', NULL, NULL, 1, true),
(4, 'VEND004', 'Quality Packaging Ltd', 'SUPPLIER', NULL, 'GB123456789', NULL, '10 Packaging Street, Manchester, M1 1AA', NULL, NULL, 'GB', NULL, NULL, '+44-161-123-4567', NULL, 'sales@qualitypack.example.uk', NULL, NULL, 'NET30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, 'Packaging materials supplier', NULL, NULL, true, '2025-05-20T18:17:22.341Z', '2025-05-20T18:17:22.341Z', NULL, NULL, 1, true),
(5, 'VEND005', 'Japan Precision Tools', 'MANUFACTURER', NULL, 'JP1234567890', NULL, '2-1 Industrial Area, Osaka, 530-0001', NULL, NULL, 'JP', NULL, NULL, '+81-6-1234-5678', NULL, 'export@jpt.example.jp', NULL, NULL, 'NET15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, 'Precision tools manufacturer', NULL, NULL, true, '2025-05-20T18:17:22.360Z', '2025-05-20T18:17:22.360Z', NULL, NULL, 1, true),
(8, 'PRODVEND1', 'Production Vendor 1', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'prod1@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T00:46:56.215Z', '2025-06-05T00:46:56.215Z', NULL, NULL, 1, true),
(11, 'VEND1749084630761', 'Test Vendor', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T00:50:31.109Z', '2025-06-05T00:50:31.109Z', NULL, NULL, 1, true),
(12, 'VEND1749084660178', 'Test Vendor', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T00:51:00.479Z', '2025-06-05T00:51:00.479Z', NULL, NULL, 1, true),
(13, 'V214', 'Test Vendor', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T00:51:53.526Z', '2025-06-05T00:51:53.526Z', NULL, NULL, 1, true),
(14, 'TV571891', 'Test Vendor', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vendor@example.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T01:56:12.064Z', '2025-06-05T01:56:12.064Z', NULL, NULL, 1, true),
(15, 'TV716672', 'Test Vendor', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vendor@example.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T01:58:36.808Z', '2025-06-05T01:58:36.808Z', NULL, NULL, 1, true),
(16, 'TV772239', 'Test Vendor', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vendor@example.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T01:59:32.382Z', '2025-06-05T01:59:32.382Z', NULL, NULL, 1, true),
(17, 'TV792967', 'Test Vendor', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vendor@example.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T01:59:53.076Z', '2025-06-05T01:59:53.076Z', NULL, NULL, 1, true),
(18, 'TV853374', 'Test Vendor', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vendor@example.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T02:00:53.534Z', '2025-06-05T02:00:53.534Z', NULL, NULL, 1, true),
(19, 'VEN001', 'Test Vendor 001', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T02:10:58.151Z', '2025-06-05T02:10:58.151Z', NULL, NULL, 1, true),
(21, 'VEN1749089635928', 'Test Vendor 1749089635928', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test1749089635928@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T02:13:57.754Z', '2025-06-05T02:13:57.754Z', NULL, NULL, 1, true),
(22, 'VEN1749089708190', 'Test Vendor 1749089708190', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test1749089708190@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T02:15:08.433Z', '2025-06-05T02:15:08.433Z', NULL, NULL, 1, true),
(23, 'VEN1749089731713', 'Test Vendor 1749089731713', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test1749089731713@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T02:15:31.902Z', '2025-06-05T02:15:31.902Z', NULL, NULL, 1, true),
(24, 'V174908976', 'Test Vendor 1749089769754', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test1749089769754@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T02:16:09.502Z', '2025-06-05T02:16:09.502Z', NULL, NULL, 1, true),
(25, 'V174908979', 'Test Vendor 1749089793928', 'Supplier', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test1749089793928@vendor.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active', false, NULL, NULL, NULL, NULL, true, '2025-06-05T02:16:34.395Z', '2025-06-05T02:16:34.395Z', NULL, NULL, 1, true);

-- Table: warehouse_bins (0 records - empty)

-- Table: work_centers (26 records)
INSERT INTO "work_centers" ("id", "code", "name", "plant_id", "description", "capacity", "capacity_unit", "cost_rate", "is_active", "created_at", "updated_at", "status", "cost_center_id", "company_code_id", "active") VALUES
(1, 'WC-ASM-01', 'Primary Assembly Line', 1, 'Main assembly line for final product assembly with automated stations', '120.00', 'units/day', '65.75', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'active', NULL, NULL, true),
(2, 'WC-ASM-02', 'Secondary Assembly', 1, 'Manual assembly operations for complex components', '85.00', 'units/day', '48.50', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'active', NULL, NULL, true),
(3, 'WC-SUBASM', 'Sub-Assembly Station', 2, 'Pre-assembly of component groups before main assembly', '200.00', 'units/day', '42.25', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'active', NULL, NULL, true),
(4, 'WC-MCH-01', 'CNC Machining Center', 2, 'Precision CNC machining for critical components', '65.00', 'units/day', '78.50', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'active', NULL, NULL, true),
(5, 'WC-MCH-02', 'Milling Station', 3, 'Multi-axis milling operations for complex geometries', '40.00', 'units/day', '82.75', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'active', NULL, NULL, true),
(6, 'WC-QC-01', 'Quality Inspection', 1, 'Manual and automated quality inspection station', '180.00', 'units/day', '45.25', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'active', NULL, NULL, true),
(7, 'WC-PKG-01', 'Packaging Line', 1, 'Automated packaging system for finished products', '200.00', 'units/day', '38.75', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'active', NULL, NULL, true),
(8, 'WC-WELD-01', 'Robotic Welding', 4, 'Automated welding cells for consistent high-quality joints', '60.00', 'units/day', '72.25', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'active', NULL, NULL, true),
(9, 'WC-LASER', 'Laser Cutting Station', 5, 'Precision laser cutting for sheet materials', '70.00', 'units/day', '92.50', true, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'maintenance', NULL, NULL, true),
(10, 'WC-3DPRINT', 'Additive Manufacturing', 6, '3D printing facility for prototypes and small production runs', '30.00', 'units/day', '105.75', false, '2025-05-21T02:02:30.357Z', '2025-05-21T02:02:30.357Z', 'inactive', NULL, NULL, true),
(11, 'WC-W001A', 'Assembly Line - East Coast Warehouse', 2, 'Main assembly line for East Coast Warehouse', '480.00', NULL, NULL, true, '2025-05-21T14:57:16.956Z', '2025-05-21T14:57:16.956Z', 'ACTIVE', NULL, NULL, true),
(12, 'WC-p001A', 'Assembly Line - plant South East', 4, 'Main assembly line for plant South East', '480.00', NULL, NULL, true, '2025-05-21T14:57:16.956Z', '2025-05-21T14:57:16.956Z', 'ACTIVE', NULL, NULL, true),
(13, 'WC-P004A', 'Assembly Line - Shanghai Facility', 6, 'Main assembly line for Shanghai Facility', '480.00', NULL, NULL, true, '2025-05-21T14:57:16.956Z', '2025-05-21T14:57:16.956Z', 'ACTIVE', NULL, NULL, true),
(14, 'WC-P003A', 'Assembly Line - Berlin Production', 5, 'Main assembly line for Berlin Production', '480.00', NULL, NULL, true, '2025-05-21T14:57:16.956Z', '2025-05-21T14:57:16.956Z', 'ACTIVE', NULL, NULL, true),
(15, 'WC-P001A', 'Assembly Line - Main Factory', 1, 'Main assembly line for Main Factory', '480.00', NULL, NULL, true, '2025-05-21T14:57:16.956Z', '2025-05-21T14:57:16.956Z', 'ACTIVE', NULL, NULL, true),
(16, 'WC-W003P', 'Packaging - Asian Distribution Hub', 8, 'Packaging workstation for Asian Distribution Hub', '960.00', NULL, NULL, true, '2025-05-21T14:57:26.598Z', '2025-05-21T14:57:26.598Z', 'ACTIVE', NULL, NULL, true),
(17, 'WC-P004P', 'Packaging - Shanghai Facility', 6, 'Packaging workstation for Shanghai Facility', '960.00', NULL, NULL, true, '2025-05-21T14:57:26.598Z', '2025-05-21T14:57:26.598Z', 'ACTIVE', NULL, NULL, true),
(18, 'WC-p001P', 'Packaging - plant South East', 4, 'Packaging workstation for plant South East', '960.00', NULL, NULL, true, '2025-05-21T14:57:26.598Z', '2025-05-21T14:57:26.598Z', 'ACTIVE', NULL, NULL, true),
(19, 'WC-W004P', 'Packaging - UK Warehouse', 9, 'Packaging workstation for UK Warehouse', '960.00', NULL, NULL, true, '2025-05-21T14:57:26.598Z', '2025-05-21T14:57:26.598Z', 'ACTIVE', NULL, NULL, true),
(20, 'WC-W001P', 'Packaging - East Coast Warehouse', 2, 'Packaging workstation for East Coast Warehouse', '960.00', NULL, NULL, true, '2025-05-21T14:57:26.598Z', '2025-05-21T14:57:26.598Z', 'ACTIVE', NULL, NULL, true),
(21, 'WC-AB01', 'Abdul WC', 1, 'Abdul Workcenter Demo', '50.00', 'units/day', '50.00', true, '2025-05-21T16:40:07.940Z', '2025-05-21T16:40:07.940Z', 'active', NULL, NULL, true),
(22, 'WC001', 'Test Work Center 001', 1, 'Test work center', '100.00', 'units/day', NULL, true, '2025-06-05T02:10:58.469Z', '2025-06-05T02:10:58.469Z', 'active', NULL, NULL, true),
(24, 'WC1749089635928', 'Test Work Center 1749089635928', 1, 'Test work center', '100.00', 'units/day', NULL, true, '2025-06-05T02:14:02.101Z', '2025-06-05T02:14:02.101Z', 'active', NULL, NULL, true),
(25, 'WC1749089708190', 'Test Work Center 1749089708190', 1, 'Test work center', '100.00', 'units/day', NULL, true, '2025-06-05T02:15:08.614Z', '2025-06-05T02:15:08.614Z', 'active', NULL, NULL, true),
(26, 'WC1749089731713', 'Test Work Center 1749089731713', 1, 'Test work center', '100.00', 'units/day', NULL, true, '2025-06-05T02:15:32.153Z', '2025-06-05T02:15:32.153Z', 'active', NULL, NULL, true),
(27, 'WC17490897', 'Test WC 1749089769754', 1, 'Test work center', '100.00', 'units/day', NULL, true, '2025-06-05T02:16:10.027Z', '2025-06-05T02:16:10.027Z', 'active', NULL, NULL, true);

-- Total Records Exported: 1398
