# Complete Database Restoration Script (PowerShell)
# Generated: 2025-06-05T15:16:22.845Z

Write-Host "Starting complete database restoration..." -ForegroundColor Green

# Check if database URL is provided
if (-not $env:DATABASE_URL) {
    Write-Host "ERROR: DATABASE_URL environment variable is required" -ForegroundColor Red
    exit 1
}

# Step 1: Create schema
Write-Host "Creating database schema..." -ForegroundColor Yellow
psql $env:DATABASE_URL -f complete-schema.sql

# Step 2: Insert data
Write-Host "Inserting data..." -ForegroundColor Yellow
psql $env:DATABASE_URL -f complete-data.sql

# Step 3: Create sequences
Write-Host "Creating sequences..." -ForegroundColor Yellow
psql $env:DATABASE_URL -f sequences.sql

# Step 4: Add constraints and indexes
Write-Host "Adding constraints and indexes..." -ForegroundColor Yellow
psql $env:DATABASE_URL -f constraints-indexes.sql

Write-Host "Database restoration complete!" -ForegroundColor Green
Write-Host "Run verification command to check tables" -ForegroundColor Cyan
