import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import CustomizableDashboard from "@/pages/CustomizableDashboard";
import { useEffect, useState } from "react";
import { 
  Package2, Users, Building, Factory, 
  Package, Store, ShoppingBag, CreditCard, Ruler, 
  ClipboardCheck, BookOpen, DollarSign, BarChart2, 
  UserCircle, Percent, Briefcase, Settings, Calendar,
  FileText, ShoppingCart
} from "lucide-react";

// Import the DraggableTiles component
import { DraggableTiles } from "@/components/master-data/DraggableTiles";

// Import the module dashboards
import Sales from "@/pages/sales/Sales";
import SalesOrderList from "@/pages/sales/SalesOrderList";
import SalesOrder from "@/pages/sales/SalesOrder";
import Inventory from "@/pages/inventory/Inventory";
import Finance from "@/pages/finance/Finance";
import Controlling from "@/pages/Controlling";
import Help from "@/pages/Help";
import UserGuides from "@/pages/UserGuides";

// Import transaction modules
import SalesOrderTransaction from "@/pages/transactions/SalesOrder";
import InvoiceTransaction from "@/pages/transactions/Invoice";

// Import sales components
import SalesLeads from "@/pages/sales/SalesLeads";
import SalesOpportunities from "@/pages/sales/SalesOpportunities";
import SalesQuotes from "@/pages/sales/SalesQuotes";
import SalesQuoteApproval from "@/pages/sales/SalesQuoteApproval";

// Import purchase and production components
import PurchaseModule from "@/pages/purchase/Purchase";
import ProductionModule from "@/pages/production/Production";

// Import master data components
import UnitOfMeasure from "@/pages/master-data/UnitOfMeasure";
import CompanyCode from "@/pages/master-data/CompanyCode";
import Transport from "@/pages/Transport";
import TransportAdmin from "@/pages/TransportAdmin";
import GitHubSetup from "@/pages/GitHubSetup";
import GitHubIntegration from "@/pages/GitHubIntegration";
import Plant from "@/pages/master-data/Plant";
import Currency from "@/pages/master-data/Currency";
import StorageLocation from "@/pages/master-data/StorageLocation";
import SalesOrganization from "@/pages/master-data/SalesOrganization";
import PurchaseOrganization from "@/pages/master-data/PurchaseOrganization";
import PurchaseReferences from "@/pages/master-data/PurchaseReferences";
import CreditControl from "@/pages/master-data/CreditControl";
import ApprovalLevels from "@/pages/master-data/ApprovalLevels";
import Material from "@/pages/master-data/MaterialFixed";
import ChartOfAccounts from "@/pages/master-data/ChartOfAccounts";
import Customer from "@/pages/master-data/Customer";
import Vendor from "@/pages/master-data/Vendor";
import BillOfMaterials from "@/pages/master-data/BillOfMaterials";
import SimpleWorkCenters from "@/pages/master-data/SimpleWorkCenters";
import CostCenters from "@/pages/master-data/CostCenters";
import ProfitCenters from "@/pages/master-data/ProfitCenters";
import Employees from "@/pages/master-data/Employees";
import TaxMaster from "@/pages/master-data/TaxMaster";
import AssetMaster from "@/pages/master-data/AssetMaster";
import Regions from "@/pages/master-data/Regions";
import Currencies from "@/pages/master-data/Currencies";
import FiscalCalendar from "@/pages/master-data/FiscalCalendar";
import FiscalYearVariant from "@/pages/master-data/FiscalYearVariant";
import GLAccounts from "@/pages/master-data/GLAccounts";
import MasterDataChecker from "@/pages/tools/MasterDataChecker";
import MasterDataProtection from "@/pages/tools/MasterDataProtection";
import TestApplication from "@/pages/tools/TestApplication";
import ApiTester from "@/pages/tools/ApiTester";
import AppLayout from "@/components/layout/AppLayout";
import { SidebarProvider } from "@/hooks/use-sidebar";

// Lazy imports for other modules we'll create
const HR = () => <div className="p-6">HR module coming soon</div>;
const AccountsReceivable = () => <div className="p-6">Accounts Receivable module coming soon</div>;
const AccountsPayable = () => <div className="p-6">Accounts Payable module coming soon</div>;
const GeneralLedger = () => <div className="p-6">General Ledger module coming soon</div>;
const SettingsPage = () => <div className="p-6">Settings module coming soon</div>;
import Reports from "@/pages/Reports";
import Upload from "@/pages/Upload";
import FinancialConfiguration from "@/pages/FinancialConfiguration";
import EndToEndFinancialGuide from "@/pages/EndToEndFinancialGuide";
import SimpleFinancialConfig from "@/pages/SimpleFinancialConfig";

// Import the Tools page
import Tools from "@/pages/Tools";
import AIAgentsDemo from "@/pages/AIAgentsDemo";
import IssuesMonitoringDashboard from "@/pages/IssuesMonitoringDashboard";
import SystemIntegrityDashboard from "@/pages/SystemIntegrityDashboard";
import ChangeLogDashboard from "@/pages/ChangeLogDashboard";

// Master Data dashboard with navigation to submodules and draggable tiles
const MasterData = () => {
  const navigate = (path: string) => () => {
    window.location.pathname = path;
  };
  
  // Define organizational master data tiles
  const initialOrgTiles = [
    {
      id: "company-code",
      title: "Company Code",
      icon: <Building className="h-5 w-5 text-blue-600" />,
      description: "Legal entities in your organization",
      linkText: "Manage Company Codes →",
      onClick: navigate("/master-data/company-code")
    },
    {
      id: "plant",
      title: "Plant",
      icon: <Factory className="h-5 w-5 text-blue-600" />,
      description: "Manufacturing sites and warehouses",
      linkText: "Manage Plants →",
      onClick: navigate("/master-data/plant")
    },
    {
      id: "storage-location",
      title: "Storage Location",
      icon: <Package className="h-5 w-5 text-blue-600" />,
      description: "Physical inventory locations within plants",
      linkText: "Manage Storage Locations →",
      onClick: navigate("/master-data/storage-location")
    },
    {
      id: "sales-organization",
      title: "Sales Organization",
      icon: <Store className="h-5 w-5 text-blue-600" />,
      description: "Sales units in your organization",
      linkText: "Manage Sales Organizations →",
      onClick: navigate("/master-data/sales-organization")
    },
    {
      id: "purchase-organization",
      title: "Purchasing Org",
      icon: <ShoppingBag className="h-5 w-5 text-blue-600" />,
      description: "Procurement units in your organization",
      linkText: "Manage Purchase Organizations →",
      onClick: navigate("/master-data/purchase-organization")
    },
    {
      id: "purchase-references",
      title: "Purchase References",
      icon: <FileText className="h-5 w-5 text-blue-600" />,
      description: "Reference data for procurement",
      linkText: "Manage Purchase References →",
      onClick: navigate("/master-data/purchase-references")
    },
    {
      id: "credit-control",
      title: "Credit Control",
      icon: <CreditCard className="h-5 w-5 text-blue-600" />,
      description: "Financial risk management units",
      linkText: "Manage Credit Control Areas →",
      onClick: navigate("/master-data/credit-control")
    }
  ];

  // Define core master data tiles
  const initialCoreTiles = [
    {
      id: "material",
      title: "Material Master",
      icon: <Package2 className="h-5 w-5 text-blue-600" />,
      description: "Products, materials and finished goods",
      linkText: "Manage Materials →",
      onClick: navigate("/master-data/material")
    },
    {
      id: "bom",
      title: "Bill of Materials",
      icon: <ClipboardCheck className="h-5 w-5 text-blue-600" />,
      description: "Components needed to produce finished goods",
      linkText: "Manage BOMs →",
      onClick: navigate("/master-data/bom")
    },
    {
      id: "uom",
      title: "Units of Measure",
      icon: <Ruler className="h-5 w-5 text-blue-600" />,
      description: "Management of measurement units with conversion factors",
      linkText: "View Module →",
      onClick: navigate("/master-data/uom")
    },
    {
      id: "customer",
      title: "Customer Master",
      icon: <Users className="h-5 w-5 text-blue-600" />,
      description: "Customer information and preferences",
      linkText: "Manage Customers →",
      onClick: navigate("/master-data/customer")
    },
    {
      id: "vendor",
      title: "Vendor Master",
      icon: <Building className="h-5 w-5 text-blue-600" />,
      description: "Supplier and vendor information",
      linkText: "Manage Vendors →",
      onClick: navigate("/master-data/vendor")
    },
    {
      id: "currency",
      title: "Currencies",
      icon: <DollarSign className="h-5 w-5 text-blue-600" />,
      description: "Define currencies and exchange rates for financial transactions",
      linkText: "Manage Currencies →",
      onClick: navigate("/master-data/currencies")
    },
    {
      id: "chart-of-accounts",
      title: "Chart of Accounts",
      icon: <BookOpen className="h-5 w-5 text-blue-600" />,
      description: "Financial account structure",
      linkText: "Manage Chart of Accounts →",
      onClick: navigate("/master-data/chart-of-accounts")
    },
    {
      id: "fiscal-calendar",
      title: "Fiscal Calendar",
      icon: <Calendar className="h-5 w-5 text-blue-600" />,
      description: "Manage fiscal periods and accounting timeframes",
      linkText: "Manage Fiscal Calendar →",
      onClick: navigate("/master-data/fiscal-calendar")
    },
    {
      id: "fiscal-year-variant",
      title: "Fiscal Year Variant",
      icon: <Calendar className="h-5 w-5 text-green-600" />,
      description: "Define fiscal year structures and period configurations",
      linkText: "Manage Fiscal Year Variants →",
      onClick: navigate("/master-data/fiscal-year-variant")
    },
    {
      id: "gl-accounts",
      title: "GL Accounts",
      icon: <BookOpen className="h-5 w-5 text-purple-600" />,
      description: "General ledger accounts for financial postings",
      linkText: "Manage GL Accounts →",
      onClick: navigate("/master-data/gl-accounts")
    },
    {
      id: "cost-centers",
      title: "Cost Centers",
      icon: <BarChart2 className="h-5 w-5 text-orange-600" />,
      description: "Organizational units for cost allocation and control",
      linkText: "Manage Cost Centers →",
      onClick: navigate("/master-data/cost-centers")
    },
    {
      id: "profit-centers",
      title: "Profit Centers",
      icon: <DollarSign className="h-5 w-5 text-emerald-600" />,
      description: "Business units for profitability analysis",
      linkText: "Manage Profit Centers →",
      onClick: navigate("/master-data/profit-centers")
    }
  ];

  // State for tiles
  const [orgTiles, setOrgTiles] = useState(initialOrgTiles);
  const [coreTiles, setCoreTiles] = useState(initialCoreTiles);

  // Load saved tile order on component mount
  useEffect(() => {
    try {
      // Load organizational tiles order
      const savedOrgTiles = localStorage.getItem('masterDataTiles-Organizational Master Data');
      if (savedOrgTiles) {
        const savedOrgOrder = JSON.parse(savedOrgTiles);
        const reorderedOrgTiles = [...initialOrgTiles].sort((a, b) => {
          return savedOrgOrder.indexOf(a.id) - savedOrgOrder.indexOf(b.id);
        });
        setOrgTiles(reorderedOrgTiles);
      }

      // Load core tiles order
      const savedCoreTiles = localStorage.getItem('masterDataTiles-Core Master Data');
      if (savedCoreTiles) {
        const savedCoreOrder = JSON.parse(savedCoreTiles);
        const reorderedCoreTiles = [...initialCoreTiles].sort((a, b) => {
          return savedCoreOrder.indexOf(a.id) - savedCoreOrder.indexOf(b.id);
        });
        setCoreTiles(reorderedCoreTiles);
      }
    } catch (error) {
      console.error("Failed to load saved tile order:", error);
    }
  }, []);
  
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Master Data Management</h1>
      
      {/* Organizational Master Data with DraggableTiles */}
      <DraggableTiles
        title="Organizational Master Data"
        description="Defines your company's hierarchy and must be created before transactional data."
        initialTiles={orgTiles}
      />
      
      {/* Core Master Data with DraggableTiles */}
      <DraggableTiles
        title="Core Master Data"
        description="Essential master records required for business operations."
        initialTiles={coreTiles}
      />
      
      {/* Additional Master Data with draggable tiles */}
      <DraggableTiles
        title="Additional Master Data"
        description="Supporting master records for specialized business processes."
        initialTiles={[
          {
            id: "approval-level",
            title: "Approval Levels",
            icon: <CreditCard className="h-5 w-5 text-blue-600" />,
            description: "Purchase approval hierarchy and authorization limits",
            linkText: "Manage Approval Levels →",
            onClick: () => window.location.pathname = "/master-data/approval-level"
          },
          {
            id: "work-centers",
            title: "Work Centers",
            icon: <Settings className="h-5 w-5 text-blue-600" />,
            description: "Production capacity units",
            linkText: "View All Work Centers →",
            onClick: () => window.location.pathname = "/master-data/work-centers"
          },
          {
            id: "cost-centers",
            title: "Cost Centers",
            icon: <DollarSign className="h-5 w-5 text-blue-600" />,
            description: "Organizational cost assignment units",
            linkText: "View All Cost Centers →",
            onClick: () => window.location.pathname = "/master-data/cost-centers"
          },
          {
            id: "profit-centers",
            title: "Profit Centers",
            icon: <BarChart2 className="h-5 w-5 text-blue-600" />,
            description: "Profit accountability units",
            linkText: "View All Profit Centers →",
            onClick: () => window.location.pathname = "/master-data/profit-centers"
          },
          {
            id: "employees",
            title: "Employees",
            icon: <UserCircle className="h-5 w-5 text-blue-600" />,
            description: "Employee records and HR data",
            linkText: "View All Employees →",
            onClick: () => window.location.pathname = "/master-data/employees"
          },
          {
            id: "tax-master",
            title: "Tax Master",
            icon: <Percent className="h-5 w-5 text-blue-600" />,
            description: "Tax codes and configurations",
            linkText: "View All Tax Codes →",
            onClick: () => window.location.pathname = "/master-data/tax-master"
          },
          {
            id: "asset-master",
            title: "Asset Master",
            icon: <Briefcase className="h-5 w-5 text-blue-600" />,
            description: "Fixed assets and depreciation rules",
            linkText: "View All Assets →",
            onClick: () => window.location.pathname = "/master-data/asset-master"
          },
          {
            id: "regions",
            title: "Regions",
            icon: <Package2 className="h-5 w-5 text-blue-600" />,
            description: "Global regions with country assignments",
            linkText: "Manage Regions →",
            onClick: () => window.location.pathname = "/master-data/regions"
          }
        ]}
      />
    </div>
  );
};

// Main application router
function Router() {
  return (
    <AppLayout>
      <Switch>
        {/* Dashboards */}
        <Route path="/" component={Dashboard} />
        <Route path="/custom-dashboard" component={CustomizableDashboard} />
        
        {/* Master Data Module and Submodules */}
        <Route path="/master-data" component={MasterData} />
        <Route path="/master-data/uom" component={UnitOfMeasure} />
        <Route path="/master-data/company-code" component={CompanyCode} />
        <Route path="/master-data/plant" component={Plant} />
        <Route path="/master-data/currency" component={Currency} />
        <Route path="/master-data/storage-location" component={StorageLocation} />
        <Route path="/master-data/sales-organization" component={SalesOrganization} />
        <Route path="/master-data/purchase-organization" component={PurchaseOrganization} />
        <Route path="/master-data/purchase-references" component={PurchaseReferences} />
        <Route path="/master-data/credit-control" component={CreditControl} />
        <Route path="/master-data/approval-level" component={ApprovalLevels} />
        <Route path="/master-data/material" component={Material} />
        <Route path="/master-data/chart-of-accounts" component={ChartOfAccounts} />
        <Route path="/master-data/customer" component={Customer} />
        <Route path="/master-data/vendor" component={Vendor} />
        <Route path="/master-data/bom" component={BillOfMaterials} />
        <Route path="/master-data/work-centers" component={SimpleWorkCenters} />
        <Route path="/master-data/cost-centers" component={CostCenters} />
        <Route path="/master-data/profit-centers" component={ProfitCenters} />
        <Route path="/master-data/employees" component={Employees} />
        <Route path="/master-data/tax-master" component={TaxMaster} />
        <Route path="/master-data/asset-master" component={AssetMaster} />
        <Route path="/master-data/regions" component={Regions} />
        <Route path="/master-data/currencies" component={Currencies} />
        <Route path="/master-data/fiscal-calendar" component={FiscalCalendar} />
        <Route path="/master-data/fiscal-year-variant" component={FiscalYearVariant} />
        <Route path="/master-data/gl-accounts" component={GLAccounts} />
        
        {/* Transport System */}
        <Route path="/transport" component={Transport} />
        <Route path="/transport/admin" component={TransportAdmin} />
        <Route path="/github-setup" component={GitHubSetup} />
        <Route path="/github-integration" component={GitHubIntegration} />
        
        {/* Other modules */}
        <Route path="/help" component={Help} />
        <Route path="/user-guides" component={UserGuides} />
        <Route path="/ai-agents" component={AIAgentsDemo} />
        <Route path="/issues" component={IssuesMonitoringDashboard} />
        <Route path="/system-integrity" component={SystemIntegrityDashboard} />
        <Route path="/change-log" component={ChangeLogDashboard} />
        <Route path="/sales" component={Sales} />
        <Route path="/sales/leads" component={SalesLeads} />
        <Route path="/sales/opportunities" component={SalesOpportunities} />
        <Route path="/sales/quotes" component={SalesQuotes} />
        <Route path="/sales/quotes/approved" component={SalesQuotes} />
        <Route path="/sales/quote-approval" component={SalesQuoteApproval} />
        <Route path="/sales/orders" component={SalesOrderList} />
        <Route path="/sales/orders/new" component={SalesOrder} />
        <Route path="/inventory" component={Inventory} />
        <Route path="/purchase" component={PurchaseModule} />
        <Route path="/production" component={ProductionModule} />
        <Route path="/hr" component={HR} />
        
        {/* Transaction Process Flows */}
        <Route path="/transactions/sales-order" component={SalesOrderTransaction} />
        <Route path="/transactions/invoice" component={InvoiceTransaction} />
        
        {/* Finance Module and Submodules */}
        <Route path="/finance" component={Finance} />
        <Route path="/finance/configuration" component={FinancialConfiguration} />
        <Route path="/finance/configuration-assistant" component={SimpleFinancialConfig} />
        <Route path="/finance/end-to-end-guide" component={EndToEndFinancialGuide} />
        <Route path="/finance/accounts-receivable" component={AccountsReceivable} />
        <Route path="/finance/accounts-payable" component={AccountsPayable} />
        <Route path="/finance/general-ledger" component={GeneralLedger} />
        <Route path="/controlling" component={Controlling} />
        
        {/* Tools and Utilities */}
        <Route path="/tools" component={Tools} />
        <Route path="/tools/master-data-checker" component={MasterDataChecker} />
        <Route path="/tools/master-data-protection" component={MasterDataProtection} />
        <Route path="/tools/test-application" component={TestApplication} />
        <Route path="/tools/api-tester" component={ApiTester} />
        
        {/* Reports, Upload and Settings */}
        <Route path="/reports" component={Reports} />
        <Route path="/upload" component={Upload} />
        <Route path="/settings" component={SettingsPage} />
        
        {/* 404 Not Found */}
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

// Main App component
export default function App() {
  return (
    <SidebarProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </SidebarProvider>
  );
}