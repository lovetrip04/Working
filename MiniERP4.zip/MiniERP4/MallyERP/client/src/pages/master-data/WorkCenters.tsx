import { ArrowLeft, Check, Plus, RefreshCcw, Settings, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
export interface WorkCenter {
  id: number;
  code: string;
  name: string;
  description: string;
  capacity: number;
  capacity_unit: string;
  cost_rate: number;
  status: 'active' | 'inactive' | 'maintenance';
  plant: string;
  plant_id?: number | null;
}

interface Plant {
  id: number;
  code: string;
  name: string;
}

const WorkCenters = () => {
  const [workCenters, setWorkCenters] = useState<WorkCenter[]>([]);
  const [plants, setPlants] = useState<Plant[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editingWorkCenter, setEditingWorkCenter] = useState<WorkCenter | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    description: "",
    capacity: "",
    capacity_unit: "units/day",
    cost_rate: "",
    status: "active",
    plant_id: ""
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  // Function to load data with refresh capability
  const loadData = async () => {
    try {
      setIsLoading(true);
      
      console.log("Fetching work centers data...");
      
      // Fetch work centers - add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const workCentersResponse = await fetch(`/api/master-data/work-center?t=${timestamp}`);
      
      if (!workCentersResponse.ok) {
        throw new Error("Failed to fetch work centers");
      }
      
      const workCentersData = await workCentersResponse.json();
      console.log("Work centers data received:", workCentersData);
      setWorkCenters(workCentersData || []);
      
      // Fetch plants for dropdown
      const plantsResponse = await fetch(`/api/master-data/work-center/options/plants?t=${timestamp}`);
      if (plantsResponse.ok) {
        const plantsData = await plantsResponse.json();
        setPlants(plantsData || []);
      }
    } catch (error) {
      console.error("Error loading data:", error);
      toast({
        title: "Error",
        description: "Failed to load work centers data. Please try refreshing.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Function to handle manual refresh
  const handleRefresh = () => {
    loadData();
  };

  // Load work centers and plants from API on component mount
  useEffect(() => {
    loadData();
  }, []);

  // Filter work centers based on search query
  const filteredWorkCenters = workCenters.filter(wc => 
    searchQuery === "" || 
    wc.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    wc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    wc.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear the error for this field if it exists
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  // Handle dropdown changes
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear the error for this field if it exists
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  // Validate form data
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.code.trim()) {
      newErrors.code = "Work Center Code is required";
    }
    
    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }
    
    if (formData.capacity && isNaN(Number(formData.capacity))) {
      newErrors.capacity = "Capacity must be a number";
    }
    
    if (formData.cost_rate && isNaN(Number(formData.cost_rate))) {
      newErrors.cost_rate = "Cost Rate must be a number";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle edit work center
  const handleEdit = (workCenter: WorkCenter) => {
    setEditingWorkCenter(workCenter);
    setIsEditMode(true);
    setFormData({
      code: workCenter.code,
      name: workCenter.name,
      description: workCenter.description,
      capacity: workCenter.capacity.toString(),
      capacity_unit: workCenter.capacity_unit,
      cost_rate: workCenter.cost_rate.toString(),
      status: workCenter.status,
      plant_id: workCenter.plant_id?.toString() || ""
    });
    setIsDialogOpen(true);
  };

  // Handle delete work center
  const handleDelete = async (workCenter: WorkCenter) => {
    if (!confirm(`Are you sure you want to delete work center "${workCenter.name}"?`)) {
      return;
    }
    
    try {
      const response = await fetch(`/api/master-data/work-center/${workCenter.id}`, {
        method: "DELETE"
      });
      
      if (!response.ok) {
        throw new Error("Failed to delete work center");
      }
      
      // Remove from local state
      setWorkCenters(prev => prev.filter(wc => wc.id !== workCenter.id));
      
      toast({
        title: "Success",
        description: "Work center deleted successfully"
      });
    } catch (error: any) {
      console.error("Error deleting work center:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to delete work center",
        variant: "destructive"
      });
    }
  };

  // Submit form data
  const handleSubmit = async () => {
    if (!validateForm()) return;
    
    try {
      // Process the plant_id (treat "none" as null)
      const plantId = formData.plant_id === "none" ? null : 
                     (formData.plant_id ? Number(formData.plant_id) : null);
      
      const url = isEditMode ? `/api/master-data/work-center/${editingWorkCenter?.id}` : "/api/master-data/work-center";
      const method = isEditMode ? "PUT" : "POST";
      
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          code: formData.code,
          name: formData.name,
          description: formData.description,
          capacity: formData.capacity ? Number(formData.capacity) : null,
          capacity_unit: formData.capacity_unit,
          cost_rate: formData.cost_rate ? Number(formData.cost_rate) : null,
          status: formData.status,
          plant_id: plantId
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `Failed to ${isEditMode ? 'update' : 'create'} work center`);
      }
      
      const workCenterData = await response.json();
      
      if (isEditMode) {
        // Update existing work center
        setWorkCenters(prev => prev.map(wc => wc.id === editingWorkCenter?.id ? workCenterData : wc));
      } else {
        // Add new work center
        setWorkCenters(prev => [...prev, workCenterData]);
      }
      
      // Reset form and close dialog
      setFormData({
        code: "",
        name: "",
        description: "",
        capacity: "",
        capacity_unit: "units/day",
        cost_rate: "",
        status: "active",
        plant_id: ""
      });
      setIsDialogOpen(false);
      setIsEditMode(false);
      setEditingWorkCenter(null);
      
      toast({
        title: "Success",
        description: `Work center ${isEditMode ? 'updated' : 'created'} successfully`
      });
    } catch (error: any) {
      console.error(`Error ${isEditMode ? 'updating' : 'creating'} work center:`, error);
      toast({
        title: "Error",
        description: error.message || `Failed to ${isEditMode ? 'update' : 'create'} work center`,
        variant: "destructive"
      });
    }
  };

  // Helper function for status badge styling
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'maintenance':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <Link href="/master-data" className="mr-4 p-2 rounded-md hover:bg-gray-100">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">Work Centers</h1>
          <p className="text-gray-600">Manage production capacity units</p>
        </div>
      </div>

      {/* Controls */}
      <div className="mb-6 flex flex-col md:flex-row justify-between items-center space-y-2 md:space-y-0">
        <div className="flex space-x-2 w-full md:w-auto">
          <Input 
            placeholder="Search work centers..." 
            className="w-full md:w-64"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
          <Button variant="default" onClick={() => setSearchQuery("")}>
            Search
          </Button>
          <Button 
            variant="outline" 
            onClick={handleRefresh} 
            className="flex items-center"
            disabled={isLoading}
          >
            <RefreshCcw className={`h-4 w-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} /> 
            Refresh
          </Button>
        </div>
        <Button 
          onClick={() => setIsDialogOpen(true)}
          className="w-full md:w-auto"
        >
          <Plus className="h-4 w-4 mr-1" /> New Work Center
        </Button>
      </div>

      {/* Work Centers Table */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="flex flex-col items-center gap-2">
            <RefreshCcw className="h-8 w-8 animate-spin text-blue-600" />
            <p>Loading work centers data...</p>
          </div>
        </div>
      ) : (
        <>
          {/* Mobile View (Card-based) */}
          <div className="md:hidden space-y-4">
            {filteredWorkCenters.map(workCenter => (
              <div key={workCenter.id} className="bg-white rounded-lg shadow-md p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium text-lg">{workCenter.name}</div>
                    <div className="text-sm text-gray-500">{workCenter.code}</div>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${getStatusBadgeClass(workCenter.status)}`}>
                    {workCenter.status.charAt(0).toUpperCase() + workCenter.status.slice(1)}
                  </span>
                </div>
                <div className="space-y-1 mb-3">
                  <div className="text-sm"><span className="font-medium">Plant:</span> {workCenter.plant}</div>
                  <div className="text-sm"><span className="font-medium">Capacity:</span> {workCenter.capacity} {workCenter.capacity_unit}</div>
                  {workCenter.cost_rate && (
                    <div className="text-sm"><span className="font-medium">Cost Rate:</span> ${workCenter.cost_rate}/hr</div>
                  )}
                  {workCenter.description && (
                    <div className="text-sm mt-1">{workCenter.description}</div>
                  )}
                </div>
                <div className="flex justify-end space-x-2 mt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-blue-600 border-blue-200"
                    onClick={() => handleEdit(workCenter)}
                  >
                    Edit
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-red-600 border-red-200"
                    onClick={() => handleDelete(workCenter)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* Desktop Table View */}
          <div className="hidden md:block bg-white rounded-md shadow">
            <div className="overflow-x-auto" style={{ maxHeight: '650px', overflowY: 'auto' }}>
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50 sticky top-0 z-10">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Code
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Description
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Capacity
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Plant
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredWorkCenters && filteredWorkCenters.length > 0 ? (
                    filteredWorkCenters.map(workCenter => (
                      <tr key={workCenter.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {workCenter.code}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                          {workCenter.name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {workCenter.description}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {workCenter.capacity} {workCenter.capacity_unit}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs rounded-full ${getStatusBadgeClass(workCenter.status)}`}>
                            {workCenter.status.charAt(0).toUpperCase() + workCenter.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {workCenter.plant}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-blue-600 hover:text-blue-800 mr-2"
                            onClick={() => handleEdit(workCenter)}
                          >
                            Edit
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-600 hover:text-red-800"
                            onClick={() => handleDelete(workCenter)}
                          >
                            Delete
                          </Button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="px-6 py-4 text-center text-sm text-gray-500">
                        {isLoading ? 'Loading data...' : 'No work centers found. Click the "New Work Center" button to create one.'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* Create Work Center Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{isEditMode ? 'Edit Work Center' : 'Create New Work Center'}</DialogTitle>
            <DialogDescription>
              {isEditMode ? 'Update the work center details below.' : 'Add a new work center to manage production capacity in your facility.'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="code" className="text-right">
                Code <span className="text-red-500">*</span>
              </Label>
              <Input
                id="code"
                name="code"
                placeholder="WC-001"
                value={formData.code}
                onChange={handleInputChange}
                className={errors.code ? "border-red-500" : ""}
              />
              {errors.code && <p className="text-xs text-red-500">{errors.code}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="name" className="text-right">
                Name <span className="text-red-500">*</span>
              </Label>
              <Input
                id="name"
                name="name"
                placeholder="Assembly Line 1"
                value={formData.name}
                onChange={handleInputChange}
                className={errors.name ? "border-red-500" : ""}
              />
              {errors.name && <p className="text-xs text-red-500">{errors.name}</p>}
            </div>
            
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description" className="text-right">
                Description
              </Label>
              <Textarea
                id="description"
                name="description"
                placeholder="Describe the work center's purpose and capabilities"
                value={formData.description}
                onChange={handleInputChange}
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="capacity" className="text-right">
                Capacity
              </Label>
              <Input
                id="capacity"
                name="capacity"
                type="number"
                placeholder="100"
                value={formData.capacity}
                onChange={handleInputChange}
                className={errors.capacity ? "border-red-500" : ""}
              />
              {errors.capacity && <p className="text-xs text-red-500">{errors.capacity}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="capacity_unit" className="text-right">
                Capacity Unit
              </Label>
              <Select 
                name="capacity_unit"
                value={formData.capacity_unit} 
                onValueChange={(value) => handleSelectChange("capacity_unit", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select unit" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="units/day">Units per day</SelectItem>
                  <SelectItem value="units/hour">Units per hour</SelectItem>
                  <SelectItem value="units/week">Units per week</SelectItem>
                  <SelectItem value="hours/day">Hours per day</SelectItem>
                  <SelectItem value="tons/day">Tons per day</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="cost_rate" className="text-right">
                Cost Rate ($/hr)
              </Label>
              <Input
                id="cost_rate"
                name="cost_rate"
                type="number"
                step="0.01"
                placeholder="45.50"
                value={formData.cost_rate}
                onChange={handleInputChange}
                className={errors.cost_rate ? "border-red-500" : ""}
              />
              {errors.cost_rate && <p className="text-xs text-red-500">{errors.cost_rate}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="status" className="text-right">
                Status
              </Label>
              <Select 
                name="status"
                value={formData.status} 
                onValueChange={(value) => handleSelectChange("status", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="plant_id" className="text-right">
                Plant
              </Label>
              <Select 
                name="plant_id"
                value={formData.plant_id} 
                onValueChange={(value) => handleSelectChange("plant_id", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select plant" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {plants.map(plant => (
                    <SelectItem key={plant.id} value={plant.id.toString()}>
                      {plant.name} ({plant.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>
              Create Work Center
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WorkCenters;