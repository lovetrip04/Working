import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, RefreshCw, ArrowLeft, Users } from "lucide-react";
import { useLocation } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
const toleranceGroupSchema = z.object({
  group_code: z.string().min(1, "Group code is required").max(10, "Group code must be 10 characters or less"),
  group_name: z.string().min(1, "Group name is required").max(100, "Group name must be 100 characters or less"),
  company_code_id: z.number().min(1, "Company code is required"),
  tolerance_type: z.enum(["employee", "customer", "vendor"]),
  amount_per_document: z.number().min(0).default(0),
  amount_per_open_item: z.number().min(0).default(0),
  cash_discount_percentage: z.number().min(0).max(100).default(0),
  payment_difference_percentage: z.number().min(0).max(100).default(0),
  payment_difference_amount: z.number().min(0).default(0),
  gain_loss_tolerance: z.number().min(0).default(0),
  residual_payment_tolerance: z.number().min(0).default(0),
  exchange_rate_tolerance: z.number().min(0).default(0),
  blocking_tolerance: z.number().min(0).default(0),
  currency: z.string().max(3, "Currency must be 3 characters or less").default("USD"),
  description: z.string().optional(),
  active: z.boolean().default(true)
});

type ToleranceGroup = z.infer<typeof toleranceGroupSchema> & { id: number };

export default function ToleranceGroups() {
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<ToleranceGroup | null>(null);
  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  const { data: toleranceGroups = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/tolerance-groups"],
  });

  const { data: companyCodes = [] } = useQuery({
    queryKey: ["/api/company-codes"],
  });

  const form = useForm<z.infer<typeof toleranceGroupSchema>>({
    resolver: zodResolver(toleranceGroupSchema),
    defaultValues: {
      group_code: "",
      group_name: "",
      company_code_id: 0,
      tolerance_type: "employee",
      amount_per_document: 0,
      amount_per_open_item: 0,
      cash_discount_percentage: 0,
      payment_difference_percentage: 0,
      payment_difference_amount: 0,
      gain_loss_tolerance: 0,
      residual_payment_tolerance: 0,
      exchange_rate_tolerance: 0,
      blocking_tolerance: 0,
      currency: "USD",
      description: "",
      active: true
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: z.infer<typeof toleranceGroupSchema>) =>
      apiRequest("/api/tolerance-groups", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tolerance-groups"] });
      setOpen(false);
      setEditingGroup(null);
      form.reset();
      toast({ title: "Success", description: "Tolerance group created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create tolerance group", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }: { id: number } & z.infer<typeof toleranceGroupSchema>) =>
      apiRequest(`/api/tolerance-groups/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tolerance-groups"] });
      setOpen(false);
      setEditingGroup(null);
      form.reset();
      toast({ title: "Success", description: "Tolerance group updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update tolerance group", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/tolerance-groups/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tolerance-groups"] });
      toast({ title: "Success", description: "Tolerance group deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete tolerance group", variant: "destructive" });
    },
  });

  const onSubmit = (data: z.infer<typeof toleranceGroupSchema>) => {
    if (editingGroup) {
      updateMutation.mutate({ id: editingGroup.id, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (group: ToleranceGroup) => {
    setEditingGroup(group);
    form.reset(group);
    setOpen(true);
  };

  const handleCreate = () => {
    setEditingGroup(null);
    form.reset();
    setOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/master-data")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Master Data
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Tolerance Groups</h1>
            <p className="text-muted-foreground">Configure posting and payment tolerance limits for employees and business partners</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={handleCreate}>
                <Plus className="h-4 w-4 mr-2" />
                Create Tolerance Group
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingGroup ? "Edit Tolerance Group" : "Create Tolerance Group"}
                </DialogTitle>
                <DialogDescription>
                  Configure tolerance limits for posting variances and payment differences
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="group_code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Group Code</FormLabel>
                          <FormControl>
                            <Input placeholder="BA55" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="group_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Group Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Standard Tolerance Group" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="company_code_id"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Code</FormLabel>
                          <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select company code" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {companyCodes.map((companyCode: any) => (
                                <SelectItem key={companyCode.id} value={companyCode.id.toString()}>
                                  {companyCode.code} - {companyCode.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="tolerance_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tolerance Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select tolerance type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="employee">Employee</SelectItem>
                              <SelectItem value="customer">Customer</SelectItem>
                              <SelectItem value="vendor">Vendor</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Tolerance Limits</h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="amount_per_document"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount per Document</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                placeholder="0.00" 
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="amount_per_open_item"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount per Open Item</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                placeholder="0.00" 
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="cash_discount_percentage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cash Discount (%)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                min="0"
                                max="100"
                                placeholder="0.00" 
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="payment_difference_percentage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Payment Difference (%)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                min="0"
                                max="100"
                                placeholder="0.00" 
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="gain_loss_tolerance"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Gain/Loss Tolerance</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                placeholder="0.00" 
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="exchange_rate_tolerance"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Exchange Rate Tolerance</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                placeholder="0.00" 
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Input placeholder="Tolerance group description" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingGroup ? "Update" : "Create"} Tolerance Group
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="h-5 w-5" />
            <span>Tolerance Groups</span>
          </CardTitle>
          <CardDescription>
            Manage posting and payment tolerance limits for different user groups and business partners
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading tolerance groups...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Group Code</TableHead>
                  <TableHead>Group Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Company Code</TableHead>
                  <TableHead>Document Amount</TableHead>
                  <TableHead>Cash Discount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {toleranceGroups.map((group: ToleranceGroup) => (
                  <TableRow key={group.id}>
                    <TableCell className="font-medium">{group.group_code}</TableCell>
                    <TableCell>{group.group_name}</TableCell>
                    <TableCell className="capitalize">{group.tolerance_type}</TableCell>
                    <TableCell>{group.company_code_id}</TableCell>
                    <TableCell>{group.currency} {group.amount_per_document.toFixed(2)}</TableCell>
                    <TableCell>{group.cash_discount_percentage}%</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        group.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {group.active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(group)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteMutation.mutate(group.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}