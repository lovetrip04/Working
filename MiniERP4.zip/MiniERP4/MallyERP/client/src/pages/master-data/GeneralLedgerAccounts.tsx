import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, RefreshCw, ArrowLeft, BookOpen } from "lucide-react";
import { useLocation } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
const glAccountSchema = z.object({
  account_number: z.string().min(1, "Account number is required").max(20, "Account number must be 20 characters or less"),
  account_name: z.string().min(1, "Account name is required").max(100, "Account name must be 100 characters or less"),
  account_type: z.enum(["assets", "liabilities", "equity", "revenue", "expenses"]),
  account_group: z.string().min(1, "Account group is required").max(10, "Account group must be 10 characters or less"),
  chart_of_accounts_id: z.number().min(1, "Chart of accounts is required"),
  balance_sheet_account: z.boolean().default(false),
  pl_account: z.boolean().default(false),
  reconciliation_account: z.boolean().default(false),
  line_item_management: z.boolean().default(false),
  open_item_management: z.boolean().default(false),
  currency: z.string().max(3, "Currency must be 3 characters or less").optional(),
  description: z.string().optional(),
  active: z.boolean().default(true)
});

type GLAccount = z.infer<typeof glAccountSchema> & { id: number };

export default function GeneralLedgerAccounts() {
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<GLAccount | null>(null);
  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  const { data: glAccounts = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/gl-accounts"],
  });

  const { data: chartOfAccounts = [] } = useQuery({
    queryKey: ["/api/chart-of-accounts"],
  });

  const form = useForm<z.infer<typeof glAccountSchema>>({
    resolver: zodResolver(glAccountSchema),
    defaultValues: {
      account_number: "",
      account_name: "",
      account_type: "assets",
      account_group: "",
      chart_of_accounts_id: 1,
      balance_sheet_account: false,
      pl_account: false,
      reconciliation_account: false,
      line_item_management: false,
      open_item_management: false,
      currency: "",
      description: "",
      active: true
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: z.infer<typeof glAccountSchema>) =>
      apiRequest("/api/gl-accounts", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gl-accounts"] });
      setOpen(false);
      setEditingAccount(null);
      form.reset();
      toast({ title: "Success", description: "General ledger account created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create GL account", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }: { id: number } & z.infer<typeof glAccountSchema>) =>
      apiRequest(`/api/gl-accounts/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gl-accounts"] });
      setOpen(false);
      setEditingAccount(null);
      form.reset();
      toast({ title: "Success", description: "General ledger account updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update GL account", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/gl-accounts/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gl-accounts"] });
      toast({ title: "Success", description: "General ledger account deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete GL account", variant: "destructive" });
    },
  });

  const onSubmit = (data: z.infer<typeof glAccountSchema>) => {
    if (editingAccount) {
      updateMutation.mutate({ id: editingAccount.id, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (account: GLAccount) => {
    setEditingAccount(account);
    form.reset(account);
    setOpen(true);
  };

  const handleCreate = () => {
    setEditingAccount(null);
    form.reset();
    setOpen(true);
  };

  const accountTypes = [
    { value: "assets", label: "Assets" },
    { value: "liabilities", label: "Liabilities" },
    { value: "equity", label: "Equity" },
    { value: "revenue", label: "Revenue" },
    { value: "expenses", label: "Expenses" }
  ];

  const accountGroups = [
    { value: "CASH", label: "Cash & Cash Equivalents" },
    { value: "AR", label: "Accounts Receivable" },
    { value: "INV", label: "Inventory" },
    { value: "FA", label: "Fixed Assets" },
    { value: "AP", label: "Accounts Payable" },
    { value: "LTD", label: "Long-term Debt" },
    { value: "REV", label: "Revenue" },
    { value: "COGS", label: "Cost of Goods Sold" },
    { value: "EXP", label: "Operating Expenses" }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/master-data")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Master Data
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">General Ledger Accounts</h1>
            <p className="text-muted-foreground">Configure chart of accounts structure and GL account definitions</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={handleCreate}>
                <Plus className="h-4 w-4 mr-2" />
                Create GL Account
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingAccount ? "Edit General Ledger Account" : "Create General Ledger Account"}
                </DialogTitle>
                <DialogDescription>
                  Configure general ledger account settings and account characteristics
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="account_number"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Number</FormLabel>
                          <FormControl>
                            <Input placeholder="1000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="account_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Cash and Cash Equivalents" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="account_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select account type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {accountTypes.map((type) => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="account_group"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Group</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select account group" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {accountGroups.map((group) => (
                                <SelectItem key={group.value} value={group.value}>
                                  {group.value} - {group.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="chart_of_accounts_id"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Chart of Accounts</FormLabel>
                          <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select chart of accounts" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {chartOfAccounts.map((chart: any) => (
                                <SelectItem key={chart.id} value={chart.id.toString()}>
                                  {chart.code} - {chart.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Currency (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="USD" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Input placeholder="Account description" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Account Settings</h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="balance_sheet_account"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Balance Sheet Account</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="pl_account"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>P&L Account</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="reconciliation_account"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Reconciliation Account</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="line_item_management"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Line Item Management</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="open_item_management"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Open Item Management</FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingAccount ? "Update" : "Create"} GL Account
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5" />
            <span>General Ledger Accounts</span>
          </CardTitle>
          <CardDescription>
            Manage chart of accounts structure and general ledger account definitions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading general ledger accounts...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Account Number</TableHead>
                  <TableHead>Account Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Group</TableHead>
                  <TableHead>Chart</TableHead>
                  <TableHead>B/S</TableHead>
                  <TableHead>P&L</TableHead>
                  <TableHead>Reconciliation</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {glAccounts.map((account: GLAccount) => (
                  <TableRow key={account.id}>
                    <TableCell className="font-medium">{account.account_number}</TableCell>
                    <TableCell>{account.account_name}</TableCell>
                    <TableCell className="capitalize">{account.account_type}</TableCell>
                    <TableCell>{account.account_group}</TableCell>
                    <TableCell>{account.chart_of_accounts_id}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        account.balance_sheet_account ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {account.balance_sheet_account ? 'Yes' : 'No'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        account.pl_account ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {account.pl_account ? 'Yes' : 'No'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        account.reconciliation_account ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {account.reconciliation_account ? 'Yes' : 'No'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        account.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {account.active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(account)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteMutation.mutate(account.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}