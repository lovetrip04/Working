import { ArrowLeft, Percent } from "lucide-react";
import { useEffect, useState } from "react";

export interface TaxCode {
  id: string;
  name: string;
  description: string;
  rate: number;
  country: string;
  region: string;
  taxType: 'sales' | 'vat' | 'gst' | 'service' | 'income';
  status: 'active' | 'inactive';
}

const sampleTaxCodes: TaxCode[] = [
  {
    id: "TAX-001",
    name: "Standard Sales Tax",
    description: "General sales tax for standard goods",
    rate: 7.5,
    country: "United States",
    region: "California",
    taxType: 'sales',
    status: 'active'
  },
  {
    id: "TAX-002",
    name: "Reduced VAT Rate",
    description: "Reduced rate for essential goods",
    rate: 5.0,
    country: "United Kingdom",
    region: "All Regions",
    taxType: 'vat',
    status: 'active'
  },
  {
    id: "TAX-003",
    name: "Standard GST",
    description: "Standard goods and services tax rate",
    rate: 10.0,
    country: "Australia",
    region: "All Regions",
    taxType: 'gst',
    status: 'active'
  },
  {
    id: "TAX-004",
    name: "Service Tax",
    description: "Tax applied to services",
    rate: 6.0,
    country: "United States",
    region: "New York",
    taxType: 'service',
    status: 'active'
  },
  {
    id: "TAX-005",
    name: "Zero Rate VAT",
    description: "Zero-rated goods and services",
    rate: 0.0,
    country: "European Union",
    region: "All Regions",
    taxType: 'vat',
    status: 'active'
  },
  {
    id: "TAX-006",
    name: "Luxury Sales Tax",
    description: "Higher rate for luxury items",
    rate: 12.5,
    country: "United States",
    region: "All Regions",
    taxType: 'sales',
    status: 'active'
  },
  {
    id: "TAX-007",
    name: "Discontinued Tax",
    description: "Formerly used tax code",
    rate: 4.5,
    country: "Canada",
    region: "Ontario",
    taxType: 'sales',
    status: 'inactive'
  }
];

const TaxMaster = () => {
  const [taxCodes, setTaxCodes] = useState<TaxCode[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate loading data from API
  useEffect(() => {
    const loadData = async () => {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      setTaxCodes(sampleTaxCodes);
      setIsLoading(false);
    };

    loadData();
  }, []);

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTaxTypeBadgeClass = (type: string) => {
    switch (type) {
      case 'sales':
        return 'bg-blue-100 text-blue-800';
      case 'vat':
        return 'bg-purple-100 text-purple-800';
      case 'gst':
        return 'bg-green-100 text-green-800';
      case 'service':
        return 'bg-yellow-100 text-yellow-800';
      case 'income':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <button 
          onClick={() => window.location.pathname = "/master-data"}
          className="mr-4 p-2 rounded-md hover:bg-gray-100"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold">Tax Master</h1>
          <p className="text-gray-600">Manage tax codes and configurations</p>
        </div>
      </div>

      {/* Banner indicating this is a placeholder */}
      <div className="mb-6 bg-blue-50 p-4 rounded-md border border-blue-200">
        <div className="flex items-center">
          <Percent className="h-5 w-5 text-blue-500 mr-2" />
          <span className="text-blue-800 font-medium">
            Tax Master module is under development. The data shown below is sample data for demonstration purposes.
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="mb-6 flex justify-between items-center">
        <div className="flex space-x-2">
          <input 
            type="text" 
            placeholder="Search tax codes..." 
            className="border border-gray-300 rounded-md px-3 py-1.5 text-sm w-64"
          />
          <button className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm">
            Search
          </button>
        </div>
        <div className="flex space-x-2">
          <button 
            className="border border-gray-300 bg-white px-3 py-1.5 rounded-md text-sm flex items-center"
            onClick={() => {
              const csvContent = taxCodes?.map((tax: TaxCode) => ({
                ID: tax.id,
                Name: tax.name,
                Description: tax.description,
                Rate: tax.rate + '%',
                Country: tax.country,
                Region: tax.region,
                Type: tax.taxType,
                Status: tax.status
              })) || [];
              
              const csvString = [
                Object.keys(csvContent[0] || {}).join(','),
                ...csvContent.map((row: any) => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'tax-codes.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            Export
          </button>
          <button 
            className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm flex items-center"
            onClick={() => {
              alert('Tax Code creation form will open here');
            }}
          >
            <span className="mr-1">+</span> New Tax Code
          </button>
        </div>
      </div>

      {/* Tax Codes Table */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="bg-white rounded-md shadow overflow-x-auto max-h-[650px] overflow-y-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0 z-10">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rate (%)
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Country
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Region
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tax Type
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {taxCodes.map(tax => (
                <tr key={tax.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {tax.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                    {tax.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tax.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tax.rate.toFixed(2)}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tax.country}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tax.region}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full ${getTaxTypeBadgeClass(tax.taxType)}`}>
                      {tax.taxType.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full ${getStatusBadgeClass(tax.status)}`}>
                      {tax.status.charAt(0).toUpperCase() + tax.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button className="text-blue-600 hover:text-blue-800 mr-2">Edit</button>
                    <button className="text-red-600 hover:text-red-800">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Pagination */}
          <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 sm:px-6 flex items-center justify-between">
            <div className="flex-1 flex justify-between sm:hidden">
              <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                Previous
              </button>
              <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                Next
              </button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Showing <span className="font-medium">1</span> to <span className="font-medium">7</span> of{' '}
                  <span className="font-medium">7</span> results
                </p>
              </div>
              <div>
                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                  <button className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <span className="sr-only">Previous</span>
                    {/* Heroicon name: solid/chevron-left */}
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </button>
                  <button aria-current="page" className="z-10 bg-blue-50 border-blue-500 text-blue-600 relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                    1
                  </button>
                  <button className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <span className="sr-only">Next</span>
                    {/* Heroicon name: solid/chevron-right */}
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaxMaster;