import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Filter, Download, Edit, Trash2, ArrowLeft, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
interface PurchasingGroup {
  id: number;
  group_code: string;
  group_name: string;
  description: string;
  phone: string;
  email: string;
  responsible_person: string;
  active: boolean;
  created_at: string;
  updated_at: string;
}

interface NewPurchasingGroup {
  group_code: string;
  group_name: string;
  description: string;
  phone: string;
  email: string;
  responsible_person: string;
}

export default function PurchasingGroups() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<PurchasingGroup | null>(null);
  const [newItem, setNewItem] = useState<NewPurchasingGroup>({
    group_code: "",
    group_name: "",
    description: "",
    phone: "",
    email: "",
    responsible_person: ""
  });

  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  useEffect(() => {
    document.title = "Purchasing Groups | MallyERP";
  }, []);

  // Fetch purchasing groups
  const { data: purchasingGroups, isLoading, refetch } = useQuery({
    queryKey: ['/api/master-data/purchasing-groups'],
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: (data: NewPurchasingGroup) => 
      apiRequest('/api/master-data/purchasing-groups', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchasing-groups'] });
      setShowCreateDialog(false);
      setNewItem({
        group_code: "",
        group_name: "",
        description: "",
        phone: "",
        email: "",
        responsible_person: ""
      });
      toast({
        title: "Success",
        description: "Purchasing group created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create purchasing group",
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<PurchasingGroup> }) =>
      apiRequest(`/api/master-data/purchasing-groups/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchasing-groups'] });
      setShowEditDialog(false);
      setEditingItem(null);
      toast({
        title: "Success",
        description: "Purchasing group updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update purchasing group",
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      apiRequest(`/api/master-data/purchasing-groups/${id}`, {
        method: 'DELETE',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchasing-groups'] });
      toast({
        title: "Success",
        description: "Purchasing group deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete purchasing group",
        variant: "destructive",
      });
    },
  });

  const handleCreate = () => {
    if (!newItem.group_code || !newItem.group_name) {
      toast({
        title: "Validation Error",
        description: "Group code and name are required",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate(newItem);
  };

  const handleEdit = (item: PurchasingGroup) => {
    setEditingItem(item);
    setShowEditDialog(true);
  };

  const handleUpdate = () => {
    if (!editingItem) return;
    updateMutation.mutate({
      id: editingItem.id,
      data: editingItem
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this purchasing group?")) {
      deleteMutation.mutate(id);
    }
  };

  const filteredItems = (purchasingGroups as PurchasingGroup[])?.filter(item => {
    const matchesSearch = 
      item.group_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.group_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.responsible_person?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "active" && item.active) || 
      (statusFilter === "inactive" && !item.active);
    
    return matchesSearch && matchesStatus;
  }) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link href="/master-data">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Master Data
              </Button>
            </Link>
          </div>
          <h1 className="text-3xl font-bold">Purchasing Groups</h1>
          <p className="text-muted-foreground">Manage procurement team structure and organization</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Group
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Purchasing Group</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="group_code">Group Code *</Label>
                  <Input
                    id="group_code"
                    value={newItem.group_code}
                    onChange={(e) => setNewItem({...newItem, group_code: e.target.value})}
                    placeholder="e.g., PUR001"
                  />
                </div>
                <div>
                  <Label htmlFor="group_name">Group Name *</Label>
                  <Input
                    id="group_name"
                    value={newItem.group_name}
                    onChange={(e) => setNewItem({...newItem, group_name: e.target.value})}
                    placeholder="e.g., Raw Materials Purchasing"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={newItem.description}
                    onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                    placeholder="Enter description"
                  />
                </div>
                <div>
                  <Label htmlFor="responsible_person">Responsible Person</Label>
                  <Input
                    id="responsible_person"
                    value={newItem.responsible_person}
                    onChange={(e) => setNewItem({...newItem, responsible_person: e.target.value})}
                    placeholder="Enter responsible person"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={newItem.phone}
                    onChange={(e) => setNewItem({...newItem, phone: e.target.value})}
                    placeholder="Enter phone number"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newItem.email}
                    onChange={(e) => setNewItem({...newItem, email: e.target.value})}
                    placeholder="Enter email address"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreate} disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Creating..." : "Create"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-2 flex-1">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by code, name, or responsible person..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={showFilters ? "default" : "outline"}
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="mr-2 h-4 w-4" />
                Filters
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
          
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 pt-4 border-t">
              <div>
                <Label>Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Purchasing Groups ({filteredItems.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading purchasing groups...</div>
          ) : filteredItems.length > 0 ? (
            <div className="overflow-auto max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Group Code</TableHead>
                    <TableHead>Group Name</TableHead>
                    <TableHead>Responsible Person</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.group_code}</TableCell>
                      <TableCell>{item.group_name}</TableCell>
                      <TableCell>{item.responsible_person}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {item.phone && <div>{item.phone}</div>}
                          {item.email && <div>{item.email}</div>}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={item.active ? "default" : "secondary"}>
                          {item.active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(item)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No purchasing groups match your search.' : 'No purchasing groups found.'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      {showEditDialog && editingItem && (
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Purchasing Group</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit_group_code">Group Code</Label>
                <Input
                  id="edit_group_code"
                  value={editingItem.group_code}
                  onChange={(e) => setEditingItem({...editingItem, group_code: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_group_name">Group Name</Label>
                <Input
                  id="edit_group_name"
                  value={editingItem.group_name}
                  onChange={(e) => setEditingItem({...editingItem, group_name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_description">Description</Label>
                <Input
                  id="edit_description"
                  value={editingItem.description}
                  onChange={(e) => setEditingItem({...editingItem, description: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_responsible_person">Responsible Person</Label>
                <Input
                  id="edit_responsible_person"
                  value={editingItem.responsible_person}
                  onChange={(e) => setEditingItem({...editingItem, responsible_person: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_phone">Phone</Label>
                <Input
                  id="edit_phone"
                  value={editingItem.phone}
                  onChange={(e) => setEditingItem({...editingItem, phone: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_email">Email</Label>
                <Input
                  id="edit_email"
                  value={editingItem.email}
                  onChange={(e) => setEditingItem({...editingItem, email: e.target.value})}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Updating..." : "Update"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}