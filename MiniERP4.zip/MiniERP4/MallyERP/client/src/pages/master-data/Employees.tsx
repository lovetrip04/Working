import { ArrowLeft, UserCircle } from "lucide-react";
import { useEffect, useState } from "react";

export interface Employee {
  id: string;
  name: string;
  position: string;
  department: string;
  email: string;
  phone: string;
  status: 'active' | 'inactive' | 'on-leave';
  joinDate: string;
}

const sampleEmployees: Employee[] = [
  {
    id: "EMP-001",
    name: "John Smith",
    position: "Production Manager",
    department: "Manufacturing",
    email: "john.smith@example.com",
    phone: "555-123-4567",
    status: 'active',
    joinDate: "2020-03-15"
  },
  {
    id: "EMP-002",
    name: "Sarah Johnson",
    position: "Sales Executive",
    department: "Sales",
    email: "sarah.johnson@example.com",
    phone: "555-234-5678",
    status: 'active',
    joinDate: "2019-08-10"
  },
  {
    id: "EMP-003",
    name: "Robert Chen",
    position: "Finance Manager",
    department: "Finance",
    email: "robert.chen@example.com",
    phone: "555-345-6789",
    status: 'active',
    joinDate: "2018-11-05"
  },
  {
    id: "EMP-004",
    name: "Jessica Martinez",
    position: "HR Specialist",
    department: "Human Resources",
    email: "jessica.martinez@example.com",
    phone: "555-456-7890",
    status: 'on-leave',
    joinDate: "2021-01-20"
  },
  {
    id: "EMP-005",
    name: "Michael Johnson",
    position: "IT Administrator",
    department: "Information Technology",
    email: "michael.johnson@example.com",
    phone: "555-567-8901",
    status: 'active',
    joinDate: "2019-05-12"
  },
  {
    id: "EMP-006",
    name: "Emily Wilson",
    position: "Quality Control Specialist",
    department: "Quality Assurance",
    email: "emily.wilson@example.com",
    phone: "555-678-9012",
    status: 'active',
    joinDate: "2020-09-30"
  },
  {
    id: "EMP-007",
    name: "David Thompson",
    position: "Warehouse Supervisor",
    department: "Logistics",
    email: "david.thompson@example.com",
    phone: "555-789-0123",
    status: 'inactive',
    joinDate: "2017-04-18"
  }
];

const Employees = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate loading data from API
  useEffect(() => {
    const loadData = async () => {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      setEmployees(sampleEmployees);
      setIsLoading(false);
    };

    loadData();
  }, []);

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-gray-100 text-gray-800';
      case 'on-leave':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <button 
          onClick={() => window.location.pathname = "/master-data"}
          className="mr-4 p-2 rounded-md hover:bg-gray-100"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold">Employees</h1>
          <p className="text-gray-600">Manage employee records and HR data</p>
        </div>
      </div>

      {/* Banner indicating this is a placeholder */}
      <div className="mb-6 bg-blue-50 p-4 rounded-md border border-blue-200">
        <div className="flex items-center">
          <UserCircle className="h-5 w-5 text-blue-500 mr-2" />
          <span className="text-blue-800 font-medium">
            Employee Master module is under development. The data shown below is sample data for demonstration purposes.
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="mb-6 flex justify-between items-center">
        <div className="flex space-x-2">
          <input 
            type="text" 
            placeholder="Search employees..." 
            className="border border-gray-300 rounded-md px-3 py-1.5 text-sm w-64"
          />
          <button className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm">
            Search
          </button>
        </div>
        <div className="flex space-x-2">
          <button 
            className="border border-gray-300 bg-white px-3 py-1.5 rounded-md text-sm flex items-center"
            onClick={() => {
              const csvContent = employees?.map((employee: Employee) => ({
                ID: employee.id,
                Name: employee.name,
                Position: employee.position,
                Department: employee.department,
                Email: employee.email,
                Phone: employee.phone,
                Status: employee.status,
                JoinDate: employee.joinDate
              })) || [];
              
              const csvString = [
                Object.keys(csvContent[0] || {}).join(','),
                ...csvContent.map((row: any) => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'employees.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            Export
          </button>
          <button 
            className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm flex items-center"
            onClick={() => {
              alert('Employee creation form will open here');
            }}
          >
            <span className="mr-1">+</span> New Employee
          </button>
        </div>
      </div>

      {/* Employees Table */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="bg-white rounded-md shadow overflow-x-auto max-h-[650px] overflow-y-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0 z-10">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Position
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Department
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Email
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Join Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {employees.map(employee => (
                <tr key={employee.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {employee.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                    {employee.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {employee.position}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {employee.department}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {employee.email}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(employee.joinDate)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full ${getStatusBadgeClass(employee.status)}`}>
                      {employee.status.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button className="text-blue-600 hover:text-blue-800 mr-2">Edit</button>
                    <button className="text-red-600 hover:text-red-800">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Pagination */}
          <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 sm:px-6 flex items-center justify-between">
            <div className="flex-1 flex justify-between sm:hidden">
              <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                Previous
              </button>
              <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                Next
              </button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Showing <span className="font-medium">1</span> to <span className="font-medium">7</span> of{' '}
                  <span className="font-medium">7</span> results
                </p>
              </div>
              <div>
                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                  <button className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <span className="sr-only">Previous</span>
                    {/* Heroicon name: solid/chevron-left */}
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </button>
                  <button aria-current="page" className="z-10 bg-blue-50 border-blue-500 text-blue-600 relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                    1
                  </button>
                  <button className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <span className="sr-only">Next</span>
                    {/* Heroicon name: solid/chevron-right */}
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Employees;