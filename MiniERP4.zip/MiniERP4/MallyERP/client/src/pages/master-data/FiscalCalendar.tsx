import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Link } from "wouter";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

import { CalendarIcon, FileUp, Plus, Search, Trash2, ArrowLeft } from "lucide-react";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
// Define form validation schema
const fiscalPeriodSchema = z.object({
  year: z.string().min(4, {
    message: "Year is required",
  }),
  periodNumber: z.string().min(1, {
    message: "Period number is required",
  }),
  periodName: z.string().min(1, {
    message: "Period name is required",
  }),
  startDate: z.date({
    required_error: "Start date is required",
  }),
  endDate: z.date({
    required_error: "End date is required",
  }),
  status: z.enum(["Open", "Closed", "Locked"], {
    required_error: "Status is required",
  }),
  companyCodeId: z.number({
    required_error: "Company Code is required",
  }),
});

// Sample Fiscal Period statuses
const PERIOD_STATUSES = ["Open", "Closed", "Locked"];

// Sample Fiscal Years for dropdown
const FISCAL_YEARS = ["2024", "2025", "2026", "2027", "2028"];

export default function FiscalCalendar() {
  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const [searchQuery, setSearchQuery] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [editingPeriod, setEditingPeriod] = useState<any>(null);
  const [deletingPeriodId, setDeletingPeriodId] = useState<number | null>(null);

  const queryClient = useQueryClient();

  // Fetch fiscal periods
  const { data: fiscalPeriods = [], isLoading: fiscalPeriodsLoading } = useQuery({
    queryKey: ["/api/master-data/fiscal-period"],
    retry: false,
  });

  // Fetch company codes for dropdown
  const { data: companyCodes = [], isLoading: companyCodesLoading } = useQuery({
    queryKey: ["/api/master-data/company-code"],
    retry: false,
  });

  // Create form with validation
  const form = useForm<z.infer<typeof fiscalPeriodSchema>>({
    resolver: zodResolver(fiscalPeriodSchema),
    defaultValues: {
      year: "",
      periodNumber: "",
      periodName: "",
      status: "Open",
      companyCodeId: undefined,
    },
  });

  // Update form when editing a period
  useEffect(() => {
    if (editingPeriod) {
      form.reset({
        year: editingPeriod.year,
        periodNumber: editingPeriod.periodNumber,
        periodName: editingPeriod.periodName,
        startDate: new Date(editingPeriod.startDate),
        endDate: new Date(editingPeriod.endDate),
        status: editingPeriod.status,
        companyCodeId: editingPeriod.companyCodeId,
      });
    } else {
      form.reset({
        year: "",
        periodNumber: "",
        periodName: "",
        status: "Open",
        companyCodeId: undefined,
      });
    }
  }, [editingPeriod, form]);

  // Create fiscal period mutation
  const createPeriodMutation = useMutation({
    mutationFn: (data: z.infer<typeof fiscalPeriodSchema>) => {
      return apiRequest("/api/master-data/fiscal-period", {
        method: "POST",
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Fiscal period created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/fiscal-period"] });
      setShowDialog(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create fiscal period",
        variant: "destructive",
      });
    },
  });

  // Update fiscal period mutation
  const updatePeriodMutation = useMutation({
    mutationFn: (data: z.infer<typeof fiscalPeriodSchema> & { id: number }) => {
      const { id, ...periodData } = data;
      return apiRequest(`/api/master-data/fiscal-period/${id}`, {
        method: "PUT",
        body: JSON.stringify(periodData)
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Fiscal period updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/fiscal-period"] });
      setShowDialog(false);
      setEditingPeriod(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update fiscal period",
        variant: "destructive",
      });
    },
  });

  // Delete fiscal period mutation
  const deletePeriodMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest(`/api/master-data/fiscal-period/${id}`, {
        method: "DELETE"
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Fiscal period deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/fiscal-period"] });
      setShowDeleteDialog(false);
      setDeletingPeriodId(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete fiscal period",
        variant: "destructive",
      });
    },
  });

  // Filter fiscal periods based on search query
  const filteredFiscalPeriods = Array.isArray(fiscalPeriods) 
    ? fiscalPeriods.filter((period: any) => {
        const searchStr = searchQuery.toLowerCase();
        return (
          period.year.toString().toLowerCase().includes(searchStr) ||
          period.periodName.toLowerCase().includes(searchStr) ||
          period.status.toLowerCase().includes(searchStr)
        );
      })
    : [];

  // Handle form submission
  const onSubmit = (data: z.infer<typeof fiscalPeriodSchema>) => {
    if (editingPeriod) {
      updatePeriodMutation.mutate({
        ...data,
        id: editingPeriod.id,
      });
    } else {
      createPeriodMutation.mutate(data);
    }
  };

  // Handle edit button click
  const handleEdit = (period: any) => {
    setEditingPeriod(period);
    setShowDialog(true);
  };

  // Handle delete button click
  const handleDelete = (id: number) => {
    setDeletingPeriodId(id);
    setShowDeleteDialog(true);
  };

  // Confirm deletion
  const confirmDelete = () => {
    if (deletingPeriodId) {
      deletePeriodMutation.mutate(deletingPeriodId);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center mb-6">
          <Link href="/master-data" className="mr-4 p-2 rounded-md hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          
            <div>
          <h1 className="text-2xl font-bold">Fiscal Calendar</h1>
          <p className="text-sm text-muted-foreground">
            Manage fiscal years, periods, and date settings
          </p>
        </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowImportDialog(true)}>
            <FileUp className="mr-2 h-4 w-4" />
            Import from Excel
          </Button>
          <Button onClick={() => setShowDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Fiscal Period
          </Button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search fiscal periods..."
          className="pl-8"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Fiscal Periods Table */}
      <Card>
        <CardHeader>
          <CardTitle>Fiscal Calendar</CardTitle>
          <CardDescription>
            Manage accounting periods and fiscal year settings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="max-h-[500px] overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-white z-10">
                  <TableRow>
                    <TableHead className="w-[100px]">Year</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden sm:table-cell">Start Date</TableHead>
                    <TableHead className="hidden sm:table-cell">End Date</TableHead>
                    <TableHead>Company Code</TableHead>
                    <TableHead className="w-[100px] text-center">Status</TableHead>
                    <TableHead className="w-[100px] text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fiscalPeriodsLoading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center h-24">
                        Loading...
                      </TableCell>
                    </TableRow>
                  ) : filteredFiscalPeriods.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center h-24">
                        No fiscal periods found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredFiscalPeriods.map((period: any) => (
                      <TableRow key={period.id}>
                        <TableCell className="font-medium">{period.year}</TableCell>
                        <TableCell>{period.periodNumber}</TableCell>
                        <TableCell>{period.periodName}</TableCell>
                        <TableCell className="hidden sm:table-cell">
                          {format(new Date(period.startDate), "MMM dd, yyyy")}
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          {format(new Date(period.endDate), "MMM dd, yyyy")}
                        </TableCell>
                        <TableCell>
                          {companyCodes.find((cc: any) => cc.id === period.companyCodeId)?.code || ""}
                        </TableCell>
                        <TableCell className="text-center">
                          <span
                            className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                              period.status === "Open"
                                ? "bg-green-100 text-green-800"
                                : period.status === "Closed"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {period.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(period)}
                            >
                              Edit
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(period.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Create/Edit Fiscal Period Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>
              {editingPeriod ? "Edit Fiscal Period" : "Create Fiscal Period"}
            </DialogTitle>
            <DialogDescription>
              {editingPeriod
                ? "Update the details of this fiscal period"
                : "Add a new fiscal period to your calendar"}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="year"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fiscal Year*</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select fiscal year" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {FISCAL_YEARS.map((year) => (
                            <SelectItem key={year} value={year}>
                              {year}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="periodNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Period Number*</FormLabel>
                      <FormControl>
                        <Input placeholder="E.g., 01, 02" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="periodName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Period Name*</FormLabel>
                    <FormControl>
                      <Input placeholder="E.g., January 2025" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date*</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={`w-full pl-3 text-left font-normal ${
                                !field.value && "text-muted-foreground"
                              }`}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date*</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={`w-full pl-3 text-left font-normal ${
                                !field.value && "text-muted-foreground"
                              }`}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="companyCodeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company Code*</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        defaultValue={field.value ? field.value.toString() : undefined}
                        value={field.value ? field.value.toString() : undefined}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select company code" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {companyCodesLoading ? (
                            <SelectItem value="loading" disabled>Loading...</SelectItem>
                          ) : (
                            Array.isArray(companyCodes) && companyCodes.map((cc: any) => (
                              <SelectItem key={cc.id} value={cc.id.toString()}>
                                {cc.code} - {cc.name}
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status*</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {PERIOD_STATUSES.map((status) => (
                            <SelectItem key={status} value={status}>
                              {status}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowDialog(false);
                    setEditingPeriod(null);
                    form.reset();
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={createPeriodMutation.isPending || updatePeriodMutation.isPending}>
                  {editingPeriod ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the fiscal period.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              onClick={() => {
                setShowDeleteDialog(false);
                setDeletingPeriodId(null);
              }}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Import Dialog (placeholder) */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import Fiscal Periods</DialogTitle>
            <DialogDescription>
              Upload an Excel file with fiscal period data
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-muted-foreground mb-4">
              Please upload an Excel file with the following columns:
              Year, Period Number, Period Name, Start Date, End Date, Status, Company Code
            </p>
            <Button variant="outline" className="w-full h-24">
              <div className="flex flex-col items-center justify-center">
                <FileUp className="h-8 w-8 mb-2" />
                <span>Click to upload or drag and drop</span>
                <span className="text-xs text-muted-foreground mt-1">
                  Excel files only (*.xlsx)
                </span>
              </div>
            </Button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowImportDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowImportDialog(false)}>Import</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}