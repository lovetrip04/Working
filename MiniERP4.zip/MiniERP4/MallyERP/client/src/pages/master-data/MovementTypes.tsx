import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Filter, Download, Edit, Trash2, ArrowLeft, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
interface MovementType {
  id: number;
  movement_code: string;
  movement_name: string;
  description: string;
  movement_category: string;
  debit_credit_indicator: string;
  quantity_update: boolean;
  value_update: boolean;
  reversal_allowed: boolean;
  active: boolean;
  created_at: string;
  updated_at: string;
}

interface NewMovementType {
  movement_code: string;
  movement_name: string;
  description: string;
  movement_category: string;
  debit_credit_indicator: string;
  quantity_update: boolean;
  value_update: boolean;
  reversal_allowed: boolean;
}

export default function MovementTypes() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<MovementType | null>(null);
  const [newItem, setNewItem] = useState<NewMovementType>({
    movement_code: "",
    movement_name: "",
    description: "",
    movement_category: "",
    debit_credit_indicator: "",
    quantity_update: true,
    value_update: true,
    reversal_allowed: false
  });

  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  useEffect(() => {
    document.title = "Movement Types | MallyERP";
  }, []);

  // Fetch movement types
  const { data: movementTypes, isLoading, refetch } = useQuery({
    queryKey: ['/api/master-data/movement-types'],
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: (data: NewMovementType) => 
      apiRequest('/api/master-data/movement-types', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/movement-types'] });
      setShowCreateDialog(false);
      setNewItem({
        movement_code: "",
        movement_name: "",
        description: "",
        movement_category: "",
        debit_credit_indicator: "",
        quantity_update: true,
        value_update: true,
        reversal_allowed: false
      });
      toast({
        title: "Success",
        description: "Movement type created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create movement type",
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<MovementType> }) =>
      apiRequest(`/api/master-data/movement-types/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/movement-types'] });
      setShowEditDialog(false);
      setEditingItem(null);
      toast({
        title: "Success",
        description: "Movement type updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update movement type",
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      apiRequest(`/api/master-data/movement-types/${id}`, {
        method: 'DELETE',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/movement-types'] });
      toast({
        title: "Success",
        description: "Movement type deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete movement type",
        variant: "destructive",
      });
    },
  });

  const handleCreate = () => {
    if (!newItem.movement_code || !newItem.movement_name) {
      toast({
        title: "Validation Error",
        description: "Movement code and name are required",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate(newItem);
  };

  const handleEdit = (item: MovementType) => {
    setEditingItem(item);
    setShowEditDialog(true);
  };

  const handleUpdate = () => {
    if (!editingItem) return;
    updateMutation.mutate({
      id: editingItem.id,
      data: editingItem
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this movement type?")) {
      deleteMutation.mutate(id);
    }
  };

  const filteredItems = (movementTypes as MovementType[])?.filter(item => {
    const matchesSearch = 
      item.movement_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.movement_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.movement_category?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "active" && item.active) || 
      (statusFilter === "inactive" && !item.active);

    const matchesCategory = categoryFilter === "all" || item.movement_category === categoryFilter;
    
    return matchesSearch && matchesStatus && matchesCategory;
  }) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link href="/master-data">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Master Data
              </Button>
            </Link>
          </div>
          <h1 className="text-3xl font-bold">Movement Types</h1>
          <p className="text-muted-foreground">Manage inventory movement classification and posting rules</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Movement Type
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Movement Type</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="movement_code">Movement Code *</Label>
                  <Input
                    id="movement_code"
                    value={newItem.movement_code}
                    onChange={(e) => setNewItem({...newItem, movement_code: e.target.value})}
                    placeholder="e.g., 101"
                  />
                </div>
                <div>
                  <Label htmlFor="movement_name">Movement Name *</Label>
                  <Input
                    id="movement_name"
                    value={newItem.movement_name}
                    onChange={(e) => setNewItem({...newItem, movement_name: e.target.value})}
                    placeholder="e.g., Goods Receipt"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={newItem.description}
                    onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                    placeholder="Enter description"
                  />
                </div>
                <div>
                  <Label htmlFor="movement_category">Movement Category</Label>
                  <Select value={newItem.movement_category} onValueChange={(value) => setNewItem({...newItem, movement_category: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="RECEIPT">Receipt</SelectItem>
                      <SelectItem value="ISSUE">Issue</SelectItem>
                      <SelectItem value="TRANSFER">Transfer</SelectItem>
                      <SelectItem value="ADJUSTMENT">Adjustment</SelectItem>
                      <SelectItem value="CONSUMPTION">Consumption</SelectItem>
                      <SelectItem value="RETURN">Return</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="debit_credit_indicator">Debit/Credit Indicator</Label>
                  <Select value={newItem.debit_credit_indicator} onValueChange={(value) => setNewItem({...newItem, debit_credit_indicator: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select indicator" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="D">D - Debit</SelectItem>
                      <SelectItem value="C">C - Credit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="quantity_update"
                      checked={newItem.quantity_update}
                      onChange={(e) => setNewItem({...newItem, quantity_update: e.target.checked})}
                      className="rounded"
                    />
                    <Label htmlFor="quantity_update">Quantity Update</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="value_update"
                      checked={newItem.value_update}
                      onChange={(e) => setNewItem({...newItem, value_update: e.target.checked})}
                      className="rounded"
                    />
                    <Label htmlFor="value_update">Value Update</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="reversal_allowed"
                      checked={newItem.reversal_allowed}
                      onChange={(e) => setNewItem({...newItem, reversal_allowed: e.target.checked})}
                      className="rounded"
                    />
                    <Label htmlFor="reversal_allowed">Reversal Allowed</Label>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreate} disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Creating..." : "Create"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-2 flex-1">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by code, name, or category..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={showFilters ? "default" : "outline"}
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="mr-2 h-4 w-4" />
                Filters
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
          
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 pt-4 border-t">
              <div>
                <Label>Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Category</Label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="RECEIPT">Receipt</SelectItem>
                    <SelectItem value="ISSUE">Issue</SelectItem>
                    <SelectItem value="TRANSFER">Transfer</SelectItem>
                    <SelectItem value="ADJUSTMENT">Adjustment</SelectItem>
                    <SelectItem value="CONSUMPTION">Consumption</SelectItem>
                    <SelectItem value="RETURN">Return</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Movement Types ({filteredItems.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading movement types...</div>
          ) : filteredItems.length > 0 ? (
            <div className="overflow-auto max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>D/C</TableHead>
                    <TableHead>Updates</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.movement_code}</TableCell>
                      <TableCell>{item.movement_name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{item.movement_category}</Badge>
                      </TableCell>
                      <TableCell>{item.debit_credit_indicator}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {item.quantity_update && <Badge variant="outline" className="text-xs">Qty</Badge>}
                          {item.value_update && <Badge variant="outline" className="text-xs">Val</Badge>}
                          {item.reversal_allowed && <Badge variant="outline" className="text-xs">Rev</Badge>}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={item.active ? "default" : "secondary"}>
                          {item.active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(item)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No movement types match your search.' : 'No movement types found.'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      {showEditDialog && editingItem && (
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Movement Type</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit_movement_code">Movement Code</Label>
                <Input
                  id="edit_movement_code"
                  value={editingItem.movement_code}
                  onChange={(e) => setEditingItem({...editingItem, movement_code: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_movement_name">Movement Name</Label>
                <Input
                  id="edit_movement_name"
                  value={editingItem.movement_name}
                  onChange={(e) => setEditingItem({...editingItem, movement_name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_description">Description</Label>
                <Input
                  id="edit_description"
                  value={editingItem.description}
                  onChange={(e) => setEditingItem({...editingItem, description: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_movement_category">Movement Category</Label>
                <Select value={editingItem.movement_category} onValueChange={(value) => setEditingItem({...editingItem, movement_category: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="RECEIPT">Receipt</SelectItem>
                    <SelectItem value="ISSUE">Issue</SelectItem>
                    <SelectItem value="TRANSFER">Transfer</SelectItem>
                    <SelectItem value="ADJUSTMENT">Adjustment</SelectItem>
                    <SelectItem value="CONSUMPTION">Consumption</SelectItem>
                    <SelectItem value="RETURN">Return</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Updating..." : "Update"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}