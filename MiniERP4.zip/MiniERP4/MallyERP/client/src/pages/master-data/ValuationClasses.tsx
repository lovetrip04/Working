import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Filter, Download, Edit, Trash2, ArrowLeft, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
interface ValuationClass {
  id: number;
  class_code: string;
  class_name: string;
  description: string;
  valuation_method: string;
  price_control: string;
  moving_price: boolean;
  standard_price: boolean;
  active: boolean;
  created_at: string;
  updated_at: string;
}

interface NewValuationClass {
  class_code: string;
  class_name: string;
  description: string;
  valuation_method: string;
  price_control: string;
  moving_price: boolean;
  standard_price: boolean;
}

export default function ValuationClasses() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [methodFilter, setMethodFilter] = useState("all");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<ValuationClass | null>(null);
  const [newItem, setNewItem] = useState<NewValuationClass>({
    class_code: "",
    class_name: "",
    description: "",
    valuation_method: "",
    price_control: "",
    moving_price: false,
    standard_price: false
  });

  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  useEffect(() => {
    document.title = "Valuation Classes | MallyERP";
  }, []);

  // Fetch valuation classes
  const { data: valuationClasses, isLoading, refetch } = useQuery({
    queryKey: ['/api/master-data/valuation-classes'],
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: (data: NewValuationClass) => 
      apiRequest('/api/master-data/valuation-classes', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/valuation-classes'] });
      setShowCreateDialog(false);
      setNewItem({
        class_code: "",
        class_name: "",
        description: "",
        valuation_method: "",
        price_control: "",
        moving_price: false,
        standard_price: false
      });
      toast({
        title: "Success",
        description: "Valuation class created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create valuation class",
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<ValuationClass> }) =>
      apiRequest(`/api/master-data/valuation-classes/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/valuation-classes'] });
      setShowEditDialog(false);
      setEditingItem(null);
      toast({
        title: "Success",
        description: "Valuation class updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update valuation class",
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      apiRequest(`/api/master-data/valuation-classes/${id}`, {
        method: 'DELETE',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/valuation-classes'] });
      toast({
        title: "Success",
        description: "Valuation class deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete valuation class",
        variant: "destructive",
      });
    },
  });

  const handleCreate = () => {
    if (!newItem.class_code || !newItem.class_name) {
      toast({
        title: "Validation Error",
        description: "Class code and name are required",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate(newItem);
  };

  const handleEdit = (item: ValuationClass) => {
    setEditingItem(item);
    setShowEditDialog(true);
  };

  const handleUpdate = () => {
    if (!editingItem) return;
    updateMutation.mutate({
      id: editingItem.id,
      data: editingItem
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this valuation class?")) {
      deleteMutation.mutate(id);
    }
  };

  const filteredItems = (valuationClasses as ValuationClass[])?.filter(item => {
    const matchesSearch = 
      item.class_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.class_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.valuation_method?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "active" && item.active) || 
      (statusFilter === "inactive" && !item.active);

    const matchesMethod = methodFilter === "all" || item.valuation_method === methodFilter;
    
    return matchesSearch && matchesStatus && matchesMethod;
  }) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link href="/master-data">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Master Data
              </Button>
            </Link>
          </div>
          <h1 className="text-3xl font-bold">Valuation Classes</h1>
          <p className="text-muted-foreground">Manage material valuation categorization and pricing methods</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Class
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Valuation Class</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="class_code">Class Code *</Label>
                  <Input
                    id="class_code"
                    value={newItem.class_code}
                    onChange={(e) => setNewItem({...newItem, class_code: e.target.value})}
                    placeholder="e.g., VC001"
                  />
                </div>
                <div>
                  <Label htmlFor="class_name">Class Name *</Label>
                  <Input
                    id="class_name"
                    value={newItem.class_name}
                    onChange={(e) => setNewItem({...newItem, class_name: e.target.value})}
                    placeholder="e.g., Raw Materials"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={newItem.description}
                    onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                    placeholder="Enter description"
                  />
                </div>
                <div>
                  <Label htmlFor="valuation_method">Valuation Method</Label>
                  <Select value={newItem.valuation_method} onValueChange={(value) => setNewItem({...newItem, valuation_method: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="FIFO">FIFO - First In First Out</SelectItem>
                      <SelectItem value="LIFO">LIFO - Last In First Out</SelectItem>
                      <SelectItem value="WAC">WAC - Weighted Average Cost</SelectItem>
                      <SelectItem value="STANDARD">Standard Cost</SelectItem>
                      <SelectItem value="MOVING">Moving Average</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="price_control">Price Control</Label>
                  <Select value={newItem.price_control} onValueChange={(value) => setNewItem({...newItem, price_control: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select price control" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="S">S - Standard Price</SelectItem>
                      <SelectItem value="V">V - Moving Average Price</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="moving_price"
                      checked={newItem.moving_price}
                      onChange={(e) => setNewItem({...newItem, moving_price: e.target.checked})}
                      className="rounded"
                    />
                    <Label htmlFor="moving_price">Moving Price</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="standard_price"
                      checked={newItem.standard_price}
                      onChange={(e) => setNewItem({...newItem, standard_price: e.target.checked})}
                      className="rounded"
                    />
                    <Label htmlFor="standard_price">Standard Price</Label>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreate} disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Creating..." : "Create"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-2 flex-1">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by code, name, or method..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={showFilters ? "default" : "outline"}
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="mr-2 h-4 w-4" />
                Filters
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
          
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 pt-4 border-t">
              <div>
                <Label>Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Valuation Method</Label>
                <Select value={methodFilter} onValueChange={setMethodFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Methods</SelectItem>
                    <SelectItem value="FIFO">FIFO</SelectItem>
                    <SelectItem value="LIFO">LIFO</SelectItem>
                    <SelectItem value="WAC">WAC</SelectItem>
                    <SelectItem value="STANDARD">Standard</SelectItem>
                    <SelectItem value="MOVING">Moving</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Valuation Classes ({filteredItems.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading valuation classes...</div>
          ) : filteredItems.length > 0 ? (
            <div className="overflow-auto max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Class Code</TableHead>
                    <TableHead>Class Name</TableHead>
                    <TableHead>Valuation Method</TableHead>
                    <TableHead>Price Control</TableHead>
                    <TableHead>Pricing</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.class_code}</TableCell>
                      <TableCell>{item.class_name}</TableCell>
                      <TableCell>{item.valuation_method}</TableCell>
                      <TableCell>{item.price_control}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {item.moving_price && <Badge variant="outline">Moving</Badge>}
                          {item.standard_price && <Badge variant="outline">Standard</Badge>}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={item.active ? "default" : "secondary"}>
                          {item.active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(item)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No valuation classes match your search.' : 'No valuation classes found.'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      {showEditDialog && editingItem && (
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Valuation Class</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit_class_code">Class Code</Label>
                <Input
                  id="edit_class_code"
                  value={editingItem.class_code}
                  onChange={(e) => setEditingItem({...editingItem, class_code: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_class_name">Class Name</Label>
                <Input
                  id="edit_class_name"
                  value={editingItem.class_name}
                  onChange={(e) => setEditingItem({...editingItem, class_name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_description">Description</Label>
                <Input
                  id="edit_description"
                  value={editingItem.description}
                  onChange={(e) => setEditingItem({...editingItem, description: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_valuation_method">Valuation Method</Label>
                <Select value={editingItem.valuation_method} onValueChange={(value) => setEditingItem({...editingItem, valuation_method: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="FIFO">FIFO - First In First Out</SelectItem>
                    <SelectItem value="LIFO">LIFO - Last In First Out</SelectItem>
                    <SelectItem value="WAC">WAC - Weighted Average Cost</SelectItem>
                    <SelectItem value="STANDARD">Standard Cost</SelectItem>
                    <SelectItem value="MOVING">Moving Average</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Updating..." : "Update"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}