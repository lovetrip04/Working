import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, RefreshCw, ArrowLeft, Calculator } from "lucide-react";
import { useLocation } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
const taxConfigSchema = z.object({
  tax_code: z.string().min(1, "Tax code is required").max(10, "Tax code must be 10 characters or less"),
  tax_description: z.string().min(1, "Tax description is required").max(100, "Tax description must be 100 characters or less"),
  country_code: z.string().min(2, "Country code is required").max(3, "Country code must be 3 characters or less"),
  tax_type: z.enum(["input_tax", "output_tax", "withholding_tax", "use_tax"]),
  tax_rate: z.number().min(0).max(100),
  calculation_procedure: z.string().max(20, "Calculation procedure must be 20 characters or less").default("TAXIN"),
  condition_type: z.string().max(10, "Condition type must be 10 characters or less"),
  account_key: z.string().max(10, "Account key must be 10 characters or less"),
  tax_account: z.string().max(20, "Tax account must be 20 characters or less"),
  base_amount_required: z.boolean().default(true),
  reverse_charge: z.boolean().default(false),
  non_deductible_percentage: z.number().min(0).max(100).default(0),
  jurisdiction_code: z.string().max(15, "Jurisdiction code must be 15 characters or less").optional(),
  effective_from: z.string().optional(),
  effective_to: z.string().optional(),
  active: z.boolean().default(true)
});

type TaxConfiguration = z.infer<typeof taxConfigSchema> & { id: number };

export default function TaxConfiguration() {
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [editingConfig, setEditingConfig] = useState<TaxConfiguration | null>(null);
  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  const { data: taxConfigs = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/tax-configurations"],
  });

  const form = useForm<z.infer<typeof taxConfigSchema>>({
    resolver: zodResolver(taxConfigSchema),
    defaultValues: {
      tax_code: "",
      tax_description: "",
      country_code: "US",
      tax_type: "output_tax",
      tax_rate: 0,
      calculation_procedure: "TAXIN",
      condition_type: "",
      account_key: "",
      tax_account: "",
      base_amount_required: true,
      reverse_charge: false,
      non_deductible_percentage: 0,
      jurisdiction_code: "",
      effective_from: "",
      effective_to: "",
      active: true
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: z.infer<typeof taxConfigSchema>) =>
      apiRequest("/api/tax-configurations", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tax-configurations"] });
      setOpen(false);
      setEditingConfig(null);
      form.reset();
      toast({ title: "Success", description: "Tax configuration created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create tax configuration", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }: { id: number } & z.infer<typeof taxConfigSchema>) =>
      apiRequest(`/api/tax-configurations/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tax-configurations"] });
      setOpen(false);
      setEditingConfig(null);
      form.reset();
      toast({ title: "Success", description: "Tax configuration updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update tax configuration", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/tax-configurations/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tax-configurations"] });
      toast({ title: "Success", description: "Tax configuration deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete tax configuration", variant: "destructive" });
    },
  });

  const onSubmit = (data: z.infer<typeof taxConfigSchema>) => {
    if (editingConfig) {
      updateMutation.mutate({ id: editingConfig.id, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (config: TaxConfiguration) => {
    setEditingConfig(config);
    form.reset(config);
    setOpen(true);
  };

  const handleCreate = () => {
    setEditingConfig(null);
    form.reset();
    setOpen(true);
  };

  const taxTypes = [
    { value: "input_tax", label: "Input Tax (Vendor)" },
    { value: "output_tax", label: "Output Tax (Customer)" },
    { value: "withholding_tax", label: "Withholding Tax" },
    { value: "use_tax", label: "Use Tax" }
  ];

  const countries = [
    { code: "US", name: "United States" },
    { code: "CA", name: "Canada" },
    { code: "GB", name: "United Kingdom" },
    { code: "DE", name: "Germany" },
    { code: "FR", name: "France" },
    { code: "IN", name: "India" },
    { code: "CN", name: "China" },
    { code: "JP", name: "Japan" }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/master-data")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Master Data
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Tax Configuration</h1>
            <p className="text-muted-foreground">Configure tax codes and calculation procedures for different jurisdictions</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={handleCreate}>
                <Plus className="h-4 w-4 mr-2" />
                Create Tax Configuration
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingConfig ? "Edit Tax Configuration" : "Create Tax Configuration"}
                </DialogTitle>
                <DialogDescription>
                  Configure tax calculation settings and account assignments
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="tax_code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tax Code</FormLabel>
                          <FormControl>
                            <Input placeholder="V1" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="tax_description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tax Description</FormLabel>
                          <FormControl>
                            <Input placeholder="Output Tax 10%" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="country_code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Country</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select country" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {countries.map((country) => (
                                <SelectItem key={country.code} value={country.code}>
                                  {country.code} - {country.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="tax_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tax Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select tax type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {taxTypes.map((type) => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="tax_rate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tax Rate (%)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01"
                              min="0" 
                              max="100" 
                              placeholder="10.00" 
                              {...field} 
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="calculation_procedure"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Calculation Procedure</FormLabel>
                          <FormControl>
                            <Input placeholder="TAXIN" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="condition_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Condition Type</FormLabel>
                          <FormControl>
                            <Input placeholder="MWVS" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="account_key"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Key</FormLabel>
                          <FormControl>
                            <Input placeholder="VST" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="tax_account"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tax Account</FormLabel>
                        <FormControl>
                          <Input placeholder="154000" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="jurisdiction_code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Jurisdiction Code</FormLabel>
                          <FormControl>
                            <Input placeholder="NY" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="non_deductible_percentage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Non-Deductible %</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01"
                              min="0" 
                              max="100" 
                              placeholder="0.00" 
                              {...field} 
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="effective_from"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Effective From</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="effective_to"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Effective To</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingConfig ? "Update" : "Create"} Tax Configuration
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calculator className="h-5 w-5" />
            <span>Tax Configurations</span>
          </CardTitle>
          <CardDescription>
            Manage tax codes, rates, and calculation procedures for different jurisdictions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading tax configurations...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tax Code</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Country</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Account</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {taxConfigs.map((config: TaxConfiguration) => (
                  <TableRow key={config.id}>
                    <TableCell className="font-medium">{config.tax_code}</TableCell>
                    <TableCell>{config.tax_description}</TableCell>
                    <TableCell>{config.country_code}</TableCell>
                    <TableCell className="capitalize">{config.tax_type.replace('_', ' ')}</TableCell>
                    <TableCell>{config.tax_rate}%</TableCell>
                    <TableCell>{config.tax_account}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        config.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {config.active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(config)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteMutation.mutate(config.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}