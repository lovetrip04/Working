import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, RefreshCw, ArrowLeft, Shield } from "lucide-react";
import { useLocation } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
const creditControlSchema = z.object({
  code: z.string().min(1, "Code is required").max(10, "Code must be 10 characters or less"),
  name: z.string().min(1, "Name is required").max(100, "Name must be 100 characters or less"),
  description: z.string().optional(),
  currency: z.string().min(1, "Currency is required").max(3, "Currency must be 3 characters"),
  fiscal_year_variant: z.string().max(10, "Fiscal year variant must be 10 characters or less").optional(),
  update_type: z.enum(["000001", "000012", "000015"]).default("000012"),
  risk_category_update: z.boolean().default(true),
  credit_representative: z.string().max(100, "Credit representative must be 100 characters or less").optional(),
  credit_limit_check: z.boolean().default(true),
  automatic_credit_control: z.boolean().default(false),
  credit_horizon_days: z.number().min(0).max(999).default(30),
  tolerance_percentage: z.number().min(0).max(100).default(5),
  credit_data_exchange: z.boolean().default(false),
  workflow_activated: z.boolean().default(false),
  active: z.boolean().default(true)
});

type CreditControlArea = z.infer<typeof creditControlSchema> & { id: number };

export default function CreditControlAreas() {
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [editingArea, setEditingArea] = useState<CreditControlArea | null>(null);
  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  const { data: creditAreas = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/credit-control-areas"],
  });

  const form = useForm<z.infer<typeof creditControlSchema>>({
    resolver: zodResolver(creditControlSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      currency: "USD",
      fiscal_year_variant: "",
      update_type: "000012",
      risk_category_update: true,
      credit_representative: "",
      credit_limit_check: true,
      automatic_credit_control: false,
      credit_horizon_days: 30,
      tolerance_percentage: 5,
      credit_data_exchange: false,
      workflow_activated: false,
      active: true
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: z.infer<typeof creditControlSchema>) =>
      apiRequest("/api/credit-control-areas", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/credit-control-areas"] });
      setOpen(false);
      setEditingArea(null);
      form.reset();
      toast({ title: "Success", description: "Credit control area created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create credit control area", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }: { id: number } & z.infer<typeof creditControlSchema>) =>
      apiRequest(`/api/credit-control-areas/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/credit-control-areas"] });
      setOpen(false);
      setEditingArea(null);
      form.reset();
      toast({ title: "Success", description: "Credit control area updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update credit control area", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/credit-control-areas/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/credit-control-areas"] });
      toast({ title: "Success", description: "Credit control area deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete credit control area", variant: "destructive" });
    },
  });

  const onSubmit = (data: z.infer<typeof creditControlSchema>) => {
    if (editingArea) {
      updateMutation.mutate({ id: editingArea.id, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (area: CreditControlArea) => {
    setEditingArea(area);
    form.reset(area);
    setOpen(true);
  };

  const handleCreate = () => {
    setEditingArea(null);
    form.reset();
    setOpen(true);
  };

  const updateTypes = [
    { value: "000001", label: "Open Item Update" },
    { value: "000012", label: "Open Order & Delivery Value" },
    { value: "000015", label: "Full Document Update" }
  ];

  const currencies = ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY", "INR"];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/master-data")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Master Data
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Credit Control Areas</h1>
            <p className="text-muted-foreground">Configure credit management and risk assessment parameters</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={handleCreate}>
                <Plus className="h-4 w-4 mr-2" />
                Create Credit Control Area
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingArea ? "Edit Credit Control Area" : "Create Credit Control Area"}
                </DialogTitle>
                <DialogDescription>
                  Configure credit management settings and customer risk assessment parameters
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Credit Control Area Code</FormLabel>
                          <FormControl>
                            <Input placeholder="CCA001" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Credit Control Area Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Main Credit Control Area" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Input placeholder="Credit control area description" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Currency</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select currency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {currencies.map((currency) => (
                                <SelectItem key={currency} value={currency}>
                                  {currency}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="update_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Update Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select update type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {updateTypes.map((type) => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.value} - {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="fiscal_year_variant"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fiscal Year Variant</FormLabel>
                          <FormControl>
                            <Input placeholder="K4" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="credit_representative"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Credit Representative</FormLabel>
                          <FormControl>
                            <Input placeholder="Credit Manager Name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Credit Control Settings</h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="credit_horizon_days"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Credit Horizon (Days)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="0" 
                                max="999" 
                                {...field} 
                                onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="tolerance_percentage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tolerance Percentage</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="0" 
                                max="100" 
                                step="0.1"
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="credit_limit_check"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Credit Limit Check</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="automatic_credit_control"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Automatic Credit Control</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="risk_category_update"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Risk Category Update</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="workflow_activated"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Workflow Activated</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingArea ? "Update" : "Create"} Credit Control Area
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Credit Control Areas</span>
          </CardTitle>
          <CardDescription>
            Manage credit control settings and customer risk assessment configurations
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading credit control areas...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Currency</TableHead>
                  <TableHead>Update Type</TableHead>
                  <TableHead>Horizon Days</TableHead>
                  <TableHead>Credit Check</TableHead>
                  <TableHead>Auto Control</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {creditAreas.map((area: CreditControlArea) => (
                  <TableRow key={area.id}>
                    <TableCell className="font-medium">{area.code}</TableCell>
                    <TableCell>{area.name}</TableCell>
                    <TableCell>{area.currency}</TableCell>
                    <TableCell>{area.update_type}</TableCell>
                    <TableCell>{area.credit_horizon_days} days</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        area.credit_limit_check ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {area.credit_limit_check ? 'Yes' : 'No'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        area.automatic_credit_control ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {area.automatic_credit_control ? 'Yes' : 'No'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        area.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {area.active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(area)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteMutation.mutate(area.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}