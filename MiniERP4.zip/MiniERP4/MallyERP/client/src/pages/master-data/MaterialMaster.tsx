import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit2, Trash2, Save, X, ArrowLeft, RefreshCw, Package } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
interface MaterialMaster {
  id: number;
  materialNumber: string;
  materialType: string;
  description: string;
  baseUnitOfMeasure: string;
  materialGroup: string;
  plant: string;
  category: string;
  active: boolean;
  createdAt: string;
}

const MATERIAL_TYPES = [
  { value: "FERT", label: "FERT - Finished Product" },
  { value: "HAWA", label: "HAWA - Trading Goods" },
  { value: "ROH", label: "ROH - Raw Material" },
  { value: "HALB", label: "HALB - Semi-Finished Product" },
  { value: "VERP", label: "VERP - Packaging" }
];

const MATERIAL_GROUPS = [
  { value: "PIZZA", label: "PIZZA - Pizza Products" },
  { value: "SIDES", label: "SIDES - Side Items" },
  { value: "DRINKS", label: "DRINKS - Beverages" },
  { value: "DESSERTS", label: "DESSERTS - Dessert Items" },
  { value: "INGRED", label: "INGRED - Ingredients" }
];

const UNITS_OF_MEASURE = [
  { value: "EA", label: "EA - Each" },
  { value: "KG", label: "KG - Kilogram" },
  { value: "LT", label: "LT - Liter" },
  { value: "PC", label: "PC - Piece" },
  { value: "BX", label: "BX - Box" }
];

export default function MaterialMaster() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState<MaterialMaster | null>(null);
  const [formData, setFormData] = useState({
    materialNumber: "",
    materialType: "FERT",
    description: "",
    baseUnitOfMeasure: "EA",
    materialGroup: "PIZZA",
    plant: "DOM-CHI01",
    category: "Food",
    active: true
  });

  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  const { data: materials = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/master-data/material"],
  });

  const createMutation = useMutation({
    mutationFn: (data: Omit<MaterialMaster, "id" | "createdAt">) =>
      apiRequest("/api/master-data/material", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/material"] });
      setIsDialogOpen(false);
      resetForm();
      toast({ title: "Success", description: "Material created successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }: { id: number } & Partial<MaterialMaster>) =>
      apiRequest(`/api/master-data/material/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/material"] });
      setEditingMaterial(null);
      resetForm();
      toast({ title: "Success", description: "Material updated successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      apiRequest(`/api/master-data/material/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/material"] });
      toast({ title: "Success", description: "Material deleted successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      materialNumber: "",
      materialType: "FERT",
      description: "",
      baseUnitOfMeasure: "EA",
      materialGroup: "PIZZA",
      plant: "DOM-CHI01",
      category: "Food",
      active: true
    });
    setEditingMaterial(null);
    setIsDialogOpen(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingMaterial) {
      updateMutation.mutate({ id: editingMaterial.id, ...formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (material: MaterialMaster) => {
    setEditingMaterial(material);
    setFormData({
      materialNumber: material.materialNumber,
      materialType: material.materialType,
      description: material.description,
      baseUnitOfMeasure: material.baseUnitOfMeasure,
      materialGroup: material.materialGroup,
      plant: material.plant,
      category: material.category,
      active: material.active
    });
    setIsDialogOpen(true);
  };

  const handleRefresh = () => {
    refetch();
    toast({ title: "Refreshed", description: "Material master data refreshed" });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/master-data">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Material Master</h1>
            <p className="text-muted-foreground">
              Manage materials, products, and ingredients for pizza production
            </p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button onClick={handleRefresh} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => { resetForm(); setIsDialogOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" />
                Add Material
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingMaterial ? "Edit Material" : "Create Material"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="materialNumber">Material Number</Label>
                    <Input
                      id="materialNumber"
                      value={formData.materialNumber}
                      onChange={(e) => setFormData({ ...formData, materialNumber: e.target.value })}
                      placeholder="e.g., DOM-PIZZA-001"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="materialType">Material Type</Label>
                    <Select
                      value={formData.materialType}
                      onValueChange={(value) => setFormData({ ...formData, materialType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select material type" />
                      </SelectTrigger>
                      <SelectContent>
                        {MATERIAL_TYPES.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Detailed description of the material"
                    rows={3}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="baseUnitOfMeasure">Base Unit of Measure</Label>
                    <Select
                      value={formData.baseUnitOfMeasure}
                      onValueChange={(value) => setFormData({ ...formData, baseUnitOfMeasure: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select unit" />
                      </SelectTrigger>
                      <SelectContent>
                        {UNITS_OF_MEASURE.map((unit) => (
                          <SelectItem key={unit.value} value={unit.value}>
                            {unit.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="materialGroup">Material Group</Label>
                    <Select
                      value={formData.materialGroup}
                      onValueChange={(value) => setFormData({ ...formData, materialGroup: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select group" />
                      </SelectTrigger>
                      <SelectContent>
                        {MATERIAL_GROUPS.map((group) => (
                          <SelectItem key={group.value} value={group.value}>
                            {group.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="plant">Plant</Label>
                    <Input
                      id="plant"
                      value={formData.plant}
                      onChange={(e) => setFormData({ ...formData, plant: e.target.value })}
                      placeholder="DOM-CHI01"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      placeholder="e.g., Food, Beverage"
                      required
                    />
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={formData.active}
                    onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                  />
                  <Label htmlFor="active">Active</Label>
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createMutation.isPending || updateMutation.isPending}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {editingMaterial ? "Update" : "Create"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-8">
          <RefreshCw className="h-6 w-6 animate-spin mr-2" />
          Loading materials...
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {materials.map((material: MaterialMaster) => (
            <Card key={material.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Package className="h-5 w-5 text-blue-600" />
                    <CardTitle className="text-lg">{material.materialNumber}</CardTitle>
                  </div>
                  <Badge variant={material.active ? "default" : "secondary"}>
                    {material.active ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <CardDescription className="font-medium">
                  {material.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div><span className="font-medium">Type:</span> {material.materialType}</div>
                    <div><span className="font-medium">UoM:</span> {material.baseUnitOfMeasure}</div>
                    <div><span className="font-medium">Group:</span> {material.materialGroup}</div>
                    <div><span className="font-medium">Plant:</span> {material.plant}</div>
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Category:</span> {material.category}
                  </div>
                  <div className="flex justify-end space-x-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(material)}
                    >
                      <Edit2 className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deleteMutation.mutate(material.id)}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="h-3 w-3 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {materials.length === 0 && !isLoading && (
        <Card>
          <CardContent className="text-center py-8">
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">No materials found</p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Material
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}