import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, RefreshCw, ArrowLeft, GitBranch } from "lucide-react";
import { useLocation } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
const controllingAreaSchema = z.object({
  area_code: z.string().min(1, "Area code is required").max(10, "Area code must be 10 characters or less"),
  area_name: z.string().min(1, "Area name is required").max(100, "Area name must be 100 characters or less"),
  description: z.string().optional(),
  operating_concern: z.string().max(10, "Operating concern must be 10 characters or less").optional(),
  person_responsible: z.string().max(100, "Person responsible must be 100 characters or less").optional(),
  company_code_assignments: z.array(z.number()),
  currency: z.string().min(3, "Currency is required").max(3, "Currency must be 3 characters"),
  fiscal_year_variant: z.string().max(10, "Fiscal year variant must be 10 characters or less").optional(),
  chart_of_accounts: z.string().max(10, "Chart of accounts must be 10 characters or less").optional(),
  cost_center_standard_hierarchy: z.string().max(20, "Cost center hierarchy must be 20 characters or less").optional(),
  profit_center_standard_hierarchy: z.string().max(20, "Profit center hierarchy must be 20 characters or less").optional(),
  activity_type_version: z.string().max(10, "Activity type version must be 10 characters or less").default("000"),
  costing_version: z.string().max(10, "Costing version must be 10 characters or less").default("1"),
  price_calculation_control: z.boolean().default(true),
  actual_costing_enabled: z.boolean().default(true),
  plan_costing_enabled: z.boolean().default(true),
  variance_calculation: z.boolean().default(true),
  settlement_method: z.enum(["full", "delta", "statistical"]).default("full"),
  allocation_cycle_posting: z.boolean().default(false),
  profit_center_accounting: z.boolean().default(false),
  active: z.boolean().default(true)
});

type ControllingArea = z.infer<typeof controllingAreaSchema> & { id: number };

export default function ControllingAreaIntegration() {
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [editingArea, setEditingArea] = useState<ControllingArea | null>(null);
  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  const { data: controllingAreas = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/controlling-areas"],
  });

  const { data: companyCodes = [] } = useQuery({
    queryKey: ["/api/company-codes"],
  });

  const form = useForm<z.infer<typeof controllingAreaSchema>>({
    resolver: zodResolver(controllingAreaSchema),
    defaultValues: {
      area_code: "",
      area_name: "",
      description: "",
      operating_concern: "",
      person_responsible: "",
      company_code_assignments: [],
      currency: "USD",
      fiscal_year_variant: "",
      chart_of_accounts: "",
      cost_center_standard_hierarchy: "",
      profit_center_standard_hierarchy: "",
      activity_type_version: "000",
      costing_version: "1",
      price_calculation_control: true,
      actual_costing_enabled: true,
      plan_costing_enabled: true,
      variance_calculation: true,
      settlement_method: "full",
      allocation_cycle_posting: false,
      profit_center_accounting: false,
      active: true
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: z.infer<typeof controllingAreaSchema>) =>
      apiRequest("/api/controlling-areas", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/controlling-areas"] });
      setOpen(false);
      setEditingArea(null);
      form.reset();
      toast({ title: "Success", description: "Management control area created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create controlling area", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }: { id: number } & z.infer<typeof controllingAreaSchema>) =>
      apiRequest(`/api/controlling-areas/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/controlling-areas"] });
      setOpen(false);
      setEditingArea(null);
      form.reset();
      toast({ title: "Success", description: "Management control area updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update controlling area", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/controlling-areas/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/controlling-areas"] });
      toast({ title: "Success", description: "Management control area deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete controlling area", variant: "destructive" });
    },
  });

  const onSubmit = (data: z.infer<typeof controllingAreaSchema>) => {
    if (editingArea) {
      updateMutation.mutate({ id: editingArea.id, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (area: ControllingArea) => {
    setEditingArea(area);
    form.reset(area);
    setOpen(true);
  };

  const handleCreate = () => {
    setEditingArea(null);
    form.reset();
    setOpen(true);
  };

  const settlementMethods = [
    { value: "full", label: "Full Settlement" },
    { value: "delta", label: "Delta Settlement" },
    { value: "statistical", label: "Statistical Only" }
  ];

  const currencies = ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY", "INR"];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/master-data")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Master Data
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Management Control Integration</h1>
            <p className="text-muted-foreground">Configure cost and profitability analysis integration with financial systems</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={handleCreate}>
                <Plus className="h-4 w-4 mr-2" />
                Create Control Area
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingArea ? "Edit Management Control Area" : "Create Management Control Area"}
                </DialogTitle>
                <DialogDescription>
                  Configure cost accounting and management reporting integration settings
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="area_code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Control Area Code</FormLabel>
                          <FormControl>
                            <Input placeholder="CTRL001" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="area_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Control Area Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Main Control Area" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Input placeholder="Management control area description" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Control Currency</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select currency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {currencies.map((currency) => (
                                <SelectItem key={currency} value={currency}>
                                  {currency}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="person_responsible"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Person Responsible</FormLabel>
                          <FormControl>
                            <Input placeholder="Controller Name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="operating_concern"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Operating Concern</FormLabel>
                          <FormControl>
                            <Input placeholder="OC001" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="fiscal_year_variant"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fiscal Year Variant</FormLabel>
                          <FormControl>
                            <Input placeholder="K4" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="chart_of_accounts"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Chart of Accounts</FormLabel>
                          <FormControl>
                            <Input placeholder="CA01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="settlement_method"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Settlement Method</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select settlement method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {settlementMethods.map((method) => (
                                <SelectItem key={method.value} value={method.value}>
                                  {method.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="activity_type_version"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Activity Type Version</FormLabel>
                          <FormControl>
                            <Input placeholder="000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="costing_version"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Costing Version</FormLabel>
                          <FormControl>
                            <Input placeholder="1" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Control Settings</h3>
                    
                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="actual_costing_enabled"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Actual Costing</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="plan_costing_enabled"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Plan Costing</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="variance_calculation"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Variance Calculation</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="price_calculation_control"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Price Calculation</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="allocation_cycle_posting"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Allocation Cycle</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="profit_center_accounting"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Profit Center Accounting</FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingArea ? "Update" : "Create"} Control Area
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <GitBranch className="h-5 w-5" />
            <span>Management Control Areas</span>
          </CardTitle>
          <CardDescription>
            Manage cost accounting and profitability analysis integration with financial reporting
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading management control areas...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Area Code</TableHead>
                  <TableHead>Area Name</TableHead>
                  <TableHead>Currency</TableHead>
                  <TableHead>Operating Concern</TableHead>
                  <TableHead>Responsible</TableHead>
                  <TableHead>Actual Costing</TableHead>
                  <TableHead>Plan Costing</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {controllingAreas.map((area: ControllingArea) => (
                  <TableRow key={area.id}>
                    <TableCell className="font-medium">{area.area_code}</TableCell>
                    <TableCell>{area.area_name}</TableCell>
                    <TableCell>{area.currency}</TableCell>
                    <TableCell>{area.operating_concern || "-"}</TableCell>
                    <TableCell>{area.person_responsible || "-"}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        area.actual_costing_enabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {area.actual_costing_enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        area.plan_costing_enabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {area.plan_costing_enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        area.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {area.active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(area)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteMutation.mutate(area.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}