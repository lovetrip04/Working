import { useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Plus, Download, Filter } from "lucide-react";
import OrdersContent from "@/components/purchase/OrdersContent";
import RequisitionsContent from "@/components/purchase/RequisitionsContent";
import VendorsContent from "@/components/purchase/VendorsContent";
import ReceiptsContent from "@/components/purchase/ReceiptsContent";

export default function Purchase() {
  useEffect(() => {
    document.title = "Purchase Management | MallyERP";
  }, []);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Purchase</h1>
          <p className="text-sm text-muted-foreground">Purchase orders, requisitions and vendor management</p>
        </div>
      </div>

      {/* Purchase Navigation Tabs */}
      <Card>
        <Tabs defaultValue="orders" className="w-full">
          <div className="border-b px-4">
            <TabsList className="bg-transparent h-12 p-0 rounded-none">
              <TabsTrigger 
                value="orders" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Orders
              </TabsTrigger>
              <TabsTrigger 
                value="requisitions" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Requisitions
              </TabsTrigger>
              <TabsTrigger 
                value="vendors" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Vendors
              </TabsTrigger>
              <TabsTrigger 
                value="receipts" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Receipts
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Orders Tab Content */}
          <TabsContent value="orders" className="p-4">
            <OrdersContent />
          </TabsContent>
          
          {/* Requisitions Tab Content */}
          <TabsContent value="requisitions" className="p-4">
            <RequisitionsContent />
          </TabsContent>
          
          {/* Vendors Tab Content */}
          <TabsContent value="vendors" className="p-4">
            <VendorsContent />
          </TabsContent>
          
          {/* Receipts Tab Content */}
          <TabsContent value="receipts" className="p-4">
            <ReceiptsContent />
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}