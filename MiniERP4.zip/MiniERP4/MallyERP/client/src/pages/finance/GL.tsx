import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  PieChart,
  LineChart,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Download,
  Filter,
  BookOpen,
  DollarSign,
  FileText,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function GeneralLedger() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">General Ledger (GL)</h1>
          <p className="text-sm text-muted-foreground">Manage chart of accounts and financial records</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            New Journal Entry
          </Button>
        </div>
      </div>

      {/* GL Navigation Tabs */}
      <Card>
        <Tabs defaultValue="overview" className="w-full">
          <div className="border-b px-4">
            <TabsList className="bg-transparent h-12 p-0 rounded-none">
              <TabsTrigger 
                value="overview" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="chart-of-accounts" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Chart of Accounts
              </TabsTrigger>
              <TabsTrigger 
                value="journal-entries" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Journal Entries
              </TabsTrigger>
              <TabsTrigger 
                value="trial-balance" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Trial Balance
              </TabsTrigger>
              <TabsTrigger 
                value="reports" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Financial Reports
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Overview Tab Content */}
          <TabsContent value="overview" className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Summary KPI Cards */}
              <GLCard 
                title="Total Assets" 
                value="$1,248,750.00" 
                change={4.7} 
                isPositive={true}
                period="vs last quarter"
                icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
              />
              <GLCard 
                title="Total Liabilities" 
                value="$785,320.25" 
                change={2.3} 
                isPositive={false}
                period="vs last quarter"
                icon={<BookOpen className="h-4 w-4 text-muted-foreground" />}
              />
              <GLCard 
                title="Total Equity" 
                value="$463,429.75" 
                change={8.2} 
                isPositive={true}
                period="vs last quarter"
                icon={<BarChart className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
            
            {/* Balance Sheet Summary */}
            <div className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Balance Sheet Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                    Assets vs Liabilities & Equity Chart
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Additional GL Widgets */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Income Statement Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <GLAccount 
                      name="Total Revenue"
                      amount="$542,873.50"
                      change={7.5}
                      isPositive={true}
                    />
                    <GLAccount 
                      name="Total Expenses"
                      amount="$387,652.30"
                      change={3.2}
                      isPositive={false}
                    />
                    <GLAccount 
                      name="Net Income"
                      amount="$155,221.20"
                      change={12.8}
                      isPositive={true}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Recent Journal Entries</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <JournalEntry 
                      description="Monthly Depreciation"
                      date="May 15, 2025"
                      amount="$12,850.00"
                      status="Posted"
                    />
                    <JournalEntry 
                      description="Revenue Recognition"
                      date="May 10, 2025"
                      amount="$87,500.00"
                      status="Posted"
                    />
                    <JournalEntry 
                      description="Vendor Payment Accrual"
                      date="May 8, 2025"
                      amount="$24,750.00"
                      status="Posted"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Other tabs content */}
          <TabsContent value="chart-of-accounts" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Chart of accounts management interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="journal-entries" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Journal entries interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="trial-balance" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Trial balance reporting interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="reports" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Financial reports generation interface would appear here
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}

// Supporting components
type GLCardProps = {
  title: string;
  value: string;
  change: number;
  isPositive: boolean;
  period: string;
  icon: React.ReactNode;
};

function GLCard({ title, value, change, isPositive, period, icon }: GLCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center space-x-1 text-xs mt-1">
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          </span>
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? "+" : ""}{change}%
          </span>
          <span className="text-muted-foreground">{period}</span>
        </div>
      </CardContent>
    </Card>
  );
}

type GLAccountProps = {
  name: string;
  amount: string;
  change: number;
  isPositive: boolean;
};

function GLAccount({ name, amount, change, isPositive }: GLAccountProps) {
  return (
    <div className="flex items-center justify-between py-1 border-b border-gray-100 last:border-0">
      <div className="font-medium">{name}</div>
      <div className="flex items-center gap-2">
        <div className="font-medium">{amount}</div>
        <div className={`text-xs ${isPositive ? "text-green-500" : "text-red-500"}`}>
          {isPositive ? "+" : ""}{change}%
        </div>
      </div>
    </div>
  );
}

type JournalEntryProps = {
  description: string;
  date: string;
  amount: string;
  status: string;
};

function JournalEntry({ description, date, amount, status }: JournalEntryProps) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{description}</div>
        <div className="text-xs text-muted-foreground">{date}</div>
      </div>
      <div className="text-right">
        <div className="font-medium">{amount}</div>
        <Badge 
          variant={status === "Posted" ? "outline" : "secondary"} 
          className="text-xs rounded-sm"
        >
          {status}
        </Badge>
      </div>
    </div>
  );
}