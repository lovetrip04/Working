import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  PieChart,
  LineChart,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Download,
  Filter,
  Clock,
  DollarSign,
  Calendar,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function AccountsPayable() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Accounts Payable (AP)</h1>
          <p className="text-sm text-muted-foreground">Manage vendor invoices and payment processing</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            New Bill
          </Button>
        </div>
      </div>

      {/* AP Navigation Tabs */}
      <Card>
        <Tabs defaultValue="overview" className="w-full">
          <div className="border-b px-4">
            <TabsList className="bg-transparent h-12 p-0 rounded-none">
              <TabsTrigger 
                value="overview" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="bills" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Bills
              </TabsTrigger>
              <TabsTrigger 
                value="vendors" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Vendors
              </TabsTrigger>
              <TabsTrigger 
                value="payments" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Payments
              </TabsTrigger>
              <TabsTrigger 
                value="reports" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Reports
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Overview Tab Content */}
          <TabsContent value="overview" className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Summary KPI Cards */}
              <APCard 
                title="Total Payables" 
                value="$367,248.50" 
                change={3.1} 
                isPositive={false}
                period="vs last month"
                icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
              />
              <APCard 
                title="Bills Due This Week" 
                value="$42,875.30" 
                change={5.8} 
                isPositive={false}
                period="vs last week"
                icon={<Calendar className="h-4 w-4 text-muted-foreground" />}
              />
              <APCard 
                title="Average Payment Period" 
                value="28 days" 
                change={2.0} 
                isPositive={true}
                period="vs last month"
                icon={<Clock className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
            
            {/* Bills by Due Date */}
            <div className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Bills by Due Date</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                    Upcoming Bills Chart
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Additional AP Widgets */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Top Vendors by Spend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <APVendor 
                      name="Office Supplies Co."
                      spend="$58,432.75"
                      outstanding="$12,580.50"
                      paymentTerms="Net 30"
                    />
                    <APVendor 
                      name="IT Solutions Inc."
                      spend="$47,890.25"
                      outstanding="$8,750.00"
                      paymentTerms="Net 45"
                    />
                    <APVendor 
                      name="Logistics Partners"
                      spend="$36,745.80"
                      outstanding="$15,200.30"
                      paymentTerms="Net 30"
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <UpcomingPayment 
                      vendor="Office Supplies Co."
                      amount="$12,580.50"
                      dueDate="May 20, 2025"
                      status="Due Soon"
                    />
                    <UpcomingPayment 
                      vendor="Logistics Partners"
                      amount="$8,350.25"
                      dueDate="May 25, 2025"
                      status="Scheduled"
                    />
                    <UpcomingPayment 
                      vendor="IT Solutions Inc."
                      amount="$4,500.00"
                      dueDate="June 5, 2025"
                      status="Pending Approval"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Other tabs content */}
          <TabsContent value="bills" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Bills management interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="vendors" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Vendor management interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="payments" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Payment processing interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="reports" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              AP reports and analytics would appear here
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}

// Supporting components
type APCardProps = {
  title: string;
  value: string;
  change: number;
  isPositive: boolean;
  period: string;
  icon: React.ReactNode;
};

function APCard({ title, value, change, isPositive, period, icon }: APCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center space-x-1 text-xs mt-1">
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          </span>
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? "+" : ""}{change}%
          </span>
          <span className="text-muted-foreground">{period}</span>
        </div>
      </CardContent>
    </Card>
  );
}

type APVendorProps = {
  name: string;
  spend: string;
  outstanding: string;
  paymentTerms: string;
};

function APVendor({ name, spend, outstanding, paymentTerms }: APVendorProps) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{name}</div>
        <div className="text-xs text-muted-foreground">Terms: {paymentTerms}</div>
      </div>
      <div className="text-right">
        <div className="font-medium">{spend}</div>
        <div className="text-xs text-muted-foreground">Outstanding: {outstanding}</div>
      </div>
    </div>
  );
}

type UpcomingPaymentProps = {
  vendor: string;
  amount: string;
  dueDate: string;
  status: string;
};

function UpcomingPayment({ vendor, amount, dueDate, status }: UpcomingPaymentProps) {
  // Status is now handled via className directly
  
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{vendor}</div>
        <div className="text-xs text-muted-foreground">{dueDate}</div>
      </div>
      <div className="text-right">
        <div className="font-medium">{amount}</div>
        <Badge 
          variant="outline"
          className={`text-xs rounded-sm ${
            status === "Due Soon" ? "bg-amber-500 text-white" : 
            status === "Scheduled" ? "bg-green-500 text-white" : 
            status === "Overdue" ? "bg-red-500 text-white" : ""
          }`}
        >
          {status}
        </Badge>
      </div>
    </div>
  );
}