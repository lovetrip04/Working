import { useState } from "react";
import { useLocation } from "wouter";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  HelpCircle,
  FileText,
  BookOpen,
  Network,
  Workflow,
  Layers,
  LifeBuoy,
  Landmark,
  Factory,
  Package,
  Store,
  ShoppingBag,
  CreditCard,
  Building,
  DollarSign,
  Users,
  ArrowRightCircle,
  FileDown,
  ExternalLink,
  BarChart2,
  X
} from "lucide-react";

export default function Help() {
  const [activeTab, setActiveTab] = useState("business-processes");
  const [location, setLocation] = useLocation();
  const [selectedFlowchart, setSelectedFlowchart] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Flowchart data structure
  const flowchartData = {
    "master-data": {
      title: "Master Data Module Flowcharts",
      icon: <Building className="h-5 w-5 text-blue-600" />,
      flowcharts: [
        {
          id: "organizational-structure",
          title: "Organizational Structure Setup Flow",
          description: "Complete setup process for company codes, plants, and storage locations",
          content: `
## Organizational Structure Setup Flow

\`\`\`mermaid
flowchart TD
    A[Start Master Data Setup] --> B[Define Chart of Accounts]
    B --> C[Create Company Code]
    C --> D[Assign Chart of Accounts to Company Code]
    D --> E[Set Fiscal Year Variant]
    E --> F[Configure Currency Settings]
    F --> G[Create Plants]
    G --> H[Assign Plants to Company Code]
    H --> I[Create Storage Locations]
    I --> J[Link Storage to Plants]
    J --> K[Setup Complete]

    style A fill:#e1f5fe
    style K fill:#c8e6c9
\`\`\`

### Process Steps (Enterprise Standard):
1. **Chart of Accounts Definition** - Create global financial reporting structure
2. **Company Code Creation** - Establish legal entity structure  
3. **Chart of Accounts Assignment** - Link CoA to Company Code
4. **Fiscal Year Variant** - Configure accounting periods for Company Code
5. **Currency Configuration** - Set primary and secondary currencies
6. **Plant Creation** - Create operational locations
7. **Plant Assignment** - Link plants to Company Code
8. **Storage Locations** - Define inventory areas within plants
          `
        },
        {
          id: "business-partner",
          title: "Business Partner Master Data Flow",
          description: "Customer and vendor master data creation and management",
          content: `
## Business Partner Master Data Flow

\`\`\`mermaid
flowchart TD
    A[Business Partner Setup] --> B{Partner Type?}
    B -->|Customer| C[Customer Master Creation]
    B -->|Vendor| D[Vendor Master Creation]
    
    C --> E[Set Customer Group]
    E --> F[Define Payment Terms]
    F --> G[Configure Credit Limits]
    G --> H[Assign Pricing Groups]
    H --> I[Customer Setup Complete]
    
    D --> J[Set Vendor Type]
    J --> K[Define Payment Terms]
    K --> L[Assign Purchase Org]
    L --> M[Configure Approval Workflow]
    M --> N[Vendor Setup Complete]
    
    I --> O[Business Partner Integration Ready]
    N --> O
    
    style A fill:#e1f5fe
    style O fill:#c8e6c9
\`\`\`

### Key Features:
- Separate workflows for customers and vendors
- Credit management integration
- Automated approval processes
- Integration with sales and purchase modules
          `
        }
      ]
    },
    "sales": {
      title: "Sales Module Flowcharts",
      icon: <Store className="h-5 w-5 text-green-600" />,
      flowcharts: [
        {
          id: "lead-to-cash",
          title: "Lead to Cash Complete Process Flow",
          description: "End-to-end sales process from lead generation to payment",
          content: `
## Lead to Cash Complete Process Flow

\`\`\`mermaid
flowchart TD
    A[Lead Creation] --> B[Lead Qualification]
    B --> C{Qualified?}
    C -->|Yes| D[Convert to Opportunity]
    C -->|No| E[Lead Nurturing]
    E --> F[Re-qualify Later]
    F --> B
    
    D --> G[Opportunity Management]
    G --> H[Needs Analysis]
    H --> I[Solution Development]
    I --> J[Quote Generation]
    J --> K[Quote Approval]
    K --> L{Quote Accepted?}
    L -->|Yes| M[Sales Order Creation]
    L -->|No| N[Quote Revision]
    N --> J
    
    M --> O[Credit Check]
    O --> P{Credit OK?}
    P -->|Yes| Q[Order Confirmation]
    P -->|No| R[Credit Review]
    R --> S[Manual Approval]
    S --> Q
    
    Q --> T[Delivery Processing]
    T --> U[Goods Issue]
    U --> V[Invoice Generation]
    V --> W[Payment Processing]
    W --> X[Order Complete]
    
    style A fill:#e3f2fd
    style X fill:#c8e6c9
\`\`\`

### Process Highlights:
- Automated lead qualification
- Quote approval workflows
- Credit check integration
- Order fulfillment tracking
          `
        }
      ]
    },
    "purchase": {
      title: "Purchase Module Flowcharts",
      icon: <ShoppingBag className="h-5 w-5 text-purple-600" />,
      flowcharts: [
        {
          id: "procure-to-pay",
          title: "Procure to Pay Complete Process",
          description: "End-to-end procurement process from requisition to payment",
          content: `## Procure to Pay Process Flow

### 1. Purchase Requisition
- Department creates purchase requisition
- System checks budget availability
- Routing for approval based on amount

### 2. Vendor Selection
- RFQ creation and distribution
- Vendor quotation comparison
- Best vendor selection

### 3. Purchase Order Processing
- PO creation with approved vendor
- PO approval workflow
- PO transmission to vendor

### 4. Goods Receipt
- Incoming goods inspection
- Quality control verification
- Goods receipt posting

### 5. Invoice Processing
- Vendor invoice receipt
- Three-way matching (PO, GR, Invoice)
- Invoice approval and posting

### 6. Payment Processing
- Payment run execution
- Bank file generation
- Payment confirmation

### Integration Points:
- Inventory management for stock updates
- Finance module for cost accounting
- Quality module for inspection
- Budget management for spending control`
        }
      ]
    },
    "production": {
      title: "Production Module Flowcharts", 
      icon: <Factory className="h-5 w-5 text-orange-600" />,
      flowcharts: [
        {
          id: "manufacturing-process",
          title: "Manufacturing Process Flow",
          description: "Complete production planning and execution workflow",
          content: `## Manufacturing Process Flow

### 1. Production Planning
- Sales order analysis
- MRP run for material requirements
- Capacity planning and scheduling

### 2. Material Preparation
- Raw material availability check
- Material reservation and allocation
- Component staging for production

### 3. Production Execution
- Work order release
- Operation scheduling by work center
- Real-time progress tracking

### 4. Quality Control
- In-process quality checks
- Final product inspection
- Non-conformance handling

### 5. Production Completion
- Finished goods receipt
- Cost settlement and variance analysis
- Production order closure

### 6. Inventory Updates
- Stock movements recording
- Valuation updates
- Inventory reconciliation

### Key Features:
- Real-time shop floor data collection
- Integrated quality management
- Automated cost allocation
- Production analytics and reporting`
        }
      ]
    },
    "finance": {
      title: "Finance Module Flowcharts",
      icon: <CreditCard className="h-5 w-5 text-emerald-600" />,
      flowcharts: [
        {
          id: "financial-processes",
          title: "Financial Process Integration",
          description: "Core financial processes and general ledger integration",
          content: `## Financial Process Integration

### 1. General Ledger Management
- Chart of accounts structure
- Automatic posting from all modules
- Period-end closing procedures

### 2. Accounts Receivable
- Customer invoice processing
- Payment allocation and matching
- Dunning process for overdue accounts

### 3. Accounts Payable
- Vendor invoice verification
- Payment processing and optimization
- Cash flow management

### 4. Asset Management
- Fixed asset capitalization
- Depreciation calculation and posting
- Asset disposal and transfers

### 5. Financial Reporting
- Trial balance generation
- Financial statement preparation
- Management reporting and analytics

### 6. Integration Points
- Sales module for revenue recognition
- Purchase module for expense accounting
- Production module for cost allocation
- Controlling module for profitability analysis

### Compliance Features:
- Multi-currency support
- Tax calculation and reporting
- Audit trail maintenance
- Regulatory compliance reporting`
        }
      ]
    }
  };

  const handleViewFlowchart = (moduleKey: string, flowchartId: string) => {
    const module = flowchartData[moduleKey as keyof typeof flowchartData];
    const flowchart = module?.flowcharts.find((f: any) => f.id === flowchartId);
    if (flowchart) {
      const selectedData = {
        ...flowchart,
        moduleTitle: module.title
      };
      setSelectedFlowchart(selectedData);
      setIsDialogOpen(true);
      console.log('Opening flowchart dialog:', selectedData.title);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">MiniERP Documentation</h1>
          <p className="text-gray-600 mt-1">
            Comprehensive guides, process flows, and system architecture
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center gap-2">
            <FileDown className="h-4 w-4" />
            <span>Download PDF</span>
          </Button>
          <Button variant="default" className="flex items-center gap-2">
            <LifeBuoy className="h-4 w-4" />
            <span>Get Support</span>
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-8">
          <TabsTrigger value="flowcharts" className="flex items-center gap-2">
            <BarChart2 className="h-4 w-4" />
            <span>Module Flowcharts</span>
          </TabsTrigger>
          <TabsTrigger value="business-processes" className="flex items-center gap-2">
            <Workflow className="h-4 w-4" />
            <span>Business Processes</span>
          </TabsTrigger>
          <TabsTrigger value="agent-system" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span>Agent System</span>
          </TabsTrigger>
          <TabsTrigger value="transport-system" className="flex items-center gap-2">
            <Network className="h-4 w-4" />
            <span>Transport System</span>
          </TabsTrigger>
          <TabsTrigger value="controlling" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            <span>Controlling</span>
          </TabsTrigger>
          <TabsTrigger value="organization" className="flex items-center gap-2">
            <Building className="h-4 w-4" />
            <span>Organization</span>
          </TabsTrigger>
          <TabsTrigger value="guides" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            <span>User Guides</span>
          </TabsTrigger>
          <TabsTrigger value="faq" className="flex items-center gap-2">
            <HelpCircle className="h-4 w-4" />
            <span>FAQs</span>
          </TabsTrigger>
        </TabsList>

        {/* Module Flowcharts Tab */}
        <TabsContent value="flowcharts" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Master Data Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="h-5 w-5 text-blue-600" />
                  Master Data Module
                </CardTitle>
                <CardDescription>
                  Organizational structure and business partner workflows
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Organizational Structure Setup</li>
                    <li>• Business Partner Master Data</li>
                    <li>• Material Master Data Flow</li>
                    <li>• Financial Master Integration</li>
                    <li>• Dependencies Map</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full" 
                        onClick={() => handleViewFlowchart("master-data", "organizational-structure")}>
                  <FileText className="h-4 w-4 mr-2" />
                  View Master Data Flowcharts
                </Button>
              </CardContent>
            </Card>

            {/* Sales Module Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Store className="h-5 w-5 text-green-600" />
                  Sales Module
                </CardTitle>
                <CardDescription>
                  Lead-to-cash process and customer management
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Lead to Cash Complete Process</li>
                    <li>• Sales Pipeline Management</li>
                    <li>• Quote to Order Conversion</li>
                    <li>• Customer Integration Flow</li>
                    <li>• Sales Analytics & Reporting</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full" 
                        onClick={() => handleViewFlowchart("sales", "lead-to-cash")}>
                  <FileText className="h-4 w-4 mr-2" />
                  View Sales Flowcharts
                </Button>
              </CardContent>
            </Card>

            {/* Purchase Module Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5 text-purple-600" />
                  Purchase Module
                </CardTitle>
                <CardDescription>
                  Procure-to-pay and vendor management processes
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Procure to Pay Complete Flow</li>
                    <li>• Purchase Requisition Workflow</li>
                    <li>• Vendor Management Integration</li>
                    <li>• Three-Way Matching Process</li>
                    <li>• Supplier Performance Management</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full" 
                        onClick={() => handleViewFlowchart("purchase", "procure-to-pay")}>
                  <FileText className="h-4 w-4 mr-2" />
                  View Purchase Flowcharts
                </Button>
              </CardContent>
            </Card>

            {/* Production Module Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Factory className="h-5 w-5 text-orange-600" />
                  Production Module
                </CardTitle>
                <CardDescription>
                  Manufacturing processes and resource planning
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Make to Order Production Process</li>
                    <li>• Bill of Materials Management</li>
                    <li>• Work Center Management</li>
                    <li>• Quality Control Integration</li>
                    <li>• Manufacturing Resource Planning</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full" 
                        onClick={() => handleViewFlowchart("production", "manufacturing-process")}>
                  <FileText className="h-4 w-4 mr-2" />
                  View Production Flowcharts
                </Button>
              </CardContent>
            </Card>

            {/* Finance Module Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-emerald-600" />
                  Finance Module
                </CardTitle>
                <CardDescription>
                  Financial processes and accounting workflows
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• General Ledger Posting Process</li>
                    <li>• Accounts Receivable Process</li>
                    <li>• Accounts Payable Process</li>
                    <li>• Financial Reporting Process</li>
                    <li>• Cash & Budget Management</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full" 
                        onClick={() => handleViewFlowchart("finance", "financial-processes")}>
                  <FileText className="h-4 w-4 mr-2" />
                  View Finance Flowcharts
                </Button>
              </CardContent>
            </Card>

            {/* Controlling Module Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-indigo-600" />
                  Controlling Module
                </CardTitle>
                <CardDescription>
                  Cost accounting and profitability analysis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Cost Center Accounting Process</li>
                    <li>• Profit Center Analysis Flow</li>
                    <li>• Activity-Based Costing (ABC)</li>
                    <li>• Profitability Analysis (CO-PA)</li>
                    <li>• Variance Analysis & Settlement</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  View Controlling Flowcharts
                </Button>
              </CardContent>
            </Card>

            {/* Inventory Module Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-teal-600" />
                  Inventory Module
                </CardTitle>
                <CardDescription>
                  Stock management and material planning
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Inventory Management Process</li>
                    <li>• Stock Movement Process</li>
                    <li>• Cycle Counting Process</li>
                    <li>• Inventory Valuation Flow</li>
                    <li>• Material Requirements Planning</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  View Inventory Flowcharts
                </Button>
              </CardContent>
            </Card>

            {/* HR Module Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-pink-600" />
                  HR Module
                </CardTitle>
                <CardDescription>
                  Human resources and employee management
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Employee Lifecycle Management</li>
                    <li>• Payroll Processing Flow</li>
                    <li>• Performance Management Process</li>
                    <li>• Leave Management Workflow</li>
                    <li>• Training & Development Flow</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  View HR Flowcharts
                </Button>
              </CardContent>
            </Card>

            {/* Transport & GitHub Integration Flowcharts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5 text-red-600" />
                  Transport & CI/CD
                </CardTitle>
                <CardDescription>
                  Development transport and GitHub integration
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Available Flowcharts:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Transport System Workflow</li>
                    <li>• GitHub Integration Process</li>
                    <li>• CI/CD Pipeline Integration</li>
                    <li>• Number Range Management</li>
                    <li>• Status & Monitoring Dashboard</li>
                  </ul>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  View Transport Flowcharts
                </Button>
              </CardContent>
            </Card>

          </div>

          {/* Flowcharts Summary Section */}
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart2 className="h-5 w-5" />
                  Complete Module Flowcharts Library
                </CardTitle>
                <CardDescription>
                  Comprehensive visual process documentation for all ERP modules
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-800">Foundation Modules</h4>
                    <p className="text-sm text-blue-600 mt-1">Master Data, Organizational Setup</p>
                    <span className="text-xs text-blue-500">5 detailed flowcharts</span>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-800">Core Business Modules</h4>
                    <p className="text-sm text-green-600 mt-1">Sales, Purchase, Production, Inventory</p>
                    <span className="text-xs text-green-500">20+ process flows</span>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-purple-800">Management Modules</h4>
                    <p className="text-sm text-purple-600 mt-1">Finance, Controlling, HR</p>
                    <span className="text-xs text-purple-500">18+ analytical flows</span>
                  </div>
                </div>

                <Separator />

                <div className="space-y-3">
                  <h4 className="font-medium">Flowchart Features:</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Decision points with conditional logic</li>
                      <li>• Error handling and exception workflows</li>
                      <li>• Integration points between modules</li>
                      <li>• Approval workflows with authorization</li>
                    </ul>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Status management throughout processes</li>
                      <li>• Color-coded operation types</li>
                      <li>• End-to-end business process visualization</li>
                      <li>• Complete documentation coverage</li>
                    </ul>
                  </div>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-yellow-800">How to Use Flowcharts</h4>
                  <p className="text-sm text-yellow-700 mt-1">
                    Each flowchart provides step-by-step visual guidance for business processes. 
                    Follow the flow from start (blue) to completion (green), with decision points (yellow) 
                    and error handling (red/orange) clearly marked.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Business Processes Tab */}
        <TabsContent value="business-processes" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Workflow className="h-5 w-5" />
                  Complete Business Process Flow
                </CardTitle>
                <CardDescription>
                  End-to-end business processes from Master Data to Finance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Accordion type="single" collapsible>
                  <AccordionItem value="master-data">
                    <AccordionTrigger>1. Master Data Foundation</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Organizational Structure</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Create Company Code (US01)</li>
                          <li>• Set up Plants (CHI01 - Chicago)</li>
                          <li>• Configure Storage Locations (RAW1, FIN1)</li>
                          <li>• Define Cost Centers and Profit Centers</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Financial Master Data</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Chart of Accounts setup</li>
                          <li>• Number ranges for all object types</li>
                          <li>• Tax codes and currency setup</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="sales-process">
                    <AccordionTrigger>2. Sales Process (Lead to Cash)</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Lead Management</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Lead Creation → Qualification → Opportunity</li>
                          <li>• Quote Generation with pricing</li>
                          <li>• Approval workflows</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Order Processing</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Sales Order creation and validation</li>
                          <li>• Credit check and ATP (Available-to-Promise)</li>
                          <li>• Delivery scheduling and confirmation</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="purchase-process">
                    <AccordionTrigger>3. Purchase Process (Procure to Pay)</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Requirements Planning</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• MRP calculation and requisitions</li>
                          <li>• Vendor selection and PO creation</li>
                          <li>• Approval workflows</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Goods Receipt & Invoice</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Three-way matching (PO, GR, Invoice)</li>
                          <li>• Quality inspection</li>
                          <li>• Payment processing</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="production">
                    <AccordionTrigger>4. Production Process</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Planning</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Master Production Schedule (MPS)</li>
                          <li>• Capacity planning and work centers</li>
                          <li>• Bill of Materials (BOM) explosion</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Execution</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Production order release</li>
                          <li>• Material issue and labor confirmation</li>
                          <li>• Cost collection and variance analysis</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Finance & Controlling Integration
                </CardTitle>
                <CardDescription>
                  How business processes integrate with financial reporting
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Accordion type="single" collapsible>
                  <AccordionItem value="finance-integration">
                    <AccordionTrigger>Finance Integration Points</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Order-to-Cash</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Revenue recognition on delivery</li>
                          <li>• Accounts receivable management</li>
                          <li>• Cost of goods sold posting</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Procure-to-Pay</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Inventory valuation updates</li>
                          <li>• Accounts payable processing</li>
                          <li>• Cash flow management</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="controlling-processes">
                    <AccordionTrigger>Controlling Processes</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Cost Center Accounting</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Primary cost collection</li>
                          <li>• Activity-based costing</li>
                          <li>• Variance analysis (plan vs actual)</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Profitability Analysis</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Profit center P&L</li>
                          <li>• Customer/product profitability</li>
                          <li>• Contribution margin analysis</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => window.open('/Complete-Business-Process-Help-Guide.md', '_blank')}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  View Complete Process Guide
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Agent System Tab */}
        <TabsContent value="agent-system" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-blue-600" />
                  AI Agent System Overview
                </CardTitle>
                <CardDescription>
                  Intelligent business process automation with hierarchical agent coordination
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="border rounded-lg p-4 bg-blue-50">
                    <h4 className="font-medium mb-2">What are AI Agents?</h4>
                    <p className="text-sm text-gray-600">
                      AI Agents are intelligent assistants that automate business processes, 
                      provide real-time monitoring, and ensure compliance across your organization 
                      with minimal human intervention.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Agent Hierarchy</h4>
                    <div className="space-y-2">
                      <div className="bg-red-50 p-3 rounded border-l-4 border-red-400">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="font-medium text-red-800">Coach Agent</span>
                          <span className="text-xs bg-red-100 px-2 py-1 rounded text-red-700">Strategic</span>
                        </div>
                        <p className="text-sm text-red-700 mt-1">System-wide oversight, policy management, cross-domain coordination</p>
                      </div>
                      <div className="bg-amber-50 p-3 rounded border-l-4 border-amber-400">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                          <span className="font-medium text-amber-800">Player Agent</span>
                          <span className="text-xs bg-amber-100 px-2 py-1 rounded text-amber-700">Operational</span>
                        </div>
                        <p className="text-sm text-amber-700 mt-1">Domain-specific automation, process execution, data validation</p>
                      </div>
                      <div className="bg-green-50 p-3 rounded border-l-4 border-green-400">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="font-medium text-green-800">Rookie Agent</span>
                          <span className="text-xs bg-green-100 px-2 py-1 rounded text-green-700">Learning</span>
                        </div>
                        <p className="text-sm text-green-700 mt-1">Read-only monitoring, training mode, guided assistance</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Workflow className="h-5 w-5 text-green-600" />
                  Business Process Automation
                </CardTitle>
                <CardDescription>
                  How agents streamline your business operations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Accordion type="single" collapsible>
                  <AccordionItem value="financial-processes">
                    <AccordionTrigger>Financial Process Automation</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Invoice Processing Flow</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Auto-validation of vendor invoices against purchase orders</li>
                          <li>• Real-time three-way matching (PO, Receipt, Invoice)</li>
                          <li>• Automated posting to General Ledger with proper cost centers</li>
                          <li>• Exception handling for discrepancies and approvals</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Payment Processing</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Automated payment runs based on terms and cash flow</li>
                          <li>• Bank reconciliation with variance analysis</li>
                          <li>• Foreign exchange rate management and hedging</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="sales-processes">
                    <AccordionTrigger>Sales Process Optimization</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Order-to-Cash Automation</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Auto-generation of sales orders from customer requests</li>
                          <li>• Real-time credit limit checking and approval routing</li>
                          <li>• Automated delivery scheduling and logistics coordination</li>
                          <li>• Invoice generation and customer communication</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Customer Relationship Management</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Lead qualification and scoring algorithms</li>
                          <li>• Automated follow-up sequences and communications</li>
                          <li>• Customer satisfaction monitoring and alerts</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="inventory-processes">
                    <AccordionTrigger>Inventory & Supply Chain</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Procurement Automation</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Auto-generation of purchase requisitions based on stock levels</li>
                          <li>• Vendor selection optimization using historical performance</li>
                          <li>• Contract compliance monitoring and renewal alerts</li>
                          <li>• Receiving process automation with quality checks</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Warehouse Operations</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Automated stock movements and cycle counting</li>
                          <li>• Optimal picking route generation</li>
                          <li>• Real-time inventory valuation and reporting</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </div>

          <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart2 className="h-5 w-5 text-purple-600" />
                  Real-Time Monitoring & Analytics
                </CardTitle>
                <CardDescription>
                  Continuous business intelligence and performance tracking
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="border rounded-lg p-4 bg-purple-50">
                    <h4 className="font-medium mb-2">System Health Dashboard</h4>
                    <p className="text-sm text-gray-600">
                      Real-time monitoring of all business domains with color-coded status indicators 
                      (Green/Amber/Red) and automatic escalation for critical issues.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Key Performance Indicators</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-blue-50 p-2 rounded">
                        <div className="text-xs font-medium text-blue-800">Financial KPIs</div>
                        <div className="text-xs text-blue-600 mt-1">Cash flow, DSO, margins</div>
                      </div>
                      <div className="bg-green-50 p-2 rounded">
                        <div className="text-xs font-medium text-green-800">Operational KPIs</div>
                        <div className="text-xs text-green-600 mt-1">Fulfillment, quality, efficiency</div>
                      </div>
                      <div className="bg-orange-50 p-2 rounded">
                        <div className="text-xs font-medium text-orange-800">Customer KPIs</div>
                        <div className="text-xs text-orange-600 mt-1">Satisfaction, retention, growth</div>
                      </div>
                      <div className="bg-purple-50 p-2 rounded">
                        <div className="text-xs font-medium text-purple-800">Supply Chain KPIs</div>
                        <div className="text-xs text-purple-600 mt-1">Lead times, costs, reliability</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="h-5 w-5 text-indigo-600" />
                  Cross-Domain Integration
                </CardTitle>
                <CardDescription>
                  Seamless data flow and process coordination across departments
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="border rounded-lg p-4 bg-indigo-50">
                    <h4 className="font-medium mb-2">Integration Patterns</h4>
                    <p className="text-sm text-gray-600">
                      Agents coordinate complex business processes that span multiple departments, 
                      ensuring data consistency and process integrity throughout the organization.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Integration Examples</h4>
                    <ul className="text-sm text-gray-600 space-y-1 ml-4">
                      <li>• Sales Order → Production Planning → Material Requirements</li>
                      <li>• Purchase Receipt → Quality Control → Inventory Update → Financial Posting</li>
                      <li>• Customer Payment → Cash Application → Credit Management → Collections</li>
                      <li>• Production Completion → Cost Settlement → Profitability Analysis</li>
                    </ul>
                  </div>
                  
                  <div className="bg-yellow-50 p-3 rounded border border-yellow-200">
                    <h4 className="font-semibold text-yellow-800 mb-1">Access Control</h4>
                    <p className="text-sm text-yellow-700">
                      Coach Agent maintains exclusive authority over system-wide configurations, 
                      data access permissions, and cross-domain policy enforcement.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5 text-teal-600" />
                  Agent Communication Protocols
                </CardTitle>
                <CardDescription>
                  How agents collaborate to optimize business processes
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Request Flow</h4>
                    <div className="space-y-2 text-sm text-blue-700">
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                        <span>Business process triggers request</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                        <span>Player Agent validates requirements</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                        <span>Coach Agent approves policy compliance</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                        <span>Automated execution with monitoring</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Escalation Paths</h4>
                    <div className="space-y-2 text-sm text-green-700">
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                        <span>Exception detected in process</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                        <span>Player Agent attempts resolution</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                        <span>Coach Agent intervention if needed</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                        <span>Human notification for critical issues</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Learning & Optimization</h4>
                    <div className="space-y-2 text-sm text-purple-700">
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-purple-500 rounded-full"></div>
                        <span>Continuous performance monitoring</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-purple-500 rounded-full"></div>
                        <span>Pattern recognition and analysis</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-purple-500 rounded-full"></div>
                        <span>Process optimization recommendations</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-purple-500 rounded-full"></div>
                        <span>Automated implementation of improvements</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-800 mb-2">Getting Started with Agents</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-medium text-sm mb-1">For Business Users:</h5>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• Access AI Agents page from main navigation</li>
                        <li>• Review Coach Agent dashboard for system status</li>
                        <li>• Monitor automated process executions</li>
                        <li>• Configure business rules and policies</li>
                      </ul>
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">For Administrators:</h5>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• Configure agent access controls and permissions</li>
                        <li>• Set up cross-domain integration policies</li>
                        <li>• Monitor system health and performance metrics</li>
                        <li>• Manage escalation procedures and notifications</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                  <Button 
                    variant="outline" 
                    onClick={() => window.open('/Agent-System-Complete-Documentation.md', '_blank')}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Complete Agent Documentation
                  </Button>
                  <Button 
                    variant="default"
                    onClick={() => window.location.href = '/ai-agents'}
                  >
                    <Users className="h-4 w-4 mr-2" />
                    Access AI Agents System
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Transport System Tab */}
        <TabsContent value="transport-system" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5" />
                  Transport System (CI/CD Objects)
                </CardTitle>
                <CardDescription>
                  Configuration management and deployment framework
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="border rounded-lg p-4 bg-blue-50">
                    <h4 className="font-medium mb-2">What are Transports?</h4>
                    <p className="text-sm text-gray-600">
                      Transports are configuration packages that move master data, 
                      configurations, and customizations across environments 
                      (Development → QA → Production).
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Transport Types</h4>
                    <ul className="text-sm text-gray-600 space-y-1 ml-4">
                      <li>• <strong>A-Series:</strong> Standard configuration and master data</li>
                      <li>• <strong>Y-Series:</strong> Custom development objects</li>
                      <li>• <strong>Z-Series:</strong> Customer-specific customizations</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Implementation Guide: Company Code to Sales Order</h4>
                    <Accordion type="single" collapsible>
                      <AccordionItem value="implementation-steps">
                        <AccordionTrigger className="text-sm">How to Create Each Transport</AccordionTrigger>
                        <AccordionContent className="space-y-3">
                          <div className="space-y-2">
                            <div className="bg-blue-50 p-3 rounded text-sm">
                              <strong>A1100001: Company Code Foundation</strong>
                              <br />
                              <span className="text-blue-700">Navigate:</span> Master Data → Organizational → Company Code
                              <br />
                              <span className="text-blue-700">Create:</span> US01 company code with chart of accounts
                              <br />
                              <span className="text-blue-700">API:</span> POST /api/master-data/company-codes
                            </div>
                            
                            <div className="bg-green-50 p-3 rounded text-sm">
                              <strong>A1100002: Plant Structure</strong>
                              <br />
                              <span className="text-green-700">Navigate:</span> Master Data → Organizational → Plants
                              <br />
                              <span className="text-green-700">Create:</span> CHI01 plant with storage locations
                              <br />
                              <span className="text-green-700">API:</span> POST /api/master-data/plants
                            </div>
                            
                            <div className="bg-yellow-50 p-3 rounded text-sm">
                              <strong>A1100003: Number Ranges</strong>
                              <br />
                              <span className="text-yellow-700">Navigate:</span> Configuration → Number Ranges
                              <br />
                              <span className="text-yellow-700">Create:</span> GL, Customer, Vendor, Asset ranges
                              <br />
                              <span className="text-yellow-700">API:</span> POST /api/number-ranges/initialize
                            </div>
                            
                            <div className="bg-purple-50 p-3 rounded text-sm">
                              <strong>A1100004: Customer Master</strong>
                              <br />
                              <span className="text-purple-700">Navigate:</span> Master Data → Business Partners → Customers
                              <br />
                              <span className="text-purple-700">Create:</span> Customer with auto-assigned number
                              <br />
                              <span className="text-purple-700">API:</span> POST /api/master-data/customers
                            </div>
                            
                            <div className="bg-red-50 p-3 rounded text-sm">
                              <strong>A1100008: Complete Sales Process</strong>
                              <br />
                              <span className="text-red-700">Navigate:</span> Sales → Configuration → Document Types
                              <br />
                              <span className="text-red-700">Create:</span> Sales order types and pricing procedures
                              <br />
                              <span className="text-red-700">API:</span> POST /api/sales/document-types
                            </div>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowRightCircle className="h-5 w-5" />
                  Number Range Management
                </CardTitle>
                <CardDescription>
                  Automated number assignment for all object types
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="space-y-2">
                    <h4 className="font-medium">Object Type Ranges</h4>
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between bg-gray-50 p-2 rounded">
                        <span className="font-medium">GL Accounts:</span>
                        <span>1000000-9999999</span>
                      </div>
                      <div className="flex justify-between bg-gray-50 p-2 rounded">
                        <span className="font-medium">Customers:</span>
                        <span>C10000-C99999</span>
                      </div>
                      <div className="flex justify-between bg-gray-50 p-2 rounded">
                        <span className="font-medium">Vendors:</span>
                        <span>V20000-V29999</span>
                      </div>
                      <div className="flex justify-between bg-gray-50 p-2 rounded">
                        <span className="font-medium">Assets:</span>
                        <span>A100000-A999999</span>
                      </div>
                      <div className="flex justify-between bg-gray-50 p-2 rounded">
                        <span className="font-medium">Purchase Orders:</span>
                        <span>4500000000+</span>
                      </div>
                      <div className="flex justify-between bg-gray-50 p-2 rounded">
                        <span className="font-medium">Sales Orders:</span>
                        <span>SO1000000+</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border rounded-lg p-3 bg-green-50">
                    <h4 className="font-medium text-green-800 mb-1">GitHub Integration & Rollback System</h4>
                    <p className="text-sm text-green-700">
                      Complete Dev → QA → Prod pipeline with automatic rollback branches, 
                      error tracking via GitHub issues, and emergency rollback capabilities.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Developer Implementation</h4>
                    <Accordion type="single" collapsible>
                      <AccordionItem value="code-examples">
                        <AccordionTrigger className="text-sm">Code Examples & API Usage</AccordionTrigger>
                        <AccordionContent className="space-y-3">
                          <div className="bg-gray-50 p-3 rounded text-xs font-mono">
                            <div>// Create transport with objects</div>
                            <div>const transport = await fetch('/api/transport-direct/requests', {'{'}</div>
                            <div className="ml-2">method: 'POST',</div>
                            <div className="ml-2">body: JSON.stringify(transportData)</div>
                            <div>{'});'}</div>
                          </div>
                          
                          <div className="bg-gray-50 p-3 rounded text-xs font-mono">
                            <div>// Get next number from range</div>
                            <div>const number = await fetch('/api/number-ranges/get-next-number', {'{'}</div>
                            <div className="ml-2">method: 'POST',</div>
                            <div className="ml-2">body: JSON.stringify({'{'} range_id: 'CUST_DOM_US01' {'}'})</div>
                            <div>{'});'}</div>
                          </div>
                          
                          <div className="text-sm text-blue-600">
                            → Complete developer guide with database schema, error handling, and GitHub integration available in documentation
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">GitHub Rollback & Error Resolution</h4>
                    <Accordion type="single" collapsible>
                      <AccordionItem value="rollback-workflow">
                        <AccordionTrigger className="text-sm">Dev → QA → Prod Error Handling</AccordionTrigger>
                        <AccordionContent className="space-y-3">
                          <div className="space-y-2">
                            <div className="bg-red-50 p-3 rounded text-sm">
                              <strong className="text-red-800">QA Deployment Failure:</strong>
                              <br />
                              <span className="text-red-700">1. Automatic rollback branch created</span>
                              <br />
                              <span className="text-red-700">2. GitHub issue generated with error analysis</span>
                              <br />
                              <span className="text-red-700">3. Error resolution suggestions provided</span>
                              <br />
                              <span className="text-red-700">4. Fix → retry or execute rollback</span>
                            </div>
                            
                            <div className="bg-orange-50 p-3 rounded text-sm">
                              <strong className="text-orange-800">Production Emergency Rollback:</strong>
                              <br />
                              <span className="text-orange-700">1. Immediate system snapshot created</span>
                              <br />
                              <span className="text-orange-700">2. Hot rollback executed (zero downtime)</span>
                              <br />
                              <span className="text-orange-700">3. Database & configuration rolled back</span>
                              <br />
                              <span className="text-orange-700">4. System integrity verified</span>
                            </div>
                            
                            <div className="bg-blue-50 p-3 rounded text-sm">
                              <strong className="text-blue-800">GitHub Integration Features:</strong>
                              <br />
                              <span className="text-blue-700">• Automatic branch creation per transport</span>
                              <br />
                              <span className="text-blue-700">• Pull requests for QA and Production</span>
                              <br />
                              <span className="text-blue-700">• Rollback branches with restoration scripts</span>
                              <br />
                              <span className="text-blue-700">• Issue tracking for deployment failures</span>
                            </div>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => window.open('/Transport-System-Complete-Guide.md', '_blank')}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Access Complete Transport Guide
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Controlling Tab */}
        <TabsContent value="controlling" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Controlling Module Overview
                </CardTitle>
                <CardDescription>
                  Cost management, profitability analysis, and performance monitoring
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Accordion type="single" collapsible>
                  <AccordionItem value="cost-centers">
                    <AccordionTrigger>Cost Center Accounting</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Cost Center Hierarchy</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Production Cost Centers (CC001, CC002, CC003)</li>
                          <li>• Administrative Cost Centers (CC101, CC102, CC103)</li>
                          <li>• Sales Cost Centers (CC201, CC202, CC203)</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Cost Planning & Control</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Annual cost budgets by cost element</li>
                          <li>• Activity type planning (machine hours, labor hours)</li>
                          <li>• Variance analysis (plan vs actual)</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="profit-centers">
                    <AccordionTrigger>Profit Center Accounting</AccordionTrigger>
                    <AccordionContent className="space-y-3">
                      <div className="space-y-2">
                        <h4 className="font-medium">Profit Center Structure</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Manufacturing Division (PC001)</li>
                          <li>• Product Lines (PC001-01, PC001-02, PC001-03)</li>
                          <li>• Sales Division (PC002)</li>
                          <li>• Service Division (PC003)</li>
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Profitability Analysis</h4>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4">
                          <li>• Revenue and margin analysis by segment</li>
                          <li>• Customer and product profitability</li>
                          <li>• Contribution margin calculations</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart2 className="h-5 w-5" />
                  Key Performance Indicators
                </CardTitle>
                <CardDescription>
                  Monitor and analyze business performance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="space-y-2">
                    <h4 className="font-medium">Financial KPIs</h4>
                    <ul className="text-sm text-gray-600 space-y-1 ml-4">
                      <li>• Gross Margin %: (Revenue - COGS) / Revenue</li>
                      <li>• Operating Margin %: Operating Income / Revenue</li>
                      <li>• Days Sales Outstanding: AR / (Revenue / Days)</li>
                      <li>• Inventory Turnover: COGS / Average Inventory</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Controlling KPIs</h4>
                    <ul className="text-sm text-gray-600 space-y-1 ml-4">
                      <li>• Cost Center Efficiency: Planned / Actual costs</li>
                      <li>• Activity Price Variance: Standard / Actual rate</li>
                      <li>• Overhead Absorption Rate: Applied / Actual overhead</li>
                      <li>• Profit Center ROI: Operating profit / Assets</li>
                    </ul>
                  </div>
                  
                  <div className="border rounded-lg p-3 bg-blue-50">
                    <h4 className="font-medium text-blue-800 mb-1">Real-Time Analysis</h4>
                    <p className="text-sm text-blue-700">
                      Access variance analysis, profitability reports, and 
                      cost center performance dashboards in real-time.
                    </p>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setLocation('/controlling')}
                >
                  <BarChart2 className="h-4 w-4 mr-2" />
                  Open Controlling Module
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Organization Structure Tab */}
        <TabsContent value="organization" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Organizational Master Data Structure</CardTitle>
              <CardDescription>
                Understanding how organizational components are related and interconnected
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="border rounded-lg p-6 bg-gray-50">
                  <h3 className="text-lg font-semibold mb-4">Organizational Structure Diagram</h3>
                  <div className="relative w-full h-[450px] bg-white rounded-lg border p-4">
                    {/* Organization Structure Diagram */}
                    <div className="flex flex-col items-center">
                      {/* Top level - Client/Company */}
                      <div className="border-2 border-blue-600 rounded-lg bg-blue-50 p-3 w-64 text-center mb-6 relative">
                        <h4 className="font-bold text-blue-800">Client</h4>
                        <p className="text-sm text-blue-600">Enterprise Level</p>
                      </div>
                      
                      {/* Line connecting to company codes */}
                      <div className="h-8 w-0.5 bg-gray-300"></div>
                      
                      {/* Company Codes Row */}
                      <div className="border-2 border-blue-500 rounded-lg bg-blue-50 p-3 w-64 text-center mb-2 relative">
                        <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-blue-100 rounded-full p-1">
                          <Landmark className="h-5 w-5 text-blue-600" />
                        </div>
                        <h4 className="font-bold text-blue-700">Company Code</h4>
                        <p className="text-sm text-blue-600">Legal Entity</p>
                      </div>
                      
                      {/* Lines connecting to different org units */}
                      <div className="flex justify-center items-center mb-4">
                        <div className="w-64 h-10 relative">
                          <div className="absolute left-1/2 top-0 w-0.5 h-full bg-gray-300"></div>
                          <div className="absolute left-0 w-full h-0.5 bg-gray-300 top-8"></div>
                          <div className="absolute left-0 w-0.5 h-2 bg-gray-300 top-8"></div>
                          <div className="absolute right-0 w-0.5 h-2 bg-gray-300 top-8"></div>
                        </div>
                      </div>
                      
                      {/* Second Level - Connected organizational elements */}
                      <div className="grid grid-cols-3 gap-8 mb-8">
                        <div className="border-2 border-green-500 rounded-lg bg-green-50 p-3 w-64 text-center relative">
                          <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-green-100 rounded-full p-1">
                            <Factory className="h-5 w-5 text-green-600" />
                          </div>
                          <h4 className="font-bold text-green-700">Plant</h4>
                          <p className="text-sm text-green-600">Physical Location</p>
                        </div>
                        
                        <div className="border-2 border-purple-500 rounded-lg bg-purple-50 p-3 w-64 text-center relative">
                          <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-purple-100 rounded-full p-1">
                            <Store className="h-5 w-5 text-purple-600" />
                          </div>
                          <h4 className="font-bold text-purple-700">Sales Organization</h4>
                          <p className="text-sm text-purple-600">Sales Entity</p>
                        </div>
                        
                        <div className="border-2 border-amber-500 rounded-lg bg-amber-50 p-3 w-64 text-center relative">
                          <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-amber-100 rounded-full p-1">
                            <ShoppingBag className="h-5 w-5 text-amber-600" />
                          </div>
                          <h4 className="font-bold text-amber-700">Purchase Organization</h4>
                          <p className="text-sm text-amber-600">Procurement Entity</p>
                        </div>
                      </div>
                      
                      {/* Lines connecting to the third level */}
                      <div className="grid grid-cols-3 gap-8 mb-2">
                        <div className="flex flex-col items-center justify-center">
                          <div className="h-8 w-0.5 bg-gray-300"></div>
                        </div>
                        <div className="flex flex-col items-center justify-center">
                          {/* Empty space */}
                        </div>
                        <div className="flex flex-col items-center justify-center">
                          {/* Empty space */}
                        </div>
                      </div>
                      
                      {/* Third Level - Storage Location */}
                      <div className="grid grid-cols-3 gap-8 mb-4">
                        <div className="border-2 border-teal-500 rounded-lg bg-teal-50 p-3 w-64 text-center relative">
                          <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-teal-100 rounded-full p-1">
                            <Package className="h-5 w-5 text-teal-600" />
                          </div>
                          <h4 className="font-bold text-teal-700">Storage Location</h4>
                          <p className="text-sm text-teal-600">Inventory Area</p>
                        </div>
                        <div></div>
                        <div></div>
                      </div>
                      
                      {/* Additional connected component - Credit Control */}
                      <div className="absolute bottom-4 right-4 border-2 border-pink-500 rounded-lg bg-pink-50 p-3 w-64 text-center">
                        <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-pink-100 rounded-full p-1">
                          <CreditCard className="h-5 w-5 text-pink-600" />
                        </div>
                        <h4 className="font-bold text-pink-700">Credit Control Area</h4>
                        <p className="text-sm text-pink-600">Financial Risk Management</p>
                        <div className="absolute -top-14 left-1/2 transform -translate-x-1/2 w-0.5 h-14 bg-gray-300"></div>
                        <div className="absolute -top-14 left-1/2 transform -translate-x-1/2 -translate-y-px w-16 h-0.5 bg-gray-300"></div>
                      </div>
                    </div>
                  </div>
                </div>

                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="company-code">
                    <AccordionTrigger className="text-lg font-medium">
                      <div className="flex items-center">
                        <Landmark className="h-5 w-5 mr-2 text-blue-600" />
                        Company Code
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pt-2">
                      <div className="space-y-4">
                        <p>
                          A Company Code represents a legal entity within your organization for which financial statements are prepared. It is the highest level in the organizational hierarchy.
                        </p>
                        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-md">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">ATTRIBUTES</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Code (unique identifier)</li>
                              <li>• Name</li>
                              <li>• Address</li>
                              <li>• City, State, Country</li>
                              <li>• Currency</li>
                              <li>• Fiscal Year Variant</li>
                              <li>• Chart of Accounts</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">RELATIONSHIPS</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Parent of Plants</li>
                              <li>• Parent of Sales Organizations</li>
                              <li>• Parent of Purchase Organizations</li>
                              <li>• Parent of Credit Control Areas</li>
                            </ul>
                          </div>
                        </div>
                        <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
                          <h4 className="font-semibold flex items-center text-yellow-800">
                            <HelpCircle className="h-4 w-4 mr-1" />
                            Key Concept
                          </h4>
                          <p className="text-sm text-yellow-700 mt-1">
                            All financial transactions are recorded at the Company Code level. Financial reporting and legal compliance are managed at this level.
                          </p>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="plant">
                    <AccordionTrigger className="text-lg font-medium">
                      <div className="flex items-center">
                        <Factory className="h-5 w-5 mr-2 text-green-600" />
                        Plant
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pt-2">
                      <div className="space-y-4">
                        <p>
                          A Plant is a physical location where goods are produced, stored, or distributed. Plants are assigned to Company Codes and are essential for inventory management and production planning.
                        </p>
                        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-md">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">ATTRIBUTES</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Code (unique identifier)</li>
                              <li>• Name</li>
                              <li>• Address</li>
                              <li>• City, State, Country</li>
                              <li>• Plant Type</li>
                              <li>• Company Code (assignment)</li>
                              <li>• Description</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">RELATIONSHIPS</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Belongs to a Company Code</li>
                              <li>• Parent of Storage Locations</li>
                              <li>• Associated with Materials</li>
                              <li>• Location for Work Centers</li>
                            </ul>
                          </div>
                        </div>
                        <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
                          <h4 className="font-semibold flex items-center text-yellow-800">
                            <HelpCircle className="h-4 w-4 mr-1" />
                            Key Concept
                          </h4>
                          <p className="text-sm text-yellow-700 mt-1">
                            Plants are central to logistics processes. Inventory, production, and maintenance activities are always plant-specific.
                          </p>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="storage-location">
                    <AccordionTrigger className="text-lg font-medium">
                      <div className="flex items-center">
                        <Package className="h-5 w-5 mr-2 text-teal-600" />
                        Storage Location
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pt-2">
                      <div className="space-y-4">
                        <p>
                          A Storage Location is a physical or logical area within a Plant where materials are stored. They provide more granular control over inventory management within a Plant.
                        </p>
                        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-md">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">ATTRIBUTES</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Code (unique within a Plant)</li>
                              <li>• Name</li>
                              <li>• Description</li>
                              <li>• Plant (assignment)</li>
                              <li>• Storage Location Type</li>
                              <li>• Status (Active/Inactive)</li>
                              <li>• Capacity</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">RELATIONSHIPS</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Belongs to a Plant</li>
                              <li>• Contains Material Stock</li>
                              <li>• Used in Goods Movements</li>
                              <li>• Referenced in Production Orders</li>
                            </ul>
                          </div>
                        </div>
                        <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
                          <h4 className="font-semibold flex items-center text-yellow-800">
                            <HelpCircle className="h-4 w-4 mr-1" />
                            Key Concept
                          </h4>
                          <p className="text-sm text-yellow-700 mt-1">
                            Storage Locations enable detailed tracking of where materials are physically located within a Plant. This is essential for efficient warehouse management and inventory control.
                          </p>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="sales-organization">
                    <AccordionTrigger className="text-lg font-medium">
                      <div className="flex items-center">
                        <Store className="h-5 w-5 mr-2 text-purple-600" />
                        Sales Organization
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pt-2">
                      <div className="space-y-4">
                        <p>
                          A Sales Organization is a unit that sells and distributes products or services. It represents the sales structure of your company and is responsible for negotiating sales terms with customers.
                        </p>
                        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-md">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">ATTRIBUTES</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Code (unique identifier)</li>
                              <li>• Name</li>
                              <li>• Company Code (assignment)</li>
                              <li>• Description</li>
                              <li>• Currency</li>
                              <li>• Status (Active/Inactive)</li>
                              <li>• Region</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">RELATIONSHIPS</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Belongs to a Company Code</li>
                              <li>• Linked to Distribution Channels</li>
                              <li>• Associated with Sales Documents</li>
                              <li>• Uses Pricing Procedures</li>
                            </ul>
                          </div>
                        </div>
                        <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
                          <h4 className="font-semibold flex items-center text-yellow-800">
                            <HelpCircle className="h-4 w-4 mr-1" />
                            Key Concept
                          </h4>
                          <p className="text-sm text-yellow-700 mt-1">
                            Sales Organizations define the highest level of the sales structure. They determine which products can be sold, to which customers, and under what terms in specific regions or markets.
                          </p>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="purchase-organization">
                    <AccordionTrigger className="text-lg font-medium">
                      <div className="flex items-center">
                        <ShoppingBag className="h-5 w-5 mr-2 text-amber-600" />
                        Purchase Organization
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pt-2">
                      <div className="space-y-4">
                        <p>
                          A Purchase Organization is responsible for procuring materials and services from vendors. It defines procurement strategies and negotiates conditions with suppliers.
                        </p>
                        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-md">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">ATTRIBUTES</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Code (unique identifier)</li>
                              <li>• Name</li>
                              <li>• Company Code (assignment)</li>
                              <li>• Description</li>
                              <li>• Currency</li>
                              <li>• Status (Active/Inactive)</li>
                              <li>• Purchasing Manager</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">RELATIONSHIPS</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Belongs to a Company Code</li>
                              <li>• Linked to Purchase Groups</li>
                              <li>• Associated with Purchase Documents</li>
                              <li>• Manages Vendor Relationships</li>
                            </ul>
                          </div>
                        </div>
                        <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
                          <h4 className="font-semibold flex items-center text-yellow-800">
                            <HelpCircle className="h-4 w-4 mr-1" />
                            Key Concept
                          </h4>
                          <p className="text-sm text-yellow-700 mt-1">
                            Purchase Organizations centralize procurement functions and enable standardized processes for purchasing materials and services. This creates opportunities for consolidated buying and better negotiating power.
                          </p>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="credit-control">
                    <AccordionTrigger className="text-lg font-medium">
                      <div className="flex items-center">
                        <CreditCard className="h-5 w-5 mr-2 text-pink-600" />
                        Credit Control Area
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pt-2">
                      <div className="space-y-4">
                        <p>
                          A Credit Control Area manages customer credit limits and payment risks. It provides a framework for monitoring and controlling customer credit exposure.
                        </p>
                        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-md">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">ATTRIBUTES</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Code (unique identifier)</li>
                              <li>• Name</li>
                              <li>• Description</li>
                              <li>• Company Code (assignment)</li>
                              <li>• Credit Checking Group</li>
                              <li>• Credit Period (days)</li>
                              <li>• Currency</li>
                              <li>• Grace Percentage</li>
                              <li>• Status (Active/Inactive)</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-600">RELATIONSHIPS</h4>
                            <ul className="mt-2 space-y-1 text-sm">
                              <li>• Belongs to a Company Code</li>
                              <li>• Linked to Customers</li>
                              <li>• Used in Sales Order Processing</li>
                              <li>• Referenced in Accounts Receivable</li>
                            </ul>
                          </div>
                        </div>
                        <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
                          <h4 className="font-semibold flex items-center text-yellow-800">
                            <HelpCircle className="h-4 w-4 mr-1" />
                            Key Concept
                          </h4>
                          <p className="text-sm text-yellow-700 mt-1">
                            Credit Control Areas help reduce financial risk by setting parameters for customer credit and monitoring payment behavior. This ensures that sales activities don't expose the company to excessive credit risk.
                          </p>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
                
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
                  <h3 className="text-xl font-semibold text-blue-800 mb-3">Setup Process Steps</h3>
                  <p className="text-blue-700 mb-4">
                    To properly set up your organizational structure, follow these steps in sequence:
                  </p>
                  
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-200 flex items-center justify-center text-blue-700 font-bold">
                        1
                      </div>
                      <div className="ml-4">
                        <h4 className="font-semibold text-blue-800">Create Company Code</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          Start by defining your legal entity with financial reporting requirements. This is the foundation of your organizational structure.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-200 flex items-center justify-center text-blue-700 font-bold">
                        2
                      </div>
                      <div className="ml-4">
                        <h4 className="font-semibold text-blue-800">Define Plants</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          Create physical locations (manufacturing sites, warehouses) and assign them to the appropriate Company Code.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-200 flex items-center justify-center text-blue-700 font-bold">
                        3
                      </div>
                      <div className="ml-4">
                        <h4 className="font-semibold text-blue-800">Set up Storage Locations</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          For each Plant, define Storage Locations to organize inventory within the physical space.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-200 flex items-center justify-center text-blue-700 font-bold">
                        4
                      </div>
                      <div className="ml-4">
                        <h4 className="font-semibold text-blue-800">Create Sales Organizations</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          Define sales units and assign them to the appropriate Company Code to manage sales activities.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-200 flex items-center justify-center text-blue-700 font-bold">
                        5
                      </div>
                      <div className="ml-4">
                        <h4 className="font-semibold text-blue-800">Create Purchase Organizations</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          Define procurement units and assign them to the appropriate Company Code to manage purchasing activities.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-200 flex items-center justify-center text-blue-700 font-bold">
                        6
                      </div>
                      <div className="ml-4">
                        <h4 className="font-semibold text-blue-800">Set up Credit Control Areas</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          Define credit management units and assign them to the appropriate Company Code to manage customer credit risks.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Previous Topic</Button>
              <Button>Next Topic</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Business Processes Tab */}
        <TabsContent value="processes" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Business Processes</CardTitle>
              <CardDescription>
                Standard workflows and integration points between modules
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Business process documentation coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Technical Architecture Tab */}
        <TabsContent value="technical" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Technical Architecture</CardTitle>
              <CardDescription>
                System components, database schema, and integration points
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Technical architecture documentation coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* User Guides Tab */}
        <TabsContent value="guides" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">User Guides</CardTitle>
              <CardDescription>
                Complete documentation for all business processes and system operations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center space-x-2">
                      <Network className="h-5 w-5" />
                      <span>Transport System Guide</span>
                    </CardTitle>
                    <CardDescription>Complete transport system management</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm space-y-1">
                      <li>• GitHub Integration Framework</li>
                      <li>• Dev → QA → Prod Pipeline</li>
                      <li>• Error Handling & Rollback</li>
                      <li>• Best Practices & Troubleshooting</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="border-green-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center space-x-2">
                      <Package className="h-5 w-5" />
                      <span>Master Data Guide</span>
                    </CardTitle>
                    <CardDescription>Complete master data management</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm space-y-1">
                      <li>• Organizational Master Data</li>
                      <li>• Business Partner Management</li>
                      <li>• Material Master Data</li>
                      <li>• Data Governance & Quality</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="border-purple-200">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center space-x-2">
                      <Workflow className="h-5 w-5" />
                      <span>Business Process Guide</span>
                    </CardTitle>
                    <CardDescription>End-to-end business workflows</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm space-y-1">
                      <li>• Master Data Foundation</li>
                      <li>• Lead to Cash Process</li>
                      <li>• Procure to Pay Process</li>
                      <li>• Production & Finance Integration</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <div className="flex justify-center pt-4">
                <Button 
                  onClick={() => setLocation('/user-guides')}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <BookOpen className="h-5 w-5 mr-2" />
                  Access Complete User Guides
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* FAQs Tab */}
        <TabsContent value="faq" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Frequently Asked Questions</CardTitle>
              <CardDescription>
                Common questions and answers about using the MiniERP system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">FAQs coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Flowchart Display Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BarChart2 className="h-5 w-5" />
              {selectedFlowchart?.title}
            </DialogTitle>
            <DialogDescription>
              {selectedFlowchart?.description}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[60vh] w-full">
            {selectedFlowchart && (
              <div className="space-y-4 p-4">
                <div className="prose max-w-none">
                  <div className="whitespace-pre-wrap text-sm bg-white p-4 rounded-lg border border-gray-200 text-gray-900 overflow-x-auto">
                    {selectedFlowchart.content}
                  </div>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h4 className="font-semibold text-blue-800 mb-2">About This Flowchart</h4>
                  <p className="text-sm text-blue-700">
                    This flowchart is part of the {selectedFlowchart.moduleTitle}. 
                    It uses Mermaid syntax for visual representation and includes decision points, 
                    error handling, and integration flows.
                  </p>
                </div>

                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <h4 className="font-semibold text-green-800 mb-2">How to Use</h4>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Follow the flow from start (blue nodes) to completion (green nodes)</li>
                    <li>• Decision points are shown in diamond shapes (yellow)</li>
                    <li>• Error handling paths are marked in red/orange</li>
                    <li>• Integration points show connections to other modules</li>
                  </ul>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                  <h4 className="font-semibold text-yellow-800 mb-2">Implementation Notes</h4>
                  <p className="text-sm text-yellow-700">
                    This flowchart corresponds to implemented functionality in your ERP system. 
                    Each step represents actual business processes and system integrations that are 
                    operational in your application.
                  </p>
                </div>
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}