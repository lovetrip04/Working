import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { 
  Search, 
  Filter, 
  Plus, 
  Download, 
  Eye, 
  Edit, 
  Trash2,
  FileText,
  Check,
  Timer,
  Truck,
  Package
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

// Define types
interface SalesOrder {
  id: string;
  customerName: string;
  orderDate: string;
  deliveryDate: string;
  totalAmount: number;
  status: 'draft' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  paymentStatus: 'unpaid' | 'partial' | 'paid';
}

// Sample data for demonstration
const sampleOrders: SalesOrder[] = [
  {
    id: "SO-2025-1001",
    customerName: "TechNova Inc",
    orderDate: "2025-05-10",
    deliveryDate: "2025-05-17",
    totalAmount: 5649.75,
    status: 'confirmed',
    paymentStatus: 'unpaid'
  },
  {
    id: "SO-2025-1002",
    customerName: "Elevate Solutions",
    orderDate: "2025-05-12",
    deliveryDate: "2025-05-19",
    totalAmount: 2375.50,
    status: 'processing',
    paymentStatus: 'partial'
  },
  {
    id: "SO-2025-1003",
    customerName: "Vertex Systems",
    orderDate: "2025-05-14",
    deliveryDate: "2025-05-21",
    totalAmount: 9825.00,
    status: 'shipped',
    paymentStatus: 'paid'
  },
  {
    id: "SO-2025-1004",
    customerName: "Global Tech Solutions",
    orderDate: "2025-05-15",
    deliveryDate: "2025-05-22",
    totalAmount: 3150.25,
    status: 'draft',
    paymentStatus: 'unpaid'
  },
  {
    id: "SO-2025-1005",
    customerName: "Innovate Partners",
    orderDate: "2025-05-16",
    deliveryDate: "2025-05-23",
    totalAmount: 7425.00,
    status: 'delivered',
    paymentStatus: 'paid'
  }
];

// Main component
export default function SalesOrderList() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [orders, setOrders] = useState<SalesOrder[]>(sampleOrders);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('date_desc');
  
  // Filter orders based on filters
  const filteredOrders = orders.filter(order => {
    // Search term filter
    const searchMatch = 
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Status filter
    const statusMatch = statusFilter === 'all' || order.status === statusFilter;
    
    return searchMatch && statusMatch;
  }).sort((a, b) => {
    // Sort orders
    switch (sortBy) {
      case 'date_asc':
        return new Date(a.orderDate).getTime() - new Date(b.orderDate).getTime();
      case 'date_desc':
        return new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime();
      case 'amount_asc':
        return a.totalAmount - b.totalAmount;
      case 'amount_desc':
        return b.totalAmount - a.totalAmount;
      default:
        return 0;
    }
  });
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };
  
  // Format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      year: 'numeric', 
      month: 'short', 
      day: 'numeric'
    });
  };
  
  // Delete order
  const deleteOrder = (orderId: string) => {
    // In a real application, you would call an API to delete the order
    setOrders(orders.filter(order => order.id !== orderId));
    
    toast({
      title: "Order Deleted",
      description: `Order ${orderId} has been deleted successfully.`,
    });
  };
  
  // Get badge color based on status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'draft':
        return <Badge variant="outline" className="text-gray-500 border-gray-300">Draft</Badge>;
      case 'confirmed':
        return <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-100">Confirmed</Badge>;
      case 'processing':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Processing</Badge>;
      case 'shipped':
        return <Badge variant="secondary" className="bg-purple-100 text-purple-800 hover:bg-purple-100">Shipped</Badge>;
      case 'delivered':
        return <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">Delivered</Badge>;
      case 'cancelled':
        return <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">Cancelled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Get payment status badge
  const getPaymentBadge = (status: string) => {
    switch (status) {
      case 'unpaid':
        return <Badge variant="outline" className="text-red-500 border-red-300">Unpaid</Badge>;
      case 'partial':
        return <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100">Partial</Badge>;
      case 'paid':
        return <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">Paid</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Get status icon
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'draft':
        return <FileText className="h-4 w-4 text-gray-500" />;
      case 'confirmed':
        return <Check className="h-4 w-4 text-blue-600" />;
      case 'processing':
        return <Timer className="h-4 w-4 text-yellow-600" />;
      case 'shipped':
        return <Truck className="h-4 w-4 text-purple-600" />;
      case 'delivered':
        return <Package className="h-4 w-4 text-green-600" />;
      default:
        return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Sales Orders</h1>
          <p className="text-sm text-muted-foreground">Manage your sales orders</p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              // Export orders functionality
              const csvContent = filteredOrders.map(order => ({
                OrderID: order.id,
                Customer: order.customerName,
                OrderDate: order.orderDate,
                DeliveryDate: order.deliveryDate,
                TotalAmount: order.totalAmount,
                Status: order.status,
                PaymentStatus: order.paymentStatus
              }));
              
              const csvString = [
                Object.keys(csvContent[0]).join(','),
                ...csvContent.map(row => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'sales-orders.csv';
              a.click();
              
              toast({
                title: "Export Complete",
                description: "Sales orders exported successfully",
              });
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm" onClick={() => navigate("/sales/orders/new")}>
            <Plus className="mr-2 h-4 w-4" />
            New Order
          </Button>
        </div>
      </div>
      
      {/* Filters and Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Search and Filters */}
        <Card className="lg:col-span-3">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search orders..." 
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-3">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="shipped">Shipped</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date_desc">Date (Newest)</SelectItem>
                    <SelectItem value="date_asc">Date (Oldest)</SelectItem>
                    <SelectItem value="amount_desc">Amount (High-Low)</SelectItem>
                    <SelectItem value="amount_asc">Amount (Low-High)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Stats Card */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Order Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Total Orders</dt>
                <dd className="font-medium">{orders.length}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Processing</dt>
                <dd className="font-medium">{orders.filter(o => o.status === 'processing').length}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Completed</dt>
                <dd className="font-medium">{orders.filter(o => o.status === 'delivered').length}</dd>
              </div>
            </dl>
          </CardContent>
        </Card>
      </div>
      
      {/* Orders Table with Tabs */}
      <Card className="overflow-hidden">
        <div className="border-b px-4 pt-2">
          <Tabs defaultValue="all" onValueChange={setStatusFilter}>
            <TabsList className="mb-4 mt-2">
              <TabsTrigger value="all">All Orders</TabsTrigger>
              <TabsTrigger value="draft">Draft</TabsTrigger>
              <TabsTrigger value="confirmed">Confirmed</TabsTrigger>
              <TabsTrigger value="processing">Processing</TabsTrigger>
              <TabsTrigger value="shipped">Shipped</TabsTrigger>
              <TabsTrigger value="delivered">Delivered</TabsTrigger>
              <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
            </TabsList>
            
            {/* Tab content for all status types */}
            {['all', 'draft', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'].map((tabValue) => (
              <TabsContent key={tabValue} value={tabValue} className="p-0">
                <div className="overflow-x-auto">
                  <div className="max-h-[600px] overflow-y-auto">
                    <Table>
                      <TableHeader className="sticky top-0 bg-white z-10">
                        <TableRow>
                          <TableHead>Order ID</TableHead>
                          <TableHead>Customer</TableHead>
                          <TableHead>Order Date</TableHead>
                          <TableHead>Delivery Date</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Payment</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredOrders.length > 0 ? (
                          filteredOrders.map(order => (
                            <TableRow key={order.id} className="group hover:bg-gray-50">
                              <TableCell className="font-medium">{order.id}</TableCell>
                              <TableCell>{order.customerName}</TableCell>
                              <TableCell>{formatDate(order.orderDate)}</TableCell>
                              <TableCell>{formatDate(order.deliveryDate)}</TableCell>
                              <TableCell>{formatCurrency(order.totalAmount)}</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  {getStatusIcon(order.status)}
                                  {getStatusBadge(order.status)}
                                </div>
                              </TableCell>
                              <TableCell>{getPaymentBadge(order.paymentStatus)}</TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Button variant="ghost" size="icon" onClick={() => navigate(`/sales/orders/${order.id}`)}>
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => navigate(`/sales/orders/${order.id}/edit`)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => deleteOrder(order.id)}>
                                    <Trash2 className="h-4 w-4 text-red-500" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                              {searchTerm ? 
                                `No orders matching "${searchTerm}" were found. Try a different search term.` :
                                tabValue === 'all' ? 
                                  "No orders found. Create a new order to get started." :
                                  `No ${tabValue} orders found. Try a different filter or create a new order.`
                              }
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </Card>
    </div>
  );
}