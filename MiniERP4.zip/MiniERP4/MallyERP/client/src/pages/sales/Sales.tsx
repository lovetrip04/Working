import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import OrdersContent from "@/components/sales/OrdersContent";
import QuotesContent from "@/components/sales/QuotesContent"; 
import InvoicesContent from "@/components/sales/InvoicesContent";
import ReturnsContent from "@/components/sales/ReturnsContent";
import CustomersContent from "@/components/sales/CustomersContent";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  BarChart,
  PieChart,
  LineChart,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Download,
  Filter,
  Search,
  ShoppingCart,
  Eye,
  Building,
  Phone,
  Mail,
  Settings,
  Database,
  Copy
} from "lucide-react";
import PipelineByStage from "@/components/sales/PipelineByStage";
import OpenOpportunitiesList from "@/components/sales/OpenOpportunitiesList";
import LeadsList from "@/components/sales/LeadsList";
import { Input } from "@/components/ui/input";
import AddLeadDialog from "@/components/sales/AddLeadDialog";

export default function Sales() {
  const [isAddLeadOpen, setIsAddLeadOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Sales</h1>
          <p className="text-sm text-muted-foreground">Sales pipeline and customer management</p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="mr-2"
            onClick={() => setActiveTab("orders")}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Orders
          </Button>
          <Button size="sm" onClick={() => setIsAddLeadOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Lead
          </Button>
        </div>
      </div>

      {/* Sales Navigation Tabs */}
      <Card>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="border-b px-4">
            <TabsList className="bg-transparent h-12 p-0 rounded-none">
              <TabsTrigger 
                value="overview" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="orders" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Orders
              </TabsTrigger>
              <TabsTrigger 
                value="leads" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Leads
              </TabsTrigger>
              <TabsTrigger 
                value="opportunities" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Opportunities
              </TabsTrigger>
              <TabsTrigger 
                value="quotes" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Quotes
              </TabsTrigger>
              <TabsTrigger 
                value="invoices" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Invoices
              </TabsTrigger>
              <TabsTrigger 
                value="returns" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Returns
              </TabsTrigger>
              <TabsTrigger 
                value="customers" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Customers
              </TabsTrigger>
              <TabsTrigger 
                value="configuration" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Configuration
              </TabsTrigger>
              <TabsTrigger 
                value="customization" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                S&D Customization
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Overview Tab Content */}
          <TabsContent value="overview" className="p-4">
            {/* Sales Process Flow - Aligned with tabs */}
            <Card className="mb-6">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">Sales Process</CardTitle>
                <div>
                  <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-800 hover:bg-blue-50">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><path d="M13 2v7h7"></path></svg>
                    View Pipeline Report
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                  <Link href="/sales/leads" className="flex flex-col items-center group cursor-pointer">
                    <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-2 group-hover:bg-blue-200 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                    </div>
                    <span className="text-sm font-medium">Leads</span>
                    <span className="text-xs text-muted-foreground">(21)</span>
                  </Link>
                  <div className="hidden md:block w-full max-w-[50px] h-0.5 bg-gray-200 relative">
                    <div className="absolute top-0 left-0 h-full w-4/5 bg-blue-500"></div>
                  </div>
                  <div className="md:hidden h-6 w-0.5 bg-gray-200 relative">
                    <div className="absolute top-0 left-0 w-full h-4/5 bg-blue-500"></div>
                  </div>
                  <Link href="/sales/opportunities" className="flex flex-col items-center group cursor-pointer">
                    <div className="w-16 h-16 rounded-full bg-indigo-100 flex items-center justify-center mb-2 group-hover:bg-indigo-200 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-600"><circle cx="12" cy="12" r="10"></circle><path d="m16 8-8 8"></path><path d="M8.5 8.5a2.5 2.5 0 0 1 5 0V12a2.5 2.5 0 0 1-5 0"></path></svg>
                    </div>
                    <span className="text-sm font-medium">Opportunities</span>
                    <span className="text-xs text-muted-foreground">(18)</span>
                  </Link>
                  <div className="hidden md:block w-full max-w-[50px] h-0.5 bg-gray-200 relative">
                    <div className="absolute top-0 left-0 h-full w-3/5 bg-indigo-500"></div>
                  </div>
                  <div className="md:hidden h-6 w-0.5 bg-gray-200 relative">
                    <div className="absolute top-0 left-0 w-full h-3/5 bg-indigo-500"></div>
                  </div>
                  <Link href="/sales/quotes" className="flex flex-col items-center group cursor-pointer">
                    <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mb-2 group-hover:bg-purple-200 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-600"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><path d="M14 2v6h6"></path><path d="M16 13H8"></path><path d="M16 17H8"></path><path d="M10 9H8"></path></svg>
                    </div>
                    <span className="text-sm font-medium">Quote/Estimate</span>
                    <span className="text-xs text-muted-foreground">(14)</span>
                  </Link>
                  <div className="hidden md:block w-full max-w-[50px] h-0.5 bg-gray-200 relative">
                    <div className="absolute top-0 left-0 h-full w-2/5 bg-purple-500"></div>
                  </div>
                  <div className="md:hidden h-6 w-0.5 bg-gray-200 relative">
                    <div className="absolute top-0 left-0 w-full h-2/5 bg-purple-500"></div>
                  </div>
                  <Link href="/sales/quotes/approved" className="flex flex-col items-center group cursor-pointer">
                    <div className="w-16 h-16 rounded-full bg-pink-100 flex items-center justify-center mb-2 group-hover:bg-pink-200 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-pink-600"><path d="M9 12l2 2 4-4"></path><circle cx="12" cy="12" r="10"></circle></svg>
                    </div>
                    <span className="text-sm font-medium">Quote Approval</span>
                    <span className="text-xs text-muted-foreground">(10)</span>
                  </Link>
                  <div className="hidden md:block w-full max-w-[50px] h-0.5 bg-gray-200 relative">
                    <div className="absolute top-0 left-0 h-full w-1/5 bg-pink-500"></div>
                  </div>
                  <div className="md:hidden h-6 w-0.5 bg-gray-200 relative">
                    <div className="absolute top-0 left-0 w-full h-1/5 bg-pink-500"></div>
                  </div>
                  <Link href="/sales/orders" className="flex flex-col items-center group cursor-pointer">
                    <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-2 group-hover:bg-green-200 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600"><path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4"></path><path d="M4 6v12c0 1.1.9 2 2 2h14v-4"></path><path d="M18 12a2 2 0 0 0-2 2c0 1.1.9 2 2 2h4v-4h-4z"></path></svg>
                    </div>
                    <span className="text-sm font-medium">Order Creation</span>
                    <span className="text-xs text-muted-foreground">(8)</span>
                  </Link>
                </div>
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Summary KPI Cards */}
              <SalesCard 
                title="Total Revenue" 
                value="$127,543.21" 
                change={8.7} 
                isPositive={true}
                period="vs last month"
                icon={<BarChart className="h-4 w-4 text-muted-foreground" />}
              />
              <SalesCard 
                title="Opportunities" 
                value="58" 
                change={15.2} 
                isPositive={true}
                period="vs last month"
                icon={<PieChart className="h-4 w-4 text-muted-foreground" />}
              />
              <SalesCard 
                title="Conversion Rate" 
                value="24.8%" 
                change={3.5} 
                isPositive={true}
                period="vs last month"
                icon={<LineChart className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
            
            {/* Sales Funnel Chart */}
            <div className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Sales Funnel</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                    Sales Funnel Visualization
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Additional Sales Widgets */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Sales by Region</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] flex items-center justify-center text-muted-foreground">
                    Regional Sales Distribution Chart
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <TopProduct 
                      name="Enterprise SaaS Solution"
                      revenue="$45,230.00"
                      growth={12.3}
                    />
                    <TopProduct 
                      name="Cloud Security Package"
                      revenue="$32,185.50"
                      growth={8.7}
                    />
                    <TopProduct 
                      name="Data Analytics Platform"
                      revenue="$28,450.25"
                      growth={15.2}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Leads Tab Content */}
          <TabsContent value="leads" className="p-4">
            {/* Search & Filter Bar */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search leads..." 
                  className="pl-8 rounded-md border border-input bg-white"
                />
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    // Reset all filters and reload data
                    const searchInput = document.querySelector('input[placeholder="Search leads..."]') as HTMLInputElement;
                    if (searchInput) {
                      searchInput.value = '';
                    }
                    window.location.reload();
                  }}
                >
                  <Filter className="mr-2 h-4 w-4" />
                  Reset
                </Button>
              </div>
            </div>
            
            {/* Standalone LeadsList component - this will persist when navigating */}
            <LeadsList />
          </TabsContent>
          
          {/* Opportunities Tab Content */}
          <TabsContent value="opportunities" className="p-4">
            <div className="grid gap-6">
              <div className="flex flex-col gap-4 md:flex-row md:items-center">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search opportunities..." 
                    className="pl-8 rounded-md border border-input bg-white"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      // Reset all filters and reload data
                      const searchInput = document.querySelector('input[placeholder="Search opportunities..."]') as HTMLInputElement;
                      if (searchInput) {
                        searchInput.value = '';
                      }
                      window.location.reload();
                    }}
                  >
                    <Filter className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                <PipelineByStage />
                <OpenOpportunitiesList />
              </div>
            </div>
          </TabsContent>
          
          {/* Other Tab Contents */}
          <TabsContent value="orders" className="p-4">
            <OrdersContent />
          </TabsContent>
          
          <TabsContent value="quotes" className="p-4">
            <QuotesContent />
          </TabsContent>
          
          <TabsContent value="invoices" className="p-4">
            <InvoicesContent />
          </TabsContent>
          
          <TabsContent value="returns" className="p-4">
            <ReturnsContent />
          </TabsContent>
          
          <TabsContent value="customers" className="p-4">
            <CustomersContent />
          </TabsContent>
          
          <TabsContent value="configuration" className="p-4">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">Sales & Distribution Configuration</h3>
                  <p className="text-sm text-muted-foreground">
                    Configure enterprise structure, document types, and pricing procedures
                  </p>
                </div>
                <Button asChild>
                  <Link href="/sales/distribution-config">
                    Open Full Configuration
                  </Link>
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Building className="h-4 w-4 mr-2" />
                      Sales Organizations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">0</div>
                    <p className="text-xs text-muted-foreground">Legal sales units</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Building className="h-4 w-4 mr-2" />
                      Sales Areas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">0</div>
                    <p className="text-xs text-muted-foreground">Organizational combinations</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Building className="h-4 w-4 mr-2" />
                      Document Types
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">0</div>
                    <p className="text-xs text-muted-foreground">Transaction documents</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center">
                      <Building className="h-4 w-4 mr-2" />
                      Pricing Config
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">0</div>
                    <p className="text-xs text-muted-foreground">Pricing procedures</p>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Quick Setup</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Get started with basic Sales & Distribution configuration
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">1. Enterprise Structure</p>
                        <p className="text-sm text-muted-foreground">Set up sales organizations, channels, and divisions</p>
                      </div>
                      <Badge variant="outline">Pending</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">2. Sales Areas</p>
                        <p className="text-sm text-muted-foreground">Combine organizational units</p>
                      </div>
                      <Badge variant="outline">Pending</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">3. Document Configuration</p>
                        <p className="text-sm text-muted-foreground">Define order, delivery, and billing documents</p>
                      </div>
                      <Badge variant="outline">Pending</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* S&D Customization Tab Content */}
          <TabsContent value="customization" className="p-4">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    Sales Distribution Customization
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Manage customer-specific SD configurations without affecting standard settings
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-100 rounded-lg">
                            <Database className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">Standard Configuration</h4>
                            <p className="text-sm text-gray-600">Base SD settings for all clients</p>
                          </div>
                        </div>
                      </Card>
                      
                      <Card className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-green-100 rounded-lg">
                            <Building className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">Client-Specific</h4>
                            <p className="text-sm text-gray-600">Custom tables per client</p>
                          </div>
                        </div>
                      </Card>
                      
                      <Card className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-purple-100 rounded-lg">
                            <Copy className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">Copy & Customize</h4>
                            <p className="text-sm text-gray-600">Start from standard, modify as needed</p>
                          </div>
                        </div>
                      </Card>
                    </div>
                    
                    <div className="flex gap-4">
                      <Link href="/sales/sd-customization">
                        <Button className="flex items-center gap-2">
                          <Settings className="w-4 h-4" />
                          Manage SD Customizations
                        </Button>
                      </Link>
                      <Link href="/sales/configuration">
                        <Button variant="outline" className="flex items-center gap-2">
                          <Eye className="w-4 h-4" />
                          View Standard Configuration
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Available Customization Types</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    These configuration areas can be customized per client
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Sales Organizations</h4>
                      <p className="text-sm text-gray-600">Company sales organization structure</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Distribution Channels</h4>
                      <p className="text-sm text-gray-600">Sales distribution channel definitions</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Divisions</h4>
                      <p className="text-sm text-gray-600">Product/business divisions</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Sales Areas</h4>
                      <p className="text-sm text-gray-600">Combinations of sales org, channel, and division</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Document Types</h4>
                      <p className="text-sm text-gray-600">Order, delivery, and billing document types</p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Pricing Procedures</h4>
                      <p className="text-sm text-gray-600">Pricing calculation procedures</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </Card>
      
      {/* Add Lead Dialog */}
      <AddLeadDialog 
        isOpen={isAddLeadOpen}
        onOpenChange={setIsAddLeadOpen}
      />
    </div>
  );
}

// Sub-components

type SalesCardProps = {
  title: string;
  value: string;
  change: number;
  isPositive: boolean;
  period: string;
  icon: React.ReactNode;
};

function SalesCard({ title, value, change, isPositive, period, icon }: SalesCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center space-x-1 text-xs mt-1">
          {isPositive ? (
            <ArrowUpRight className="h-3 w-3 text-green-500" />
          ) : (
            <ArrowDownRight className="h-3 w-3 text-red-500" />
          )}
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? "+" : "-"}{Math.abs(change)}%
          </span>
          <span className="text-muted-foreground">{period}</span>
        </div>
      </CardContent>
    </Card>
  );
}

type TopProductProps = {
  name: string;
  revenue: string;
  growth: number;
};

function TopProduct({ name, revenue, growth }: TopProductProps) {
  return (
    <div className="flex justify-between items-center">
      <div className="space-y-1">
        <p className="font-medium">{name}</p>
        <div className="text-sm text-muted-foreground flex items-center space-x-1">
          <ArrowUpRight className="h-3 w-3 text-green-500" />
          <span className="text-green-500">+{growth}%</span>
        </div>
      </div>
      <div className="font-medium">{revenue}</div>
    </div>
  );
}

type LeadCardProps = {
  name: string;
  company: string;
  location: string;
  phone: string;
  email: string;
  source: string;
};

function LeadCard({ name, company, location, phone, email, source }: LeadCardProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-base font-medium">{name}</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="p-4 space-y-2">
        <div className="text-sm">
          <div className="flex justify-between">
            <span className="font-medium">{company}</span>
            <span>{location}</span>
          </div>
          <div className="text-muted-foreground mt-1">{phone}</div>
          <div className="text-muted-foreground text-xs mt-1">{email}</div>
          <div className="text-xs mt-2 bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full inline-block">
            {source}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}