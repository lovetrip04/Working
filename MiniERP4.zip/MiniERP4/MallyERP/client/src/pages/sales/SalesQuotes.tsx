import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Plus, Search, Filter, FileUp, FileDown, RefreshCw, 
  Building, DollarSign, Calendar, ArrowRight, FileText, 
  CheckCircle, XCircle, Clock, Eye
} from "lucide-react";

export default function SalesQuotes() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  // Mock quotes for now
  const quotes = [
    {
      id: 1,
      number: "QT-2023-0001",
      name: "Enterprise Software Suite - Initial Quote",
      customer: "ABC Manufacturing",
      contactPerson: "John Smith",
      totalValue: 78500,
      validUntil: "2023-07-15T00:00:00Z",
      status: "draft",
      createdAt: "2023-05-10T14:30:00Z",
      lastUpdated: "2023-05-10T14:30:00Z"
    },
    {
      id: 2,
      number: "QT-2023-0002",
      name: "Retail POS System Upgrade - Full Package",
      customer: "XYZ Retail",
      contactPerson: "Sarah Johnson",
      totalValue: 37250,
      validUntil: "2023-07-01T00:00:00Z",
      status: "sent",
      createdAt: "2023-05-05T09:15:00Z",
      lastUpdated: "2023-05-06T11:25:00Z"
    },
    {
      id: 3,
      number: "QT-2023-0003",
      name: "IT Infrastructure Overhaul - Phase 1",
      customer: "Global Solutions Inc.",
      contactPerson: "Michael Brown",
      totalValue: 125000,
      validUntil: "2023-07-30T00:00:00Z",
      status: "approved",
      createdAt: "2023-04-28T10:30:00Z",
      lastUpdated: "2023-05-12T16:10:00Z"
    },
    {
      id: 4,
      number: "QT-2023-0004",
      name: "Warehouse Management System - Standard",
      customer: "Eastern Distributors",
      contactPerson: "Emily Davis",
      totalValue: 62000,
      validUntil: "2023-08-15T00:00:00Z",
      status: "rejected",
      createdAt: "2023-05-01T11:45:00Z",
      lastUpdated: "2023-05-08T09:30:00Z"
    },
    {
      id: 5,
      number: "QT-2023-0005",
      name: "Guest Management Platform - Premium",
      customer: "Sunshine Hospitality",
      contactPerson: "David Wilson",
      totalValue: 48500,
      validUntil: "2023-06-30T00:00:00Z",
      status: "expired",
      createdAt: "2023-04-15T14:15:00Z",
      lastUpdated: "2023-04-15T14:15:00Z"
    }
  ];

  // Filter quotes based on search term and active tab
  const filteredQuotes = quotes.filter(quote => {
    const matchesSearch = searchTerm === "" || 
      quote.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quote.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quote.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quote.contactPerson.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTab = activeTab === "all" || 
      (activeTab === "draft" && quote.status === "draft") ||
      (activeTab === "sent" && quote.status === "sent") ||
      (activeTab === "approved" && quote.status === "approved") ||
      (activeTab === "rejected" && quote.status === "rejected") ||
      (activeTab === "expired" && quote.status === "expired");
    
    return matchesSearch && matchesTab;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Draft</Badge>;
      case "sent":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Sent</Badge>;
      case "approved":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>;
      case "expired":
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Expired</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Quotes & Estimates</h1>
          <p className="text-gray-600 mt-1">
            Create and manage customer quotations and price estimates
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
          >
            <FileUp className="h-4 w-4" />
            <span>Import</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
          >
            <FileDown className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button 
            variant="default" 
            className="flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Create Quote</span>
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="p-4 border-b">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search quotes..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <Filter className="h-4 w-4" />
                  <span>Filter</span>
                </Button>
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
            <div className="px-4">
              <TabsList className="mb-4 mt-2">
                <TabsTrigger value="all">All Quotes</TabsTrigger>
                <TabsTrigger value="draft">Draft</TabsTrigger>
                <TabsTrigger value="sent">Sent</TabsTrigger>
                <TabsTrigger value="approved">Approved</TabsTrigger>
                <TabsTrigger value="rejected">Rejected</TabsTrigger>
                <TabsTrigger value="expired">Expired</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="all" className="mt-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead>Quote #</TableHead>
                      <TableHead>Quote Name</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Total Value</TableHead>
                      <TableHead>Valid Until</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredQuotes.map((quote) => (
                      <TableRow key={quote.id} className="cursor-pointer hover:bg-gray-50">
                        <TableCell className="font-medium">{quote.number}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-blue-500 mr-2" />
                            {quote.name}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Building className="h-4 w-4 text-gray-400 mr-2" />
                            <div>
                              <div>{quote.customer}</div>
                              <div className="text-sm text-gray-500">{quote.contactPerson}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 text-green-500 mr-1" />
                            {formatCurrency(quote.totalValue)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                            {new Date(quote.validUntil).toLocaleDateString()}
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(quote.status)}</TableCell>
                        <TableCell>
                          {new Date(quote.lastUpdated).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              title="View Quote"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            {quote.status === "sent" && (
                              <Button
                                variant="ghost"
                                size="sm"
                                asChild
                              >
                                <Link href={`/sales/quote-approval?quoteId=${quote.id}`}>
                                  Submit for Approval
                                </Link>
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            
            {/* Other tab contents with filtered content */}
            <TabsContent value="draft" className="mt-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead>Quote #</TableHead>
                      <TableHead>Quote Name</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Total Value</TableHead>
                      <TableHead>Valid Until</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredQuotes.filter(quote => quote.status === "draft").map((quote) => (
                      <TableRow key={quote.id} className="cursor-pointer hover:bg-gray-50">
                        <TableCell className="font-medium">{quote.number}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-blue-500 mr-2" />
                            {quote.name}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Building className="h-4 w-4 text-gray-400 mr-2" />
                            <div>
                              <div>{quote.customer}</div>
                              <div className="text-sm text-gray-500">{quote.contactPerson}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 text-green-500 mr-1" />
                            {formatCurrency(quote.totalValue)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                            {new Date(quote.validUntil).toLocaleDateString()}
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(quote.status)}</TableCell>
                        <TableCell>
                          {new Date(quote.lastUpdated).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              title="View Quote"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="sent" className="mt-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead>Quote #</TableHead>
                      <TableHead>Quote Name</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Total Value</TableHead>
                      <TableHead>Valid Until</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredQuotes.filter(quote => quote.status === "sent").map((quote) => (
                      <TableRow key={quote.id} className="cursor-pointer hover:bg-gray-50">
                        <TableCell className="font-medium">{quote.number}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-blue-500 mr-2" />
                            {quote.name}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Building className="h-4 w-4 text-gray-400 mr-2" />
                            <div>
                              <div>{quote.customer}</div>
                              <div className="text-sm text-gray-500">{quote.contactPerson}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 text-green-500 mr-1" />
                            {formatCurrency(quote.totalValue)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                            {new Date(quote.validUntil).toLocaleDateString()}
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(quote.status)}</TableCell>
                        <TableCell>
                          {new Date(quote.lastUpdated).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              asChild
                            >
                              <Link href={`/sales/quote-approval?quoteId=${quote.id}`}>
                                Submit for Approval
                              </Link>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="approved" className="mt-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead>Quote #</TableHead>
                      <TableHead>Quote Name</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Total Value</TableHead>
                      <TableHead>Valid Until</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredQuotes.filter(quote => quote.status === "approved").map((quote) => (
                      <TableRow key={quote.id} className="cursor-pointer hover:bg-gray-50">
                        <TableCell className="font-medium">{quote.number}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-blue-500 mr-2" />
                            {quote.name}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Building className="h-4 w-4 text-gray-400 mr-2" />
                            <div>
                              <div>{quote.customer}</div>
                              <div className="text-sm text-gray-500">{quote.contactPerson}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 text-green-500 mr-1" />
                            {formatCurrency(quote.totalValue)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                            {new Date(quote.validUntil).toLocaleDateString()}
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(quote.status)}</TableCell>
                        <TableCell>
                          {new Date(quote.lastUpdated).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              asChild
                            >
                              <Link href={`/sales/orders/new?quoteId=${quote.id}`}>
                                Create Order
                              </Link>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="rejected" className="mt-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead>Quote #</TableHead>
                      <TableHead>Quote Name</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Total Value</TableHead>
                      <TableHead>Valid Until</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredQuotes.filter(quote => quote.status === "rejected").map((quote) => (
                      <TableRow key={quote.id} className="cursor-pointer hover:bg-gray-50">
                        <TableCell className="font-medium">{quote.number}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-blue-500 mr-2" />
                            {quote.name}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Building className="h-4 w-4 text-gray-400 mr-2" />
                            <div>
                              <div>{quote.customer}</div>
                              <div className="text-sm text-gray-500">{quote.contactPerson}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 text-green-500 mr-1" />
                            {formatCurrency(quote.totalValue)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                            {new Date(quote.validUntil).toLocaleDateString()}
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(quote.status)}</TableCell>
                        <TableCell>
                          {new Date(quote.lastUpdated).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                            >
                              Revise Quote
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="expired" className="mt-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead>Quote #</TableHead>
                      <TableHead>Quote Name</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Total Value</TableHead>
                      <TableHead>Valid Until</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredQuotes.filter(quote => quote.status === "expired").map((quote) => (
                      <TableRow key={quote.id} className="cursor-pointer hover:bg-gray-50">
                        <TableCell className="font-medium">{quote.number}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-blue-500 mr-2" />
                            {quote.name}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Building className="h-4 w-4 text-gray-400 mr-2" />
                            <div>
                              <div>{quote.customer}</div>
                              <div className="text-sm text-gray-500">{quote.contactPerson}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 text-green-500 mr-1" />
                            {formatCurrency(quote.totalValue)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                            {new Date(quote.validUntil).toLocaleDateString()}
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(quote.status)}</TableCell>
                        <TableCell>
                          {new Date(quote.lastUpdated).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                            >
                              Renew Quote
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}