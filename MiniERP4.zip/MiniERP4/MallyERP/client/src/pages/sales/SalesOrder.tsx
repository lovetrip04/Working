import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { 
  ArrowLeft, 
  Save, 
  Plus, 
  Trash2, 
  FileText,
  ShoppingCart,
  Truck,
  Check,
  Calendar,
  User,
  Building
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

// Type definitions
interface Customer {
  id: number;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  contactPerson: string;
  email: string;
  phone: string;
}

interface Product {
  id: number;
  name: string;
  sku: string;
  price: number;
  availableQuantity: number;
  unit: string;
}

interface OrderItem {
  id: number;
  productId: number;
  productName: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  total: number;
}

interface SalesOrder {
  id: string;
  customerId: number;
  orderDate: string;
  deliveryDate: string;
  status: 'draft' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  paymentTerms: string;
  shippingMethod: string;
  items: OrderItem[];
  subtotal: number;
  taxAmount: number;
  shippingAmount: number;
  totalAmount: number;
  notes: string;
}

// Sample data for demonstration
const sampleCustomers: Customer[] = [
  {
    id: 1,
    name: "TechNova Inc",
    address: "123 Tech Blvd",
    city: "San Francisco",
    state: "CA",
    zipCode: "94105",
    contactPerson: "Michael Chen",
    email: "mchen@technova.com",
    phone: "(415) 555-8765"
  },
  {
    id: 2,
    name: "Elevate Solutions",
    address: "456 Innovation Ave",
    city: "New York",
    state: "NY",
    zipCode: "10001",
    contactPerson: "Sarah Johnson",
    email: "sjohnson@elevate.co",
    phone: "(212) 555-3982"
  },
  {
    id: 3,
    name: "Vertex Systems",
    address: "789 Enterprise Dr",
    city: "Austin",
    state: "TX",
    zipCode: "78701",
    contactPerson: "David Rodriguez",
    email: "drodriguez@vertexsys.com",
    phone: "(512) 555-1247"
  }
];

const sampleProducts: Product[] = [
  {
    id: 1,
    name: "Enterprise SaaS Solution",
    sku: "SAS-ENT-001",
    price: 1299.99,
    availableQuantity: 100,
    unit: "License"
  },
  {
    id: 2,
    name: "Cloud Security Package",
    sku: "CSP-PRO-002",
    price: 899.50,
    availableQuantity: 50,
    unit: "Package"
  },
  {
    id: 3,
    name: "Data Analytics Platform",
    sku: "DAP-STD-003",
    price: 1499.99,
    availableQuantity: 75,
    unit: "Subscription"
  },
  {
    id: 4,
    name: "Network Monitoring Tool",
    sku: "NMT-PRO-004",
    price: 599.99,
    availableQuantity: 120,
    unit: "License"
  },
  {
    id: 5,
    name: "Advanced Reporting Module",
    sku: "ARM-ENT-005",
    price: 349.99,
    availableQuantity: 200,
    unit: "Module"
  }
];

// Main component
export default function SalesOrder() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  
  // State for form
  const [order, setOrder] = useState<SalesOrder>({
    id: `SO-${new Date().getFullYear()}-${String(Math.floor(1000 + Math.random() * 9000))}`,
    customerId: 0,
    orderDate: new Date().toISOString().split('T')[0],
    deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'draft',
    paymentTerms: "Net 30",
    shippingMethod: "Standard Shipping",
    items: [],
    subtotal: 0,
    taxAmount: 0,
    shippingAmount: 0,
    totalAmount: 0,
    notes: ""
  });
  
  // State for product selection
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [discount, setDiscount] = useState<number>(0);
  const [customerDetails, setCustomerDetails] = useState<Customer | null>(null);
  
  // Update totals whenever items change
  useEffect(() => {
    const subtotal = order.items.reduce((sum, item) => sum + item.total, 0);
    const taxRate = 0.07; // 7% tax
    const taxAmount = subtotal * taxRate;
    const shippingAmount = subtotal > 5000 ? 0 : 75; // Free shipping for orders over $5000
    const totalAmount = subtotal + taxAmount + shippingAmount;
    
    setOrder({
      ...order,
      subtotal,
      taxAmount,
      shippingAmount,
      totalAmount
    });
  }, [order.items]);
  
  // Update customer details when customerId changes
  useEffect(() => {
    if (order.customerId) {
      const customer = sampleCustomers.find(c => c.id === order.customerId);
      setCustomerDetails(customer || null);
    } else {
      setCustomerDetails(null);
    }
  }, [order.customerId]);
  
  // Add item to order
  const addItem = () => {
    if (!selectedProduct || quantity <= 0) return;
    
    const product = sampleProducts.find(p => p.id === selectedProduct);
    if (!product) return;
    
    const existingItemIndex = order.items.findIndex(item => item.productId === product.id);
    
    if (existingItemIndex >= 0) {
      // Update existing item
      const updatedItems = [...order.items];
      const item = updatedItems[existingItemIndex];
      const newQuantity = item.quantity + quantity;
      const total = product.price * newQuantity * (1 - discount / 100);
      
      updatedItems[existingItemIndex] = {
        ...item,
        quantity: newQuantity,
        discount,
        total
      };
      
      setOrder({
        ...order,
        items: updatedItems
      });
    } else {
      // Add new item
      const total = product.price * quantity * (1 - discount / 100);
      const newItem: OrderItem = {
        id: Date.now(),
        productId: product.id,
        productName: product.name,
        quantity,
        unitPrice: product.price,
        discount,
        total
      };
      
      setOrder({
        ...order,
        items: [...order.items, newItem]
      });
    }
    
    // Reset selection
    setSelectedProduct(null);
    setQuantity(1);
    setDiscount(0);
    
    toast({
      title: "Item Added",
      description: `${product.name} added to the order.`,
    });
  };
  
  // Remove item from order
  const removeItem = (itemId: number) => {
    setOrder({
      ...order,
      items: order.items.filter(item => item.id !== itemId)
    });
    
    toast({
      title: "Item Removed",
      description: "The item has been removed from the order.",
    });
  };
  
  // Save order
  const saveOrder = () => {
    if (order.items.length === 0) {
      toast({
        title: "Cannot Save Order",
        description: "Please add at least one item to the order.",
        variant: "destructive"
      });
      return;
    }
    
    if (!order.customerId) {
      toast({
        title: "Cannot Save Order",
        description: "Please select a customer for the order.",
        variant: "destructive"
      });
      return;
    }
    
    // Here you would normally save the order to the backend
    // For this demo, we'll just show a success message
    
    toast({
      title: "Order Saved",
      description: `Order ${order.id} has been saved successfully.`,
    });
    
    // Navigate to orders list
    navigate("/sales/orders");
  };
  
  // Confirm order
  const confirmOrder = () => {
    if (order.items.length === 0) {
      toast({
        title: "Cannot Confirm Order",
        description: "Please add at least one item to the order.",
        variant: "destructive"
      });
      return;
    }
    
    if (!order.customerId) {
      toast({
        title: "Cannot Confirm Order",
        description: "Please select a customer for the order.",
        variant: "destructive"
      });
      return;
    }
    
    setOrder({
      ...order,
      status: 'confirmed'
    });
    
    toast({
      title: "Order Confirmed",
      description: `Order ${order.id} has been confirmed successfully.`,
    });
  };
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };
  
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate("/sales/orders")}
            className="mr-2"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">New Sales Order</h1>
            <p className="text-sm text-muted-foreground">Create a new sales order</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={order.status === 'draft' ? "outline" : "default"} className="text-sm py-1 px-3">
            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
          </Badge>
          <Button variant="outline" size="sm" onClick={saveOrder}>
            <Save className="mr-2 h-4 w-4" />
            Save
          </Button>
          {order.status === 'draft' && (
            <Button size="sm" onClick={confirmOrder}>
              <Check className="mr-2 h-4 w-4" />
              Confirm Order
            </Button>
          )}
        </div>
      </div>
      
      {/* Order Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order Details - Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Order Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <FileText className="mr-2 h-5 w-5 text-blue-600" />
                Order Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="orderNumber">Order Number</Label>
                  <Input id="orderNumber" value={order.id} readOnly className="bg-gray-50" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="orderDate">Order Date</Label>
                  <Input 
                    id="orderDate" 
                    type="date" 
                    value={order.orderDate} 
                    onChange={e => setOrder({...order, orderDate: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="paymentTerms">Payment Terms</Label>
                  <Select 
                    value={order.paymentTerms} 
                    onValueChange={value => setOrder({...order, paymentTerms: value})}
                  >
                    <SelectTrigger id="paymentTerms">
                      <SelectValue placeholder="Select payment terms" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Net 15">Net 15</SelectItem>
                      <SelectItem value="Net 30">Net 30</SelectItem>
                      <SelectItem value="Net 45">Net 45</SelectItem>
                      <SelectItem value="Net 60">Net 60</SelectItem>
                      <SelectItem value="Due on Receipt">Due on Receipt</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="deliveryDate">Expected Delivery Date</Label>
                  <Input 
                    id="deliveryDate" 
                    type="date" 
                    value={order.deliveryDate} 
                    onChange={e => setOrder({...order, deliveryDate: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="shippingMethod">Shipping Method</Label>
                <Select 
                  value={order.shippingMethod} 
                  onValueChange={value => setOrder({...order, shippingMethod: value})}
                >
                  <SelectTrigger id="shippingMethod">
                    <SelectValue placeholder="Select shipping method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Standard Shipping">Standard Shipping</SelectItem>
                    <SelectItem value="Express Shipping">Express Shipping</SelectItem>
                    <SelectItem value="Priority Shipping">Priority Shipping</SelectItem>
                    <SelectItem value="Free Shipping">Free Shipping</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
          
          {/* Customer Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <User className="mr-2 h-5 w-5 text-blue-600" />
                Customer Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="customer">Customer</Label>
                <Select 
                  value={order.customerId.toString()} 
                  onValueChange={value => setOrder({...order, customerId: parseInt(value)})}
                >
                  <SelectTrigger id="customer">
                    <SelectValue placeholder="Select customer" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Select a customer</SelectItem>
                    {sampleCustomers.map(customer => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {customerDetails && (
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="font-medium">{customerDetails.name}</div>
                  <div className="text-sm text-gray-600">
                    {customerDetails.address}<br />
                    {customerDetails.city}, {customerDetails.state} {customerDetails.zipCode}
                  </div>
                  <div className="mt-2 text-sm">
                    <div><span className="font-medium">Contact:</span> {customerDetails.contactPerson}</div>
                    <div><span className="font-medium">Email:</span> {customerDetails.email}</div>
                    <div><span className="font-medium">Phone:</span> {customerDetails.phone}</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Order Items */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <ShoppingCart className="mr-2 h-5 w-5 text-blue-600" />
                Order Items
              </CardTitle>
            </CardHeader>
            <CardContent className="max-h-[500px] overflow-y-auto">
              {/* Add New Item Section */}
              <div className="mb-6 p-4 bg-gray-50 rounded-md">
                <h3 className="font-medium mb-3">Add Item</h3>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                  <div className="md:col-span-2">
                    <Select 
                      value={selectedProduct?.toString() || ""} 
                      onValueChange={value => setSelectedProduct(parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select product" />
                      </SelectTrigger>
                      <SelectContent>
                        {sampleProducts.map(product => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Input 
                      type="number" 
                      placeholder="Quantity" 
                      min="1"
                      value={quantity}
                      onChange={e => setQuantity(parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div>
                    <Input 
                      type="number" 
                      placeholder="Discount %" 
                      min="0"
                      max="100"
                      value={discount}
                      onChange={e => setDiscount(parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div>
                    <Button 
                      className="w-full" 
                      onClick={addItem}
                      disabled={!selectedProduct || quantity <= 0}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Order Items Table */}
              {order.items.length > 0 ? (
                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead className="text-right">Unit Price</TableHead>
                        <TableHead className="text-right">Quantity</TableHead>
                        <TableHead className="text-right">Discount</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {order.items.map(item => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.productName}</TableCell>
                          <TableCell className="text-right">{formatCurrency(item.unitPrice)}</TableCell>
                          <TableCell className="text-right">{item.quantity}</TableCell>
                          <TableCell className="text-right">{item.discount}%</TableCell>
                          <TableCell className="text-right">{formatCurrency(item.total)}</TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => removeItem(item.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground border rounded-md">
                  No items added to this order yet.
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Order Notes */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Notes & Additional Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea 
                placeholder="Add notes or special instructions for this order..."
                value={order.notes}
                onChange={e => setOrder({...order, notes: e.target.value})}
                rows={4}
              />
            </CardContent>
          </Card>
        </div>
        
        {/* Order Summary - Right Column */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{formatCurrency(order.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax (7%)</span>
                <span>{formatCurrency(order.taxAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span>{formatCurrency(order.shippingAmount)}</span>
              </div>
              <div className="border-t pt-2 mt-2 flex justify-between font-medium">
                <span>Total</span>
                <span className="text-lg">{formatCurrency(order.totalAmount)}</span>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col">
              <Button 
                className="w-full mb-2" 
                onClick={order.status === 'draft' ? confirmOrder : saveOrder}
              >
                {order.status === 'draft' ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Confirm Order
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                  </>
                )}
              </Button>
              <Button variant="outline" className="w-full" onClick={() => navigate("/sales/orders")}>
                Cancel
              </Button>
            </CardFooter>
          </Card>
          
          {/* Order Timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Order Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="mr-3 bg-blue-100 rounded-full p-1">
                    <FileText className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-medium">Order Created</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date().toLocaleString()}
                    </div>
                  </div>
                </div>
                
                {order.status !== 'draft' && (
                  <div className="flex items-start">
                    <div className="mr-3 bg-green-100 rounded-full p-1">
                      <Check className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <div className="font-medium">Order Confirmed</div>
                      <div className="text-xs text-muted-foreground">
                        {new Date().toLocaleString()}
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Placeholder for future status updates */}
                <div className="text-xs text-muted-foreground border-t pt-3 mt-3">
                  Order status updates will appear here
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}