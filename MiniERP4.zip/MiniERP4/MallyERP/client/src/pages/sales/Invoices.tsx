import { useState } from "react";
import Header from "@/components/layout/Header";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Download, Mail, Search, Printer, ChevronRight, CalendarDays, DollarSign } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

export default function Invoices() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  const { data: invoices, isLoading } = useQuery({
    queryKey: ['/api/invoices'],
  });

  const getInvoicesByStatus = (status: string) => {
    if (!invoices) return [];
    
    if (status === "all") {
      return invoices.filter((invoice: any) => 
        invoice.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
        invoice.customer.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    return invoices.filter((invoice: any) => 
      invoice.status === status && 
      (invoice.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
      invoice.customer.name.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'Paid':
        return 'bg-green-100 text-green-800';
      case 'Due':
        return 'bg-yellow-100 text-yellow-800';
      case 'Overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredInvoices = getInvoicesByStatus(activeTab);
  
  return (
    <>
      <Header title="Invoices" />
      
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 mt-4">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search invoices..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Generate Invoice
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="Paid">Paid</TabsTrigger>
          <TabsTrigger value="Due">Due</TabsTrigger>
          <TabsTrigger value="Overdue">Overdue</TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab}>
          <Card className="border border-gray-100">
            <CardHeader>
              <CardTitle>Invoice List</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="py-8 text-center">Loading invoices...</div>
              ) : filteredInvoices && filteredInvoices.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="py-3 px-4 text-left">Invoice #</th>
                        <th className="py-3 px-4 text-left">Order #</th>
                        <th className="py-3 px-4 text-left">Customer</th>
                        <th className="py-3 px-4 text-left">Issue Date</th>
                        <th className="py-3 px-4 text-left">Due Date</th>
                        <th className="py-3 px-4 text-left">Amount</th>
                        <th className="py-3 px-4 text-left">Status</th>
                        <th className="py-3 px-4 text-left">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredInvoices.map((invoice: any) => (
                        <tr key={invoice.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">INV-{invoice.invoiceNumber}</td>
                          <td className="py-3 px-4">#{invoice.orderNumber}</td>
                          <td className="py-3 px-4">{invoice.customer.name}</td>
                          <td className="py-3 px-4">{new Date(invoice.issueDate).toLocaleDateString()}</td>
                          <td className="py-3 px-4">{new Date(invoice.dueDate).toLocaleDateString()}</td>
                          <td className="py-3 px-4 font-medium">${invoice.amount.toFixed(2)}</td>
                          <td className="py-3 px-4">
                            <Badge className={getStatusBadgeClass(invoice.status)}>
                              {invoice.status}
                            </Badge>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex space-x-2">
                              <Button variant="ghost" size="icon" title="Download">
                                <Download className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" title="Email">
                                <Mail className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" title="Print">
                                <Printer className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="py-8 text-center">
                  {searchTerm ? "No invoices found matching your search." : "No invoices found."}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        <Card className="border border-gray-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium flex items-center">
              <CalendarDays className="h-4 w-4 mr-2 text-primary-600" />
              Upcoming Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="py-4 text-center">Loading...</div>
            ) : (
              <div className="space-y-4">
                {invoices?.filter((i: any) => i.status === 'Due')
                  .slice(0, 3)
                  .map((invoice: any) => (
                    <div key={invoice.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">INV-{invoice.invoiceNumber}</p>
                        <p className="text-sm text-gray-500">{invoice.customer.name}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">${invoice.amount.toFixed(2)}</p>
                        <p className="text-sm text-gray-500">Due: {new Date(invoice.dueDate).toLocaleDateString()}</p>
                      </div>
                    </div>
                  ))}
                {invoices?.filter((i: any) => i.status === 'Due').length === 0 && (
                  <p className="py-2 text-center text-gray-500">No upcoming payments</p>
                )}
              </div>
            )}
            <Link href="/invoices?status=due">
              <a className="mt-4 text-primary-600 text-sm font-medium flex items-center hover:text-primary-800">
                View all upcoming payments
                <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </Link>
          </CardContent>
        </Card>
        
        <Card className="border border-gray-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium flex items-center">
              <DollarSign className="h-4 w-4 mr-2 text-green-600" />
              Recent Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="py-4 text-center">Loading...</div>
            ) : (
              <div className="space-y-4">
                {invoices?.filter((i: any) => i.status === 'Paid')
                  .slice(0, 3)
                  .map((invoice: any) => (
                    <div key={invoice.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">INV-{invoice.invoiceNumber}</p>
                        <p className="text-sm text-gray-500">{invoice.customer.name}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-green-600">${invoice.amount.toFixed(2)}</p>
                        <p className="text-sm text-gray-500">Paid: {new Date(invoice.paidDate).toLocaleDateString()}</p>
                      </div>
                    </div>
                  ))}
                {invoices?.filter((i: any) => i.status === 'Paid').length === 0 && (
                  <p className="py-2 text-center text-gray-500">No recent payments</p>
                )}
              </div>
            )}
            <Link href="/invoices?status=paid">
              <a className="mt-4 text-primary-600 text-sm font-medium flex items-center hover:text-primary-800">
                View all payments
                <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </Link>
          </CardContent>
        </Card>
        
        <Card className="border border-gray-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium flex items-center text-red-600">
              <FileText className="h-4 w-4 mr-2 text-red-600" />
              Overdue Invoices
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="py-4 text-center">Loading...</div>
            ) : (
              <div className="space-y-4">
                {invoices?.filter((i: any) => i.status === 'Overdue')
                  .slice(0, 3)
                  .map((invoice: any) => (
                    <div key={invoice.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">INV-{invoice.invoiceNumber}</p>
                        <p className="text-sm text-gray-500">{invoice.customer.name}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-red-600">${invoice.amount.toFixed(2)}</p>
                        <p className="text-sm text-red-500">
                          Overdue: {Math.floor((Date.now() - new Date(invoice.dueDate).getTime()) / (1000 * 60 * 60 * 24))} days
                        </p>
                      </div>
                    </div>
                  ))}
                {invoices?.filter((i: any) => i.status === 'Overdue').length === 0 && (
                  <p className="py-2 text-center text-gray-500">No overdue invoices</p>
                )}
              </div>
            )}
            <Link href="/invoices?status=overdue">
              <a className="mt-4 text-primary-600 text-sm font-medium flex items-center hover:text-primary-800">
                View all overdue invoices
                <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </Link>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
