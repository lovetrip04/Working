import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/ui/theme-provider";

export default function Settings() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-medium">Application Preferences</h3>
                <p className="text-sm text-muted-foreground">
                  Configure your application-wide preferences.
                </p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="text-sm font-medium">Language</p>
                <select className="w-full p-2 border rounded-md">
                  <option value="en">English</option>
                  <option value="es">Spanish</option>
                  <option value="fr">French</option>
                </select>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="text-sm font-medium">Time Zone</p>
                <select className="w-full p-2 border rounded-md">
                  <option value="utc">UTC</option>
                  <option value="est">Eastern Standard Time</option>
                  <option value="pst">Pacific Standard Time</option>
                </select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-medium">Theme Preferences</h3>
                <p className="text-sm text-muted-foreground">
                  Customize how the application looks.
                </p>
              </div>
              <div className="flex space-x-4">
                <Button
                  variant={theme === "light" ? "default" : "outline"}
                  onClick={() => setTheme("light")}
                >
                  Light Mode
                </Button>
                <Button
                  variant={theme === "dark" ? "default" : "outline"}
                  onClick={() => setTheme("dark")}
                >
                  Dark Mode
                </Button>
                <Button
                  variant={theme === "system" ? "default" : "outline"}
                  onClick={() => setTheme("system")}
                >
                  System
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-medium">Notification Preferences</h3>
                <p className="text-sm text-muted-foreground">
                  Configure how you receive notifications.
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="email-notifications" className="w-4 h-4" />
                <label htmlFor="email-notifications">Email Notifications</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="push-notifications" className="w-4 h-4" />
                <label htmlFor="push-notifications">Push Notifications</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="sound-alerts" className="w-4 h-4" />
                <label htmlFor="sound-alerts">Sound Alerts</label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-medium">Account Security</h3>
                <p className="text-sm text-muted-foreground">
                  Manage your account security preferences.
                </p>
              </div>
              <Button variant="default">Change Password</Button>
              <div className="pt-4">
                <div className="space-y-1">
                  <h3 className="font-medium">Two-Factor Authentication</h3>
                  <p className="text-sm text-muted-foreground">
                    Add an extra layer of security to your account.
                  </p>
                </div>
                <Button variant="outline" className="mt-2">
                  Enable Two-Factor Authentication
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}