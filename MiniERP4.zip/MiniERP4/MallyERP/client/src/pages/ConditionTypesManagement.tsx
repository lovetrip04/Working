import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Edit, Trash2, Copy, Calculator, DollarSign, Percent, Hash } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const conditionTypeSchema = z.object({
  condition_code: z.string().min(2).max(10).regex(/^[A-Z0-9]+$/, "Only uppercase letters and numbers"),
  condition_name: z.string().min(3).max(100),
  condition_category: z.enum(["Revenue", "Cost", "Discount", "Tax", "Surcharge", "Fee"]),
  calculation_type: z.enum(["percentage", "fixed_amount", "quantity_based", "tiered"]),
  description: z.string().optional(),
  default_value: z.number().optional(),
  min_value: z.number().optional(),
  max_value: z.number().optional(),
  sequence_number: z.number().min(1).max(99),
  is_mandatory: z.boolean().default(false),
  is_active: z.boolean().default(true)
});

type ConditionType = z.infer<typeof conditionTypeSchema> & {
  id?: number;
  company_code_id?: number;
  created_at?: string;
  updated_at?: string;
};

export default function ConditionTypesManagement() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCondition, setEditingCondition] = useState<ConditionType | null>(null);
  const [selectedCompany, setSelectedCompany] = useState<string>("DOM01");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ConditionType>({
    resolver: zodResolver(conditionTypeSchema),
    defaultValues: {
      condition_code: "",
      condition_name: "",
      condition_category: "Revenue",
      calculation_type: "percentage",
      description: "",
      default_value: 0,
      sequence_number: 1,
      is_mandatory: false,
      is_active: true
    }
  });

  // Fetch condition types
  const { data: conditionTypes, isLoading } = useQuery({
    queryKey: ['/api/condition-types', selectedCompany],
    enabled: !!selectedCompany
  });

  // Fetch companies
  const { data: companies } = useQuery({
    queryKey: ['/api/companies']
  });

  // Create/Update mutation
  const createMutation = useMutation({
    mutationFn: async (data: ConditionType) => {
      const url = editingCondition 
        ? `/api/condition-types/${editingCondition.id}`
        : '/api/condition-types';
      const method = editingCondition ? 'PUT' : 'POST';
      
      return apiRequest(url, {
        method,
        body: JSON.stringify({ ...data, company_code: selectedCompany })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/condition-types'] });
      setIsDialogOpen(false);
      setEditingCondition(null);
      form.reset();
      toast({
        title: "Success",
        description: `Condition type ${editingCondition ? 'updated' : 'created'} successfully`
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${editingCondition ? 'update' : 'create'} condition type`,
        variant: "destructive"
      });
    }
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/condition-types/${id}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/condition-types'] });
      toast({
        title: "Success",
        description: "Condition type deleted successfully"
      });
    }
  });

  const onSubmit = (data: ConditionType) => {
    createMutation.mutate(data);
  };

  const handleEdit = (condition: ConditionType) => {
    setEditingCondition(condition);
    form.reset(condition);
    setIsDialogOpen(true);
  };

  const handleCopy = (condition: ConditionType) => {
    const newCondition = {
      ...condition,
      condition_code: `${condition.condition_code}_COPY`,
      condition_name: `${condition.condition_name} (Copy)`
    };
    form.reset(newCondition);
    setEditingCondition(null);
    setIsDialogOpen(true);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Revenue': return <DollarSign className="h-4 w-4" />;
      case 'Cost': return <Calculator className="h-4 w-4" />;
      case 'Discount': return <Percent className="h-4 w-4" />;
      case 'Tax': return <Hash className="h-4 w-4" />;
      default: return <DollarSign className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Revenue': return 'bg-green-100 text-green-800';
      case 'Cost': return 'bg-red-100 text-red-800';
      case 'Discount': return 'bg-blue-100 text-blue-800';
      case 'Tax': return 'bg-purple-100 text-purple-800';
      case 'Surcharge': return 'bg-orange-100 text-orange-800';
      case 'Fee': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Condition Types Management</h1>
          <p className="text-muted-foreground">Configure pricing components for your business</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <Select value={selectedCompany} onValueChange={setSelectedCompany}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select Company" />
            </SelectTrigger>
            <SelectContent>
              {companies?.map((company: any) => (
                <SelectItem key={company.code} value={company.code}>
                  {company.code} - {company.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => {
                setEditingCondition(null);
                form.reset();
              }}>
                <Plus className="h-4 w-4 mr-2" />
                Add Condition Type
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingCondition ? 'Edit' : 'Create'} Condition Type
                </DialogTitle>
                <DialogDescription>
                  Define how pricing components are calculated in your business processes
                </DialogDescription>
              </DialogHeader>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="condition_code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Condition Code</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., PIZZA_BASE" {...field} />
                          </FormControl>
                          <FormDescription>
                            Unique code (uppercase letters/numbers only)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="sequence_number"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sequence</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormDescription>
                            Order of calculation (1-99)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="condition_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Condition Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Base Pizza Price" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="condition_category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Revenue">Revenue</SelectItem>
                              <SelectItem value="Cost">Cost</SelectItem>
                              <SelectItem value="Discount">Discount</SelectItem>
                              <SelectItem value="Tax">Tax</SelectItem>
                              <SelectItem value="Surcharge">Surcharge</SelectItem>
                              <SelectItem value="Fee">Fee</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="calculation_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Calculation Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="percentage">Percentage</SelectItem>
                              <SelectItem value="fixed_amount">Fixed Amount</SelectItem>
                              <SelectItem value="quantity_based">Quantity Based</SelectItem>
                              <SelectItem value="tiered">Tiered Pricing</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="default_value"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Default Value</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="min_value"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Min Value</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || undefined)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="max_value"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Max Value</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || undefined)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe how this condition type is used..."
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex items-center space-x-6">
                    <FormField
                      control={form.control}
                      name="is_mandatory"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel>Mandatory</FormLabel>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="is_active"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel>Active</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending}>
                      {editingCondition ? 'Update' : 'Create'}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="list" className="w-full">
        <TabsList>
          <TabsTrigger value="list">Condition Types</TabsTrigger>
          <TabsTrigger value="calculator">Pricing Calculator</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>Condition Types for {selectedCompany}</CardTitle>
              <CardDescription>
                Manage your pricing components and calculation rules
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div>Loading condition types...</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Seq</TableHead>
                      <TableHead>Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Default</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {conditionTypes?.map((condition: ConditionType) => (
                      <TableRow key={condition.id}>
                        <TableCell className="font-mono text-sm">
                          {condition.sequence_number}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {condition.condition_code}
                        </TableCell>
                        <TableCell>{condition.condition_name}</TableCell>
                        <TableCell>
                          <Badge 
                            variant="secondary" 
                            className={getCategoryColor(condition.condition_category)}
                          >
                            {getCategoryIcon(condition.condition_category)}
                            <span className="ml-1">{condition.condition_category}</span>
                          </Badge>
                        </TableCell>
                        <TableCell>{condition.calculation_type}</TableCell>
                        <TableCell>
                          {condition.default_value !== undefined ? 
                            (condition.calculation_type === 'percentage' ? 
                              `${condition.default_value}%` : 
                              `$${condition.default_value}`) : 
                            '-'
                          }
                        </TableCell>
                        <TableCell>
                          <Badge variant={condition.is_active ? "default" : "secondary"}>
                            {condition.is_active ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEdit(condition)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleCopy(condition)}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteMutation.mutate(condition.id!)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calculator">
          <Card>
            <CardHeader>
              <CardTitle>Pricing Calculator</CardTitle>
              <CardDescription>
                Test your condition types with sample calculations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center text-muted-foreground">
                Pricing calculator will be implemented here
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates">
          <Card>
            <CardHeader>
              <CardTitle>Business Templates</CardTitle>
              <CardDescription>
                Quick start templates for different business types
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="p-4">
                  <h3 className="font-semibold">Restaurant/Food Service</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Base price, toppings, delivery, tax, food cost
                  </p>
                  <Button size="sm" variant="outline">Apply Template</Button>
                </Card>
                <Card className="p-4">
                  <h3 className="font-semibold">Retail/E-commerce</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Product price, shipping, discounts, tax, COGS
                  </p>
                  <Button size="sm" variant="outline">Apply Template</Button>
                </Card>
                <Card className="p-4">
                  <h3 className="font-semibold">Manufacturing</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Material cost, labor, overhead, freight, margin
                  </p>
                  <Button size="sm" variant="outline">Apply Template</Button>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}