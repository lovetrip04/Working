import { X, Home, Database, ShoppingCart, Package, Factory, DollarSign, BarChart2, Users, Settings } from "lucide-react";
import { Link } from "wouter";

interface MobileSidebarProps {
  onClose: () => void;
}

export default function MobileSidebar({ onClose }: MobileSidebarProps) {
  return (
    <div className="flex flex-col h-full bg-gray-900 text-white p-4">
      <div className="flex justify-between items-center mb-6">
        <div className="text-xl font-bold">MallyERP</div>
        <button onClick={onClose} className="text-white">
          <X className="h-6 w-6" />
        </button>
      </div>
      
      <div className="flex flex-col space-y-1 mt-2">
        <Link href="/">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <Home className="h-5 w-5 mr-3" />
            Dashboard
          </div>
        </Link>
        
        <Link href="/master-data">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <Database className="h-5 w-5 mr-3" />
            Master Data
          </div>
        </Link>
        
        <Link href="/sales">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <ShoppingCart className="h-5 w-5 mr-3" />
            Sales
          </div>
        </Link>
        
        <Link href="/inventory">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <Package className="h-5 w-5 mr-3" />
            Inventory
          </div>
        </Link>
        
        <Link href="/purchase">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <ShoppingCart className="h-5 w-5 mr-3" />
            Purchase
          </div>
        </Link>
        
        <Link href="/production">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <Factory className="h-5 w-5 mr-3" />
            Production
          </div>
        </Link>
        
        <Link href="/finance">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <DollarSign className="h-5 w-5 mr-3" />
            Finance
          </div>
        </Link>
        
        <Link href="/reports">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <BarChart2 className="h-5 w-5 mr-3" />
            Reports
          </div>
        </Link>
      </div>
      
      <div className="mt-auto pt-6 border-t border-gray-800">
        <Link href="/settings">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <Settings className="h-5 w-5 mr-3" />
            Settings
          </div>
        </Link>
        
        <Link href="/help">
          <div className="flex items-center px-3 py-2 text-sm rounded-md hover:bg-gray-800">
            <Users className="h-5 w-5 mr-3" />
            Help
          </div>
        </Link>
      </div>
    </div>
  );
}