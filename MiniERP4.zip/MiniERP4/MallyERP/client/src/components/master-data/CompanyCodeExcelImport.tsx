import { useState } from 'react';
import * as XLSX from 'xlsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, CheckCircle2, UploadCloud, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

type ImportedCompanyCode = {
  code: string;
  name: string;
  description: string;
  currency: string;
  country: string;
  taxId: string;
  fiscalYear: string;
  address: string;
  city: string;
  state: string;
  postalCode: string;
  phone: string;
  email: string;
  website: string;
  logoUrl: string;
  isActive: boolean;
};

const CompanyCodeExcelImport = () => {
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [previewData, setPreviewData] = useState<ImportedCompanyCode[]>([]);
  const [importResult, setImportResult] = useState<{
    success: number;
    failed: number;
    errors: string[];
  } | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Excel file validation
  const isExcelFile = (file: File) => {
    return (
      file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      file.type === 'application/vnd.ms-excel' ||
      file.name.endsWith('.xlsx') ||
      file.name.endsWith('.xls')
    );
  };

  // Handle file selection
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportResult(null);
    
    if (!e.target.files || e.target.files.length === 0) {
      setFile(null);
      setPreviewData([]);
      return;
    }
    
    const selectedFile = e.target.files[0];
    
    if (!isExcelFile(selectedFile)) {
      toast({
        title: "Invalid file format",
        description: "Please upload an Excel file (.xlsx or .xls)",
        variant: "destructive"
      });
      e.target.value = '';
      return;
    }
    
    setFile(selectedFile);
    
    // Read file and generate preview
    try {
      const data = await readExcelFile(selectedFile);
      setPreviewData(data);
    } catch (error) {
      toast({
        title: "Error reading file",
        description: "The Excel file couldn't be processed. Please check its format.",
        variant: "destructive"
      });
      setFile(null);
      setPreviewData([]);
      e.target.value = '';
    }
  };

  // Read Excel file and convert to Company Code objects
  const readExcelFile = async (file: File): Promise<ImportedCompanyCode[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          
          // Get first sheet
          const sheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[sheetName];
          
          // Convert to JSON
          const jsonData = XLSX.utils.sheet_to_json(sheet);
          
          // Map to Company Code format and validate
          const companyCodeData = jsonData.map((row: any) => {
            const isActive = typeof row.isActive === 'boolean' 
              ? row.isActive
              : row.isActive === 'Yes' || row.isActive === 'TRUE' || row.isActive === '1' || row.isActive === 1 || row.isActive === 'true';
            
            return {
              code: String(row.code || row.Code || '').trim(),
              name: String(row.name || row.Name || '').trim(),
              description: String(row.description || row.Description || ''),
              currency: String(row.currency || row.Currency || 'USD').trim(),
              country: String(row.country || row.Country || 'United States').trim(),
              taxId: String(row.taxId || row.TaxId || row['Tax ID'] || ''),
              fiscalYear: String(row.fiscalYear || row.FiscalYear || row['Fiscal Year'] || 'Calendar Year (Jan-Dec)').trim(),
              address: String(row.address || row.Address || ''),
              city: String(row.city || row.City || ''),
              state: String(row.state || row.State || ''),
              postalCode: String(row.postalCode || row.PostalCode || row['Postal Code'] || ''),
              phone: String(row.phone || row.Phone || ''),
              email: String(row.email || row.Email || ''),
              website: String(row.website || row.Website || ''),
              logoUrl: String(row.logoUrl || row.LogoUrl || row['Logo URL'] || ''),
              isActive: isActive
            };
          }).filter(cc => cc.code && cc.name && cc.currency && cc.country && cc.fiscalYear); // Filter out incomplete rows
          
          resolve(companyCodeData);
        } catch (error) {
          reject(error);
        }
      };
      
      reader.onerror = (error) => reject(error);
      reader.readAsBinaryString(file);
    });
  };

  // Import Company Codes to the database
  const handleImport = async () => {
    if (!file || previewData.length === 0) return;
    
    setImporting(true);
    
    const results = {
      success: 0,
      failed: 0,
      errors: [] as string[]
    };
    
    // Process items in batches to avoid overwhelming the server
    for (const companyCode of previewData) {
      try {
        await apiRequest('/api/master-data/company-code', {
          method: 'POST',
          body: JSON.stringify(companyCode)
        });
        results.success++;
      } catch (error: any) {
        results.failed++;
        results.errors.push(`${companyCode.code}: ${error.message || 'Unknown error'}`);
      }
    }
    
    setImportResult(results);
    
    if (results.success > 0) {
      // Invalidate the cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/company-code'] });
      
      toast({
        title: "Import completed",
        description: `Successfully imported ${results.success} company codes${results.failed > 0 ? ` (${results.failed} failed)` : ''}`
      });
    } else {
      toast({
        title: "Import failed",
        description: "None of the company codes could be imported. Please check the errors.",
        variant: "destructive"
      });
    }
    
    setImporting(false);
  };

  // Reset the import form
  const resetImport = () => {
    setFile(null);
    setPreviewData([]);
    setImportResult(null);
  };

  // Download sample template
  const downloadTemplate = () => {
    const templateData = [
      {
        Code: 'US01',
        Name: 'ACME Corporation USA',
        Description: 'US operations of ACME Corp',
        Currency: 'USD',
        Country: 'United States',
        TaxId: '123-45-6789',
        FiscalYear: 'Calendar Year (Jan-Dec)',
        Address: '123 Main Street',
        City: 'Chicago',
        State: 'IL',
        PostalCode: '60601',
        Phone: '+1 312-555-1234',
        Email: 'info@acmecorp.us',
        Website: 'www.acmecorp.us',
        IsActive: true
      },
      {
        Code: 'EU01',
        Name: 'ACME Europe GmbH',
        Description: 'European division headquartered in Germany',
        Currency: 'EUR',
        Country: 'Germany',
        TaxId: 'DE123456789',
        FiscalYear: 'Calendar Year (Jan-Dec)',
        Address: 'Hauptstrasse 1',
        City: 'Munich',
        State: 'Bavaria',
        PostalCode: '80331',
        Phone: '+49 89 1234567',
        Email: 'info@acmecorp.eu',
        Website: 'www.acmecorp.eu',
        IsActive: true
      }
    ];
    
    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'CompanyCodes');
    
    // Generate and download the file
    XLSX.writeFile(workbook, 'CompanyCode_Template.xlsx');
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Import Company Codes from Excel</CardTitle>
          <CardDescription>
            Upload an Excel file containing company code data to bulk import them into the system.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Input 
                type="file" 
                accept=".xlsx,.xls" 
                onChange={handleFileChange} 
                disabled={importing}
                className="flex-1"
              />
              <Button 
                variant="outline" 
                onClick={downloadTemplate}
                disabled={importing}
              >
                Download Template
              </Button>
            </div>
            
            {previewData.length > 0 && (
              <div className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium">Preview: {previewData.length} Company Codes</h3>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={resetImport}
                    disabled={importing}
                  >
                    <X className="h-4 w-4 mr-1" />
                    Clear
                  </Button>
                </div>
                <div className="max-h-60 overflow-y-auto">
                  <table className="w-full border-collapse">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-2 text-sm">Code</th>
                        <th className="text-left p-2 text-sm">Name</th>
                        <th className="text-left p-2 text-sm">Currency</th>
                        <th className="text-left p-2 text-sm">Country</th>
                        <th className="text-left p-2 text-sm">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {previewData.slice(0, 5).map((companyCode, index) => (
                        <tr key={index} className="border-t">
                          <td className="p-2 text-sm">{companyCode.code}</td>
                          <td className="p-2 text-sm">{companyCode.name}</td>
                          <td className="p-2 text-sm">{companyCode.currency}</td>
                          <td className="p-2 text-sm">{companyCode.country}</td>
                          <td className="p-2 text-sm">{companyCode.isActive ? 'Active' : 'Inactive'}</td>
                        </tr>
                      ))}
                      {previewData.length > 5 && (
                        <tr className="border-t">
                          <td colSpan={5} className="p-2 text-sm text-center text-muted-foreground">
                            + {previewData.length - 5} more items
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            
            {importResult && (
              <Alert variant={importResult.failed > 0 ? "destructive" : "default"} className="mt-4">
                {importResult.failed > 0 ? <AlertCircle className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
                <AlertTitle>Import Complete</AlertTitle>
                <AlertDescription>
                  <p>Successfully imported {importResult.success} company codes.
                  {importResult.failed > 0 && ` Failed to import ${importResult.failed} company codes.`}</p>
                  
                  {importResult.errors.length > 0 && (
                    <div className="mt-2">
                      <p className="font-medium">Errors:</p>
                      <ul className="list-disc pl-5 text-sm space-y-1 mt-1">
                        {importResult.errors.slice(0, 5).map((error, i) => (
                          <li key={i}>{error}</li>
                        ))}
                        {importResult.errors.length > 5 && (
                          <li>...and {importResult.errors.length - 5} more errors</li>
                        )}
                      </ul>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={resetImport} disabled={importing || !file}>
            Cancel
          </Button>
          <Button
            onClick={handleImport}
            disabled={importing || previewData.length === 0}
          >
            {importing ? (
              <>
                <span className="animate-spin mr-2">⌛</span>
                Importing...
              </>
            ) : (
              <>
                <UploadCloud className="mr-2 h-4 w-4" />
                Import {previewData.length} Company Codes
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default CompanyCodeExcelImport;