import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, Download, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function ReceiptsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  
  // Sample data for goods receipts
  const receipts = [
    {
      id: 1,
      receipt_number: "GR-2025-1001",
      po_number: "PO-2025-1001",
      vendor_name: "Tech Supplies Inc.",
      receipt_date: new Date(2025, 0, 20).toISOString(),
      status: "Completed",
      delivery_note: "DN-45678"
    },
    {
      id: 2,
      receipt_number: "GR-2025-1002",
      po_number: "PO-2025-1002",
      vendor_name: "Global Manufacturing Ltd.",
      receipt_date: new Date(2025, 0, 22).toISOString(),
      status: "Partial",
      delivery_note: "DN-56789"
    },
    {
      id: 3,
      receipt_number: "GR-2025-1003",
      po_number: "PO-2025-1003",
      vendor_name: "Industrial Components Co.",
      receipt_date: new Date(2025, 0, 25).toISOString(),
      status: "Pending Inspection",
      delivery_note: "DN-67890"
    }
  ];

  const filteredReceipts = receipts.filter(receipt => 
    receipt.receipt_number.toLowerCase().includes(searchTerm.toLowerCase()) || 
    receipt.po_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    receipt.vendor_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    receipt.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return <Badge className="bg-green-500 text-white">Completed</Badge>;
      case 'partial':
        return <Badge className="bg-yellow-500 text-white">Partial</Badge>;
      case 'pending inspection':
        return <Badge className="bg-blue-500 text-white">Pending Inspection</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search goods receipts..." 
            className="pl-8 rounded-md border border-input bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              console.log('Filter receipts clicked');
              // Add filter functionality
            }}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              console.log('Export receipts clicked');
              // Add export functionality
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button 
            size="sm"
            onClick={() => {
              console.log('New receipt clicked');
              // Add new receipt functionality
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            New Receipt
          </Button>
        </div>
      </div>
      
      {/* Receipts Table */}
      <Card>
        <CardHeader>
          <CardTitle>Goods Receipts</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredReceipts.length > 0 ? (
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Receipt Number</TableHead>
                    <TableHead>PO Number</TableHead>
                    <TableHead>Vendor</TableHead>
                    <TableHead>Receipt Date</TableHead>
                    <TableHead>Delivery Note</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReceipts.map((receipt) => (
                    <TableRow key={receipt.id}>
                      <TableCell className="font-medium">{receipt.receipt_number}</TableCell>
                      <TableCell>{receipt.po_number}</TableCell>
                      <TableCell>{receipt.vendor_name}</TableCell>
                      <TableCell>{formatDate(receipt.receipt_date)}</TableCell>
                      <TableCell>{receipt.delivery_note}</TableCell>
                      <TableCell>{getStatusBadge(receipt.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No goods receipts match your search.' : 'No goods receipts found.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}