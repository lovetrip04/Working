import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, Download, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function JobsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [showNewJobForm, setShowNewJobForm] = useState(false);
  const [newJob, setNewJob] = useState({
    production_order: "",
    product_name: "",
    work_center: "",
    start_date: "",
    end_date: "",
    quantity: ""
  });
  
  // Sample data for production jobs
  const jobs = [
    {
      id: 1,
      job_number: "JOB-2025-1001",
      production_order: "PROD-2025-1001",
      product_name: "Smart Phone XS",
      work_center: "Assembly Line 1",
      start_date: new Date(2025, 0, 10).toISOString(),
      end_date: new Date(2025, 0, 12).toISOString(),
      status: "In Progress",
      quantity: 100
    },
    {
      id: 2,
      job_number: "JOB-2025-1002",
      production_order: "PROD-2025-1001",
      product_name: "Smart Phone XS",
      work_center: "Testing Station",
      start_date: new Date(2025, 0, 12).toISOString(),
      end_date: new Date(2025, 0, 14).toISOString(),
      status: "Scheduled",
      quantity: 100
    },
    {
      id: 3,
      job_number: "JOB-2025-1003",
      production_order: "PROD-2025-1002",
      product_name: "Wireless Earbuds Pro",
      work_center: "Assembly Line 2",
      start_date: new Date(2025, 0, 12).toISOString(),
      end_date: new Date(2025, 0, 14).toISOString(),
      status: "Completed",
      quantity: 250
    }
  ];

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.job_number.toLowerCase().includes(searchTerm.toLowerCase()) || 
      job.production_order.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.work_center.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.status.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || job.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesStatus;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'in progress':
        return <Badge className="bg-blue-500 text-white">In Progress</Badge>;
      case 'scheduled':
        return <Badge className="bg-yellow-500 text-white">Scheduled</Badge>;
      case 'completed':
        return <Badge className="bg-green-500 text-white">Completed</Badge>;
      case 'delayed':
        return <Badge variant="destructive">Delayed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search production jobs..." 
            className="pl-8 rounded-md border border-input bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant={showFilters ? "default" : "outline"}
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              const csvContent = filteredJobs.map(job => ({
                JobNumber: job.job_number,
                ProductionOrder: job.production_order,
                Product: job.product_name,
                WorkCenter: job.work_center,
                StartDate: formatDate(job.start_date),
                EndDate: formatDate(job.end_date),
                Quantity: job.quantity,
                Status: job.status
              }));
              
              const csvString = [
                Object.keys(csvContent[0]).join(','),
                ...csvContent.map(row => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'production-jobs.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Dialog open={showNewJobForm} onOpenChange={setShowNewJobForm}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                New Job
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Production Job</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="production_order">Production Order</Label>
                  <Input
                    id="production_order"
                    value={newJob.production_order}
                    onChange={(e) => setNewJob({...newJob, production_order: e.target.value})}
                    placeholder="Enter production order"
                  />
                </div>
                <div>
                  <Label htmlFor="product_name">Product Name</Label>
                  <Input
                    id="product_name"
                    value={newJob.product_name}
                    onChange={(e) => setNewJob({...newJob, product_name: e.target.value})}
                    placeholder="Enter product name"
                  />
                </div>
                <div>
                  <Label htmlFor="work_center">Work Center</Label>
                  <Input
                    id="work_center"
                    value={newJob.work_center}
                    onChange={(e) => setNewJob({...newJob, work_center: e.target.value})}
                    placeholder="Enter work center"
                  />
                </div>
                <div>
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={newJob.quantity}
                    onChange={(e) => setNewJob({...newJob, quantity: e.target.value})}
                    placeholder="Enter quantity"
                  />
                </div>
                <div>
                  <Label htmlFor="start_date">Start Date</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={newJob.start_date}
                    onChange={(e) => setNewJob({...newJob, start_date: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="end_date">End Date</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={newJob.end_date}
                    onChange={(e) => setNewJob({...newJob, end_date: e.target.value})}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowNewJobForm(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => {
                    console.log('Creating production job:', newJob);
                    setShowNewJobForm(false);
                    setNewJob({production_order: "", product_name: "", work_center: "", start_date: "", end_date: "", quantity: ""});
                  }}>
                    Create Job
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Filter Panel */}
      {showFilters && (
        <Card>
          <CardHeader>
            <CardTitle>Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="status-filter">Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="in progress">In Progress</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="delayed">Delayed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setStatusFilter("all");
                    setSearchTerm("");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Jobs Table */}
      <Card>
        <CardHeader>
          <CardTitle>Production Jobs</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredJobs.length > 0 ? (
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Job Number</TableHead>
                    <TableHead>Prod. Order</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead>Work Center</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>End Date</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredJobs.map((job) => (
                    <TableRow key={job.id}>
                      <TableCell className="font-medium">{job.job_number}</TableCell>
                      <TableCell>{job.production_order}</TableCell>
                      <TableCell>{job.product_name}</TableCell>
                      <TableCell>{job.work_center}</TableCell>
                      <TableCell>{formatDate(job.start_date)}</TableCell>
                      <TableCell>{formatDate(job.end_date)}</TableCell>
                      <TableCell>{job.quantity}</TableCell>
                      <TableCell>{getStatusBadge(job.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No production jobs match your search.' : 'No production jobs found.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}