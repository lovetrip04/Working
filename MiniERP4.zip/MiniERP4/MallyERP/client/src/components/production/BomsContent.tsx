import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, Download, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function BomsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [showNewBomForm, setShowNewBomForm] = useState(false);
  const [newBom, setNewBom] = useState({
    product_name: "",
    version: "",
    description: "",
    base_quantity: "",
    uom: ""
  });
  
  // Sample data for bill of materials
  const boms = [
    {
      id: 1,
      bom_number: "BOM-001",
      product_name: "Smart Phone XS",
      description: "Bill of materials for Smart Phone XS production",
      version: "1.0",
      effective_date: new Date(2025, 0, 1).toISOString(),
      status: "Active",
      components: 15
    },
    {
      id: 2,
      bom_number: "BOM-002",
      product_name: "Wireless Earbuds Pro",
      description: "Bill of materials for Wireless Earbuds Pro production",
      version: "1.0",
      effective_date: new Date(2025, 0, 1).toISOString(),
      status: "Active",
      components: 8
    },
    {
      id: 3,
      bom_number: "BOM-003",
      product_name: "Smart Watch Elite",
      description: "Bill of materials for Smart Watch Elite production",
      version: "1.0",
      effective_date: new Date(2025, 0, 1).toISOString(),
      status: "Active",
      components: 12
    },
    {
      id: 4,
      bom_number: "BOM-004",
      product_name: "Smart Home Hub",
      description: "Bill of materials for Smart Home Hub production",
      version: "2.1",
      effective_date: new Date(2025, 1, 1).toISOString(),
      status: "Draft",
      components: 10
    }
  ];

  const filteredBoms = boms.filter(bom => {
    const matchesSearch = bom.bom_number.toLowerCase().includes(searchTerm.toLowerCase()) || 
      bom.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bom.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bom.status.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || bom.status.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesStatus;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return <Badge className="bg-green-500 text-white">Active</Badge>;
      case 'draft':
        return <Badge className="bg-yellow-500 text-white">Draft</Badge>;
      case 'obsolete':
        return <Badge variant="outline">Obsolete</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search bill of materials..." 
            className="pl-8 rounded-md border border-input bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant={showFilters ? "default" : "outline"}
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              const csvContent = filteredBoms.map(bom => ({
                BOMNumber: bom.bom_number,
                Product: bom.product_name,
                Version: bom.version,
                Description: bom.description,
                Status: bom.status,
                Components: bom.components,
                EffectiveDate: formatDate(bom.effective_date)
              }));
              
              const csvString = [
                Object.keys(csvContent[0]).join(','),
                ...csvContent.map(row => Object.values(row).join(','))
              ].join('\n');
              
              const blob = new Blob([csvString], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'bill-of-materials.csv';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Dialog open={showNewBomForm} onOpenChange={setShowNewBomForm}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                New BOM
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Bill of Materials</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="product_name">Product Name</Label>
                  <Input
                    id="product_name"
                    value={newBom.product_name}
                    onChange={(e) => setNewBom({...newBom, product_name: e.target.value})}
                    placeholder="Enter product name"
                  />
                </div>
                <div>
                  <Label htmlFor="version">Version</Label>
                  <Input
                    id="version"
                    value={newBom.version}
                    onChange={(e) => setNewBom({...newBom, version: e.target.value})}
                    placeholder="Enter BOM version"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={newBom.description}
                    onChange={(e) => setNewBom({...newBom, description: e.target.value})}
                    placeholder="Enter BOM description"
                  />
                </div>
                <div>
                  <Label htmlFor="base_quantity">Base Quantity</Label>
                  <Input
                    id="base_quantity"
                    type="number"
                    value={newBom.base_quantity}
                    onChange={(e) => setNewBom({...newBom, base_quantity: e.target.value})}
                    placeholder="Enter base quantity"
                  />
                </div>
                <div>
                  <Label htmlFor="uom">Unit of Measure</Label>
                  <Input
                    id="uom"
                    value={newBom.uom}
                    onChange={(e) => setNewBom({...newBom, uom: e.target.value})}
                    placeholder="Enter unit of measure"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowNewBomForm(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => {
                    console.log('Creating BOM:', newBom);
                    setShowNewBomForm(false);
                    setNewBom({product_name: "", version: "", description: "", base_quantity: "", uom: ""});
                  }}>
                    Create BOM
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Filter Panel */}
      {showFilters && (
        <Card>
          <CardHeader>
            <CardTitle>Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="status-filter">Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="obsolete">Obsolete</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setStatusFilter("all");
                    setSearchTerm("");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* BOMs Table */}
      <Card>
        <CardHeader>
          <CardTitle>Bill of Materials</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredBoms.length > 0 ? (
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>BOM Number</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Version</TableHead>
                    <TableHead>Effective Date</TableHead>
                    <TableHead>Components</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBoms.map((bom) => (
                    <TableRow key={bom.id}>
                      <TableCell className="font-medium">{bom.bom_number}</TableCell>
                      <TableCell>{bom.product_name}</TableCell>
                      <TableCell>{bom.description}</TableCell>
                      <TableCell>{bom.version}</TableCell>
                      <TableCell>{formatDate(bom.effective_date)}</TableCell>
                      <TableCell>{bom.components}</TableCell>
                      <TableCell>{getStatusBadge(bom.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No bill of materials match your search.' : 'No bill of materials found.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}