import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Download, Filter } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface StockLevel {
  id: number;
  name: string;
  sku: string;
  current_stock: number;
  min_stock: number;
  max_stock: number;
  category_name: string;
  storage_location_name: string;
  plant_name: string;
}

export default function StockLevelsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: stockLevels, isLoading, isError } = useQuery<StockLevel[]>({
    queryKey: ['/api/inventory/stock-levels'],
  });

  const filteredStockLevels = stockLevels?.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.storage_location_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Prepare data for chart
  const chartData = filteredStockLevels?.map(item => ({
    name: item.name.length > 15 ? item.name.substring(0, 15) + '...' : item.name,
    currentStock: item.current_stock,
    minStock: item.min_stock,
    maxStock: item.max_stock
  })).slice(0, 10);

  return (
    <div className="space-y-6">
      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Stock Level</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stockLevels ? 
                `${Math.round(stockLevels.reduce((sum, item) => sum + item.current_stock, 0) / stockLevels.length)}` 
                : "Loading..."}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stockLevels ? 
                stockLevels.filter(item => item.current_stock < item.min_stock).length
                : "Loading..."}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overstocked Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stockLevels ? 
                stockLevels.filter(item => item.current_stock > item.max_stock).length
                : "Loading..."}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart Card */}
      <Card>
        <CardHeader>
          <CardTitle>Stock Level Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            {chartData && chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={70} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="currentStock" name="Current Stock" fill="#3b82f6" />
                  <Bar dataKey="minStock" name="Min Stock" fill="#ef4444" />
                  <Bar dataKey="maxStock" name="Max Stock" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full">
                {isLoading ? "Loading chart data..." : "No data available for chart"}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Stock Levels Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Stock Levels</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search stock items..." 
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  console.log('Filter stock levels clicked');
                  // Add filter functionality
                }}
              >
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  console.log('Export stock levels clicked');
                  // Add export functionality
                }}
              >
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading stock levels...</div>
          ) : isError ? (
            <div className="text-center py-4 text-red-500">Error loading stock data. Please try again.</div>
          ) : filteredStockLevels && filteredStockLevels.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>SKU</TableHead>
                  <TableHead>Product Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead className="text-right">Current Stock</TableHead>
                  <TableHead className="text-right">Min Stock</TableHead>
                  <TableHead className="text-right">Max Stock</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStockLevels.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.sku}</TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>{item.category_name || 'Uncategorized'}</TableCell>
                    <TableCell>{item.storage_location_name || 'Default'}</TableCell>
                    <TableCell className="text-right">{item.current_stock}</TableCell>
                    <TableCell className="text-right">{item.min_stock}</TableCell>
                    <TableCell className="text-right">{item.max_stock}</TableCell>
                    <TableCell>
                      {item.current_stock < item.min_stock ? (
                        <Badge variant="destructive">Low Stock</Badge>
                      ) : item.current_stock > item.max_stock ? (
                        <Badge variant="outline" className="bg-amber-500 text-white">Overstock</Badge>
                      ) : (
                        <Badge variant="outline" className="bg-green-500 text-white">Normal</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-4">
              {searchTerm ? 'No items match your search.' : 'No stock data available.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}