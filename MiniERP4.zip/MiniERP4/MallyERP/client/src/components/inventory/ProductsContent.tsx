import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Filter, Plus, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import CreateProductDialog from "./CreateProductDialog";

interface Product {
  id: number;
  name: string;
  sku: string;
  description: string;
  price: string;
  current_stock: number;
  min_stock: number;
  max_stock: number;
  category_name: string;
  unit_of_measure_id: number;
}

export default function ProductsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [stockFilter, setStockFilter] = useState("all");
  const [showNewProductForm, setShowNewProductForm] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: "",
    sku: "",
    category: "",
    price: "",
    stock_quantity: ""
  });
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  
  const { data: products, isLoading, isError } = useQuery<Product[]>({
    queryKey: ['/api/inventory/products'],
  });

  const filteredProducts = products?.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category_name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === "all" || product.category_name?.toLowerCase() === categoryFilter.toLowerCase();
    
    const matchesStock = stockFilter === "all" || 
      (stockFilter === "low" && product.current_stock <= product.min_stock) ||
      (stockFilter === "out" && product.current_stock === 0) ||
      (stockFilter === "in" && product.current_stock > 0);
    
    return matchesSearch && matchesCategory && matchesStock;
  });

  return (
    <>
      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search products..." 
            className="pl-8 rounded-md border border-input bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="electronics">Electronics</SelectItem>
              <SelectItem value="tools">Tools</SelectItem>
              <SelectItem value="components">Components</SelectItem>
              <SelectItem value="accessories">Accessories</SelectItem>
            </SelectContent>
          </Select>
          <Select value={stockFilter} onValueChange={setStockFilter}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Stock" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Stock</SelectItem>
              <SelectItem value="in">In Stock</SelectItem>
              <SelectItem value="low">Low Stock</SelectItem>
              <SelectItem value="out">Out of Stock</SelectItem>
            </SelectContent>
          </Select>
          <Button size="sm" onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Product
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="text-center py-8">Loading products...</div>
      ) : isError ? (
        <div className="text-center py-8 text-red-500">Error loading products. Please try again.</div>
      ) : filteredProducts && filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {filteredProducts.map(product => (
            <ProductCard 
              key={product.id}
              name={product.name}
              sku={product.sku}
              price={`$${parseFloat(product.price).toFixed(2)}`}
              stock={product.current_stock}
              minStock={product.min_stock}
              category={product.category_name || 'Uncategorized'}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          {searchTerm ? 'No products match your search.' : 'No products found. Add your first product!'}
        </div>
      )}

      <CreateProductDialog 
        isOpen={isCreateDialogOpen} 
        onClose={() => setIsCreateDialogOpen(false)} 
      />
    </>
  );
}

type ProductCardProps = {
  name: string;
  sku: string;
  price: string;
  stock: number;
  minStock: number;
  category: string;
};

function ProductCard({ name, sku, price, stock, minStock, category }: ProductCardProps) {
  const isLowStock = stock < minStock;
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="p-4 bg-gray-50 border-b">
        <div className="flex justify-between items-center">
          <div className="text-base font-medium">{name}</div>
          {isLowStock && (
            <Badge variant="destructive" className="rounded-sm text-xs">
              Low Stock
            </Badge>
          )}
        </div>
      </div>
      <CardContent className="p-4 space-y-2">
        <div className="text-sm">
          <div className="flex justify-between mb-1">
            <span className="text-muted-foreground">SKU:</span>
            <span className="font-medium">{sku}</span>
          </div>
          <div className="flex justify-between mb-1">
            <span className="text-muted-foreground">Price:</span>
            <span className="font-medium">{price}</span>
          </div>
          <div className="flex justify-between mb-1">
            <span className="text-muted-foreground">Stock:</span>
            <span className={`font-medium ${isLowStock ? 'text-red-500' : ''}`}>
              {stock}/{minStock}
            </span>
          </div>
          <div className="mt-2">
            <Badge variant="outline" className="rounded-sm text-xs">
              {category}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}