import React, { useState, useEffect, useRef } from 'react';
import { Bot, Send, X, Minimize2, Maximize2, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLocation } from 'wouter';
import { useAgentRole } from '@/contexts/AgentRoleContext';

interface Message {
  id: string;
  type: 'user' | 'jr' | 'system' | 'action';
  content: string;
  timestamp: Date;
  agentContext?: string;
  actionData?: {
    type: 'navigate' | 'show_tile';
    target: string;
    url?: string;
  };
}

interface AgentContext {
  currentModule: string;
  availableAgents: string[];
  primaryAgent: string;
  supportLevel: 'rookie' | 'player' | 'coach' | 'chief';
}

export const JrChatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [agentContext, setAgentContext] = useState<AgentContext | null>(null);
  const [location] = useLocation();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { currentRole, roleConfig } = useAgentRole();

  // Determine current business domain based on route - Uses current agent role
  useEffect(() => {
    const getContextFromRoute = (path: string): AgentContext => {
      const agentDisplayName = `Jr. (${roleConfig.name})`;
      if (path.includes('/finance')) {
        return {
          currentModule: 'Finance Domain',
          availableAgents: [agentDisplayName],
          primaryAgent: agentDisplayName,
          supportLevel: currentRole
        };
      } else if (path.includes('/sales')) {
        return {
          currentModule: 'Sales Domain',
          availableAgents: [agentDisplayName],
          primaryAgent: agentDisplayName,
          supportLevel: currentRole
        };
      } else if (path.includes('/inventory')) {
        return {
          currentModule: 'Inventory Domain',
          availableAgents: [agentDisplayName],
          primaryAgent: agentDisplayName,
          supportLevel: currentRole
        };
      } else if (path.includes('/hr')) {
        return {
          currentModule: 'HR Domain',
          availableAgents: [agentDisplayName],
          primaryAgent: agentDisplayName,
          supportLevel: currentRole
        };
      } else if (path.includes('/production')) {
        return {
          currentModule: 'Production Domain',
          availableAgents: [agentDisplayName],
          primaryAgent: agentDisplayName,
          supportLevel: currentRole
        };
      } else if (path.includes('/purchasing')) {
        return {
          currentModule: 'Purchasing Domain',
          availableAgents: [agentDisplayName],
          primaryAgent: agentDisplayName,
          supportLevel: currentRole
        };
      } else if (path.includes('/chief-agent') || path.includes('/coach-agent') || path.includes('/rookie-agent') || path.includes('/agent-player')) {
        return {
          currentModule: 'Agent Management',
          availableAgents: [agentDisplayName],
          primaryAgent: agentDisplayName,
          supportLevel: currentRole
        };
      } else {
        return {
          currentModule: 'General Business Support',
          availableAgents: [agentDisplayName],
          primaryAgent: agentDisplayName,
          supportLevel: currentRole
        };
      }
    };

    setAgentContext(getContextFromRoute(location));
  }, [location, currentRole, roleConfig]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initialize with business domain welcome message when opened
  useEffect(() => {
    if (isOpen && messages.length === 0 && agentContext) {
      const getDomainSpecificWelcome = () => {
        const domain = agentContext.currentModule;
        
        if (domain.includes('Finance')) {
          return `Hi! I'm Jr., your business assistant for ${domain}. As a ${roleConfig.name}, I can help you with:

• GL Account data entry and validation
• Invoice processing guidance
• Financial posting procedures
• Chart of accounts navigation
• Basic financial reporting questions

I'm here to learn with you and provide step-by-step guidance!`;
        } else if (domain.includes('Sales')) {
          return `Hi! I'm Jr., your business assistant for ${domain}. As a ${roleConfig.name}, I can help you with:

• Customer master data creation
• Sales order entry guidance
• Pricing and discount validation
• Lead and opportunity management
• Basic sales reporting

I'm learning alongside you - let's tackle your sales tasks together!`;
        } else if (domain.includes('Inventory')) {
          return `Hi! I'm Jr., your business assistant for ${domain}. As a ${roleConfig.name}, I can help you with:

• Material master data entry
• Stock movement procedures
• Warehouse location guidance
• Inventory counting support
• Basic inventory reports

I'm here to guide you through inventory processes step by step!`;
        } else if (domain.includes('HR')) {
          return `Hi! I'm Jr., your business assistant for ${domain}. As a ${roleConfig.name}, I can help you with:

• Employee data entry and validation
• Payroll processing guidance
• Time recording procedures
• Benefits administration basics
• HR reporting assistance

Let me help you navigate HR processes with confidence!`;
        } else if (domain.includes('Production')) {
          return `Hi! I'm Jr., your business assistant for ${domain}. As a ${roleConfig.name}, I can help you with:

• Work order creation and tracking
• Bill of materials guidance
• Production scheduling basics
• Quality control procedures
• Manufacturing reports

I'm here to support your production activities!`;
        } else if (domain.includes('Purchasing')) {
          return `Hi! I'm Jr., your business assistant for ${domain}. As a ${roleConfig.name}, I can help you with:

• Purchase requisition creation
• Vendor master data entry
• Purchase order processing
• Goods receipt procedures
• Basic procurement reports

Let's work through your purchasing tasks together!`;
        } else {
          return `Hi! I'm Jr., your business assistant. As a ${roleConfig.name}, I can help you with:

• Data entry validation and guidance
• Basic business process questions
• Screen navigation assistance
• Field-level help and suggestions
• Learning business procedures

How can I assist you today?`;
        }
      };

      const welcomeMessage: Message = {
        id: `welcome-${Date.now()}`,
        type: 'jr',
        content: getDomainSpecificWelcome(),
        timestamp: new Date(),
        agentContext: agentContext.primaryAgent
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen, agentContext]);

  // Tile mapping for navigation
  const availableTiles: Record<string, string> = {
    'document number': '/transactions/document-number-ranges',
    'document posting': '/transactions/document-posting-system',
    'automatic clearing': '/transactions/automatic-clearing',
    'asset accounting': '/transactions/asset-accounting',
    'bank statement': '/transactions/bank-statement-processing',
    'sales order': '/sales/sales-order',
    'invoice': '/transactions/invoice',
    'gl account': '/finance',
    'customer master': '/sales',
    'material master': '/inventory',
    'vendor master': '/purchase',
    'cost center': '/controlling',
    'profit center': '/controlling',
    'work order': '/production',
    'purchase order': '/purchase',
    'purchasing': '/purchase',
    'stock movement': '/inventory/stock-movement',
    'employee master': '/hr',
    'payroll': '/hr'
  };

  const findTileMatch = (input: string): { route: string; name: string } | null => {
    const inputLower = input.toLowerCase();
    for (const [tileName, route] of Object.entries(availableTiles)) {
      if (inputLower.includes(tileName)) {
        return { route, name: tileName };
      }
    }
    return null;
  };

  const getAgentResponse = async (userMessage: string): Promise<string> => {
    if (!agentContext) return "I'm still learning about this business domain. Please try again in a moment.";

    const domain = agentContext.currentModule;
    const userInput = userMessage.toLowerCase();

    // PRIORITY 1: Handle domain-specific data requests FIRST (before showing tiles)
    // Use domain intelligence service for comprehensive business area coverage
    
    const domainKeywords = [
      'condition', 'customer', 'sales order', 'quote', 'product', 'stock', 'inventory',
      'account', 'gl', 'ledger', 'company code', 'plant', 'vendor', 'material',
      'work order', 'production', 'bom', 'bill of materials', 'purchase order',
      'purchasing', 'requisition', 'employee', 'payroll', 'hr', 'cost center',
      'profit center', 'controlling'
    ];
    
    const actionKeywords = ['show', 'list', 'bring', 'display', 'open', 'navigate'];
    
    const hasDomainKeyword = domainKeywords.some(keyword => userInput.includes(keyword));
    const hasActionKeyword = actionKeywords.some(keyword => userInput.includes(keyword));
    
    if (hasDomainKeyword && hasActionKeyword) {
      try {
        const response = await fetch('/api/jr/domain/analyze-request', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            message: userInput, 
            current_domain: agentContext.currentModule 
          })
        });
        const data = await response.json();
        
        if (data.success) {
          setTimeout(() => {
            window.location.href = data.navigation_url;
          }, 1000);
          
          return `${data.data_summary}\n\nAvailable actions:\n${data.quick_actions.map((action: string) => `• ${action}`).join('\n')}\n\nOpening management screen now...`;
        }
      } catch (error) {
        console.error('Domain intelligence error:', error);
      }
    }

    // Sales Domain Requests
    if ((userInput.includes('customer') || userInput.includes('sales order') || userInput.includes('quote')) && 
        (userInput.includes('show') || userInput.includes('list') || userInput.includes('bring'))) {
      setTimeout(() => {
        if (userInput.includes('customer')) {
          window.location.href = '/sales/customers';
        } else if (userInput.includes('order')) {
          window.location.href = '/sales/orders';
        } else if (userInput.includes('quote')) {
          window.location.href = '/sales/quotes';
        }
      }, 1000);
      
      return `Accessing sales data now...\n\nNavigating to the appropriate sales management screen...`;
    }

    // Inventory Domain Requests  
    if ((userInput.includes('product') || userInput.includes('stock') || userInput.includes('inventory')) && 
        (userInput.includes('show') || userInput.includes('list') || userInput.includes('bring'))) {
      setTimeout(() => {
        if (userInput.includes('product')) {
          window.location.href = '/inventory/products';
        } else if (userInput.includes('stock')) {
          window.location.href = '/inventory/stock';
        } else {
          window.location.href = '/inventory';
        }
      }, 1000);
      
      return `Accessing inventory data now...\n\nNavigating to the inventory management screen...`;
    }

    // Finance Domain Requests
    if ((userInput.includes('account') || userInput.includes('gl') || userInput.includes('ledger')) && 
        (userInput.includes('show') || userInput.includes('list') || userInput.includes('bring'))) {
      setTimeout(() => {
        window.location.href = '/finance';
      }, 1000);
      
      return `Accessing financial accounts now...\n\nNavigating to the finance management screen...`;
    }

    // Master Data Domain Requests
    if ((userInput.includes('company code') || userInput.includes('plant') || userInput.includes('vendor') || 
         userInput.includes('chart of accounts') || userInput.includes('material')) && 
        (userInput.includes('show') || userInput.includes('list') || userInput.includes('bring'))) {
      setTimeout(() => {
        if (userInput.includes('company')) {
          window.location.href = '/master-data/company-code';
        } else if (userInput.includes('plant')) {
          window.location.href = '/master-data/plant';
        } else if (userInput.includes('vendor')) {
          window.location.href = '/master-data/vendor';
        } else if (userInput.includes('chart')) {
          window.location.href = '/master-data/chart-of-accounts';
        } else if (userInput.includes('material')) {
          window.location.href = '/master-data/material';
        }
      }, 1000);
      
      return `Accessing master data now...\n\nNavigating to the master data management screen...`;
    }

    // Production Domain Requests
    if ((userInput.includes('work order') || userInput.includes('production') || userInput.includes('bom') || 
         userInput.includes('bill of materials')) && 
        (userInput.includes('show') || userInput.includes('list') || userInput.includes('bring'))) {
      setTimeout(() => {
        if (userInput.includes('work order')) {
          window.location.href = '/production';
        } else if (userInput.includes('bom') || userInput.includes('bill of materials')) {
          window.location.href = '/master-data/bill-of-materials';
        } else {
          window.location.href = '/production';
        }
      }, 1000);
      
      return `Accessing production data now...\n\nNavigating to the production management screen...`;
    }

    // Purchase Domain Requests
    if ((userInput.includes('purchase order') || userInput.includes('purchasing') || userInput.includes('requisition')) && 
        (userInput.includes('show') || userInput.includes('list') || userInput.includes('bring'))) {
      setTimeout(() => {
        if (userInput.includes('order')) {
          window.location.href = '/purchase';
        } else if (userInput.includes('requisition')) {
          window.location.href = '/transactions/purchase-requisition';
        } else {
          window.location.href = '/purchase';
        }
      }, 1000);
      
      return `Accessing purchasing data now...\n\nNavigating to the purchasing management screen...`;
    }

    // HR Domain Requests
    if ((userInput.includes('employee') || userInput.includes('payroll') || userInput.includes('hr')) && 
        (userInput.includes('show') || userInput.includes('list') || userInput.includes('bring'))) {
      setTimeout(() => {
        if (userInput.includes('employee')) {
          window.location.href = '/master-data/employees';
        } else if (userInput.includes('payroll')) {
          window.location.href = '/transactions/payroll-processing';
        } else {
          window.location.href = '/hr';
        }
      }, 1000);
      
      return `Accessing HR data now...\n\nNavigating to the HR management screen...`;
    }

    // Controlling Domain Requests
    if ((userInput.includes('cost center') || userInput.includes('profit center') || userInput.includes('controlling')) && 
        (userInput.includes('show') || userInput.includes('list') || userInput.includes('bring'))) {
      setTimeout(() => {
        if (userInput.includes('cost center')) {
          window.location.href = '/master-data/cost-centers';
        } else if (userInput.includes('profit center')) {
          window.location.href = '/master-data/profit-centers';
        } else {
          window.location.href = '/controlling';
        }
      }, 1000);
      
      return `Accessing controlling data now...\n\nNavigating to the controlling management screen...`;
    }

    // Check for tile navigation requests
    if (userInput.includes('show') || userInput.includes('open') || userInput.includes('go to') || userInput.includes('navigate')) {
      const tileMatch = findTileMatch(userInput);
      if (tileMatch) {
        // Create action message after a delay
        setTimeout(() => {
          const actionMessage: Message = {
            id: `action-${Date.now()}`,
            type: 'action',
            content: `Opening ${tileMatch.name} tile for you...`,
            timestamp: new Date(),
            agentContext: agentContext.primaryAgent,
            actionData: {
              type: 'show_tile',
              target: tileMatch.name,
              url: tileMatch.route
            }
          };
          setMessages(prev => [...prev, actionMessage]);
          
          // Navigate to the tile after showing the action
          setTimeout(() => {
            window.location.href = tileMatch.route;
          }, 1000);
        }, 1000);

        return `I found the "${tileMatch.name}" tile! Let me open it for you. This tile will help you with:\n\n• Business process management\n• Data entry and validation\n• Configuration settings\n• Reporting and analysis\n\nNavigating now...`;
      } else {
        // Create tile selection message with buttons
        setTimeout(() => {
          const tileSelectionMessage: Message = {
            id: `tiles-${Date.now()}`,
            type: 'action',
            content: `Here are the available tiles you can access. Click any tile to navigate directly:`,
            timestamp: new Date(),
            agentContext: agentContext.primaryAgent,
            actionData: {
              type: 'show_tile',
              target: 'tile-selection',
              url: ''
            }
          };
          setMessages(prev => [...prev, tileSelectionMessage]);
        }, 500);

        return `I can help you navigate to business tiles! Let me show you all available options with clickable buttons...`;
      }
    }

    // Business domain-specific responses for common tasks
    if (domain.includes('Finance')) {
      if (userInput.includes('gl account') || userInput.includes('account')) {
        return "For GL Account setup, I can help you with:\n\n• Account number format (usually 6 digits)\n• Account description requirements\n• Account type selection (Asset, Liability, Equity, Revenue, Expense)\n• Cost center assignments\n\nWhat specific GL account task are you working on?";
      }
      if (userInput.includes('invoice') || userInput.includes('posting')) {
        return "For invoice processing, let me guide you through:\n\n• Vendor invoice verification\n• Three-way matching (PO, Receipt, Invoice)\n• Posting key selection\n• Tax code validation\n• Payment terms checking\n\nWhich step needs assistance?";
      }
      if (userInput.includes('error') || userInput.includes('problem')) {
        return "I see you're having a financial posting issue. Common problems I can help with:\n\n• Balance validation errors\n• Missing cost center assignments\n• Incorrect account combinations\n• Period closing restrictions\n\nWhat error message are you seeing?";
      }
    }

    if (domain.includes('Sales')) {
      if (userInput.includes('customer') || userInput.includes('master')) {
        return "For Customer Master creation, I'll help you with:\n\n• Customer number assignment\n• Required address fields\n• Credit limit setup\n• Payment terms selection\n• Sales organization assignment\n\nWhat customer data are you entering?";
      }
      if (userInput.includes('order') || userInput.includes('sales order')) {
        return "For Sales Order entry, here's what I can assist with:\n\n• Customer selection and validation\n• Material availability checking\n• Pricing and discount application\n• Delivery date calculation\n• Credit limit verification\n\nWhich part of the order needs help?";
      }
      if (userInput.includes('pricing') || userInput.includes('discount')) {
        return "For pricing validation, I can help check:\n\n• Base price accuracy\n• Discount eligibility rules\n• Volume pricing tiers\n• Customer-specific agreements\n• Tax calculations\n\nWhat pricing issue are you facing?";
      }
    }

    if (domain.includes('Inventory')) {
      if (userInput.includes('material') || userInput.includes('stock')) {
        return "For Material Master and stock management:\n\n• Material number assignment\n• Unit of measure setup\n• Storage location details\n• Procurement type selection\n• Inventory tracking methods\n\nWhat material data needs attention?";
      }
      if (userInput.includes('movement') || userInput.includes('receipt')) {
        return "For stock movements, I can guide you through:\n\n• Movement type selection\n• Quantity validation\n• Storage location verification\n• Batch number tracking\n• Document reference requirements\n\nWhich movement are you processing?";
      }
    }

    if (domain.includes('HR')) {
      if (userInput.includes('employee') || userInput.includes('personnel')) {
        return "For Employee data entry:\n\n• Personnel number assignment\n• Required personal information\n• Organizational assignment\n• Position and job classification\n• Benefits enrollment basics\n\nWhat employee information do you need help with?";
      }
      if (userInput.includes('payroll') || userInput.includes('time')) {
        return "For payroll and time recording:\n\n• Time entry validation\n• Overtime calculations\n• Leave balance checking\n• Pay scale assignments\n• Deduction processing\n\nWhich payroll task needs assistance?";
      }
    }

    // General rookie-level responses
    if (userInput.includes('error') || userInput.includes('problem')) {
      return `I'm here to help troubleshoot ${domain} issues! As a ${roleConfig.name}, I can:\n\n• Guide you through basic validation checks\n• Explain required field rules\n• Help identify common data entry mistakes\n• Suggest when to escalate to senior agents\n\nWhat specific error are you encountering?`;
    }

    if (userInput.includes('how to') || userInput.includes('help')) {
      return `I'd love to help you learn ${domain} processes! I can provide:\n\n• Step-by-step guidance for data entry\n• Field-level explanations\n• Business rule clarifications\n• Best practice suggestions\n• Validation check assistance\n\nWhat task would you like to learn?`;
    }

    if (userInput.includes('validation') || userInput.includes('required')) {
      return `For ${domain} data validation, I can help with:\n\n• Required field identification\n• Format checking (dates, numbers, codes)\n• Business rule verification\n• Cross-field validation\n• Quality control checks\n\nWhich fields need validation assistance?`;
    }

    return `I'm Jr., your ${roleConfig.name} assistant for ${domain}. I specialize in:\n\n• Data entry guidance\n• Basic business process support\n• Field validation help\n• Learning together with users\n\nCould you tell me more about what you're trying to accomplish? I'll provide step-by-step guidance!`;
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      type: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate typing delay
    setTimeout(async () => {
      const response = await getAgentResponse(userMessage.content);
      const jrMessage: Message = {
        id: `jr-${Date.now()}`,
        type: 'jr',
        content: response,
        timestamp: new Date(),
        agentContext: agentContext?.primaryAgent
      };
      setMessages(prev => [...prev, jrMessage]);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getAgentColor = (level: string) => {
    switch (level) {
      case 'chief': return 'bg-red-500';
      case 'coach': return 'bg-blue-500';
      case 'player': return 'bg-green-500';
      case 'rookie': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="h-14 w-14 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 shadow-lg hover:shadow-xl transition-all duration-300 group"
        >
          <Bot className="h-6 w-6 text-white group-hover:scale-110 transition-transform" />
        </Button>
        <div className="absolute -top-2 -left-2">
          <Badge className="bg-orange-500 text-white text-xs px-1 py-0.5">Jr.</Badge>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className={`transition-all duration-300 shadow-2xl ${isMinimized ? 'w-80 h-16' : 'w-96 h-[500px]'}`}>
        <CardHeader className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              <div>
                <CardTitle className="text-sm">Jr. Assistant</CardTitle>
                {agentContext && (
                  <div className="flex items-center gap-1 mt-1">
                    <div className={`w-2 h-2 rounded-full ${getAgentColor(agentContext.supportLevel)}`} />
                    <span className="text-xs opacity-90">{agentContext.currentModule}</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMinimized(!isMinimized)}
                className="h-6 w-6 p-0 text-white hover:bg-white/20"
              >
                {isMinimized ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="h-6 w-6 p-0 text-white hover:bg-white/20"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardHeader>

        {!isMinimized && (
          <CardContent className="p-0 flex flex-col h-[calc(500px-80px)]">
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-3">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 text-sm ${
                        message.type === 'user'
                          ? 'bg-blue-500 text-white'
                          : message.type === 'action'
                          ? 'bg-green-100 text-green-800 border border-green-200'
                          : 'bg-gray-100 text-gray-800 border'
                      }`}
                    >
                      {(message.type === 'jr' || message.type === 'action') && message.agentContext && (
                        <div className="flex items-center gap-1 mb-2">
                          <Bot className="h-3 w-3" />
                          <Badge variant="outline" className="text-xs">
                            {message.agentContext}
                          </Badge>
                        </div>
                      )}
                      <div className="whitespace-pre-wrap">{message.content}</div>
                      
                      {message.actionData && (
                        <div className="mt-3 pt-2 border-t border-current/20">
                          {message.actionData.target === 'tile-selection' ? (
                            <div className="grid grid-cols-2 gap-2">
                              {Object.entries(availableTiles).map(([tileName, route]) => (
                                <Button
                                  key={tileName}
                                  size="sm"
                                  variant="outline"
                                  className="text-xs p-2 h-auto"
                                  onClick={() => {
                                    window.location.href = route;
                                  }}
                                >
                                  <div className="text-center">
                                    <ExternalLink className="w-3 h-3 mx-auto mb-1" />
                                    <div className="capitalize">{tileName}</div>
                                  </div>
                                </Button>
                              ))}
                            </div>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-full text-xs"
                              onClick={() => {
                                if (message.actionData?.url) {
                                  window.location.href = message.actionData.url;
                                }
                              }}
                            >
                              <ExternalLink className="w-3 h-3 mr-1" />
                              Open {message.actionData.target}
                            </Button>
                          )}
                        </div>
                      )}
                      
                      <div className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            <div className="border-t p-3">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask Jr. for help..."
                  className="flex-1 text-sm"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim()}
                  size="sm"
                  className="bg-blue-500 hover:bg-blue-600"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
              {agentContext && (
                <div className="text-xs text-gray-500 mt-2">
                  Available: {agentContext.availableAgents.join(', ')}
                </div>
              )}
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
};