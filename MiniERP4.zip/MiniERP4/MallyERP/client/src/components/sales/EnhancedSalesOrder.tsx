import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  ArrowLeft, 
  Save, 
  Plus, 
  Trash2, 
  FileText,
  ShoppingCart,
  Truck,
  Check,
  Calendar,
  User,
  Building,
  AlertCircle,
  Search,
  RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Customer {
  id: number;
  name: string;
  code: string;
  address?: string;
  city?: string;
  email?: string;
  phone?: string;
  credit_limit?: number;
  payment_terms?: string;
}

interface Product {
  id: number;
  name: string;
  code: string;
  price: number;
  unit: string;
  stock_quantity?: number;
  category?: string;
}

interface OrderItem {
  id?: number;
  product_id: number;
  product_code: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  discount: number;
  line_total: number;
  delivery_date?: string;
  notes?: string;
}

interface SalesOrderForm {
  customer_id: number;
  order_date: string;
  delivery_date: string;
  payment_terms: string;
  shipping_method: string;
  currency: string;
  sales_rep: string;
  priority: string;
  notes: string;
  items: OrderItem[];
}

const initialOrderForm: SalesOrderForm = {
  customer_id: 0,
  order_date: new Date().toISOString().split('T')[0],
  delivery_date: '',
  payment_terms: 'NET30',
  shipping_method: 'Standard',
  currency: 'USD',
  sales_rep: '',
  priority: 'Normal',
  notes: '',
  items: []
};

export default function EnhancedSalesOrder() {
  const [location, setLocation] = useLocation();
  const [orderForm, setOrderForm] = useState<SalesOrderForm>(initialOrderForm);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [currentItemForm, setCurrentItemForm] = useState<Partial<OrderItem>>({});
  const [editingItemIndex, setEditingItemIndex] = useState<number | null>(null);
  const [customerSearch, setCustomerSearch] = useState('');
  const [productSearch, setProductSearch] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch customers with search
  const { data: customers = [], isLoading: customersLoading, refetch: refetchCustomers } = useQuery({
    queryKey: ['/api/master-data/customers', customerSearch],
    queryFn: async () => {
      const response = await apiRequest(`/api/master-data/customers?search=${customerSearch}`);
      return Array.isArray(response) ? response : [];
    }
  });

  // Fetch products with search
  const { data: products = [], isLoading: productsLoading, refetch: refetchProducts } = useQuery({
    queryKey: ['/api/master-data/materials', productSearch],
    queryFn: async () => {
      const response = await apiRequest(`/api/master-data/materials?search=${productSearch}`);
      return Array.isArray(response) ? response : [];
    }
  });

  // Create sales order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (orderData: SalesOrderForm) => {
      return await apiRequest('/api/sales-orders', {
        method: 'POST',
        body: JSON.stringify(orderData)
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Sales order created successfully"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/sales-orders'] });
      setLocation('/sales');
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create sales order",
        variant: "destructive"
      });
    }
  });

  const validateOrder = (): string[] => {
    const errors: string[] = [];
    
    if (!orderForm.customer_id || orderForm.customer_id === 0) {
      errors.push("Customer is required");
    }
    
    if (!orderForm.order_date) {
      errors.push("Order date is required");
    }
    
    if (!orderForm.delivery_date) {
      errors.push("Delivery date is required");
    }
    
    if (orderForm.items.length === 0) {
      errors.push("At least one item is required");
    }

    orderForm.items.forEach((item, index) => {
      if (!item.product_id) {
        errors.push(`Item ${index + 1}: Product is required`);
      }
      if (!item.quantity || item.quantity <= 0) {
        errors.push(`Item ${index + 1}: Valid quantity is required`);
      }
      if (!item.unit_price || item.unit_price <= 0) {
        errors.push(`Item ${index + 1}: Valid unit price is required`);
      }
    });

    return errors;
  };

  const handleCustomerSelect = (customerId: number) => {
    const customer = customers.find(c => c.id === customerId);
    if (customer) {
      setSelectedCustomer(customer);
      setOrderForm(prev => ({ 
        ...prev, 
        customer_id: customerId,
        payment_terms: customer.payment_terms || 'NET30'
      }));
    }
  };

  const handleAddItem = () => {
    if (!currentItemForm.product_id || !currentItemForm.quantity || !currentItemForm.unit_price) {
      toast({
        title: "Validation Error",
        description: "Product, quantity, and unit price are required",
        variant: "destructive"
      });
      return;
    }

    const product = products.find(p => p.id === currentItemForm.product_id);
    if (!product) return;

    const lineTotal = (currentItemForm.quantity || 0) * (currentItemForm.unit_price || 0) * (1 - (currentItemForm.discount || 0) / 100);

    const newItem: OrderItem = {
      product_id: currentItemForm.product_id,
      product_code: product.code,
      product_name: product.name,
      quantity: currentItemForm.quantity || 0,
      unit_price: currentItemForm.unit_price || 0,
      discount: currentItemForm.discount || 0,
      line_total: lineTotal,
      delivery_date: currentItemForm.delivery_date || orderForm.delivery_date,
      notes: currentItemForm.notes || ''
    };

    if (editingItemIndex !== null) {
      const updatedItems = [...orderForm.items];
      updatedItems[editingItemIndex] = newItem;
      setOrderForm(prev => ({ ...prev, items: updatedItems }));
      setEditingItemIndex(null);
    } else {
      setOrderForm(prev => ({ ...prev, items: [...prev.items, newItem] }));
    }

    setCurrentItemForm({});
  };

  const handleRemoveItem = (index: number) => {
    const updatedItems = orderForm.items.filter((_, i) => i !== index);
    setOrderForm(prev => ({ ...prev, items: updatedItems }));
  };

  const calculateTotals = () => {
    const subtotal = orderForm.items.reduce((sum, item) => sum + item.line_total, 0);
    const taxAmount = subtotal * 0.1; // 10% tax
    const shippingAmount = subtotal > 1000 ? 0 : 50; // Free shipping over $1000
    const totalAmount = subtotal + taxAmount + shippingAmount;

    return { subtotal, taxAmount, shippingAmount, totalAmount };
  };

  const handleSubmit = () => {
    const errors = validateOrder();
    setValidationErrors(errors);

    if (errors.length > 0) {
      toast({
        title: "Validation Failed",
        description: `Please fix ${errors.length} error(s) before submitting`,
        variant: "destructive"
      });
      return;
    }

    createOrderMutation.mutate(orderForm);
  };

  const { subtotal, taxAmount, shippingAmount, totalAmount } = calculateTotals();

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header with Back Button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            onClick={() => setLocation('/sales')}
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Sales</span>
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Create Sales Order</h1>
            <p className="text-sm text-muted-foreground">
              Enter order details and add items
            </p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => setOrderForm(initialOrderForm)}>
            Reset
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={createOrderMutation.isPending}
            className="flex items-center space-x-2"
          >
            <Save className="h-4 w-4" />
            <span>Create Order</span>
          </Button>
        </div>
      </div>

      {/* Validation Errors */}
      {validationErrors.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <div className="space-y-1">
              <p className="font-medium">Please fix the following errors:</p>
              <ul className="list-disc list-inside space-y-1">
                {validationErrors.map((error, index) => (
                  <li key={index} className="text-sm">{error}</li>
                ))}
              </ul>
            </div>
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="header" className="space-y-4">
        <TabsList>
          <TabsTrigger value="header">Order Header</TabsTrigger>
          <TabsTrigger value="items">Order Items</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
        </TabsList>

        {/* Order Header Tab */}
        <TabsContent value="header" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Customer Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="h-5 w-5" />
                  <span>Customer Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="customer-search">Search Customer *</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="customer-search"
                      placeholder="Search customers..."
                      value={customerSearch}
                      onChange={(e) => setCustomerSearch(e.target.value)}
                    />
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => refetchCustomers()}
                      disabled={customersLoading}
                    >
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="customer">Select Customer *</Label>
                  <Select 
                    value={orderForm.customer_id?.toString() || ''} 
                    onValueChange={(value) => handleCustomerSelect(parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose customer" />
                    </SelectTrigger>
                    <SelectContent>
                      <ScrollArea className="h-48">
                        {customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.name} ({customer.code})
                          </SelectItem>
                        ))}
                      </ScrollArea>
                    </SelectContent>
                  </Select>
                </div>

                {selectedCustomer && (
                  <div className="p-3 bg-muted rounded-lg space-y-2">
                    <p className="font-medium">{selectedCustomer.name}</p>
                    {selectedCustomer.address && (
                      <p className="text-sm text-muted-foreground">{selectedCustomer.address}</p>
                    )}
                    {selectedCustomer.email && (
                      <p className="text-sm text-muted-foreground">{selectedCustomer.email}</p>
                    )}
                    {selectedCustomer.phone && (
                      <p className="text-sm text-muted-foreground">{selectedCustomer.phone}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Order Details */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <span>Order Details</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="order-date">Order Date *</Label>
                    <Input
                      id="order-date"
                      type="date"
                      value={orderForm.order_date}
                      onChange={(e) => setOrderForm(prev => ({ ...prev, order_date: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="delivery-date">Delivery Date *</Label>
                    <Input
                      id="delivery-date"
                      type="date"
                      value={orderForm.delivery_date}
                      onChange={(e) => setOrderForm(prev => ({ ...prev, delivery_date: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="payment-terms">Payment Terms</Label>
                    <Select 
                      value={orderForm.payment_terms} 
                      onValueChange={(value) => setOrderForm(prev => ({ ...prev, payment_terms: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="NET15">NET 15</SelectItem>
                        <SelectItem value="NET30">NET 30</SelectItem>
                        <SelectItem value="NET45">NET 45</SelectItem>
                        <SelectItem value="COD">Cash on Delivery</SelectItem>
                        <SelectItem value="PREPAID">Prepaid</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="shipping-method">Shipping Method</Label>
                    <Select 
                      value={orderForm.shipping_method} 
                      onValueChange={(value) => setOrderForm(prev => ({ ...prev, shipping_method: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Standard">Standard Shipping</SelectItem>
                        <SelectItem value="Express">Express Shipping</SelectItem>
                        <SelectItem value="Overnight">Overnight</SelectItem>
                        <SelectItem value="Pickup">Customer Pickup</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="currency">Currency</Label>
                    <Select 
                      value={orderForm.currency} 
                      onValueChange={(value) => setOrderForm(prev => ({ ...prev, currency: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="EUR">EUR</SelectItem>
                        <SelectItem value="GBP">GBP</SelectItem>
                        <SelectItem value="JPY">JPY</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority</Label>
                    <Select 
                      value={orderForm.priority} 
                      onValueChange={(value) => setOrderForm(prev => ({ ...prev, priority: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Normal">Normal</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sales-rep">Sales Representative</Label>
                  <Input
                    id="sales-rep"
                    value={orderForm.sales_rep}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, sales_rep: e.target.value }))}
                    placeholder="Enter sales rep name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Order Notes</Label>
                  <Textarea
                    id="notes"
                    value={orderForm.notes}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="Additional notes or special instructions"
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Order Items Tab */}
        <TabsContent value="items" className="space-y-6">
          {/* Add Item Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Plus className="h-5 w-5" />
                <span>{editingItemIndex !== null ? 'Edit Item' : 'Add Item'}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="product-search">Search Product</Label>
                <div className="flex space-x-2">
                  <Input
                    id="product-search"
                    placeholder="Search products..."
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                  />
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => refetchProducts()}
                    disabled={productsLoading}
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="product">Product *</Label>
                  <Select 
                    value={currentItemForm.product_id?.toString() || ''} 
                    onValueChange={(value) => {
                      const productId = parseInt(value);
                      const product = products.find(p => p.id === productId);
                      setCurrentItemForm(prev => ({ 
                        ...prev, 
                        product_id: productId,
                        unit_price: product?.price || 0
                      }));
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select product" />
                    </SelectTrigger>
                    <SelectContent>
                      <ScrollArea className="h-48">
                        {products.map((product) => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                            {product.name} ({product.code})
                          </SelectItem>
                        ))}
                      </ScrollArea>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={currentItemForm.quantity || ''}
                    onChange={(e) => setCurrentItemForm(prev => ({ 
                      ...prev, 
                      quantity: parseFloat(e.target.value) || 0 
                    }))}
                    placeholder="0.00"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="unit-price">Unit Price *</Label>
                  <Input
                    id="unit-price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={currentItemForm.unit_price || ''}
                    onChange={(e) => setCurrentItemForm(prev => ({ 
                      ...prev, 
                      unit_price: parseFloat(e.target.value) || 0 
                    }))}
                    placeholder="0.00"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="discount">Discount %</Label>
                  <Input
                    id="discount"
                    type="number"
                    min="0"
                    max="100"
                    step="0.01"
                    value={currentItemForm.discount || ''}
                    onChange={(e) => setCurrentItemForm(prev => ({ 
                      ...prev, 
                      discount: parseFloat(e.target.value) || 0 
                    }))}
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  Line Total: {orderForm.currency} {((currentItemForm.quantity || 0) * (currentItemForm.unit_price || 0) * (1 - (currentItemForm.discount || 0) / 100)).toFixed(2)}
                </p>
                <div className="space-x-2">
                  {editingItemIndex !== null && (
                    <Button variant="outline" onClick={() => {
                      setEditingItemIndex(null);
                      setCurrentItemForm({});
                    }}>
                      Cancel
                    </Button>
                  )}
                  <Button onClick={handleAddItem}>
                    {editingItemIndex !== null ? 'Update Item' : 'Add Item'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Items List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ShoppingCart className="h-5 w-5" />
                <span>Order Items ({orderForm.items.length})</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {orderForm.items.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <ShoppingCart className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No items added yet</p>
                  <p className="text-sm">Add items using the form above</p>
                </div>
              ) : (
                <ScrollArea className="h-80">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Unit Price</TableHead>
                        <TableHead>Discount</TableHead>
                        <TableHead>Line Total</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orderForm.items.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{item.product_name}</p>
                              <p className="text-sm text-muted-foreground">{item.product_code}</p>
                            </div>
                          </TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell>{orderForm.currency} {item.unit_price.toFixed(2)}</TableCell>
                          <TableCell>{item.discount}%</TableCell>
                          <TableCell>{orderForm.currency} {item.line_total.toFixed(2)}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => {
                                  setCurrentItemForm({
                                    product_id: item.product_id,
                                    quantity: item.quantity,
                                    unit_price: item.unit_price,
                                    discount: item.discount
                                  });
                                  setEditingItemIndex(index);
                                }}
                              >
                                Edit
                              </Button>
                              <Button 
                                variant="destructive" 
                                size="sm"
                                onClick={() => handleRemoveItem(index)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Summary Tab */}
        <TabsContent value="summary" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Order Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedCustomer && (
                  <div className="space-y-2">
                    <h4 className="font-medium">Customer</h4>
                    <p>{selectedCustomer.name}</p>
                    <p className="text-sm text-muted-foreground">{selectedCustomer.code}</p>
                  </div>
                )}

                <div className="space-y-2">
                  <h4 className="font-medium">Order Details</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <span className="text-muted-foreground">Order Date:</span>
                    <span>{orderForm.order_date}</span>
                    <span className="text-muted-foreground">Delivery Date:</span>
                    <span>{orderForm.delivery_date}</span>
                    <span className="text-muted-foreground">Payment Terms:</span>
                    <span>{orderForm.payment_terms}</span>
                    <span className="text-muted-foreground">Shipping:</span>
                    <span>{orderForm.shipping_method}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Items ({orderForm.items.length})</h4>
                  <div className="space-y-1">
                    {orderForm.items.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span>{item.product_name} x {item.quantity}</span>
                        <span>{orderForm.currency} {item.line_total.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Financial Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Financial Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>{orderForm.currency} {subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax (10%):</span>
                    <span>{orderForm.currency} {taxAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping:</span>
                    <span>{orderForm.currency} {shippingAmount.toFixed(2)}</span>
                  </div>
                  <div className="border-t pt-3">
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total Amount:</span>
                      <span>{orderForm.currency} {totalAmount.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                {subtotal > 1000 && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-800 font-medium">
                      🎉 Free shipping applied! (Order over $1,000)
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}