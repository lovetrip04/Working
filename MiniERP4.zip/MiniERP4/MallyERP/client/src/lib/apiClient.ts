/**
 * API Client utility for making API requests
 * This utility helps handle errors consistently and ensures proper JSON parsing
 */
import { QueryClient } from "@tanstack/react-query";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

/**
 * Make a generic API request
 * @param url The URL to make the request to
 * @param method The HTTP method to use
 * @param data The data to send in the request body (for POST/PUT)
 * @returns The parsed JSON response
 */
export async function apiRequest<T>(url: string, method: string, data?: any): Promise<T> {
  const options: RequestInit = {
    method,
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    credentials: 'include'
  };

  if (data && (method === 'POST' || method === 'PUT')) {
    options.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(url, options);

    // Check if response is ok
    if (!response.ok) {
      const errorText = await response.text();
      // Check if the response is HTML
      if (errorText.includes('<!DOCTYPE')) {
        throw new Error('Server returned HTML instead of JSON');
      }
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    // Parse the response as JSON
    return await response.json() as T;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

/**
 * Make a GET request to the API
 * @param url The URL to make the request to
 * @returns The parsed JSON response
 */
export async function apiGet<T>(url: string): Promise<T> {
  try {
    // Make request with explicit headers
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      credentials: 'include'
    });

    // Check if response is ok
    if (!response.ok) {
      const errorText = await response.text();
      // Check if the response is HTML
      if (errorText.includes('<!DOCTYPE')) {
        throw new Error('Server returned HTML instead of JSON');
      }
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    // Parse the response as JSON
    return await response.json() as T;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

/**
 * Make a POST request to the API
 * @param url The URL to make the request to
 * @param data The data to send in the request body
 * @returns The parsed JSON response
 */
export async function apiPost<T>(url: string, data: any): Promise<T> {
  try {
    // Make request with explicit headers
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      credentials: 'include',
      body: JSON.stringify(data)
    });

    // Check if response is ok
    if (!response.ok) {
      const errorText = await response.text();
      // Check if the response is HTML
      if (errorText.includes('<!DOCTYPE')) {
        throw new Error('Server returned HTML instead of JSON');
      }
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    // Parse the response as JSON
    return await response.json() as T;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

/**
 * Make a PUT request to the API
 * @param url The URL to make the request to
 * @param data The data to send in the request body
 * @returns The parsed JSON response
 */
export async function apiPut<T>(url: string, data: any): Promise<T> {
  try {
    // Make request with explicit headers
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      credentials: 'include',
      body: JSON.stringify(data)
    });

    // Check if response is ok
    if (!response.ok) {
      const errorText = await response.text();
      // Check if the response is HTML
      if (errorText.includes('<!DOCTYPE')) {
        throw new Error('Server returned HTML instead of JSON');
      }
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    // Parse the response as JSON
    return await response.json() as T;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

/**
 * Make a DELETE request to the API
 * @param url The URL to make the request to
 * @returns The parsed JSON response
 */
export async function apiDelete<T>(url: string): Promise<T> {
  try {
    // Make request with explicit headers
    const response = await fetch(url, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      credentials: 'include'
    });

    // Check if response is ok
    if (!response.ok) {
      const errorText = await response.text();
      // Check if the response is HTML
      if (errorText.includes('<!DOCTYPE')) {
        throw new Error('Server returned HTML instead of JSON');
      }
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    // Parse the response as JSON
    return await response.json() as T;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}