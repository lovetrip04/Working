import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    try {
      // First check if we can parse as JSON
      const contentType = res.headers.get("content-type");
      
      if (contentType && contentType.includes("application/json")) {
        const data = await res.json();
        throw new Error(data.message || data.error || `${res.status}: ${res.statusText}`);
      } else {
        // Try to get text response
        const text = await res.text();
        
        // Check if it's HTML with doctype (server error page)
        if (text.includes("<!DOCTYPE")) {
          throw new Error(`Server error (${res.status}): The server returned an HTML page instead of JSON`);
        } else {
          throw new Error(`${res.status}: ${text || res.statusText}`);
        }
      }
    } catch (parseError) {
      if (parseError instanceof Error) {
        throw parseError;
      }
      throw new Error(`${res.status}: ${res.statusText}`);
    }
  }
}

export async function apiRequest(
  url: string,
  options?: RequestInit,
): Promise<Response> {
  const res = await fetch(url, {
    ...options,
    headers: {
      ...(options?.headers || {}),
      ...(options?.body ? { "Content-Type": "application/json" } : {}),
      "Accept": "application/json",
    },
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    try {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
        headers: {
          "Accept": "application/json"
        }
      });

      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        return null;
      }

      await throwIfResNotOk(res);
      
      // Safely parse the JSON
      try {
        const contentType = res.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          return await res.json();
        } else {
          const text = await res.text();
          if (text.includes("<!DOCTYPE")) {
            throw new Error("Server returned HTML instead of JSON");
          }
          // Try to parse it as JSON anyway
          try {
            return JSON.parse(text);
          } catch (parseError) {
            console.error("Failed to parse response as JSON:", text);
            throw new Error("Invalid response format");
          }
        }
      } catch (parseError) {
        console.error("Error parsing response:", parseError);
        throw parseError;
      }
    } catch (error) {
      console.error("Query error:", error);
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
