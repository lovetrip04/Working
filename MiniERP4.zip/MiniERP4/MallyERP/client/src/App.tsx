import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AgentRoleProvider } from "@/contexts/AgentRoleContext";
import AgentRoleSwitcher from "@/components/AgentRoleSwitcher";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import CustomizableDashboard from "@/pages/CustomizableDashboard";
import { useEffect, useState, lazy, Suspense } from "react";
import { 
  Package2, Users, Building, Factory, 
  Package, Store, ShoppingBag, CreditCard, Ruler, 
  ClipboardCheck, BookOpen, DollarSign, BarChart2, 
  UserCircle, Percent, Briefcase, Settings, Calendar,
  FileText, ShoppingCart
} from "lucide-react";

// Import the DraggableTiles component
import { DraggableTiles } from "@/components/master-data/DraggableTiles";
import { JrChatbot } from "@/components/JrChatbot";

// Import the module dashboards
import Sales from "@/pages/sales/Sales";
import SalesOrderList from "@/pages/sales/SalesOrderList";
import SalesOrder from "@/pages/sales/SalesOrder";
import Inventory from "@/pages/inventory/Inventory";
import Finance from "@/pages/finance/Finance";
import Controlling from "@/pages/Controlling";
import Help from "@/pages/Help";
import UserGuides from "@/pages/UserGuides";
import WorkspaceManager from "@/pages/WorkspaceManager";
import AgentPlayer from "@/pages/AgentPlayer";
import CoachAgent from "@/pages/CoachAgent";
import ChiefAgent from "@/pages/ChiefAgent";
import RookieAgent from "@/pages/RookieAgent";
import DesignerAgent from "@/pages/DesignerAgent";
import IntelligentTestingAgent from "@/pages/IntelligentTestingAgent";
import DominosPizzaE2ETesting from "@/pages/DominosPizzaE2ETesting";
import CoachAgentHealthDashboard from "@/pages/CoachAgentHealthDashboard";
import ProjectTest from "@/pages/ProjectTest";
import TestResults from "@/pages/TestResults";

// Import transaction modules
import SalesOrderTransaction from "@/pages/transactions/SalesOrder";
import InvoiceTransaction from "@/pages/transactions/Invoice";
import DocumentNumberRanges from "@/pages/transactions/DocumentNumberRanges";
import DocumentPostingSystem from "@/pages/transactions/DocumentPostingSystem";
import AutomaticClearing from "@/pages/transactions/AutomaticClearing";
import AssetAccounting from "@/pages/transactions/AssetAccounting";
import BankStatementProcessing from "@/pages/transactions/BankStatementProcessing";

// Import sales components
import SalesLeads from "@/pages/sales/SalesLeads";
import SalesOpportunities from "@/pages/sales/SalesOpportunities";
import SalesQuotes from "@/pages/sales/SalesQuotes";
import SalesQuoteApproval from "@/pages/sales/SalesQuoteApproval";

// Import SD-FI Integration components
import SalesOrderManagement from "@/pages/sales/SalesOrderManagement";
import SDFIIntegrationDashboard from "@/pages/integration/SDFIIntegrationDashboard";
import SalesDistributionConfig from "@/pages/sales/SalesDistributionConfig";
import SDCustomization from "@/pages/sales/SDCustomization";

// Import purchase and production components
import PurchaseModule from "@/pages/purchase/Purchase";
import ProductionModule from "@/pages/production/Production";

// Import master data components
import UnitOfMeasure from "@/pages/master-data/UnitOfMeasure";
import CompanyCode from "@/pages/master-data/CompanyCode";
import Transport from "@/pages/Transport";
import TransportAdmin from "@/pages/TransportAdmin";
import GitHubSetup from "@/pages/GitHubSetup";
import GitHubIntegration from "@/pages/GitHubIntegration";
import Plant from "@/pages/master-data/Plant";
import Currency from "@/pages/master-data/Currency";
import StorageLocation from "@/pages/master-data/StorageLocation";
import SalesOrganization from "@/pages/master-data/SalesOrganization";
import PurchaseOrganization from "@/pages/master-data/PurchaseOrganization";
import PurchaseReferences from "@/pages/master-data/PurchaseReferences";
import CreditControl from "@/pages/master-data/CreditControl";
import ApprovalLevels from "@/pages/master-data/ApprovalLevels";
import Material from "@/pages/master-data/MaterialFixed";
import MaterialMaster from "@/pages/master-data/MaterialMaster";
import DistributionChannels from "@/pages/master-data/DistributionChannels";
import ChartOfAccounts from "@/pages/master-data/ChartOfAccounts";
import Customer from "@/pages/master-data/Customer";
import Vendor from "@/pages/master-data/Vendor";
import BillOfMaterials from "@/pages/master-data/BillOfMaterials";
import SimpleWorkCenters from "@/pages/master-data/SimpleWorkCenters";
import CostCenters from "@/pages/master-data/CostCenters";
import ProfitCenters from "@/pages/master-data/ProfitCenters";
import Employees from "@/pages/master-data/Employees";
import TaxMaster from "@/pages/master-data/TaxMaster";
import AssetMaster from "@/pages/master-data/AssetMaster";
import Regions from "@/pages/master-data/Regions";
import Currencies from "@/pages/master-data/Currencies";
import FiscalCalendar from "@/pages/master-data/FiscalCalendar";
import FiscalYearVariant from "@/pages/master-data/FiscalYearVariant";
import GeneralLedgerAccounts from "@/pages/master-data/GeneralLedgerAccounts";
import PurchasingGroups from "@/pages/master-data/PurchasingGroups";
import PurchasingOrganizations from "@/pages/master-data/PurchasingOrganizations";
import ValuationClasses from "@/pages/master-data/ValuationClasses";
import MovementTypes from "@/pages/master-data/MovementTypes";
import MasterDataChecker from "@/pages/tools/MasterDataChecker";
import MasterDataProtection from "@/pages/tools/MasterDataProtection";
import TestApplication from "@/pages/tools/TestApplication";
import ApiTester from "@/pages/tools/ApiTester";
import AppLayout from "@/components/layout/AppLayout";
import { SidebarProvider } from "@/hooks/use-sidebar";

// Lazy imports for other modules we'll create
const HR = () => <div className="p-6">HR module coming soon</div>;
const AccountsReceivable = () => <div className="p-6">Accounts Receivable module coming soon</div>;
const AccountsPayable = () => <div className="p-6">Accounts Payable module coming soon</div>;
const GeneralLedger = () => <div className="p-6">General Ledger module coming soon</div>;
const SettingsPage = () => <div className="p-6">Settings module coming soon</div>;
import Reports from "@/pages/Reports";
import Upload from "@/pages/Upload";
import FinancialConfiguration from "@/pages/FinancialConfiguration";
import EndToEndFinancialGuide from "@/pages/EndToEndFinancialGuide";
import SimpleFinancialConfig from "@/pages/SimpleFinancialConfig";

// Import the Tools page
import Tools from "@/pages/Tools";
import AIAgentsDemo from "@/pages/AIAgentsDemo";
import IssuesMonitoringDashboard from "@/pages/IssuesMonitoringDashboard";
import SystemIntegrityDashboard from "@/pages/SystemIntegrityDashboard";
import ChangeLogDashboard from "@/pages/ChangeLogDashboard";

// Master Data dashboard with navigation to submodules and draggable tiles
const MasterData = () => {
  const navigate = (path: string) => () => {
    window.location.pathname = path;
  };
  
  // Define organizational master data tiles
  const initialOrgTiles = [
    {
      id: "company-code",
      title: "Company Code",
      icon: <Building className="h-5 w-5 text-blue-600" />,
      description: "Legal entities in your organization",
      linkText: "Manage Company Codes →",
      onClick: navigate("/master-data/company-code")
    },
    {
      id: "plant",
      title: "Plant",
      icon: <Factory className="h-5 w-5 text-blue-600" />,
      description: "Manufacturing sites and warehouses",
      linkText: "Manage Plants →",
      onClick: navigate("/master-data/plant")
    },
    {
      id: "storage-location",
      title: "Storage Location",
      icon: <Package className="h-5 w-5 text-blue-600" />,
      description: "Physical inventory locations within plants",
      linkText: "Manage Storage Locations →",
      onClick: navigate("/master-data/storage-location")
    },
    {
      id: "sales-organization",
      title: "Sales Organization",
      icon: <Store className="h-5 w-5 text-blue-600" />,
      description: "Sales units in your organization",
      linkText: "Manage Sales Organizations →",
      onClick: navigate("/master-data/sales-organization")
    },
    {
      id: "purchase-organization",
      title: "Purchasing Org",
      icon: <ShoppingBag className="h-5 w-5 text-blue-600" />,
      description: "Procurement units in your organization",
      linkText: "Manage Purchase Organizations →",
      onClick: navigate("/master-data/purchase-organization")
    },
    {
      id: "purchase-references",
      title: "Purchase References",
      icon: <FileText className="h-5 w-5 text-blue-600" />,
      description: "Reference data for procurement",
      linkText: "Manage Purchase References →",
      onClick: navigate("/master-data/purchase-references")
    },
    {
      id: "credit-control",
      title: "Credit Control",
      icon: <CreditCard className="h-5 w-5 text-blue-600" />,
      description: "Financial risk management units",
      linkText: "Manage Credit Control Areas →",
      onClick: navigate("/master-data/credit-control")
    }
  ];

  // Define core master data tiles
  const initialCoreTiles = [
    {
      id: "material",
      title: "Material Master",
      icon: <Package2 className="h-5 w-5 text-blue-600" />,
      description: "Products, materials and finished goods",
      linkText: "Manage Materials →",
      onClick: navigate("/master-data/material")
    },
    {
      id: "bom",
      title: "Bill of Materials",
      icon: <ClipboardCheck className="h-5 w-5 text-blue-600" />,
      description: "Components needed to produce finished goods",
      linkText: "Manage BOMs →",
      onClick: navigate("/master-data/bom")
    },
    {
      id: "uom",
      title: "Units of Measure",
      icon: <Ruler className="h-5 w-5 text-blue-600" />,
      description: "Management of measurement units with conversion factors",
      linkText: "View Module →",
      onClick: navigate("/master-data/uom")
    },
    {
      id: "customer",
      title: "Customer Master",
      icon: <Users className="h-5 w-5 text-blue-600" />,
      description: "Customer information and preferences",
      linkText: "Manage Customers →",
      onClick: navigate("/master-data/customer")
    },
    {
      id: "vendor",
      title: "Vendor Master",
      icon: <Building className="h-5 w-5 text-blue-600" />,
      description: "Supplier and vendor information",
      linkText: "Manage Vendors →",
      onClick: navigate("/master-data/vendor")
    },
    {
      id: "currency",
      title: "Currencies",
      icon: <DollarSign className="h-5 w-5 text-blue-600" />,
      description: "Define currencies and exchange rates for financial transactions",
      linkText: "Manage Currencies →",
      onClick: navigate("/master-data/currencies")
    },
    {
      id: "chart-of-accounts",
      title: "Chart of Accounts",
      icon: <BookOpen className="h-5 w-5 text-blue-600" />,
      description: "Financial account structure",
      linkText: "Manage Chart of Accounts →",
      onClick: navigate("/master-data/chart-of-accounts")
    },
    {
      id: "fiscal-calendar",
      title: "Fiscal Calendar",
      icon: <Calendar className="h-5 w-5 text-blue-600" />,
      description: "Manage fiscal periods and accounting timeframes",
      linkText: "Manage Fiscal Calendar →",
      onClick: navigate("/master-data/fiscal-calendar")
    },
    {
      id: "fiscal-year-variant",
      title: "Fiscal Year Variant",
      icon: <Calendar className="h-5 w-5 text-green-600" />,
      description: "Define fiscal year structures and period configurations",
      linkText: "Manage Fiscal Year Variants →",
      onClick: navigate("/master-data/fiscal-year-variant")
    },
    {
      id: "gl-accounts",
      title: "GL Accounts",
      icon: <BookOpen className="h-5 w-5 text-purple-600" />,
      description: "General ledger accounts for financial postings",
      linkText: "Manage GL Accounts →",
      onClick: navigate("/master-data/gl-accounts")
    },
    {
      id: "cost-centers",
      title: "Cost Centers",
      icon: <BarChart2 className="h-5 w-5 text-orange-600" />,
      description: "Organizational units for cost allocation and control",
      linkText: "Manage Cost Centers →",
      onClick: navigate("/master-data/cost-centers")
    },
    {
      id: "profit-centers",
      title: "Profit Centers",
      icon: <DollarSign className="h-5 w-5 text-emerald-600" />,
      description: "Business units for profitability analysis",
      linkText: "Manage Profit Centers →",
      onClick: navigate("/master-data/profit-centers")
    },
    {
      id: "condition-types",
      title: "Condition Types",
      icon: <Percent className="h-5 w-5 text-blue-600" />,
      description: "Configure pricing components and calculation rules",
      linkText: "Manage Condition Types →",
      onClick: navigate("/condition-types")
    }
  ];

  // State for tiles
  const [orgTiles, setOrgTiles] = useState(initialOrgTiles);
  const [coreTiles, setCoreTiles] = useState(initialCoreTiles);

  // Load saved tile order on component mount
  useEffect(() => {
    try {
      // Load organizational tiles order
      const savedOrgTiles = localStorage.getItem('masterDataTiles-Organizational Master Data');
      if (savedOrgTiles) {
        const savedOrgOrder = JSON.parse(savedOrgTiles);
        const reorderedOrgTiles = [...initialOrgTiles].sort((a, b) => {
          return savedOrgOrder.indexOf(a.id) - savedOrgOrder.indexOf(b.id);
        });
        setOrgTiles(reorderedOrgTiles);
      }

      // Load core tiles order
      const savedCoreTiles = localStorage.getItem('masterDataTiles-Core Master Data');
      if (savedCoreTiles) {
        const savedCoreOrder = JSON.parse(savedCoreTiles);
        const reorderedCoreTiles = [...initialCoreTiles].sort((a, b) => {
          return savedCoreOrder.indexOf(a.id) - savedCoreOrder.indexOf(b.id);
        });
        setCoreTiles(reorderedCoreTiles);
      }
    } catch (error) {
      console.error("Failed to load saved tile order:", error);
    }
  }, []);
  
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Master Data Management</h1>
      
      {/* Organizational Master Data with DraggableTiles */}
      <DraggableTiles
        title="Organizational Master Data"
        description="Defines your company's hierarchy and must be created before transactional data."
        initialTiles={orgTiles}
      />
      
      {/* Core Master Data with DraggableTiles */}
      <DraggableTiles
        title="Core Master Data"
        description="Essential master records required for business operations."
        initialTiles={coreTiles}
      />
      
      {/* Additional Master Data with draggable tiles */}
      <DraggableTiles
        title="Additional Master Data"
        description="Supporting master records for specialized business processes."
        initialTiles={[
          {
            id: "approval-level",
            title: "Approval Levels",
            icon: <CreditCard className="h-5 w-5 text-blue-600" />,
            description: "Purchase approval hierarchy and authorization limits",
            linkText: "Manage Approval Levels →",
            onClick: () => window.location.pathname = "/master-data/approval-level"
          },
          {
            id: "work-centers",
            title: "Work Centers",
            icon: <Settings className="h-5 w-5 text-blue-600" />,
            description: "Production capacity units",
            linkText: "View All Work Centers →",
            onClick: () => window.location.pathname = "/master-data/work-centers"
          },
          {
            id: "cost-centers",
            title: "Cost Centers",
            icon: <DollarSign className="h-5 w-5 text-blue-600" />,
            description: "Organizational cost assignment units",
            linkText: "View All Cost Centers →",
            onClick: () => window.location.pathname = "/master-data/cost-centers"
          },
          {
            id: "profit-centers",
            title: "Profit Centers",
            icon: <BarChart2 className="h-5 w-5 text-blue-600" />,
            description: "Profit accountability units",
            linkText: "View All Profit Centers →",
            onClick: () => window.location.pathname = "/master-data/profit-centers"
          },
          {
            id: "employees",
            title: "Employees",
            icon: <UserCircle className="h-5 w-5 text-blue-600" />,
            description: "Employee records and HR data",
            linkText: "View All Employees →",
            onClick: () => window.location.pathname = "/master-data/employees"
          },
          {
            id: "tax-master",
            title: "Tax Master",
            icon: <Percent className="h-5 w-5 text-blue-600" />,
            description: "Tax codes and configurations",
            linkText: "View All Tax Codes →",
            onClick: () => window.location.pathname = "/master-data/tax-master"
          },
          {
            id: "asset-master",
            title: "Asset Master",
            icon: <Briefcase className="h-5 w-5 text-blue-600" />,
            description: "Fixed assets and depreciation rules",
            linkText: "View All Assets →",
            onClick: () => window.location.pathname = "/master-data/asset-master"
          },
          {
            id: "regions",
            title: "Regions",
            icon: <Package2 className="h-5 w-5 text-blue-600" />,
            description: "Global regions with country assignments",
            linkText: "Manage Regions →",
            onClick: () => window.location.pathname = "/master-data/regions"
          }
        ]}
      />
    </div>
  );
};

// Main application router
function Router() {
  return (
    <AppLayout>
      <Suspense fallback={<div className="flex items-center justify-center min-h-screen">Loading...</div>}>
        <Switch>
        {/* Dashboards */}
        <Route path="/" component={Dashboard} />
        <Route path="/custom-dashboard" component={CustomizableDashboard} />
        
        {/* Master Data Module and Submodules */}
        <Route path="/master-data" component={MasterData} />
        <Route path="/master-data/uom" component={UnitOfMeasure} />
        <Route path="/master-data/company-code" component={CompanyCode} />
        <Route path="/master-data/plant" component={Plant} />
        <Route path="/master-data/currency" component={Currency} />
        <Route path="/master-data/storage-location" component={StorageLocation} />
        <Route path="/master-data/sales-organization" component={SalesOrganization} />
        <Route path="/master-data/purchase-organization" component={PurchaseOrganization} />
        <Route path="/master-data/purchase-references" component={PurchaseReferences} />
        <Route path="/master-data/credit-control" component={CreditControl} />
        <Route path="/master-data/approval-level" component={ApprovalLevels} />
        <Route path="/master-data/material" component={Material} />
        <Route path="/master-data/material-master" component={MaterialMaster} />
        <Route path="/master-data/distribution-channels" component={DistributionChannels} />
        <Route path="/distribution-channels" component={DistributionChannels} />
        <Route path="/material-master" component={MaterialMaster} />
        <Route path="/master-data/chart-of-accounts" component={ChartOfAccounts} />
        <Route path="/master-data/customer" component={Customer} />
        <Route path="/master-data/vendor" component={Vendor} />
        <Route path="/master-data/bom" component={BillOfMaterials} />
        <Route path="/master-data/work-centers" component={SimpleWorkCenters} />
        <Route path="/master-data/cost-centers" component={CostCenters} />
        <Route path="/master-data/profit-centers" component={ProfitCenters} />
        <Route path="/master-data/employees" component={Employees} />
        <Route path="/master-data/tax-master" component={TaxMaster} />
        <Route path="/master-data/asset-master" component={AssetMaster} />
        <Route path="/master-data/regions" component={Regions} />
        <Route path="/master-data/currencies" component={Currencies} />
        <Route path="/master-data/fiscal-calendar" component={FiscalCalendar} />
        <Route path="/master-data/fiscal-year-variant" component={FiscalYearVariant} />
        <Route path="/master-data/gl-accounts" component={GeneralLedgerAccounts} />
        <Route path="/master-data/purchasing-groups" component={PurchasingGroups} />
        <Route path="/master-data/purchasing-organizations" component={PurchasingOrganizations} />
        <Route path="/master-data/valuation-classes" component={ValuationClasses} />
        <Route path="/master-data/movement-types" component={MovementTypes} />
        
        {/* Transport System */}
        <Route path="/transport" component={Transport} />
        <Route path="/transport/admin" component={TransportAdmin} />
        <Route path="/github-setup" component={GitHubSetup} />
        <Route path="/github-integration" component={GitHubIntegration} />
        
        {/* Transaction Applications */}
        <Route path="/transactions" component={lazy(() => import("./pages/Transactions"))} />
        
        {/* All Transaction Component Routes - Complete Set */}
        <Route path="/transactions/accounts-payable" component={lazy(() => import("./pages/transactions/AccountsPayable"))} />
        <Route path="/transactions/accounts-receivable" component={lazy(() => import("./pages/transactions/AccountsReceivable"))} />
        <Route path="/transactions/activity-based-costing" component={lazy(() => import("./pages/transactions/ActivityBasedCosting"))} />
        <Route path="/transactions/advanced-authorization-management" component={lazy(() => import("./pages/transactions/AdvancedAuthorizationManagement"))} />
        <Route path="/transactions/allocation-posting" component={lazy(() => import("./pages/transactions/AllocationPosting"))} />
        <Route path="/transactions/asset-accounting" component={lazy(() => import("./pages/transactions/AssetAccounting"))} />
        <Route path="/transactions/automatic-clearing" component={lazy(() => import("./pages/transactions/AutomaticClearing"))} />
        <Route path="/transactions/balance-sheet-reporting" component={lazy(() => import("./pages/transactions/BalanceSheetReporting"))} />
        <Route path="/transactions/bank-statement-processing" component={lazy(() => import("./pages/transactions/BankStatementProcessing"))} />
        <Route path="/transactions/batch-management" component={lazy(() => import("./pages/transactions/BatchManagement"))} />
        <Route path="/transactions/bill-of-exchange-management" component={lazy(() => import("./pages/transactions/BillOfExchangeManagement"))} />
        <Route path="/transactions/capacity-planning" component={lazy(() => import("./pages/transactions/CapacityPlanning"))} />
        <Route path="/transactions/cash-management" component={lazy(() => import("./pages/transactions/CashManagement"))} />
        <Route path="/transactions/consignment-processing" component={lazy(() => import("./pages/transactions/ConsignmentProcessing"))} />
        <Route path="/transactions/contract-management" component={lazy(() => import("./pages/transactions/ContractManagement"))} />
        <Route path="/transactions/cost-center-accounting" component={lazy(() => import("./pages/transactions/CostCenterAccounting"))} />
        <Route path="/transactions/cost-center-planning" component={lazy(() => import("./pages/transactions/CostCenterPlanning"))} />
        <Route path="/transactions/credit-management" component={lazy(() => import("./pages/transactions/CreditManagement"))} />
        <Route path="/transactions/debit-management" component={lazy(() => import("./pages/transactions/DebitManagement"))} />
        <Route path="/transactions/document-number-ranges" component={lazy(() => import("./pages/transactions/DocumentNumberRanges"))} />
        <Route path="/transactions/document-posting" component={lazy(() => import("./pages/transactions/DocumentPosting"))} />
        <Route path="/transactions/document-posting-system" component={lazy(() => import("./pages/transactions/DocumentPostingSystem"))} />
        <Route path="/transactions/down-payment-management" component={lazy(() => import("./pages/transactions/DownPaymentManagement"))} />
        <Route path="/transactions/dunning-management" component={lazy(() => import("./pages/transactions/DunningManagement"))} />
        <Route path="/transactions/dunning-process" component={lazy(() => import("./pages/transactions/DunningProcess"))} />
        <Route path="/transactions/exchange-rate-management" component={lazy(() => import("./pages/transactions/ExchangeRateManagement"))} />
        <Route path="/transactions/financial-reporting" component={lazy(() => import("./pages/transactions/FinancialReporting"))} />
        <Route path="/transactions/foreign-currency-valuation" component={lazy(() => import("./pages/transactions/ForeignCurrencyValuation"))} />
        <Route path="/transactions/funds-management" component={lazy(() => import("./pages/transactions/FundsManagement"))} />
        <Route path="/transactions/general-ledger-posting" component={lazy(() => import("./pages/transactions/GeneralLedgerPosting"))} />
        <Route path="/transactions/goods-issue" component={lazy(() => import("./pages/transactions/GoodsIssue"))} />
        <Route path="/transactions/goods-receipt" component={lazy(() => import("./pages/transactions/GoodsReceipt"))} />
        <Route path="/transactions/intercompany-transactions" component={lazy(() => import("./pages/transactions/IntercompanyTransactions"))} />
        <Route path="/transactions/internal-orders" component={lazy(() => import("./pages/transactions/InternalOrders"))} />
        <Route path="/transactions/inventory-management" component={lazy(() => import("./pages/transactions/InventoryManagement"))} />
        <Route path="/transactions/inventory-valuation" component={lazy(() => import("./pages/transactions/InventoryValuation"))} />
        <Route path="/transactions/invoice" component={lazy(() => import("./pages/transactions/Invoice"))} />
        <Route path="/transactions/invoice-verification" component={lazy(() => import("./pages/transactions/InvoiceVerification"))} />
        <Route path="/transactions/ledger-management" component={lazy(() => import("./pages/transactions/LedgerManagement"))} />
        <Route path="/transactions/management-reporting-dashboard-enhancement" component={lazy(() => import("./pages/transactions/ManagementReportingDashboardEnhancement"))} />
        <Route path="/transactions/material-requirement-planning" component={lazy(() => import("./pages/transactions/MaterialRequirementPlanning"))} />
        <Route path="/transactions/material-reservation" component={lazy(() => import("./pages/transactions/MaterialReservation"))} />
        <Route path="/transactions/mm-fi-integration-enhancement" component={lazy(() => import("./pages/transactions/MMFIIntegrationEnhancement"))} />
        <Route path="/transactions/overhead-calculation" component={lazy(() => import("./pages/transactions/OverheadCalculation"))} />
        <Route path="/transactions/payment-processing" component={lazy(() => import("./pages/transactions/PaymentProcessing"))} />
        <Route path="/transactions/payment-run" component={lazy(() => import("./pages/transactions/PaymentRun"))} />
        <Route path="/transactions/payroll-processing" component={lazy(() => import("./pages/transactions/PayrollProcessing"))} />
        <Route path="/transactions/period-end-closing" component={lazy(() => import("./pages/transactions/PeriodEndClosing"))} />
        <Route path="/transactions/physical-inventory" component={lazy(() => import("./pages/transactions/PhysicalInventory"))} />
        <Route path="/transactions/pricing-management" component={lazy(() => import("./pages/transactions/PricingManagement"))} />
        <Route path="/transactions/product-costing" component={lazy(() => import("./pages/transactions/ProductCosting"))} />
        <Route path="/transactions/production-order-processing" component={lazy(() => import("./pages/transactions/ProductionOrderProcessing"))} />
        <Route path="/transactions/profit-center-accounting" component={lazy(() => import("./pages/transactions/ProfitCenterAccounting"))} />
        <Route path="/transactions/profit-loss-reporting" component={lazy(() => import("./pages/transactions/ProfitLossReporting"))} />
        <Route path="/transactions/project-accounting" component={lazy(() => import("./pages/transactions/ProjectAccounting"))} />
        <Route path="/transactions/purchase-order" component={lazy(() => import("./pages/transactions/PurchaseOrder"))} />
        <Route path="/transactions/purchase-order-processing" component={lazy(() => import("./pages/transactions/PurchaseOrderProcessing"))} />
        <Route path="/transactions/purchase-requisition" component={lazy(() => import("./pages/transactions/PurchaseRequisition"))} />
        <Route path="/transactions/quality-management" component={lazy(() => import("./pages/transactions/QualityManagement"))} />
        <Route path="/transactions/quotation-management" component={lazy(() => import("./pages/transactions/QuotationManagement"))} />
        <Route path="/transactions/recurring-entries" component={lazy(() => import("./pages/transactions/RecurringEntries"))} />
        <Route path="/transactions/sales-billing" component={lazy(() => import("./pages/transactions/SalesBilling"))} />
        <Route path="/transactions/sales-order" component={lazy(() => import("./pages/transactions/SalesOrder"))} />
        <Route path="/transactions/sd-fi-integration-enhancement" component={lazy(() => import("./pages/transactions/SDFIIntegrationEnhancement"))} />
        <Route path="/transactions/serial-number-management" component={lazy(() => import("./pages/transactions/SerialNumberManagement"))} />
        <Route path="/transactions/serial-number-tracking" component={lazy(() => import("./pages/transactions/SerialNumberTracking"))} />
        <Route path="/transactions/shop-floor-control" component={lazy(() => import("./pages/transactions/ShopFloorControl"))} />
        <Route path="/transactions/stock-transfer" component={lazy(() => import("./pages/transactions/StockTransfer"))} />
        <Route path="/transactions/subcontracting" component={lazy(() => import("./pages/transactions/Subcontracting"))} />
        <Route path="/transactions/supplier-evaluation" component={lazy(() => import("./pages/transactions/SupplierEvaluation"))} />
        <Route path="/transactions/tax-processing" component={lazy(() => import("./pages/transactions/TaxProcessing"))} />
        <Route path="/transactions/tax-reporting" component={lazy(() => import("./pages/transactions/TaxReporting"))} />
        <Route path="/transactions/time-management" component={lazy(() => import("./pages/transactions/TimeManagement"))} />
        <Route path="/transactions/transfer-posting" component={lazy(() => import("./pages/transactions/TransferPosting"))} />
        <Route path="/transactions/validation-substitution" component={lazy(() => import("./pages/transactions/ValidationSubstitution"))} />
        <Route path="/transactions/variance-analysis" component={lazy(() => import("./pages/transactions/VarianceAnalysis"))} />
        <Route path="/transactions/vendor-evaluation" component={lazy(() => import("./pages/transactions/VendorEvaluation"))} />
        <Route path="/transactions/work-center-management" component={lazy(() => import("./pages/transactions/WorkCenterManagement"))} />
        <Route path="/transactions/workflow-management" component={lazy(() => import("./pages/transactions/WorkflowManagement"))} />
        
        {/* Enhanced Transaction Routes */}
        <Route path="/transactions/cash-management-enhanced" component={lazy(() => import("./pages/transactions/CashManagement"))} />
        <Route path="/transactions/tax-reporting-enhanced" component={lazy(() => import("./pages/transactions/TaxReporting"))} />
        <Route path="/transactions/intercompany-transactions-enhanced" component={lazy(() => import("./pages/transactions/IntercompanyTransactions"))} />
        <Route path="/transactions/inventory-valuation-enhanced" component={lazy(() => import("./pages/transactions/InventoryValuation"))} />
        <Route path="/transactions/payment-processing-enhanced" component={lazy(() => import("./pages/transactions/PaymentProcessing"))} />
        <Route path="/transactions/period-end-closing-enhanced" component={lazy(() => import("./pages/transactions/PeriodEndClosing"))} />
        <Route path="/transactions/down-payment-management-enhanced" component={lazy(() => import("./pages/transactions/DownPaymentManagement"))} />
        <Route path="/transactions/recurring-entries-enhanced" component={lazy(() => import("./pages/transactions/RecurringEntries"))} />
        <Route path="/transactions/automatic-clearing-enhanced" component={lazy(() => import("./pages/transactions/AutomaticClearing"))} />
        <Route path="/transactions/asset-accounting-enhanced" component={lazy(() => import("./pages/transactions/AssetAccounting"))} />
        <Route path="/transactions/bank-statement-processing-enhanced" component={lazy(() => import("./pages/transactions/BankStatementProcessing"))} />

        {/* Other modules */}
        <Route path="/help" component={Help} />
        <Route path="/user-guides" component={UserGuides} />
        <Route path="/workspace-manager" component={WorkspaceManager} />
        <Route path="/ai-agents" component={AIAgentsDemo} />
        <Route path="/test-results" component={lazy(() => import("./pages/TestResults"))} />
        <Route path="/issues" component={IssuesMonitoringDashboard} />
        <Route path="/system-integrity" component={SystemIntegrityDashboard} />
        <Route path="/change-log" component={ChangeLogDashboard} />
        <Route path="/sales" component={Sales} />
        <Route path="/sales/leads" component={SalesLeads} />
        <Route path="/sales/opportunities" component={SalesOpportunities} />
        <Route path="/sales/quotes" component={SalesQuotes} />
        <Route path="/sales/quotes/approved" component={SalesQuotes} />
        <Route path="/sales/quote-approval" component={SalesQuoteApproval} />
        <Route path="/sales/orders" component={SalesOrderList} />
        <Route path="/sales/orders/new" component={SalesOrder} />
        <Route path="/inventory" component={Inventory} />
        <Route path="/purchase" component={PurchaseModule} />
        <Route path="/production" component={ProductionModule} />
        <Route path="/hr" component={HR} />
        
        {/* Transaction Process Flows */}
        <Route path="/transactions/sales-order" component={SalesOrderTransaction} />
        <Route path="/transactions/invoice" component={InvoiceTransaction} />
        
        {/* Finance Module and Submodules */}
        <Route path="/finance" component={Finance} />
        <Route path="/finance/configuration" component={FinancialConfiguration} />
        <Route path="/finance/configuration-assistant" component={SimpleFinancialConfig} />
        <Route path="/finance/end-to-end-guide" component={EndToEndFinancialGuide} />
        <Route path="/finance/accounts-receivable" component={AccountsReceivable} />
        <Route path="/finance/accounts-payable" component={AccountsPayable} />
        <Route path="/finance/general-ledger" component={GeneralLedger} />
        <Route path="/controlling" component={Controlling} />
        
        {/* Tools and Utilities */}
        <Route path="/tools" component={Tools} />
        <Route path="/tools/master-data-checker" component={MasterDataChecker} />
        <Route path="/tools/master-data-protection" component={MasterDataProtection} />
        <Route path="/tools/test-application" component={TestApplication} />
        <Route path="/tools/api-tester" component={ApiTester} />
        
        {/* Reports, Upload and Settings */}
        <Route path="/reports" component={Reports} />
        <Route path="/upload" component={Upload} />
        <Route path="/settings" component={SettingsPage} />
        
        {/* 404 Not Found */}
        {/* SD-FI Integration Routes - Order-to-Cash Process */}
        <Route path="/sales/sales-order-management" component={SalesOrderManagement} />
        <Route path="/sales/configuration" component={SalesDistributionConfig} />
        <Route path="/sales/sd-customization" component={SDCustomization} />
        <Route path="/integration/sd-fi-dashboard" component={SDFIIntegrationDashboard} />
        <Route path="/agent-player" component={AgentPlayer} />
        <Route path="/coach-agent" component={CoachAgent} />
        <Route path="/chief-agent" component={ChiefAgent} />
        <Route path="/rookie-agent" component={RookieAgent} />
        <Route path="/designer-agent" component={DesignerAgent} />
        <Route path="/intelligent-testing" component={IntelligentTestingAgent} />
        <Route path="/dominos-pizza-e2e" component={DominosPizzaE2ETesting} />
        <Route path="/coach-agent/health-dashboard" component={CoachAgentHealthDashboard} />
        <Route path="/test-results" component={TestResults} />
        <Route path="/project-test" component={ProjectTest} />
        <Route path="/condition-types" component={lazy(() => import("@/pages/ConditionTypesManagement"))} />
        
        <Route component={NotFound} />
        </Switch>
      </Suspense>
    </AppLayout>
  );
}

// Main App component
export default function App() {
  return (
    <SidebarProvider>
      <QueryClientProvider client={queryClient}>
        <AgentRoleProvider>
          <TooltipProvider>
            <Router />
            <Toaster />
            <JrChatbot />
          </TooltipProvider>
        </AgentRoleProvider>
      </QueryClientProvider>
    </SidebarProvider>
  );
}