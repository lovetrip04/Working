# MallyERP Deployment Guide

## Quick Start Deployment

### 1. Prerequisites
- Node.js 18 or higher
- PostgreSQL 14 or higher
- OpenAI API key

### 2. Database Setup
```bash
# Create database
createdb mallyerp

# Import schema
psql -d mallyerp < database-schema-complete.sql

# Import data
psql -d mallyerp < database-data-complete.sql
```

### 3. Environment Configuration
Create `.env` file:
```
DATABASE_URL=postgresql://username:password@localhost:5432/mallyerp
OPENAI_API_KEY=your_openai_api_key_here
NODE_ENV=production
PORT=5000
```

### 4. Application Deployment
```bash
# Install dependencies
npm install

# Build application
npm run build

# Start production server
npm start
```

### 5. Verification
- Access application at http://localhost:5000
- Verify all modules are functional
- Test AI agents are responding
- Check audit trail system

## Production Considerations

### Security
- Use HTTPS in production
- Configure secure session secrets
- Set up proper firewall rules
- Enable database encryption

### Performance
- Configure database connection pooling
- Set up Redis for session storage
- Enable compression middleware
- Configure proper caching headers

### Monitoring
- Set up application monitoring
- Configure database performance monitoring
- Enable error tracking
- Set up automated backups

## Troubleshooting

### Common Issues
1. **Database Connection Errors**: Check DATABASE_URL format
2. **OpenAI API Errors**: Verify API key and quota
3. **Permission Errors**: Check file system permissions
4. **Port Conflicts**: Ensure PORT is available

### Support
For technical support, please refer to the documentation or contact the development team.
