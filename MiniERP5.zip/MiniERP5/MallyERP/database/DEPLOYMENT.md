# JuneERP Production Deployment Guide

## Quick Start

### 1. System Preparation
```bash
# Verify PostgreSQL installation
psql --version

# Verify Node.js installation  
node --version
npm --version
```

### 2. Database Setup
```bash
# Create database
createdb juneerp

# Restore complete database
cd database
./restore.sh "postgresql://user:pass@localhost:5432/juneerp"
```

### 3. Application Setup
```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with your settings

# Start application
npm run dev
```

### 4. Verification
- Access http://localhost:5173
- Login with admin credentials
- Verify all modules load correctly
- Test finance/ap-tiles functionality

## Production Configuration

### Environment Variables
```bash
# Database
DATABASE_URL=postgresql://user:pass@host:port/juneerp

# Application
NODE_ENV=production
PORT=5000
VITE_PORT=5173

# Security
SESSION_SECRET=your-secure-secret-here

# Features
OPENAI_API_KEY=your-openai-key (optional)
```

### SSL/HTTPS Setup
```bash
# Install SSL certificates
sudo certbot --nginx -d yourdomain.com

# Configure reverse proxy
# Edit nginx configuration for SSL
```

## Monitoring & Maintenance

### Health Checks
```bash
# Database health
psql $DATABASE_URL -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';"

# Application health
curl http://localhost:5000/health

# Memory usage
free -m

# Disk space
df -h
```

### Backup Procedures
```bash
# Daily backup
pg_dump $DATABASE_URL > backup-$(date +%Y%m%d).sql

# Weekly full backup
./create-complete-export.sh
```

Ready for enterprise production deployment!
