import express, { type Request, Response, NextFunction } from "express";
import path from "path";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { errorCaptureMiddleware, responseInterceptor } from "./middleware/realTimeErrorCapture";
// import transactionRoutes from "./routes/transactionRoutes.js";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Serve static files from uploads directory for screenshots
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// Add real-time error capture
app.use(responseInterceptor);

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);
// app.use("/api/transactions", transactionRoutes);

  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    // Capture error immediately with enhanced logging
    errorCaptureMiddleware(err, req, res, next);
    
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, async () => {
    log(`serving on port ${port}`);
    
    // Initialize Rock Agent for system protection
    try {
      const { rockAgent } = await import('./agents/RockAgent.js');
      
      // Perform initial health check
      console.log("🛡️ Initializing Rock Agent system protection...");
      await rockAgent.performSystemHealthCheck();
      
      // Start continuous monitoring every 10 minutes
      rockAgent.startMonitoring(10);
      
      console.log("✅ Rock Agent protection activated");
    } catch (error) {
      console.error("❌ Failed to initialize Rock Agent:", error);
    }
  });
})();
