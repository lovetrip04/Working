/**
 * AI-Powered Module-Specific Agents for MallyERP System
 * Each agent is specialized for their respective module and handles all activities within that domain
 */

import OpenAI from "openai";
import APIKeyManager from "./apiKeyManager.js";
import pkg from 'pg';
const { Pool } = pkg;

let openai = null;
const keyManager = new APIKeyManager();

// Database connection for AI agents to analyze real data
const dbPool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Initialize OpenAI with API key from database or environment
async function initializeOpenAI() {
  try {
    let apiKey = process.env.OPENAI_API_KEY;
    
    // If no environment key, try to get from database
    if (!apiKey) {
      apiKey = await keyManager.getAPIKey('openai');
    }
    
    if (apiKey) {
      openai = new OpenAI({ 
        apiKey,
        timeout: 30000,
        maxRetries: 2
      });
      console.log('OpenAI initialized successfully with key:', apiKey.substring(0, 8) + '...');
      
      // Test the connection
      try {
        await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [{ role: "user", content: "test" }],
          max_tokens: 5
        });
        console.log('OpenAI connection test successful');
        return true;
      } catch (testError) {
        console.error('OpenAI connection test failed:', testError.message);
        return false;
      }
    }
    
    console.log('No OpenAI API key found');
    return false;
  } catch (error) {
    console.error('Error initializing OpenAI:', error);
    return false;
  }
}

// Initialize OpenAI on startup
initializeOpenAI();

// Module-specific agent configurations
const AGENT_CONFIGS = {
  upload: {
    name: "Upload AI Agent",
    role: "Data Import & Validation Specialist", 
    systemPrompt: `You are the Upload AI Agent for the MallyERP system. You specialize in:
    - Validating external data from CSV, Excel, and database imports
    - Detecting null values, format errors, and data inconsistencies
    - Mapping external data to MallyERP table structures
    - Ensuring data accuracy before database updates
    - Providing corrective recommendations for invalid records
    - Validating master data and transactional data integrity
    
    For every upload validation:
    1. Check for required fields and null values
    2. Validate data formats and types
    3. Verify relationships with existing master data
    4. Flag duplicate or conflicting records
    5. Suggest corrections for invalid data
    6. Ensure all records have active flag and datetime timestamp
    
    Always provide detailed validation reports with clear pass/fail status and specific recommendations for data corrections.`,
    expertise: ["csv_import", "excel_import", "data_validation", "error_detection", "external_database_integration"]
  },
  
  masterData: {
    name: "Master Data Agent",
    role: "Expert in master data management including customers, vendors, materials, charts of accounts, cost centers, and organizational structures",
    systemPrompt: `You are a Master Data Management specialist for MallyERP system. You help users with:
    - Customer and vendor master data creation and maintenance
    - Material master data setup and classification
    - Chart of accounts and GL account management
    - Cost center and profit center configuration
    - Organizational structure setup (company codes, plants, storage locations)
    - Data validation and consistency checks
    - Best practices for master data governance
    
    Always provide specific, actionable guidance and ensure data integrity.`,
    expertise: ["customers", "vendors", "materials", "chart_of_accounts", "cost_centers", "profit_centers", "organizational_structure"]
  },
  
  sales: {
    name: "Sales Agent",
    role: "Sales process expert specializing in leads, opportunities, quotes, orders, and customer relationship management",
    systemPrompt: `You are a Sales Management specialist for MallyERP system. You help users with:
    - Lead generation and qualification processes
    - Opportunity management and pipeline tracking
    - Quote and proposal creation
    - Sales order processing and fulfillment
    - Customer relationship management
    - Sales analytics and reporting
    - Pricing strategies and discount management
    - Sales territory and team management
    
    Focus on sales best practices and revenue optimization.`,
    expertise: ["leads", "opportunities", "quotes", "sales_orders", "customers", "pricing", "sales_analytics"]
  },
  
  inventory: {
    name: "Inventory Agent", 
    role: "Inventory management expert for stock control, movements, warehousing, and material planning",
    systemPrompt: `You are an Inventory Management specialist for MallyERP system. You help users with:
    - Stock level monitoring and optimization
    - Inventory movements and transactions
    - Warehouse and storage location management
    - Material requirements planning (MRP)
    - ABC analysis and inventory classification
    - Stock valuation and costing methods
    - Cycle counting and physical inventory
    - Supply chain optimization
    
    Ensure efficient inventory management and cost control.`,
    expertise: ["stock_levels", "inventory_movements", "warehouses", "material_planning", "stock_valuation"]
  },
  
  purchase: {
    name: "Purchase Agent",
    role: "Procurement specialist for purchase orders, vendor management, and supply chain optimization",
    systemPrompt: `You are a Procurement specialist for MallyERP system. You help users with:
    - Purchase requisition and approval workflows
    - Purchase order creation and management
    - Vendor evaluation and selection
    - Contract management and negotiations
    - Goods receipt and invoice verification
    - Purchase analytics and cost optimization
    - Supplier relationship management
    - Strategic sourcing and procurement planning
    
    Focus on cost savings and supplier performance optimization.`,
    expertise: ["purchase_orders", "vendors", "contracts", "goods_receipt", "procurement_analytics"]
  },
  
  production: {
    name: "Production Agent",
    role: "Manufacturing expert for production planning, work centers, BOMs, and shop floor management",
    systemPrompt: `You are a Production Management specialist for MallyERP system. You help users with:
    - Production planning and scheduling
    - Bill of Materials (BOM) management
    - Work center and routing configuration
    - Shop floor control and execution
    - Capacity planning and resource allocation
    - Quality management and control
    - Manufacturing analytics and KPIs
    - Lean manufacturing principles
    
    Optimize production efficiency and quality standards.`,
    expertise: ["production_orders", "bom", "work_centers", "routing", "capacity_planning", "quality_control"]
  },
  
  finance: {
    name: "Finance Agent",
    role: "Financial management expert for accounting, reporting, and financial analysis",
    systemPrompt: `You are a Financial Management specialist for MallyERP system. You help users with:
    - General ledger and journal entries
    - Accounts payable and receivable management
    - Financial reporting and analysis
    - Cash flow management
    - Budget planning and variance analysis
    - Fixed asset management
    - Tax compliance and reporting
    - Financial controls and audit preparation
    
    Ensure financial accuracy and regulatory compliance.`,
    expertise: ["general_ledger", "accounts_payable", "accounts_receivable", "financial_reports", "budgeting"]
  },
  
  controlling: {
    name: "Controlling Agent",
    role: "Management accounting expert for cost analysis, profitability, and performance management",
    systemPrompt: `You are a Controlling specialist for MallyERP system. You help users with:
    - Cost center accounting and allocation
    - Profitability analysis (CO-PA)
    - Internal orders and projects
    - Product costing and calculation
    - Variance analysis and reporting
    - Management reporting and dashboards
    - Performance measurement and KPIs
    - Strategic planning and budgeting
    
    Provide insights for management decision-making and performance optimization.`,
    expertise: ["cost_centers", "profitability_analysis", "variance_analysis", "product_costing", "management_reporting"]
  }
};

class ERPAgent {
  constructor(moduleType) {
    this.config = AGENT_CONFIGS[moduleType];
    this.moduleType = moduleType;
    
    if (!this.config) {
      throw new Error(`Unknown module type: ${moduleType}`);
    }
  }

  // Fetch actual data from database for analysis
  async fetchModuleData() {
    try {
      const queries = {
        masterData: `
          SELECT 
            (SELECT COUNT(*) FROM materials) as materials_count,
            (SELECT COUNT(*) FROM customers) as customers_count,
            (SELECT COUNT(*) FROM vendors) as vendors_count,
            (SELECT COUNT(*) FROM cost_centers) as cost_centers_count,
            (SELECT COUNT(*) FROM profit_centers) as profit_centers_count
        `,
        sales: `
          SELECT 
            (SELECT COUNT(*) FROM sales_orders) as orders_count,
            (SELECT COUNT(*) FROM leads) as leads_count,
            (SELECT COUNT(*) FROM opportunities) as opportunities_count,
            (SELECT COUNT(*) FROM quotes) as quotes_count
        `,
        inventory: `
          SELECT 
            (SELECT COUNT(*) FROM materials) as materials_count,
            (SELECT COUNT(*) FROM stock_movements) as movements_count,
            (SELECT COUNT(*) FROM storage_locations) as storage_locations_count
        `,
        finance: `
          SELECT 
            (SELECT COUNT(*) FROM journal_entries) as journal_entries_count,
            (SELECT COUNT(*) FROM expenses) as expenses_count,
            (SELECT COUNT(*) FROM gl_accounts) as gl_accounts_count
        `,
        controlling: `
          SELECT 
            (SELECT COUNT(*) FROM cost_centers) as cost_centers_count,
            (SELECT COUNT(*) FROM profit_centers) as profit_centers_count,
            (SELECT COUNT(*) FROM journal_entries) as journal_entries_count
        `
      };

      const query = queries[this.moduleType] || queries.masterData;
      const result = await dbPool.query(query);
      return result.rows[0] || {};
    } catch (error) {
      console.error(`Error fetching ${this.moduleType} data:`, error);
      return {};
    }
  }

  async processQuery(userQuery, context = {}) {
    try {
      // Check if OpenAI is available, try to reinitialize if not
      if (!openai) {
        const initialized = await initializeOpenAI();
        if (!initialized) {
          return {
            success: false,
            error: "AI_KEY_MISSING",
            response: "Analysis requires AI configuration. Please provide an OpenAI API key to enable data analysis features.",
            agent: this.config.name,
            module: this.moduleType,
            fallback: this.getFallbackResponse(userQuery)
          };
        }
      }

      const systemMessage = {
        role: "system",
        content: `${this.config.systemPrompt}
        
        Module: ${this.config.name}
        Expertise Areas: ${this.config.expertise.join(", ")}
        
        Context Information:
        ${context.currentData ? `Current Data: ${JSON.stringify(context.currentData, null, 2)}` : ""}
        ${context.userRole ? `User Role: ${context.userRole}` : ""}
        ${context.currentModule ? `Current Module: ${context.currentModule}` : ""}
        
        Provide helpful, accurate, and actionable responses. Format your response in a clear, professional manner.
        If the query is outside your expertise area, politely redirect to the appropriate module specialist.`
      };

      const userMessage = {
        role: "user", 
        content: userQuery
      };

      console.log(`Processing query for ${this.moduleType} agent: ${userQuery.substring(0, 50)}...`);
      
      // Fetch real database data for comprehensive analysis
      const realData = await this.fetchModuleData();
      
      // Enhanced user message with actual database context
      const enhancedUserMessage = {
        role: "user",
        content: `${userQuery}

Current ERP System Status:
${JSON.stringify(realData, null, 2)}

Please provide specific insights based on this actual data from the system.`
      };

      // Use reliable OpenAI configuration
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [systemMessage, enhancedUserMessage],
        max_tokens: 600,
        temperature: 0.7
      });
      
      console.log(`OpenAI response received for ${this.moduleType} agent`);

      return {
        success: true,
        response: response.choices[0].message.content,
        agent: this.config.name,
        module: this.moduleType
      };

    } catch (error) {
      console.error(`Error in ${this.config.name}:`, error);
      return {
        success: false,
        error: error.message,
        agent: this.config.name,
        module: this.moduleType,
        fallback: this.getFallbackResponse(userQuery)
      };
    }
  }

  getFallbackResponse(query) {
    const commonQuestions = {
      'help': `I can assist you with ${this.moduleType} processes. Here are the main areas I cover: ${this.config.expertise.join(", ").replace(/_/g, " ")}`,
      'process': `For ${this.moduleType} processes, I recommend following standard MallyERP workflows and ensuring data validation at each step.`,
      'best practice': `Best practices for ${this.moduleType} include maintaining data consistency, following approval workflows, and regular monitoring of key metrics.`,
      'error': `For troubleshooting ${this.moduleType} issues, check data validation, user permissions, and system configuration settings.`
    };

    const lowerQuery = query.toLowerCase();
    for (const [key, response] of Object.entries(commonQuestions)) {
      if (lowerQuery.includes(key)) {
        return response;
      }
    }

    return `I understand you're asking about ${this.moduleType}. While I need an API key for detailed responses, I can tell you that this module handles: ${this.config.expertise.slice(0, 3).join(", ").replace(/_/g, " ")}.`;
  }

  async analyzeData(data, analysisType = "general") {
    try {
      // Check if OpenAI is available, try to reinitialize if not
      if (!openai) {
        const initialized = await initializeOpenAI();
        if (!initialized) {
          return {
            success: false,
            error: "AI_KEY_MISSING",
            analysis: "Analysis requires AI configuration. Please provide an OpenAI API key to enable data analysis features.",
            agent: this.config.name,
            module: this.moduleType,
            analysisType
          };
        }
      }

      // Fetch actual database data for comprehensive analysis
      const realData = await this.fetchModuleData();
      const combinedData = { ...data, ...realData };

      const systemMessage = {
        role: "system",
        content: `${this.config.systemPrompt}
        
        You are analyzing real ${this.moduleType} data from MallyERP system. Provide insights, identify patterns, and suggest improvements.
        Analysis Type: ${analysisType}
        
        Focus on:
        - Key performance indicators relevant to ${this.moduleType}
        - Data quality and consistency issues
        - Optimization opportunities
        - Best practice recommendations
        - Risk factors or concerns
        - Growth trends and operational efficiency
        
        Provide a structured analysis with specific, actionable recommendations based on the actual data.`
      };

      const userMessage = {
        role: "user",
        content: `Please analyze this ${this.moduleType} ERP data and provide comprehensive insights:
        
        Current System Data: ${JSON.stringify(combinedData, null, 2)}
        
        Analysis Type: ${analysisType}
        
        Please provide specific insights about the current state, potential issues, and actionable recommendations for improvement.`
      };

      console.log(`Starting OpenAI analysis for ${this.moduleType} module`);

      // Use more efficient model and shorter prompts to prevent timeouts
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [systemMessage, userMessage],
        max_tokens: 500,
        temperature: 0.3
      });

      console.log(`OpenAI analysis completed for ${this.moduleType} module`);

      return {
        success: true,
        analysis: response.choices[0].message.content,
        agent: this.config.name,
        module: this.moduleType,
        analysisType
      };

    } catch (error) {
      console.error(`Error in ${this.config.name} analysis:`, error);
      return {
        success: false,
        error: error.message,
        agent: this.config.name,
        module: this.moduleType
      };
    }
  }

  async validateData(data, validationType = "standard") {
    try {
      // Check if OpenAI is available, try to reinitialize if not
      if (!openai) {
        const initialized = await initializeOpenAI();
        if (!initialized) {
          return {
            success: false,
            error: "AI_KEY_MISSING",
            validation: "Validation requires AI configuration. Please provide an OpenAI API key to enable data validation features.",
            agent: this.config.name,
            module: this.moduleType,
            validationType
          };
        }
      }

      const systemMessage = {
        role: "system",
        content: `${this.config.systemPrompt}
        
        You are validating ${this.moduleType} data for correctness, completeness, and compliance.
        Validation Type: ${validationType}
        
        Check for:
        - Required field completeness
        - Data format and type validation
        - Business rule compliance
        - Cross-reference consistency
        - Best practice adherence
        
        Provide specific validation results with clear pass/fail status and recommendations.`
      };

      const userMessage = {
        role: "user",
        content: `Please validate this ${this.moduleType} data:
        
        Data: ${JSON.stringify(data, null, 2)}
        
        Validation type: ${validationType}`
      };

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [systemMessage, userMessage],
        max_tokens: 1200,
        temperature: 0.2
      });

      return {
        success: true,
        validation: response.choices[0].message.content,
        agent: this.config.name,
        module: this.moduleType,
        validationType
      };

    } catch (error) {
      console.error(`Error in ${this.config.name} validation:`, error);
      return {
        success: false,
        error: error.message,
        agent: this.config.name,
        module: this.moduleType
      };
    }
  }

  getCapabilities() {
    return {
      name: this.config.name,
      role: this.config.role,
      expertise: this.config.expertise,
      module: this.moduleType,
      capabilities: [
        "Query Processing",
        "Data Analysis", 
        "Data Validation",
        "Process Guidance",
        "Best Practice Recommendations"
      ]
    };
  }
}

// Agent factory function
export const createAgent = (moduleType) => {
  return new ERPAgent(moduleType);
};

// Get all available agents
export const getAvailableAgents = () => {
  return Object.keys(AGENT_CONFIGS).map(moduleType => ({
    moduleType,
    name: AGENT_CONFIGS[moduleType].name,
    role: AGENT_CONFIGS[moduleType].role,
    expertise: AGENT_CONFIGS[moduleType].expertise
  }));
};

export default ERPAgent;