import express from 'express';
import { pool } from '../db.js';

const router = express.Router();

// Initialize controlling module
router.post('/initialize', async (req, res) => {
  try {
    // Create controlling tables if they don't exist
    await pool.query(`
      CREATE TABLE IF NOT EXISTS cost_centers (
        id SERIAL PRIMARY KEY,
        cost_center VARCHAR(20) UNIQUE NOT NULL,
        description VARCHAR(255) NOT NULL,
        cost_center_category VARCHAR(50) NOT NULL,
        hierarchy_area VARCHAR(100),
        valid_from DATE DEFAULT CURRENT_DATE,
        valid_to DATE,
        company_code VARCHAR(4) DEFAULT '1000',
        controlling_area VARCHAR(4) DEFAULT 'A000',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS cost_center_planning (
        id SERIAL PRIMARY KEY,
        cost_center VARCHAR(20) NOT NULL,
        fiscal_year INTEGER NOT NULL,
        period INTEGER NOT NULL,
        account VARCHAR(10) NOT NULL,
        activity_type VARCHAR(20),
        planned_amount DECIMAL(15,2) DEFAULT 0,
        planned_quantity DECIMAL(15,3) DEFAULT 0,
        currency VARCHAR(3) DEFAULT 'USD',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (cost_center) REFERENCES cost_centers(cost_center)
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS cost_center_actuals (
        id SERIAL PRIMARY KEY,
        cost_center VARCHAR(20) NOT NULL,
        fiscal_year INTEGER NOT NULL,
        period INTEGER NOT NULL,
        account VARCHAR(10) NOT NULL,
        activity_type VARCHAR(20),
        actual_amount DECIMAL(15,2) DEFAULT 0,
        actual_quantity DECIMAL(15,3) DEFAULT 0,
        currency VARCHAR(3) DEFAULT 'USD',
        posting_date DATE DEFAULT CURRENT_DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (cost_center) REFERENCES cost_centers(cost_center)
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS profit_centers (
        id SERIAL PRIMARY KEY,
        profit_center VARCHAR(20) UNIQUE NOT NULL,
        description VARCHAR(255) NOT NULL,
        profit_center_category VARCHAR(50) NOT NULL,
        valid_from DATE DEFAULT CURRENT_DATE,
        valid_to DATE,
        company_code VARCHAR(4) DEFAULT '1000',
        controlling_area VARCHAR(4) DEFAULT 'A000',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Insert sample cost centers if empty
    const costCenterCount = await pool.query('SELECT COUNT(*) FROM cost_centers');
    if (parseInt(costCenterCount.rows[0].count) === 0) {
      await pool.query(`
        INSERT INTO cost_centers (cost_center, description, cost_center_category, hierarchy_area) VALUES
        ('CC-PROD-001', 'Assembly Line 1', 'PRODUCTION', 'Manufacturing'),
        ('CC-PROD-002', 'Assembly Line 2', 'PRODUCTION', 'Manufacturing'),
        ('CC-QC-001', 'Quality Control', 'PRODUCTION', 'Manufacturing'),
        ('CC-MAINT-001', 'Maintenance', 'SERVICE', 'Manufacturing'),
        ('CC-IT-001', 'IT Services', 'SERVICE', 'Support'),
        ('CC-HR-001', 'HR Services', 'ADMINISTRATIVE', 'Support'),
        ('CC-FAC-001', 'Facility Management', 'SERVICE', 'Support'),
        ('CC-FIN-001', 'Finance & Accounting', 'ADMINISTRATIVE', 'Corporate'),
        ('CC-MGT-001', 'General Management', 'ADMINISTRATIVE', 'Corporate'),
        ('CC-SALES-001', 'Sales & Marketing', 'SALES', 'Commercial')
      `);
    }

    // Insert sample planning data
    const planningCount = await pool.query('SELECT COUNT(*) FROM cost_center_planning');
    if (parseInt(planningCount.rows[0].count) === 0) {
      const costCenters = await pool.query('SELECT cost_center FROM cost_centers');
      for (const cc of costCenters.rows) {
        await pool.query(`
          INSERT INTO cost_center_planning (cost_center, fiscal_year, period, account, planned_amount) VALUES
          ($1, 2025, 6, '400000', ${Math.floor(Math.random() * 8000) + 12000}),
          ($1, 2025, 6, '410000', ${Math.floor(Math.random() * 3000) + 5000}),
          ($1, 2025, 6, '420000', ${Math.floor(Math.random() * 2000) + 3000})
        `, [cc.cost_center]);
      }
    }

    // Insert sample actual data
    const actualCount = await pool.query('SELECT COUNT(*) FROM cost_center_actuals');
    if (parseInt(actualCount.rows[0].count) === 0) {
      const costCenters = await pool.query('SELECT cost_center FROM cost_centers');
      for (const cc of costCenters.rows) {
        await pool.query(`
          INSERT INTO cost_center_actuals (cost_center, fiscal_year, period, account, actual_amount, posting_date) VALUES
          ($1, 2025, 6, '400000', ${Math.floor(Math.random() * 7000) + 11000}, '2025-06-01'),
          ($1, 2025, 6, '410000', ${Math.floor(Math.random() * 2500) + 4800}, '2025-06-01'),
          ($1, 2025, 6, '420000', ${Math.floor(Math.random() * 1800) + 2900}, '2025-06-01')
        `, [cc.cost_center]);
      }
    }

    res.json({ message: 'Controlling module initialized successfully' });
  } catch (error) {
    console.error('Error initializing controlling module:', error);
    res.status(500).json({ error: 'Failed to initialize controlling module' });
  }
});

// Get cost centers with aggregated data
router.get('/cost-centers', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        cc.id,
        cc.cost_center,
        cc.description,
        cc.cost_center_category,
        cc.hierarchy_area,
        COALESCE(SUM(ccp.planned_amount), 0) as total_planned,
        COALESCE(SUM(cca.actual_amount), 0) as total_actual,
        COUNT(DISTINCT ccp.id) as planning_entries,
        COUNT(DISTINCT cca.id) as actual_entries
      FROM cost_centers cc
      LEFT JOIN cost_center_planning ccp ON cc.cost_center = ccp.cost_center
      LEFT JOIN cost_center_actuals cca ON cc.cost_center = cca.cost_center
      GROUP BY cc.id, cc.cost_center, cc.description, cc.cost_center_category, cc.hierarchy_area
      ORDER BY cc.cost_center
    `);

    res.json({ cost_centers: result.rows });
  } catch (error) {
    console.error('Error fetching cost centers:', error);
    res.status(500).json({ error: 'Failed to fetch cost centers' });
  }
});

// Generate variance analysis
router.post('/variance-analysis/:year/:period', async (req, res) => {
  try {
    const { year, period } = req.params;
    
    const result = await pool.query(`
      SELECT 
        cc.cost_center,
        cc.description,
        cc.cost_center_category,
        COALESCE(SUM(ccp.planned_amount), 0) as planned_amount,
        COALESCE(SUM(cca.actual_amount), 0) as actual_amount,
        COALESCE(SUM(cca.actual_amount), 0) - COALESCE(SUM(ccp.planned_amount), 0) as variance_amount,
        CASE 
          WHEN COALESCE(SUM(ccp.planned_amount), 0) = 0 THEN 0
          ELSE ROUND(((COALESCE(SUM(cca.actual_amount), 0) - COALESCE(SUM(ccp.planned_amount), 0)) / COALESCE(SUM(ccp.planned_amount), 0) * 100)::numeric, 2)
        END as variance_percentage
      FROM cost_centers cc
      LEFT JOIN cost_center_planning ccp ON cc.cost_center = ccp.cost_center 
        AND ccp.fiscal_year = $1 AND ccp.period = $2
      LEFT JOIN cost_center_actuals cca ON cc.cost_center = cca.cost_center 
        AND cca.fiscal_year = $1 AND cca.period = $2
      GROUP BY cc.cost_center, cc.description, cc.cost_center_category
      HAVING COALESCE(SUM(ccp.planned_amount), 0) > 0 OR COALESCE(SUM(cca.actual_amount), 0) > 0
      ORDER BY ABS(COALESCE(SUM(cca.actual_amount), 0) - COALESCE(SUM(ccp.planned_amount), 0)) DESC
    `, [parseInt(year), parseInt(period)]);

    res.json({ variance_analysis: result.rows });
  } catch (error) {
    console.error('Error generating variance analysis:', error);
    res.status(500).json({ error: 'Failed to generate variance analysis' });
  }
});

// Get CO-PA (profitability analysis) data
router.get('/copa/:year/:period', async (req, res) => {
  try {
    const { year, period } = req.params;
    
    // Generate sample CO-PA data (in real system, this would come from sales/billing data)
    const copaData = [
      {
        customer_group: 'Manufacturing',
        product_group: 'Industrial Equipment',
        sales_organization: 'US East',
        profit_center: 'PC-MFG-001',
        revenue: 750000,
        cogs: 450000,
        gross_margin: 300000,
        operating_expenses: 125000,
        operating_profit: 175000,
        transactions: 156
      },
      {
        customer_group: 'Retail',
        product_group: 'Consumer Electronics',
        sales_organization: 'US West',
        profit_center: 'PC-SALES-W',
        revenue: 650000,
        cogs: 390000,
        gross_margin: 260000,
        operating_expenses: 110000,
        operating_profit: 150000,
        transactions: 234
      },
      {
        customer_group: 'Wholesale',
        product_group: 'Components',
        sales_organization: 'US Central',
        profit_center: 'PC-SALES-C',
        revenue: 480000,
        cogs: 288000,
        gross_margin: 192000,
        operating_expenses: 85000,
        operating_profit: 107000,
        transactions: 89
      },
      {
        customer_group: 'Government',
        product_group: 'Specialized Equipment',
        sales_organization: 'Federal',
        profit_center: 'PC-GOV-001',
        revenue: 920000,
        cogs: 552000,
        gross_margin: 368000,
        operating_expenses: 165000,
        operating_profit: 203000,
        transactions: 67
      },
      {
        customer_group: 'International',
        product_group: 'Export Products',
        sales_organization: 'Export',
        profit_center: 'PC-EXP-001',
        revenue: 320000,
        cogs: 192000,
        gross_margin: 128000,
        operating_expenses: 58000,
        operating_profit: 70000,
        transactions: 45
      }
    ];

    res.json({ profitability_analysis: copaData });
  } catch (error) {
    console.error('Error fetching CO-PA data:', error);
    res.status(500).json({ error: 'Failed to fetch CO-PA data' });
  }
});

// Create cost center planning
router.post('/cost-center-planning', async (req, res) => {
  try {
    const { cost_center, fiscal_year, period, planning_data } = req.body;

    for (const data of planning_data) {
      await pool.query(`
        INSERT INTO cost_center_planning 
        (cost_center, fiscal_year, period, account, activity_type, planned_amount, planned_quantity, currency)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        ON CONFLICT (cost_center, fiscal_year, period, account, COALESCE(activity_type, ''))
        DO UPDATE SET 
          planned_amount = EXCLUDED.planned_amount,
          planned_quantity = EXCLUDED.planned_quantity,
          updated_at = CURRENT_TIMESTAMP
      `, [
        cost_center, 
        fiscal_year, 
        period, 
        data.account, 
        data.activity_type, 
        data.planned_amount, 
        data.planned_quantity, 
        data.currency
      ]);
    }

    res.json({ message: 'Cost center planning created successfully' });
  } catch (error) {
    console.error('Error creating cost center planning:', error);
    res.status(500).json({ error: 'Failed to create cost center planning' });
  }
});

export default router;