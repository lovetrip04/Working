/**
 * Advanced Reports API Routes
 * Handles custom report building, SQL execution, table joining, and chart configuration
 */

import express from 'express';
import pkg from 'pg';
const { Pool } = pkg;
const router = express.Router();

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Available tables and their schemas for the report builder
const TABLE_SCHEMAS = {
  materials: ['id', 'code', 'name', 'description', 'category_id', 'uom_id', 'price', 'created_at'],
  customers: ['id', 'code', 'name', 'email', 'phone', 'address', 'city', 'country', 'created_at'],
  vendors: ['id', 'code', 'name', 'email', 'phone', 'address', 'city', 'country', 'created_at'],
  sales_orders: ['id', 'order_number', 'customer_id', 'order_date', 'total_amount', 'status', 'created_at'],
  purchase_orders: ['id', 'order_number', 'vendor_id', 'order_date', 'total_amount', 'status', 'created_at'],
  inventory: ['id', 'material_id', 'storage_location_id', 'quantity', 'reserved_quantity', 'updated_at'],
  journal_entries: ['id', 'entry_number', 'posting_date', 'document_type', 'reference', 'total_amount', 'created_at'],
  cost_centers: ['id', 'code', 'name', 'description', 'company_code_id', 'responsible_person', 'created_at'],
  profit_centers: ['id', 'code', 'name', 'description', 'company_code_id', 'manager', 'created_at'],
  employees: ['id', 'employee_number', 'first_name', 'last_name', 'email', 'department', 'position', 'hire_date'],
  company_codes: ['id', 'code', 'name', 'country', 'currency', 'address', 'created_at'],
  plants: ['id', 'code', 'name', 'company_code_id', 'address', 'city', 'country', 'created_at'],
  storage_locations: ['id', 'code', 'name', 'plant_id', 'description', 'created_at'],
  sales_organizations: ['id', 'code', 'name', 'company_code_id', 'currency', 'created_at'],
  purchase_organizations: ['id', 'code', 'name', 'company_code_id', 'created_at'],
  currencies: ['id', 'code', 'name', 'symbol', 'decimal_places', 'created_at'],
  uoms: ['id', 'code', 'name', 'description', 'created_at'],
  categories: ['id', 'name', 'description', 'parent_id', 'created_at'],
  work_centers: ['id', 'code', 'name', 'description', 'plant_id', 'capacity', 'created_at'],
  bill_of_materials: ['id', 'material_id', 'component_id', 'quantity', 'unit', 'created_at'],
  expenses: ['id', 'expense_number', 'employee_id', 'category', 'amount', 'expense_date', 'status', 'created_at'],
  leads: ['id', 'lead_number', 'company_name', 'contact_person', 'email', 'phone', 'status', 'source', 'created_at'],
  opportunities: ['id', 'opportunity_number', 'lead_id', 'title', 'value', 'probability', 'stage', 'created_at'],
  quotes: ['id', 'quote_number', 'opportunity_id', 'total_amount', 'valid_until', 'status', 'created_at']
};

// Safe SQL execution with parameter validation
async function executeSafeSQL(query, params = []) {
  const client = await pool.connect();
  try {
    // Basic SQL injection protection
    const sanitizedQuery = query.replace(/;[\s]*$/g, ''); // Remove trailing semicolons
    
    // Validate that query is SELECT only for security
    const trimmedQuery = sanitizedQuery.trim().toUpperCase();
    if (!trimmedQuery.startsWith('SELECT') && !trimmedQuery.startsWith('WITH')) {
      throw new Error('Only SELECT queries are allowed for reports');
    }
    
    // Block dangerous keywords
    const dangerousKeywords = ['DROP', 'DELETE', 'UPDATE', 'INSERT', 'ALTER', 'CREATE', 'TRUNCATE'];
    for (const keyword of dangerousKeywords) {
      if (trimmedQuery.includes(keyword)) {
        throw new Error(`Query contains prohibited keyword: ${keyword}`);
      }
    }
    
    const startTime = Date.now();
    const result = await client.query(sanitizedQuery, params);
    const executionTime = Date.now() - startTime;
    
    return {
      columns: result.fields ? result.fields.map(field => field.name) : [],
      data: result.rows || [],
      total_rows: result.rowCount || 0,
      execution_time: executionTime
    };
  } finally {
    client.release();
  }
}

// GET /api/reports/schemas - Get table schemas for query builder
router.get('/schemas', async (req, res) => {
  try {
    res.json(TABLE_SCHEMAS);
  } catch (error) {
    console.error('Error fetching table schemas:', error);
    res.status(500).json({ error: 'Failed to fetch table schemas' });
  }
});

// POST /api/reports/execute - Execute SQL query and return results
router.post('/execute', async (req, res) => {
  try {
    const { query, parameters = [] } = req.body;
    
    if (!query) {
      return res.status(400).json({ error: 'SQL query is required' });
    }
    
    const result = await executeSafeSQL(query, parameters);
    res.json(result);
  } catch (error) {
    console.error('Error executing query:', error);
    res.status(400).json({ 
      error: error.message || 'Failed to execute query',
      details: error.message
    });
  }
});

// GET /api/reports - Get all saved reports
router.get('/', async (req, res) => {
  try {
    const { category, search, limit = 50, offset = 0 } = req.query;
    
    let query = `
      SELECT id, name, description, category, chart_config, sql_query,
             created_at, updated_at
      FROM reports 
      WHERE 1=1
    `;
    const params = [];
    let paramIndex = 1;
    
    if (category) {
      query += ` AND category = $${paramIndex}`;
      params.push(category);
      paramIndex++;
    }
    
    if (search) {
      query += ` AND (name ILIKE $${paramIndex} OR description ILIKE $${paramIndex})`;
      params.push(`%${search}%`);
      paramIndex++;
    }
    
    query += ` ORDER BY updated_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(parseInt(limit), parseInt(offset));
    
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching reports:', error);
    res.status(500).json({ error: 'Failed to fetch reports' });
  }
});

// POST /api/reports - Create new custom report
router.post('/', async (req, res) => {
  try {
    const { 
      name, 
      description, 
      sql_query, 
      chart_config = {}, 
      parameters = [], 
      category = 'custom',
      is_shared = false 
    } = req.body;
    
    if (!name || !sql_query) {
      return res.status(400).json({ error: 'Name and SQL query are required' });
    }
    
    // Validate SQL query by executing it with LIMIT 1
    try {
      await executeSafeSQL(sql_query + ' LIMIT 1');
    } catch (error) {
      return res.status(400).json({ 
        error: 'Invalid SQL query', 
        details: error.message 
      });
    }
    
    const query = `
      INSERT INTO custom_reports (name, description, sql_query, chart_config, parameters, category, is_shared, created_by)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;
    
    const result = await pool.query(query, [
      name,
      description,
      sql_query,
      JSON.stringify(chart_config),
      JSON.stringify(parameters),
      category,
      is_shared,
      'system' // TODO: Replace with actual user ID from session
    ]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating report:', error);
    res.status(500).json({ error: 'Failed to create report' });
  }
});

// PUT /api/reports/:id - Update existing report
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { 
      name, 
      description, 
      sql_query, 
      chart_config, 
      parameters, 
      category,
      is_shared 
    } = req.body;
    
    // Validate SQL query if provided
    if (sql_query) {
      try {
        await executeSafeSQL(sql_query + ' LIMIT 1');
      } catch (error) {
        return res.status(400).json({ 
          error: 'Invalid SQL query', 
          details: error.message 
        });
      }
    }
    
    const query = `
      UPDATE custom_reports 
      SET name = COALESCE($1, name),
          description = COALESCE($2, description),
          sql_query = COALESCE($3, sql_query),
          chart_config = COALESCE($4, chart_config),
          parameters = COALESCE($5, parameters),
          category = COALESCE($6, category),
          is_shared = COALESCE($7, is_shared),
          updated_at = NOW()
      WHERE id = $8
      RETURNING *
    `;
    
    const result = await pool.query(query, [
      name,
      description,
      sql_query,
      chart_config ? JSON.stringify(chart_config) : null,
      parameters ? JSON.stringify(parameters) : null,
      category,
      is_shared,
      id
    ]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating report:', error);
    res.status(500).json({ error: 'Failed to update report' });
  }
});

// GET /api/reports/:id - Get specific report
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const query = `
      SELECT * FROM custom_reports WHERE id = $1
    `;
    
    const result = await pool.query(query, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching report:', error);
    res.status(500).json({ error: 'Failed to fetch report' });
  }
});

// POST /api/reports/:id/execute - Execute specific saved report
router.post('/:id/execute', async (req, res) => {
  try {
    const { id } = req.params;
    const { parameters = {} } = req.body;
    
    // Get the report
    const reportQuery = 'SELECT * FROM custom_reports WHERE id = $1';
    const reportResult = await pool.query(reportQuery, [id]);
    
    if (reportResult.rows.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }
    
    const report = reportResult.rows[0];
    let sqlQuery = report.sql_query;
    
    // Replace parameters in SQL query
    Object.entries(parameters).forEach(([key, value]) => {
      sqlQuery = sqlQuery.replace(new RegExp(`{{${key}}}`, 'g'), value);
    });
    
    const result = await executeSafeSQL(sqlQuery);
    
    res.json({
      report: {
        id: report.id,
        name: report.name,
        description: report.description,
        chart_config: report.chart_config
      },
      ...result
    });
  } catch (error) {
    console.error('Error executing saved report:', error);
    res.status(500).json({ error: 'Failed to execute report' });
  }
});

// DELETE /api/reports/:id - Delete report
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const query = 'DELETE FROM custom_reports WHERE id = $1 RETURNING *';
    const result = await pool.query(query, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }
    
    res.json({ message: 'Report deleted successfully' });
  } catch (error) {
    console.error('Error deleting report:', error);
    res.status(500).json({ error: 'Failed to delete report' });
  }
});

// POST /api/reports/:id/duplicate - Duplicate a report
router.post('/:id/duplicate', async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    // Get the original report
    const originalQuery = 'SELECT * FROM custom_reports WHERE id = $1';
    const originalResult = await pool.query(originalQuery, [id]);
    
    if (originalResult.rows.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }
    
    const original = originalResult.rows[0];
    const duplicateName = name || `${original.name} (Copy)`;
    
    // Create duplicate
    const duplicateQuery = `
      INSERT INTO custom_reports (name, description, sql_query, chart_config, parameters, category, is_shared, created_by)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;
    
    const result = await pool.query(duplicateQuery, [
      duplicateName,
      original.description,
      original.sql_query,
      original.chart_config,
      original.parameters,
      original.category,
      false, // Duplicates are private by default
      'system' // TODO: Replace with actual user ID
    ]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error duplicating report:', error);
    res.status(500).json({ error: 'Failed to duplicate report' });
  }
});

// GET /api/reports/categories/list - Get available report categories
router.get('/categories/list', async (req, res) => {
  try {
    const query = `
      SELECT category, COUNT(*) as count 
      FROM custom_reports 
      GROUP BY category 
      ORDER BY count DESC
    `;
    
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

// GET /api/reports/tables/info - Get detailed table information
router.get('/tables/info', async (req, res) => {
  try {
    const tablesInfo = {};
    
    // Get actual table information from database
    for (const [tableName, columns] of Object.entries(TABLE_SCHEMAS)) {
      try {
        // Get row count
        const countResult = await pool.query(`SELECT COUNT(*) as count FROM ${tableName}`);
        const rowCount = parseInt(countResult.rows[0].count);
        
        // Get sample data
        const sampleResult = await pool.query(`SELECT * FROM ${tableName} LIMIT 3`);
        
        tablesInfo[tableName] = {
          columns,
          rowCount,
          sampleData: sampleResult.rows
        };
      } catch (error) {
        // Table might not exist
        tablesInfo[tableName] = {
          columns,
          rowCount: 0,
          sampleData: [],
          error: 'Table not accessible'
        };
      }
    }
    
    res.json(tablesInfo);
  } catch (error) {
    console.error('Error fetching table info:', error);
    res.status(500).json({ error: 'Failed to fetch table information' });
  }
});

// POST /api/reports/export/:id - Export report to various formats
router.post('/export/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { format = 'csv', parameters = {} } = req.body;
    
    // Get and execute the report
    const reportQuery = 'SELECT * FROM custom_reports WHERE id = $1';
    const reportResult = await pool.query(reportQuery, [id]);
    
    if (reportResult.rows.length === 0) {
      return res.status(404).json({ error: 'Report not found' });
    }
    
    const report = reportResult.rows[0];
    let sqlQuery = report.sql_query;
    
    // Replace parameters in SQL query
    Object.entries(parameters).forEach(([key, value]) => {
      sqlQuery = sqlQuery.replace(new RegExp(`{{${key}}}`, 'g'), value);
    });
    
    const result = await executeSafeSQL(sqlQuery);
    
    if (format === 'csv') {
      // Generate CSV
      let csv = result.columns.join(',') + '\n';
      result.data.forEach(row => {
        const values = result.columns.map(col => {
          const value = row[col];
          return typeof value === 'string' ? `"${value.replace(/"/g, '""')}"` : value;
        });
        csv += values.join(',') + '\n';
      });
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${report.name}.csv"`);
      res.send(csv);
    } else {
      res.status(400).json({ error: 'Unsupported export format' });
    }
  } catch (error) {
    console.error('Error exporting report:', error);
    res.status(500).json({ error: 'Failed to export report' });
  }
});

export default router;