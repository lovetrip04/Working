import { Router, Request, Response } from "express";
import { storage } from "../../storage";

const router = Router();

// Get all vendors with organizational relationships
router.get("/", async (req: Request, res: Response) => {
  try {
    // Return sample data for our ERP vendors with organizational relationships
    const sampleVendors = [
      {
        id: 1,
        vendor_code: "V1001",
        name: "Prime Steel Supply",
        type: "supplier",
        description: "Steel and metal supplier",
        tax_id: "PS-12345",
        industry: "manufacturing",
        address: "100 Industrial Road",
        city: "Pittsburgh",
        state: "PA",
        country: "US",
        postal_code: "15222",
        phone: "+1-412-555-1111",
        email: "orders@primesteelsupply.com",
        currency: "USD",
        payment_terms: "net_30",
        supplier_type: "manufacturer",
        category: "strategic",
        lead_time: 14,
        evaluation_score: 92,
        status: "active",
        company_code_id: 2,
        company_code: "2000 - US Operations",
        purchase_organization_id: 1,
        purchase_organization: "2000 - US Purchasing",
        purchasing_group_id: 1,
        purchasing_group: "101 - Raw Materials",
        is_active: true,
        created_at: new Date(2023, 1, 10).toISOString(),
        updated_at: new Date(2023, 10, 15).toISOString()
      },
      {
        id: 2,
        vendor_code: "V1002",
        name: "Quality Electronics",
        type: "supplier",
        description: "Electronic components supplier",
        tax_id: "QE-67890",
        industry: "electronics",
        address: "200 Tech Avenue",
        city: "San Jose", 
        state: "CA",
        country: "US",
        postal_code: "95110",
        phone: "+1-408-555-2222",
        email: "sales@qualityelectronics.com",
        currency: "USD",
        payment_terms: "net_45",
        supplier_type: "distributor",
        category: "preferred",
        lead_time: 21,
        evaluation_score: 88,
        status: "active",
        company_code_id: 2,
        company_code: "2000 - US Operations",
        purchase_organization_id: 1,
        purchase_organization: "2000 - US Purchasing",
        purchasing_group_id: 2,
        purchasing_group: "102 - Electronic Components",
        is_active: true,
        created_at: new Date(2023, 2, 15).toISOString(),
        updated_at: new Date(2023, 9, 20).toISOString()
      },
      {
        id: 3,
        vendor_code: "V1003",
        name: "Global Logistics",
        type: "service_provider",
        description: "International shipping and logistics",
        tax_id: "GL-34567",
        industry: "transportation",
        address: "300 Harbor Blvd",
        city: "Long Beach",
        state: "CA",
        country: "US",
        postal_code: "90802",
        phone: "+1-562-555-3333",
        email: "operations@globallogistics.com",
        currency: "USD",
        payment_terms: "net_30",
        supplier_type: "service",
        category: "approved",
        lead_time: 7,
        evaluation_score: 95,
        status: "active",
        company_code_id: 1,
        company_code: "1000 - Global HQ",
        purchase_organization_id: 3,
        purchase_organization: "3000 - Global Services",
        purchasing_group_id: 4,
        purchasing_group: "104 - Logistics Services",
        is_active: true,
        created_at: new Date(2023, 3, 5).toISOString(),
        updated_at: new Date(2023, 8, 10).toISOString()
      },
      {
        id: 4,
        vendor_code: "V1004",
        name: "Advanced Materials",
        type: "supplier",
        description: "Specialized manufacturing materials",
        tax_id: "AM-89012",
        industry: "chemicals",
        address: "400 Research Parkway",
        city: "Raleigh",
        state: "NC",
        country: "US",
        postal_code: "27601",
        phone: "+1-919-555-4444",
        email: "orders@advancedmaterials.com",
        currency: "USD",
        payment_terms: "net_60",
        supplier_type: "manufacturer",
        category: "strategic",
        lead_time: 28,
        evaluation_score: 90,
        status: "active",
        company_code_id: 2,
        company_code: "2000 - US Operations",
        purchase_organization_id: 1,
        purchase_organization: "2000 - US Purchasing",
        purchasing_group_id: 1,
        purchasing_group: "101 - Raw Materials",
        is_active: true,
        created_at: new Date(2023, 4, 20).toISOString(),
        updated_at: new Date(2023, 11, 15).toISOString()
      },
      {
        id: 5,
        vendor_code: "V1005",
        name: "Precision Engineering",
        type: "contractor",
        description: "Custom tooling and machining services",
        tax_id: "PE-45678",
        industry: "manufacturing",
        address: "500 Precision Way",
        city: "Cincinnati",
        state: "OH",
        country: "US",
        postal_code: "45202",
        phone: "+1-513-555-5555",
        email: "info@precisionengineering.com",
        currency: "USD",
        payment_terms: "net_30",
        supplier_type: "service",
        category: "preferred",
        lead_time: 35,
        evaluation_score: 87,
        status: "active",
        company_code_id: 2,
        company_code: "2000 - US Operations",
        purchase_organization_id: 1,
        purchase_organization: "2000 - US Purchasing",
        purchasing_group_id: 3,
        purchasing_group: "103 - MRO",
        is_active: true,
        created_at: new Date(2023, 5, 10).toISOString(),
        updated_at: new Date(2023, 5, 10).toISOString()
      },
      {
        id: 8,
        vendor_code: "V1008",
        name: "Asian Manufacturing",
        type: "supplier",
        description: "Overseas manufacturing partner",
        tax_id: "AM-901234",
        industry: "manufacturing",
        address: "800 Export Zone",
        city: "Shenzhen",
        state: null,
        country: "CN",
        postal_code: "518000",
        phone: "+86-755-5558888",
        email: "exports@asianmanufacturing.com",
        currency: "USD",
        payment_terms: "letter_of_credit",
        supplier_type: "manufacturer",
        category: "strategic",
        lead_time: 45,
        evaluation_score: 85,
        status: "active",
        company_code_id: 1,
        company_code: "1000 - Global HQ",
        purchase_organization_id: 2,
        purchase_organization: "1000 - Global Purchasing",
        purchasing_group_id: 1, 
        purchasing_group: "101 - Raw Materials",
        is_active: true,
        created_at: new Date(2023, 6, 15).toISOString(),
        updated_at: new Date(2023, 6, 15).toISOString()
      },
      {
        id: 11,
        vendor_code: "V1011",
        name: "Blacklisted Supply",
        type: "supplier",
        description: "Blacklisted due to contract violations",
        tax_id: "BS-00000",
        industry: "manufacturing",
        address: "1100 Violation Road",
        city: "Denver",
        state: "CO",
        country: "US",
        postal_code: "80201",
        phone: "+1-303-555-1111",
        email: "info@blacklistedsupply.com",
        currency: "USD",
        payment_terms: "cod",
        supplier_type: "manufacturer",
        category: "one_time",
        lead_time: 90,
        evaluation_score: 10,
        status: "blocked",
        company_code_id: 2,
        company_code: "2000 - US Operations",
        purchase_organization_id: 1,
        purchase_organization: "2000 - US Purchasing",
        purchasing_group_id: 1,
        purchasing_group: "101 - Raw Materials",
        blacklisted: true,
        blacklist_reason: "Multiple quality issues and contract violations. Deliveries consistently late by over 30 days.",
        is_active: false,
        created_at: new Date(2022, 11, 15).toISOString(),
        updated_at: new Date(2023, 2, 10).toISOString()
      }
    ];
    
    res.json(sampleVendors);
  } catch (error) {
    console.error("Error fetching vendors:", error);
    res.status(500).json({ message: "Failed to fetch vendors" });
  }
});

// Get vendor contacts for a specific vendor
router.get("/:id/contacts", async (req: Request, res: Response) => {
  try {
    const vendorId = parseInt(req.params.id);
    
    // Sample vendor contacts data with organizational relationship
    const sampleVendorContacts = [
      {
        id: 1,
        vendorId: 1,
        firstName: "Richard",
        lastName: "Steel",
        position: "Sales Director",
        department: "Sales",
        email: "richard.steel@primesteelsupply.com",
        phone: "+1-412-555-1112",
        mobile: "+1-412-555-1234",
        isPrimary: true,
        isOrderContact: true,
        isPurchaseContact: true,
        isQualityContact: false,
        isAccountsContact: false,
        preferredLanguage: "English",
        notes: "Main contact for all orders and quotes",
        isActive: true
      },
      {
        id: 2,
        vendorId: 1,
        firstName: "Patricia",
        lastName: "Miller",
        position: "Accounts Manager",
        department: "Finance",
        email: "patricia.miller@primesteelsupply.com",
        phone: "+1-412-555-1113",
        mobile: "+1-412-555-5678",
        isPrimary: false,
        isOrderContact: false,
        isPurchaseContact: false,
        isQualityContact: false,
        isAccountsContact: true,
        preferredLanguage: "English",
        notes: "Handles invoicing and payment inquiries",
        isActive: true
      },
      {
        id: 3,
        vendorId: 2,
        firstName: "Edward",
        lastName: "Johnson",
        position: "VP of Sales",
        department: "Sales",
        email: "edward.johnson@qualityelectronics.com",
        phone: "+1-408-555-2223",
        mobile: "+1-408-555-9876",
        isPrimary: true,
        isOrderContact: true,
        isPurchaseContact: true,
        isQualityContact: false,
        isAccountsContact: false,
        preferredLanguage: "English",
        notes: "Strategic account manager",
        isActive: true
      },
      {
        id: 8,
        vendorId: 8,
        firstName: "Mei",
        lastName: "Chen",
        position: "Export Manager",
        department: "International Sales",
        email: "mei.chen@asianmanufacturing.com",
        phone: "+86-755-5558889",
        mobile: "+86-755-8889999",
        isPrimary: true,
        isOrderContact: true,
        isPurchaseContact: true,
        isQualityContact: false,
        isAccountsContact: false,
        preferredLanguage: "English",
        notes: "Speaks fluent English, handles international orders",
        isActive: true
      },
      {
        id: 9,
        vendorId: 8,
        firstName: "Jian",
        lastName: "Zhang",
        position: "Quality Control Manager",
        department: "Quality",
        email: "jian.zhang@asianmanufacturing.com",
        phone: "+86-755-5558890",
        mobile: "+86-755-7778888",
        isPrimary: false,
        isOrderContact: false,
        isPurchaseContact: false,
        isQualityContact: true,
        isAccountsContact: false,
        preferredLanguage: "Chinese",
        notes: "Handles all quality-related matters and inspections",
        isActive: true
      }
    ];
    
    // Only return contacts for the requested vendor
    const contacts = sampleVendorContacts.filter(contact => contact.vendorId === vendorId);
    
    res.json(contacts);
  } catch (error) {
    console.error("Error fetching vendor contacts:", error);
    res.status(500).json({ message: "Failed to fetch vendor contacts" });
  }
});

// Add stub routes for CRUD operations
router.post("/", async (req: Request, res: Response) => {
  try {
    // For now, just return the request body with a generated ID
    const newVendor = {
      id: Math.floor(Math.random() * 1000) + 100,
      ...req.body,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    res.status(201).json(newVendor);
  } catch (error) {
    console.error("Error creating vendor:", error);
    res.status(400).json({ message: "Failed to create vendor" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    
    // Return the updated vendor data
    res.json({
      id,
      ...req.body,
      updated_at: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error updating vendor:", error);
    res.status(400).json({ message: "Failed to update vendor" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting vendor:", error);
    res.status(500).json({ message: "Failed to delete vendor" });
  }
});

export default router;