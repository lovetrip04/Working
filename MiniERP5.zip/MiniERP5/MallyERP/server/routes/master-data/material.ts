/**
 * API Route for material master data
 */

import { Request, Response } from "express";
import { db } from "../../db";

export async function getMaterial(req: Request, res: Response) {
  try {
    // Query data from the materials table with retry logic
    let retries = 3;
    let result;
    
    while (retries > 0) {
      try {
        result = await db.execute('SELECT * FROM materials');
        break; // Success, exit the retry loop
      } catch (retryError) {
        retries--;
        if (retries === 0) throw retryError; // If no more retries, throw the error
        
        // Wait for 500ms before retrying
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
    
    if (!result || !result.rows) {
      return res.status(500).json({ message: "Database returned empty result" });
    }
    
    // Transform data to match frontend expectations
    const transformedData = result.rows.map(row => ({
      id: row.id,
      code: row.code,
      name: row.name,
      type: row.type || 'RAW',
      description: row.description,
      uomId: row.uom_id,
      baseUnitPrice: row.base_unit_price,
      cost: row.cost,
      reOrderLevel: row.reorder_point,
      minimumOrderQuantity: row.min_order_qty,
      leadTime: row.lead_time,
      isActive: row.is_active === undefined ? true : row.is_active,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
    
    return res.json(transformedData);
  } catch (error: any) {
    console.error("Error fetching material data:", error);
    return res.status(500).json({ 
      message: `Failed to fetch material data: ${error.message}`,
      error: error.toString()
    });
  }
}

export default getMaterial;