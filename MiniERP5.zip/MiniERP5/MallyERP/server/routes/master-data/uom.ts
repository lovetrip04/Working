/**
 * API Route for uom (mapped from uom)
 */

import { Request, Response } from "express";
import { db } from "../../db";

export async function getUom(req: Request, res: Response) {
  try {
    // Query data from the original table
    const result = await db.execute('SELECT * FROM uom');
    
    return res.json(result.rows);
  } catch (error: any) {
    console.error("Error fetching UoM data:", error);
    return res.status(500).json({ message: `Failed to fetch UoM data: ${error.message}` });
  }
}

export default getUom;