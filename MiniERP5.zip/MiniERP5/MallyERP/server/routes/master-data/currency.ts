/**
 * API Route for currency (mapped from currencies)
 */

import { Request, Response } from "express";
import { db } from "../../db";

export async function getCurrency(req: Request, res: Response) {
  try {
    // Query data from the original table
    const result = await db.execute('SELECT * FROM currencies');
    
    return res.json(result.rows);
  } catch (error: any) {
    console.error("Error fetching currency data:", error);
    return res.status(500).json({ message: `Failed to fetch currency data: ${error.message}` });
  }
}

export default getCurrency;