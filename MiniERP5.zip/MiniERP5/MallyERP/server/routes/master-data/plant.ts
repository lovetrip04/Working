import { Request, Response } from "express";
import { db } from "../../db";
import { pool } from "../../db";
import { plants, companyCodes } from "../../../shared/organizational-schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

// Validation schema for plant
const plantSchema = z.object({
  code: z.string().min(2, "Code is required").max(10, "Code must be at most 10 characters"),
  name: z.string().min(1, "Name is required").max(100, "Name must be at most 100 characters"),
  description: z.string().optional().nullable(),
  companyCodeId: z.number().min(1, "Company Code is required"),
  type: z.string().min(1, "Type is required"),
  category: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  state: z.string().optional().nullable(),
  country: z.string().optional().nullable(),
  postalCode: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  email: z.string().email("Invalid email format").optional().nullable(),
  manager: z.string().optional().nullable(),
  timezone: z.string().optional().nullable(),
  operatingHours: z.string().optional().nullable(),
  coordinates: z.string().optional().nullable(),
  status: z.string().default("active"),
  isActive: z.boolean().default(true),
});

// GET /api/master-data/plant - List all plants
export async function getPlants(req: Request, res: Response) {
  try {
    // Select plants with joined company code information
    const result = await db
      .select({
        id: plants.id,
        code: plants.code,
        name: plants.name,
        description: plants.description,
        companyCodeId: plants.companyCodeId,
        companyCodeName: companyCodes.name,
        companyCodeCode: companyCodes.code,
        type: plants.type,
        category: plants.category,
        address: plants.address,
        city: plants.city,
        state: plants.state,
        country: plants.country,
        postalCode: plants.postalCode,
        phone: plants.phone,
        email: plants.email,
        manager: plants.manager,
        timezone: plants.timezone,
        operatingHours: plants.operatingHours,
        coordinates: plants.coordinates,
        status: plants.status,
        isActive: plants.isActive,
        createdAt: plants.createdAt,
        updatedAt: plants.updatedAt
      })
      .from(plants)
      .leftJoin(companyCodes, eq(plants.companyCodeId, companyCodes.id))
      .orderBy(plants.code);

    return res.status(200).json(result.map(plant => ({
      ...plant,
      // Format the company code information for display
      companyCodeName: plant.companyCodeCode 
        ? `${plant.companyCodeCode} - ${plant.companyCodeName}`
        : plant.companyCodeName
    })));
  } catch (error: any) {
    console.error("Error fetching plants:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}

// GET /api/master-data/plant/:id - Get a specific plant by ID
export async function getPlantById(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }

    const [result] = await db
      .select({
        id: plants.id,
        code: plants.code,
        name: plants.name,
        description: plants.description,
        companyCodeId: plants.companyCodeId,
        companyCodeName: companyCodes.name,
        companyCodeCode: companyCodes.code,
        type: plants.type,
        category: plants.category,
        address: plants.address,
        city: plants.city,
        state: plants.state,
        country: plants.country,
        postalCode: plants.postalCode,
        phone: plants.phone,
        email: plants.email,
        manager: plants.manager,
        timezone: plants.timezone,
        operatingHours: plants.operatingHours,
        coordinates: plants.coordinates,
        status: plants.status,
        isActive: plants.isActive,
        createdAt: plants.createdAt,
        updatedAt: plants.updatedAt
      })
      .from(plants)
      .leftJoin(companyCodes, eq(plants.companyCodeId, companyCodes.id))
      .where(eq(plants.id, id));

    if (!result) {
      return res.status(404).json({ error: "Plant not found" });
    }

    return res.status(200).json({
      ...result,
      companyCodeName: result.companyCodeCode 
        ? `${result.companyCodeCode} - ${result.companyCodeName}`
        : result.companyCodeName
    });
  } catch (error: any) {
    console.error("Error fetching plant:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}

// POST /api/master-data/plant - Create a new plant
export async function createPlant(req: Request, res: Response) {
  try {
    const validation = plantSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({ 
        error: "Validation error", 
        message: validation.error.errors.map(e => e.message).join(", ") 
      });
    }

    const data = validation.data;

    // Check if company code exists
    const [companyCode] = await db
      .select()
      .from(companyCodes)
      .where(eq(companyCodes.id, data.companyCodeId));

    if (!companyCode) {
      return res.status(400).json({ error: "Invalid company code ID" });
    }

    // Check if plant code already exists
    const [existingPlant] = await db
      .select()
      .from(plants)
      .where(eq(plants.code, data.code));

    if (existingPlant) {
      return res.status(409).json({ error: "Conflict", message: "Plant code already exists" });
    }

    // Auto-Recovery Agent: Handle schema mismatch with zero data loss
    let newPlant;
    try {
      // Attempt Drizzle ORM insert first
      [newPlant] = await db
        .insert(plants)
        .values({
          code: data.code,
          name: data.name,
          description: data.description,
          companyCodeId: data.companyCodeId,
          type: data.type,
          category: data.category,
          address: data.address,
          city: data.city,
          state: data.state,
          country: data.country,
          postalCode: data.postalCode,
          phone: data.phone,
          email: data.email,
          manager: data.manager,
          timezone: data.timezone,
          operatingHours: data.operatingHours,
          coordinates: data.coordinates,
          status: data.status,
          isActive: data.isActive,
          createdAt: new Date(),
          updatedAt: new Date()
        })
        .returning();
    } catch (schemaError: any) {
      // Auto-Recovery: Use direct SQL with database column names
      console.log('Auto-Recovery Agent: Fixing schema mismatch for plant creation');
      const result = await pool.query(`
        INSERT INTO plants (
          code, name, description, company_code_id, type, category, 
          address, city, state, country, postal_code, phone, email, 
          manager, timezone, operating_hours, coordinates, status, 
          is_active, created_at, updated_at, created_by, updated_by, version
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, 
          $14, $15, $16, $17, $18, $19, NOW(), NOW(), 1, 1, 1
        ) RETURNING *
      `, [
        data.code, data.name, data.description, data.companyCodeId, data.type, 
        data.category, data.address, data.city, data.state, data.country, 
        data.postalCode, data.phone, data.email, data.manager, data.timezone, 
        data.operatingHours, data.coordinates, data.status, data.isActive
      ]);
      newPlant = result.rows[0];
    }

    return res.status(201).json(newPlant);
  } catch (error: any) {
    console.error("Error creating plant:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}

// PUT /api/master-data/plant/:id - Update a plant
export async function updatePlant(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }

    const validation = plantSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({ 
        error: "Validation error", 
        message: validation.error.errors.map(e => e.message).join(", ") 
      });
    }

    const data = validation.data;

    // Check if plant exists
    const [existingPlant] = await db
      .select()
      .from(plants)
      .where(eq(plants.id, id));

    if (!existingPlant) {
      return res.status(404).json({ error: "Plant not found" });
    }

    // Check if company code exists
    const [companyCode] = await db
      .select()
      .from(companyCodes)
      .where(eq(companyCodes.id, data.companyCodeId));

    if (!companyCode) {
      return res.status(400).json({ error: "Invalid company code ID" });
    }

    // If code is being changed, check it doesn't conflict with another plant
    if (data.code !== existingPlant.code) {
      const [duplicate] = await db
        .select()
        .from(plants)
        .where(eq(plants.code, data.code));

      if (duplicate) {
        return res.status(409).json({ error: "Conflict", message: "Plant code already exists" });
      }
    }

    // Update plant
    const [updatedPlant] = await db
      .update(plants)
      .set({
        code: data.code,
        name: data.name,
        description: data.description,
        companyCodeId: data.companyCodeId,
        type: data.type,
        category: data.category,
        address: data.address,
        city: data.city,
        state: data.state,
        country: data.country,
        postalCode: data.postalCode,
        phone: data.phone,
        email: data.email,
        manager: data.manager,
        timezone: data.timezone,
        operatingHours: data.operatingHours,
        coordinates: data.coordinates,
        status: data.status,
        isActive: data.isActive,
        updatedAt: new Date()
      })
      .where(eq(plants.id, id))
      .returning();

    return res.status(200).json(updatedPlant);
  } catch (error: any) {
    console.error("Error updating plant:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}

// DELETE /api/master-data/plant/:id - Delete a plant
export async function deletePlant(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }

    // Check if plant exists
    const [existingPlant] = await db
      .select()
      .from(plants)
      .where(eq(plants.id, id));

    if (!existingPlant) {
      return res.status(404).json({ error: "Plant not found" });
    }

    // In a real-world application, we would check for dependencies (referential integrity)
    // before deleting. For this implementation, we'll allow deletion without checks.

    await db
      .delete(plants)
      .where(eq(plants.id, id));

    return res.status(200).json({ success: true, message: "Plant deleted successfully" });
  } catch (error: any) {
    console.error("Error deleting plant:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}