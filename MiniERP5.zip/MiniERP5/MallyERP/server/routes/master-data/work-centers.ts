import { Request, Response, Router } from 'express';
import { pool } from '../../db';

// Create the router
const router = Router();

// Middleware to ensure the table exists
router.use(async (_req, _res, next) => {
  try {
    // Create the work_centers table if it doesn't exist
    await pool.query(`
      CREATE TABLE IF NOT EXISTS work_centers (
        id SERIAL PRIMARY KEY,
        code VARCHAR(20) NOT NULL UNIQUE,
        name VARCHAR(100) NOT NULL,
        plant_id INTEGER,
        description TEXT,
        capacity DECIMAL(10, 2),
        capacity_unit VARCHAR(20),
        cost_rate DECIMAL(15, 2),
        status VARCHAR(20) DEFAULT 'active',
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    next();
  } catch (error) {
    console.error("Error creating work_centers table:", error);
    next(error);
  }
});

// GET /api/master-data/work-center
router.get('/', async (_req: Request, res: Response) => {
  try {
    // Simpler query to ensure we get data
    const result = await pool.query(`
      SELECT 
        wc.id, 
        wc.code, 
        wc.name, 
        wc.description, 
        wc.capacity, 
        wc.capacity_unit, 
        wc.cost_rate, 
        wc.status, 
        wc.is_active,
        wc.plant_id,
        p.code as plant_code, 
        p.name as plant_name
      FROM 
        work_centers wc
      LEFT JOIN 
        plants p ON wc.plant_id = p.id
      ORDER BY 
        wc.code ASC
    `);
    
    // Log the result rows for debugging
    console.log(`Found ${result.rows.length} work centers`);
    
    // Transform the data to match the expected format
    const workCenters = result.rows.map(row => ({
      id: row.id,
      code: row.code || '',
      name: row.name || '',
      description: row.description || '',
      capacity: Number(row.capacity) || 0,
      capacity_unit: row.capacity_unit || 'units/day',
      cost_rate: Number(row.cost_rate) || 0,
      status: row.status || 'active',
      is_active: row.is_active === undefined ? true : row.is_active,
      plant: row.plant_name || 'Unassigned',
      plant_code: row.plant_code || 'N/A',
      plant_id: row.plant_id || null
    }));
    
    console.log("Sending work centers data:", workCenters.length, "items");
    
    return res.status(200).json(workCenters);
  } catch (error) {
    console.error("Error fetching work centers:", error);
    res.status(500).json({ message: "Failed to fetch work centers" });
  }
});

// GET /api/master-data/work-center/:id
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`
      SELECT wc.id, wc.code, wc.name, wc.description, wc.capacity, 
             wc.capacity_unit, wc.cost_rate, wc.status, wc.is_active,
             p.code as plant_code, p.name as plant_name, wc.plant_id
      FROM work_centers wc
      LEFT JOIN plants p ON wc.plant_id = p.id
      WHERE wc.id = $1
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: `Work center with ID ${id} not found` });
    }
    
    const row = result.rows[0];
    const workCenter = {
      id: row.id,
      code: row.code,
      name: row.name,
      description: row.description || '',
      capacity: row.capacity,
      capacity_unit: row.capacity_unit || 'units/day',
      cost_rate: row.cost_rate,
      status: row.status || 'active',
      is_active: row.is_active,
      plant: row.plant_name || '-',
      plant_code: row.plant_code || '-',
      plant_id: row.plant_id || null
    };
    
    res.status(200).json(workCenter);
  } catch (error) {
    console.error("Error fetching work center:", error);
    res.status(500).json({ message: "Failed to fetch work center" });
  }
});

// POST /api/master-data/work-center
router.post('/', async (req: Request, res: Response) => {
  try {
    const { 
      code, 
      name, 
      plant_id, 
      description, 
      capacity, 
      capacity_unit, 
      cost_rate,
      status
    } = req.body;
    
    if (!code || !name) {
      return res.status(400).json({ message: "Code and name are required fields" });
    }
    
    console.log("Creating work center:", { code, name, plant_id, description, capacity, capacity_unit, cost_rate, status });
    
    const result = await pool.query(`
      INSERT INTO work_centers 
        (code, name, plant_id, description, capacity, capacity_unit, cost_rate, status, is_active)
      VALUES 
        ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING 
        id, code, name, plant_id, description, capacity, capacity_unit, cost_rate, status, is_active
    `, [
      code, 
      name, 
      plant_id || null, 
      description || null, 
      capacity || null, 
      capacity_unit || 'units/day', 
      cost_rate || null,
      status || 'active',
      true
    ]);
    
    // Get the plant details if plant_id is provided
    let plantDetails = { plant_name: null, plant_code: null };
    if (plant_id) {
      const plantResult = await pool.query('SELECT code, name FROM plants WHERE id = $1', [plant_id]);
      if (plantResult.rows.length > 0) {
        plantDetails = {
          plant_name: plantResult.rows[0].name,
          plant_code: plantResult.rows[0].code
        };
      }
    }
    
    const newWorkCenter = {
      ...result.rows[0],
      plant: plantDetails.plant_name || '-',
      plant_code: plantDetails.plant_code || '-'
    };
    
    res.status(201).json(newWorkCenter);
  } catch (error) {
    console.error("Error creating work center:", error);
    
    // Check for duplicate key violation
    if (error.code === '23505') {
      return res.status(400).json({ message: "A work center with this code already exists" });
    }
    
    res.status(500).json({ message: "Failed to create work center" });
  }
});

// PUT /api/master-data/work-center/:id
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { 
      code, 
      name, 
      plant_id, 
      description, 
      capacity, 
      capacity_unit, 
      cost_rate,
      status,
      is_active
    } = req.body;
    
    if (!code || !name) {
      return res.status(400).json({ message: "Code and name are required fields" });
    }
    
    const result = await pool.query(`
      UPDATE work_centers
      SET 
        code = $1,
        name = $2,
        plant_id = $3,
        description = $4,
        capacity = $5,
        capacity_unit = $6,
        cost_rate = $7,
        status = $8,
        is_active = $9,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $10
      RETURNING id, code, name, plant_id, description, capacity, capacity_unit, cost_rate, status, is_active
    `, [
      code, 
      name, 
      plant_id || null, 
      description || null, 
      capacity || null, 
      capacity_unit || 'units/day', 
      cost_rate || null,
      status || 'active',
      is_active !== undefined ? is_active : true,
      id
    ]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: `Work center with ID ${id} not found` });
    }
    
    // Get the plant details if plant_id is provided
    let plantDetails = { plant_name: null, plant_code: null };
    if (plant_id) {
      const plantResult = await pool.query('SELECT code, name FROM plants WHERE id = $1', [plant_id]);
      if (plantResult.rows.length > 0) {
        plantDetails = {
          plant_name: plantResult.rows[0].name,
          plant_code: plantResult.rows[0].code
        };
      }
    }
    
    const updatedWorkCenter = {
      ...result.rows[0],
      plant: plantDetails.plant_name || '-',
      plant_code: plantDetails.plant_code || '-'
    };
    
    res.status(200).json(updatedWorkCenter);
  } catch (error) {
    console.error("Error updating work center:", error);
    
    // Check for duplicate key violation
    if (error.code === '23505') {
      return res.status(400).json({ message: "A work center with this code already exists" });
    }
    
    res.status(500).json({ message: "Failed to update work center" });
  }
});

// DELETE /api/master-data/work-center/:id
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    const result = await pool.query(`
      DELETE FROM work_centers
      WHERE id = $1
      RETURNING id
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: `Work center with ID ${id} not found` });
    }
    
    res.status(200).json({ message: `Work center with ID ${id} successfully deleted` });
  } catch (error) {
    console.error("Error deleting work center:", error);
    res.status(500).json({ message: "Failed to delete work center" });
  }
});

// GET plants for dropdown selection
router.get('/options/plants', async (_req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT id, code, name 
      FROM plants 
      ORDER BY name ASC
    `);
    
    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching plants:", error);
    res.status(500).json({ message: "Failed to fetch plants for selection" });
  }
});

export default router;