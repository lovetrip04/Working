/**
 * Production-Ready Master Data Routes
 * Matches exact database schema to ensure all creation operations work
 */

import { Express, Request, Response } from "express";
import { pool } from "../../db";

export function registerProductionMasterDataRoutes(app: Express) {
  
  // Materials - using exact database columns with uom_id
  app.post("/api/master-data/material", async (req: Request, res: Response) => {
    try {
      const { code, name, type, baseUom } = req.body;
      
      // Get default UOM ID
      const uomResult = await pool.query(`SELECT id FROM units_of_measure WHERE code = $1 LIMIT 1`, [baseUom || 'PC']);
      const uomId = uomResult.rows[0]?.id || 1;
      
      const result = await pool.query(`
        INSERT INTO materials (code, name, type, base_uom, uom_id, created_at, updated_at, is_active)
        VALUES ($1, $2, $3, $4, $5, NOW(), NOW(), true)
        RETURNING *
      `, [code, name, type || 'Raw Material', baseUom || 'PC', uomId]);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating material:", error);
      return res.status(500).json({ message: "Failed to create material", error: error.message });
    }
  });

  // Customers - using exact database columns with all required fields
  app.post("/api/master-data/customer", async (req: Request, res: Response) => {
    try {
      const { code, name, email, phone, address } = req.body;
      const result = await pool.query(`
        INSERT INTO customers (code, name, email, phone, address, created_at, updated_at, active)
        VALUES ($1, $2, $3, $4, $5, NOW(), NOW(), true)
        RETURNING *
      `, [code, name, email, phone || '000-000-0000', address || 'Default Address']);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating customer:", error);
      return res.status(500).json({ message: "Failed to create customer", error: error.message });
    }
  });

  // Vendors - using exact database columns with required type field
  app.post("/api/master-data/vendor", async (req: Request, res: Response) => {
    try {
      const { code, name, email, type } = req.body;
      const result = await pool.query(`
        INSERT INTO vendors (code, name, email, type, created_at, updated_at, is_active)
        VALUES ($1, $2, $3, $4, NOW(), NOW(), true)
        RETURNING *
      `, [code, name, email, type || 'Supplier']);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating vendor:", error);
      return res.status(500).json({ message: "Failed to create vendor", error: error.message });
    }
  });

  // Plants - using exact database columns with proper defaults
  app.post("/api/master-data/plant", async (req: Request, res: Response) => {
    try {
      const { code, name, company_code_id, companyCodeId, type, status, isActive } = req.body;
      
      // Validate required fields
      if (!code || !name) {
        return res.status(400).json({ message: "Code and name are required" });
      }
      
      // Handle both field name formats from frontend
      const companyCode = company_code_id || companyCodeId;
      
      const result = await pool.query(`
        INSERT INTO plants (
          code, name, company_code_id, type, status, is_active, 
          created_at, updated_at, created_by, updated_by, version, active
        )
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW(), 1, 1, 1, $7)
        RETURNING *
      `, [code, name, companyCode || null, type || null, status || 'active', isActive !== false, true]);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating plant:", error);
      return res.status(500).json({ message: "Failed to create plant", error: error.message });
    }
  });

  // Company Codes - handle duplicates and character limits
  app.post("/api/master-data/company-code", async (req: Request, res: Response) => {
    try {
      const { code, name, currency, country } = req.body;
      
      // Validate required fields
      if (!code || !name) {
        return res.status(400).json({ message: "Code and name are required" });
      }
      
      // Ensure code fits varchar(10) limit
      const shortCode = code.substring(0, 10);
      
      // Check if code already exists
      const existing = await pool.query('SELECT id FROM company_codes WHERE code = $1', [shortCode]);
      if (existing.rows.length > 0) {
        return res.status(409).json({ message: "Company code already exists" });
      }
      
      const result = await pool.query(`
        INSERT INTO company_codes (code, name, currency, country, created_at, updated_at)
        VALUES ($1, $2, $3, $4, NOW(), NOW())
        RETURNING *
      `, [shortCode, name, currency, country]);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating company code:", error);
      return res.status(500).json({ message: "Failed to create company code", error: error.message });
    }
  });
}