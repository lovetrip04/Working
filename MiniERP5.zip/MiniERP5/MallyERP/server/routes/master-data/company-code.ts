import { Request, Response } from "express";
import { db } from "../../db";
import { sql } from "drizzle-orm";
import { z } from "zod";

// Validation schema for company code - accept all frontend fields but only use database fields
const companyCodeSchema = z.object({
  code: z.string().min(2, "Code is required").max(10, "Code must be at most 10 characters"),
  name: z.string().min(1, "Name is required").max(100, "Name must be at most 100 characters"),
  city: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  currency: z.string().min(1, "Currency is required"),
  country: z.string().min(1, "Country is required"),
  language: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  active: z.boolean().default(true),
  // Accept but ignore these frontend fields that don't exist in database
  description: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  taxId: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  fiscalYear: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  address: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  state: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  postalCode: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  phone: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  email: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  website: z.string().transform(val => val === "" ? null : val).nullable().optional(),
  logoUrl: z.string().transform(val => val === "" ? null : val).nullable().optional(),
});

// GET /api/master-data/company-code - List all company codes
export async function getCompanyCodes(req: Request, res: Response) {
  try {
    const result = await db.execute(sql`SELECT * FROM company_codes ORDER BY code`);
    return res.status(200).json(result.rows);
  } catch (error: any) {
    console.error("Error fetching company codes:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}

// GET /api/master-data/company-code/:id - Get a specific company code by ID
export async function getCompanyCodeById(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }

    const result = await db.execute(sql`SELECT * FROM company_codes WHERE id = ${id}`);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Company code not found" });
    }

    return res.status(200).json(result.rows[0]);
  } catch (error: any) {
    console.error("Error fetching company code:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}

// POST /api/master-data/company-code - Create a new company code
export async function createCompanyCode(req: Request, res: Response) {
  try {
    console.log("Received company code creation request:", req.body);
    
    const validation = companyCodeSchema.safeParse(req.body);
    
    if (!validation.success) {
      console.log("Validation failed:", validation.error);
      return res.status(400).json({ 
        error: "Validation error", 
        message: validation.error.errors.map(e => e.message).join(", ") 
      });
    }

    const data = validation.data;
    console.log("Validated data:", data);

    // Check if company code already exists
    const existingResult = await db.execute(sql`SELECT id FROM company_codes WHERE code = ${data.code}`);
    
    if (existingResult.rows.length > 0) {
      return res.status(409).json({ error: "Conflict", message: "Company code already exists" });
    }

    // Create company code - only use fields that exist in the actual table
    const insertResult = await db.execute(sql`
      INSERT INTO company_codes (code, name, city, country, currency, language, active, created_at, updated_at)
      VALUES (${data.code}, ${data.name}, ${data.city || null}, ${data.country}, ${data.currency}, ${data.language || null}, ${data.active}, NOW(), NOW())
      RETURNING *
    `);
    
    console.log("Insert result:", insertResult);
    
    if (insertResult.rows && insertResult.rows.length > 0) {
      return res.status(201).json(insertResult.rows[0]);
    } else {
      return res.status(500).json({ error: "Failed to create company code", message: "No data returned from insert" });
    }
  } catch (error: any) {
    console.error("Error creating company code:", error);
    return res.status(500).json({ 
      error: "Internal server error", 
      message: error.message,
      stack: error.stack 
    });
  }
}

// PUT /api/master-data/company-code/:id - Update a company code
export async function updateCompanyCode(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }

    const validation = companyCodeSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({ 
        error: "Validation error", 
        message: validation.error.errors.map(e => e.message).join(", ") 
      });
    }

    const data = validation.data;

    // Check if company code exists
    const existingResult = await db.execute(sql`SELECT * FROM company_codes WHERE id = ${id}`);
    
    if (existingResult.rows.length === 0) {
      return res.status(404).json({ error: "Company code not found" });
    }

    const existingCompanyCode = existingResult.rows[0];

    // If code is being changed, check it doesn't conflict with another company code
    if (data.code !== existingCompanyCode.code) {
      const duplicateResult = await db.execute(sql`SELECT id FROM company_codes WHERE code = ${data.code} AND id != ${id}`);
      
      if (duplicateResult.rows.length > 0) {
        return res.status(409).json({ error: "Conflict", message: "Company code already exists" });
      }
    }

    // Update company code
    const updateResult = await db.execute(sql`
      UPDATE company_codes 
      SET code = ${data.code}, name = ${data.name}, city = ${data.city || null}, country = ${data.country}, currency = ${data.currency}, language = ${data.language || null}, active = ${data.active}, updated_at = NOW()
      WHERE id = ${id}
      RETURNING *
    `);
    
    return res.status(200).json(updateResult.rows[0]);
  } catch (error: any) {
    console.error("Error updating company code:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}

// DELETE /api/master-data/company-code/:id - Delete a company code
export async function deleteCompanyCode(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }

    // Check if company code exists
    const existingResult = await db.execute(sql`SELECT * FROM company_codes WHERE id = ${id}`);
    
    if (existingResult.rows.length === 0) {
      return res.status(404).json({ error: "Company code not found" });
    }

    // Delete company code
    await db.execute(sql`DELETE FROM company_codes WHERE id = ${id}`);

    return res.status(200).json({ success: true, message: "Company code deleted successfully" });
  } catch (error: any) {
    console.error("Error deleting company code:", error);
    return res.status(500).json({ error: "Internal server error", message: error.message });
  }
}