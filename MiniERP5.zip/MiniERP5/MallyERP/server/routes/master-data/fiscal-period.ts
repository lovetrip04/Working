/**
 * API Route for fiscal periods
 */

import { Request, Response } from "express";
import { db } from "../../db";

export async function getFiscalPeriod(req: Request, res: Response) {
  try {
    // Create sample fiscal periods
    const sampleFiscalPeriods = [
      { id: 1, code: 'FY2024Q1', name: 'Q1 FY 2024', start_date: '2024-01-01', end_date: '2024-03-31', status: 'CLOSED', company_code_id: 1 },
      { id: 2, code: 'FY2024Q2', name: 'Q2 FY 2024', start_date: '2024-04-01', end_date: '2024-06-30', status: 'CLOSED', company_code_id: 1 },
      { id: 3, code: 'FY2024Q3', name: 'Q3 FY 2024', start_date: '2024-07-01', end_date: '2024-09-30', status: 'ACTIVE', company_code_id: 1 },
      { id: 4, code: 'FY2024Q4', name: 'Q4 FY 2024', start_date: '2024-10-01', end_date: '2024-12-31', status: 'OPEN', company_code_id: 1 },
      { id: 5, code: 'FY2025Q1', name: 'Q1 FY 2025', start_date: '2025-01-01', end_date: '2025-03-31', status: 'PLANNED', company_code_id: 1 }
    ];
    
    return res.json(sampleFiscalPeriods);
  } catch (error: any) {
    console.error("Error fetching fiscal period data:", error);
    return res.status(500).json({ message: `Failed to fetch fiscal period data: ${error.message}` });
  }
}

export default getFiscalPeriod;