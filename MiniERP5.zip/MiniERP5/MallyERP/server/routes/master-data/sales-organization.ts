/**
 * API Route for sales-organization (mapped from sales_organizations)
 */

import { Request, Response } from "express";
import { db } from "../../db";

export async function getSalesOrganization(req: Request, res: Response) {
  try {
    // Query data from the original table
    const result = await db.execute('SELECT * FROM sales_organizations');
    
    return res.json(result.rows);
  } catch (error: any) {
    console.error("Error fetching sales-organization data:", error);
    return res.status(500).json({ message: `Failed to fetch sales-organization data: ${error.message}` });
  }
}

export default getSalesOrganization;