/**
 * API Route for purchase-organization (mapped from purchase_organizations)
 */

import { Request, Response } from "express";
import { db } from "../../db";

export async function getPurchaseOrganization(req: Request, res: Response) {
  try {
    // Query data from the original table
    const result = await db.execute('SELECT * FROM purchase_organizations');
    
    return res.json(result.rows);
  } catch (error: any) {
    console.error("Error fetching purchase-organization data:", error);
    return res.status(500).json({ message: `Failed to fetch purchase-organization data: ${error.message}` });
  }
}

export default getPurchaseOrganization;