import { Request, Response } from "express";
import { db } from "../../db";
import { creditControlAreas, companyCodes, insertCreditControlSchema } from "../../../shared/organizational-schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

// Get all credit control areas
export async function getCreditControlAreas(req: Request, res: Response) {
  try {
    const results = await db.select({
      creditControl: creditControlAreas,
      companyCode: {
        id: companyCodes.id,
        code: companyCodes.code,
        name: companyCodes.name
      }
    })
    .from(creditControlAreas)
    .leftJoin(companyCodes, eq(creditControlAreas.companyCodeId, companyCodes.id))
    .where(eq(creditControlAreas.isActive, true));

    // Transform the results to a more API-friendly format
    const formattedResults = results.map(r => ({
      ...r.creditControl,
      companyCode: r.companyCode
    }));

    return res.status(200).json(formattedResults);
  } catch (error) {
    console.error("Error fetching credit control areas:", error);
    return res.status(500).json({ message: "Failed to fetch credit control areas", error });
  }
}

// Get a single credit control area by id
export async function getCreditControlAreaById(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    const results = await db.select({
      creditControl: creditControlAreas,
      companyCode: {
        id: companyCodes.id,
        code: companyCodes.code,
        name: companyCodes.name
      }
    })
    .from(creditControlAreas)
    .leftJoin(companyCodes, eq(creditControlAreas.companyCodeId, companyCodes.id))
    .where(eq(creditControlAreas.id, id));
    
    if (results.length === 0) {
      return res.status(404).json({ message: "Credit control area not found" });
    }
    
    // Format the result
    const formattedResult = {
      ...results[0].creditControl,
      companyCode: results[0].companyCode
    };
    
    return res.status(200).json(formattedResult);
  } catch (error) {
    console.error("Error fetching credit control area:", error);
    return res.status(500).json({ message: "Failed to fetch credit control area", error });
  }
}

// Create a new credit control area
export async function createCreditControlArea(req: Request, res: Response) {
  try {
    const validatedData = insertCreditControlSchema.parse(req.body);
    
    // Check if company code exists
    const companyCode = await db.select().from(companyCodes).where(eq(companyCodes.id, validatedData.companyCodeId));
    if (companyCode.length === 0) {
      return res.status(400).json({ message: "Company code not found" });
    }
    
    // Make sure numeric values are properly formatted
    const dataToInsert = {
      ...validatedData,
      // Ensure numeric fields are properly converted
      gracePercentage: validatedData.gracePercentage ? parseFloat(String(validatedData.gracePercentage)) : 10,
      creditPeriod: validatedData.creditPeriod ? parseInt(String(validatedData.creditPeriod), 10) : 30,
      // Set defaults for required fields if not provided
      isActive: validatedData.isActive !== undefined ? validatedData.isActive : true,
      status: validatedData.status || 'active'
    };
    
    // Use direct SQL to insert the credit control area to avoid compatibility issues
    const insertResult = await db.execute(`
      INSERT INTO credit_control_areas 
      (code, name, description, company_code_id, credit_checking_group, credit_period, 
      grace_percentage, blocking_reason, review_frequency, currency, credit_approver, 
      status, is_active, notes, created_at, updated_at)
      VALUES 
      ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW(), NOW())
      RETURNING *
    `, [
      dataToInsert.code,
      dataToInsert.name, 
      dataToInsert.description || null,
      dataToInsert.companyCodeId,
      dataToInsert.creditCheckingGroup || null,
      dataToInsert.creditPeriod,
      dataToInsert.gracePercentage,
      dataToInsert.blockingReason || null,
      dataToInsert.reviewFrequency || 'monthly',
      dataToInsert.currency || 'USD',
      dataToInsert.creditApprover || null,
      dataToInsert.status || 'active',
      dataToInsert.isActive,
      dataToInsert.notes || null
    ]);
    
    const newCreditControl = insertResult.rows[0];
    
    // Get the company code details to include in the response using direct SQL
    const companyCodeResult = await db.execute(
      `SELECT id, code, name FROM company_codes WHERE id = $1`,
      [newCreditControl.company_code_id]
    );
    
    const companyCodeDetails = companyCodeResult.rows[0];
    
    const result = {
      ...newCreditControl,
      companyCode: companyCodeDetails
    };
    
    return res.status(201).json(result);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    console.error("Error creating credit control area:", error);
    return res.status(500).json({ message: "Failed to create credit control area", error });
  }
}

// Update a credit control area
export async function updateCreditControlArea(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    // Check if credit control area exists
    const existingCreditControl = await db.select().from(creditControlAreas).where(eq(creditControlAreas.id, id));
    if (existingCreditControl.length === 0) {
      return res.status(404).json({ message: "Credit control area not found" });
    }
    
    // Parse and validate the update data
    const validatedData = insertCreditControlSchema.partial().parse(req.body);
    
    // If company code ID is provided, check if it exists
    if (validatedData.companyCodeId) {
      const companyCode = await db.select().from(companyCodes).where(eq(companyCodes.id, validatedData.companyCodeId));
      if (companyCode.length === 0) {
        return res.status(400).json({ message: "Company code not found" });
      }
    }
    
    // Update the credit control area
    const [updatedCreditControl] = await db.update(creditControlAreas)
      .set({
        ...validatedData,
        updatedAt: new Date()
      })
      .where(eq(creditControlAreas.id, id))
      .returning();
    
    // Get the company code details to include in the response
    const [companyCodeDetails] = await db.select({
      id: companyCodes.id,
      code: companyCodes.code,
      name: companyCodes.name
    })
    .from(companyCodes)
    .where(eq(companyCodes.id, updatedCreditControl.companyCodeId));
    
    const result = {
      ...updatedCreditControl,
      companyCode: companyCodeDetails
    };
    
    return res.status(200).json(result);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    console.error("Error updating credit control area:", error);
    return res.status(500).json({ message: "Failed to update credit control area", error });
  }
}

// Delete a credit control area (soft delete by setting isActive to false)
export async function deleteCreditControlArea(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID format" });
    }
    
    // Check if credit control area exists
    const existingCreditControl = await db.select().from(creditControlAreas).where(eq(creditControlAreas.id, id));
    if (existingCreditControl.length === 0) {
      return res.status(404).json({ message: "Credit control area not found" });
    }
    
    // Soft delete by setting isActive to false
    await db.update(creditControlAreas)
      .set({
        isActive: false,
        updatedAt: new Date()
      })
      .where(eq(creditControlAreas.id, id));
    
    return res.status(200).json({ message: "Credit control area deleted successfully" });
  } catch (error) {
    console.error("Error deleting credit control area:", error);
    return res.status(500).json({ message: "Failed to delete credit control area", error });
  }
}