import { Router, Request, Response } from "express";
import { storage } from "../../storage";

const router = Router();

// Get all customers with organizational relationships
router.get("/", async (req: Request, res: Response) => {
  try {
    // Return sample data for our ERP customers with organizational relationships
    const sampleCustomers = [
      {
        id: 1,
        code: "C1001",
        name: "Acme Corporation",
        type: "corporate",
        description: "Large manufacturing client",
        tax_id: "123-45-6789",
        industry: "manufacturing",
        segment: "enterprise",
        address: "123 Main Street",
        city: "Chicago",
        state: "IL",
        country: "US",
        postal_code: "60601",
        phone: "+1-312-555-1234",
        email: "contact@acmecorp.com",
        currency: "USD",
        payment_terms: "net_30",
        credit_limit: 50000.00,
        company_code_id: 2,
        company_code: "2000 - US Operations",
        sales_organization_id: 1,
        sales_organization: "2000 - US Domestic Sales",
        credit_control_area_id: 1,
        credit_control_area: "US01 - US Credit Control",
        is_b2b: true,
        is_vip: true,
        is_active: true,
        status: "active",
        created_at: new Date(2023, 1, 15).toISOString(),
        updated_at: new Date(2023, 10, 5).toISOString()
      },
      {
        id: 2,
        code: "C1002",
        name: "Global Retailers",
        type: "corporate",
        description: "International retail chain",
        tax_id: "987-65-4321",
        industry: "retail",
        segment: "key_account",
        address: "456 Market Ave",
        city: "New York",
        state: "NY",
        country: "US",
        postal_code: "10001",
        phone: "+1-212-555-2345",
        email: "orders@globalretail.com",
        currency: "USD",
        payment_terms: "net_45",
        credit_limit: 100000.00,
        company_code_id: 2,
        company_code: "2000 - US Operations",
        sales_organization_id: 1,
        sales_organization: "2000 - US Domestic Sales",
        credit_control_area_id: 2,
        credit_control_area: "US02 - US Special Accounts",
        is_b2b: true,
        is_vip: true,
        is_active: true,
        status: "active",
        created_at: new Date(2023, 2, 10).toISOString(),
        updated_at: new Date(2023, 9, 22).toISOString()
      },
      {
        id: 3,
        code: "C1003",
        name: "City Hospital",
        type: "corporate",
        description: "Regional medical center",
        tax_id: "456-78-9012",
        industry: "healthcare",
        segment: "mid_market",
        address: "789 Health Blvd",
        city: "Boston",
        state: "MA",
        country: "US",
        postal_code: "02110",
        phone: "+1-617-555-3456",
        email: "procurement@cityhospital.org",
        currency: "USD",
        payment_terms: "net_60",
        credit_limit: 75000.00,
        company_code_id: 2,
        company_code: "2000 - US Operations",
        sales_organization_id: 2,
        sales_organization: "2010 - US Government & Healthcare",
        credit_control_area_id: 1,
        credit_control_area: "US01 - US Credit Control",
        is_b2b: true,
        is_vip: false,
        is_active: true,
        status: "active",
        created_at: new Date(2023, 3, 5).toISOString(),
        updated_at: new Date(2023, 8, 15).toISOString()
      },
      {
        id: 4,
        code: "C1004",
        name: "Tech Innovations",
        type: "corporate",
        description: "Technology startup",
        tax_id: "789-01-2345",
        industry: "technology",
        segment: "small_business",
        address: "321 Tech Park",
        city: "San Francisco",
        state: "CA",
        country: "US",
        postal_code: "94105",
        phone: "+1-415-555-4567",
        email: "orders@techinnovate.com",
        currency: "USD",
        payment_terms: "net_30",
        credit_limit: 25000.00,
        company_code_id: 1,
        company_code: "1000 - Global HQ",
        sales_organization_id: 1,
        sales_organization: "2000 - US Domestic Sales",
        credit_control_area_id: 2,
        credit_control_area: "US02 - US Special Accounts",
        is_b2b: true,
        is_vip: false,
        is_active: true,
        status: "active",
        created_at: new Date(2023, 4, 20).toISOString(),
        updated_at: new Date(2023, 11, 10).toISOString()
      },
      {
        id: 5,
        code: "C1005",
        name: "John Smith",
        type: "individual",
        description: "Regular customer",
        industry: null,
        segment: "consumer",
        address: "555 Residential St",
        city: "Los Angeles",
        state: "CA",
        country: "US",
        postal_code: "90001",
        phone: "+1-213-555-5678",
        email: "john.smith@email.com",
        currency: "USD",
        payment_terms: "prepaid",
        credit_limit: 1000.00,
        company_code_id: 2,
        company_code: "2000 - US Operations",
        sales_organization_id: 2,
        sales_organization: "2010 - US Government & Healthcare",
        credit_control_area_id: 1,
        credit_control_area: "US01 - US Credit Control",
        is_b2b: false,
        is_b2c: true,
        is_vip: false,
        is_active: true,
        status: "active",
        created_at: new Date(2023, 5, 12).toISOString(),
        updated_at: new Date(2023, 5, 12).toISOString()
      },
      {
        id: 6,
        code: "C1007",
        name: "European Distributors",
        type: "corporate",
        description: "European distribution partner",
        tax_id: "EU-8765432",
        industry: "distribution",
        segment: "strategic",
        address: "10 International Blvd",
        city: "Berlin",
        state: null,
        country: "DE",
        postal_code: "10115",
        phone: "+49-30-555-7890",
        email: "orders@eurodist.eu",
        currency: "EUR",
        payment_terms: "net_45",
        credit_limit: 200000.00,
        company_code_id: 1,
        company_code: "1000 - Global HQ",
        sales_organization_id: 3,
        sales_organization: "3000 - European Sales",
        credit_control_area_id: 3,
        credit_control_area: "EU01 - European Credit Control",
        is_b2b: true,
        is_b2c: false,
        is_vip: true,
        is_active: true,
        status: "active",
        created_at: new Date(2023, 6, 1).toISOString(),
        updated_at: new Date(2023, 6, 1).toISOString()
      },
      {
        id: 7,
        code: "C1008",
        name: "Education Foundation",
        type: "non_profit",
        description: "Educational institution",
        tax_id: "TAX-EXEMPT-123",
        industry: "education",
        segment: "mid_market",
        address: "200 Learning Way",
        city: "Atlanta",
        state: "GA",
        country: "US",
        postal_code: "30301",
        phone: "+1-404-555-8901",
        email: "purchases@edufoundation.org",
        currency: "USD",
        payment_terms: "net_30",
        credit_limit: 30000.00,
        company_code_id: 2,
        company_code: "2000 - US Operations",
        sales_organization_id: 2,
        sales_organization: "2010 - US Government & Healthcare",
        credit_control_area_id: 1,
        credit_control_area: "US01 - US Credit Control",
        is_b2b: true,
        is_b2c: false,
        is_vip: false,
        is_active: true,
        status: "active",
        created_at: new Date(2023, 7, 5).toISOString(),
        updated_at: new Date(2023, 7, 5).toISOString()
      }
    ];
    
    res.json(sampleCustomers);
  } catch (error) {
    console.error("Error fetching customers:", error);
    res.status(500).json({ message: "Failed to fetch customers" });
  }
});

// Get customer contacts for a specific customer
router.get("/:id/contacts", async (req: Request, res: Response) => {
  try {
    const customerId = parseInt(req.params.id);
    
    // Sample customer contacts data with organizational relationship
    const sampleCustomerContacts = [
      {
        id: 1,
        customerId: 1,
        firstName: "James",
        lastName: "Wilson",
        position: "Purchasing Manager",
        department: "Procurement",
        email: "james.wilson@acmecorp.com",
        phone: "+1-312-555-1235",
        mobile: "+1-312-555-9876",
        isPrimary: true,
        isBilling: false,
        isShipping: false,
        isTechnical: false,
        isMarketing: false,
        preferredLanguage: "English",
        notes: "Main contact for all purchase orders",
        isActive: true
      },
      {
        id: 2,
        customerId: 1,
        firstName: "Sarah",
        lastName: "Johnson",
        position: "Accounts Payable Manager",
        department: "Finance",
        email: "sarah.johnson@acmecorp.com",
        phone: "+1-312-555-1236",
        mobile: "+1-312-555-8765",
        isPrimary: false,
        isBilling: true,
        isShipping: false,
        isTechnical: false,
        isMarketing: false,
        preferredLanguage: "English",
        notes: "Handles all invoicing and payment matters",
        isActive: true
      },
      {
        id: 3,
        customerId: 1,
        firstName: "Robert",
        lastName: "Davis",
        position: "Logistics Coordinator",
        department: "Operations",
        email: "robert.davis@acmecorp.com",
        phone: "+1-312-555-1237",
        mobile: "+1-312-555-7654",
        isPrimary: false,
        isBilling: false,
        isShipping: true,
        isTechnical: false,
        isMarketing: false,
        preferredLanguage: "English",
        notes: "Coordinates all deliveries and shipping arrangements",
        isActive: true
      }
    ];
    
    // Only return contacts for the requested customer
    const contacts = sampleCustomerContacts.filter(contact => contact.customerId === customerId);
    
    res.json(contacts);
  } catch (error) {
    console.error("Error fetching customer contacts:", error);
    res.status(500).json({ message: "Failed to fetch customer contacts" });
  }
});

// Add stub routes for CRUD operations
router.post("/", async (req: Request, res: Response) => {
  try {
    // For now, just return the request body with a generated ID
    const newCustomer = {
      id: Math.floor(Math.random() * 1000) + 100,
      ...req.body,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    res.status(201).json(newCustomer);
  } catch (error) {
    console.error("Error creating customer:", error);
    res.status(400).json({ message: "Failed to create customer" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    
    // Return the updated customer data
    res.json({
      id,
      ...req.body,
      updated_at: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error updating customer:", error);
    res.status(400).json({ message: "Failed to update customer" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting customer:", error);
    res.status(500).json({ message: "Failed to delete customer" });
  }
});

export default router;