/**
 * API Route for storage-location (mapped from storage_locations)
 */

import { Request, Response } from "express";
import { db } from "../../db";

export async function getStorageLocation(req: Request, res: Response) {
  try {
    // Query data from the original table
    const result = await db.execute('SELECT * FROM storage_locations');
    
    return res.json(result.rows);
  } catch (error: any) {
    console.error("Error fetching storage-location data:", error);
    return res.status(500).json({ message: `Failed to fetch storage-location data: ${error.message}` });
  }
}

export default getStorageLocation;