/**
 * API Route for region data
 */

import { Request, Response } from "express";
import { db } from "../../db";

export async function getRegion(req: Request, res: Response) {
  try {
    // Since the regions table may not exist yet, we'll create sample data
    const sampleRegions = [
      { id: 1, code: 'NA', name: 'North America', description: 'United States and Canada', is_active: true },
      { id: 2, code: 'EMEA', name: 'Europe, Middle East, and Africa', description: 'European, Middle Eastern, and African markets', is_active: true },
      { id: 3, code: 'APAC', name: 'Asia Pacific', description: 'Asian and Pacific markets', is_active: true },
      { id: 4, code: 'LATAM', name: 'Latin America', description: 'Central and South American markets', is_active: true },
      { id: 5, code: 'ANZ', name: 'Australia & New Zealand', description: 'Australian and New Zealand markets', is_active: true }
    ];
    
    return res.json(sampleRegions);
  } catch (error: any) {
    console.error("Error fetching region data:", error);
    return res.status(500).json({ message: `Failed to fetch region data: ${error.message}` });
  }
}

export default getRegion;