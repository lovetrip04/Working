import { Request, Response } from "express";
import { db, pool } from "../../db";
import { sql } from "drizzle-orm";

// GET /api/master-data/bom
export default async function getBillOfMaterials(req: Request, res: Response) {
  try {
    // Use pool directly for simpler queries
    const { rows } = await pool.query(`
      SELECT id, code, name, material_id, description, version, is_active, created_at, updated_at
      FROM bill_of_materials
      ORDER BY id ASC
    `);
    
    return res.status(200).json(rows);
  } catch (error: any) {
    console.error("[API] Error fetching bill of materials:", error);
    return res.status(500).json({ message: `Failed to fetch bill of materials: ${error.message}` });
  }
}

// GET /api/master-data/bom/:id
export async function getBillOfMaterialsById(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(`
      SELECT id, code, name, material_id, description, version, is_active, created_at, updated_at
      FROM bill_of_materials
      WHERE id = $1
    `, [id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ message: `Bill of materials with ID ${id} not found` });
    }
    
    return res.status(200).json(rows[0]);
  } catch (error: any) {
    console.error("[API] Error fetching bill of materials:", error);
    return res.status(500).json({ message: `Failed to fetch bill of materials: ${error.message}` });
  }
}

// GET /api/master-data/bom-items
export async function getBOMItems(req: Request, res: Response) {
  try {
    const bomId = req.query.bomId;
    
    // If bomId is provided, filter in the query
    if (bomId) {
      const { rows } = await pool.query(`
        SELECT * FROM bom_items
        WHERE bom_id = $1
        ORDER BY id ASC
      `, [Number(bomId)]);
      return res.status(200).json(rows);
    } else {
      // Get all items
      const { rows } = await pool.query(`
        SELECT * FROM bom_items
        ORDER BY id ASC
      `);
      return res.status(200).json(rows);
    }
  } catch (error: any) {
    console.error("[API] Error fetching BOM items:", error);
    return res.status(500).json({ message: `Failed to fetch BOM items: ${error.message}` });
  }
}