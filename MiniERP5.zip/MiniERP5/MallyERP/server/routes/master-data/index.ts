import { Express, Request, Response } from "express";
import * as purchaseReferences from "./purchase-references";
import * as creditControl from "./credit-control-simplified";
import * as approvalLevel from "./approval-level";
import * as plant from "./plant";
import { pool } from "../../db";
import { registerProductionMasterDataRoutes } from "./production-ready";

// Import the route handlers for master data tables
import getSalesOrganization from "./sales-organization";
import getPurchaseOrganization from "./purchase-organization";
import getStorageLocation from "./storage-location";
import getCurrency from "./currency";
import getUom from "./uom";
import getRegion from "./region";
import getFiscalPeriod from "./fiscal-period";
import getMaterial from "./material";
import getBillOfMaterials, { getBillOfMaterialsById, getBOMItems } from "./bom";
import workCentersRoutes from "./work-centers";
import vendorsRoutes from "./vendors";

export function registerMasterDataRoutes(app: Express) {
  // Register production-ready routes first (these override the broken ones)
  registerProductionMasterDataRoutes(app);
  
  // Register Work Centers Routes
  app.use('/api/master-data/work-center', workCentersRoutes);
  
  // Register Vendors Routes
  app.use('/api/master-data/vendors', vendorsRoutes);
  
  // Register vendor contact routes
  app.get("/api/master-data/vendor-contact", async (req: Request, res: Response) => {
    try {
      // Return empty array for now - this endpoint exists for compatibility
      res.json([]);
    } catch (error) {
      console.error("Error fetching vendor contacts:", error);
      res.status(500).json({ message: "Failed to fetch vendor contacts" });
    }
  });
  
  // Add vendor route for backward compatibility
  app.get("/api/master-data/vendor", async (req: Request, res: Response) => {
    try {
      // Redirect to vendors route
      const result = await fetch('http://localhost:5000/api/master-data/vendors');
      const vendors = await result.json();
      res.json(vendors);
    } catch (error) {
      console.error("Error fetching vendors:", error);
      res.status(500).json({ message: "Failed to fetch vendors" });
    }
  });
  
  app.post("/api/master-data/vendor", async (req: Request, res: Response) => {
    try {
      // Redirect to vendors route
      const result = await fetch('http://localhost:5000/api/master-data/vendors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body)
      });
      const vendor = await result.json();
      res.status(201).json(vendor);
    } catch (error) {
      console.error("Error creating vendor:", error);
      res.status(400).json({ message: "Failed to create vendor" });
    }
  });
  
  app.put("/api/master-data/vendor/:id", async (req: Request, res: Response) => {
    try {
      const id = req.params.id;
      // Redirect to vendors route
      const result = await fetch(`http://localhost:5000/api/master-data/vendors/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body)
      });
      const vendor = await result.json();
      res.json(vendor);
    } catch (error) {
      console.error("Error updating vendor:", error);
      res.status(400).json({ message: "Failed to update vendor" });
    }
  });
  // Company Code routes
  app.get("/api/master-data/company-codes", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM company_codes");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching company codes:", error);
      return res.status(500).json({ message: "Failed to fetch company codes" });
    }
  });

  app.get("/api/master-data/company-code", async (req: Request, res: Response) => {
    try {
      const result = await pool.query("SELECT * FROM company_codes");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching company codes:", error);
      return res.status(500).json({ message: "Failed to fetch company codes" });
    }
  });

  // Plants routes
  app.get("/api/master-data/plants", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM plants");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching plants:", error);
      return res.status(500).json({ message: "Failed to fetch plants" });
    }
  });

  app.get("/api/master-data/plant", plant.getPlants);
  app.get("/api/master-data/plant/:id", plant.getPlantById);
  app.post("/api/master-data/plant", plant.createPlant);
  app.put("/api/master-data/plant/:id", plant.updatePlant);
  app.delete("/api/master-data/plant/:id", plant.deletePlant);

  // Materials routes
  app.get("/api/master-data/materials", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM materials");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching materials:", error);
      return res.status(500).json({ message: "Failed to fetch materials" });
    }
  });

  app.get("/api/master-data/material", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM materials");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching materials:", error);
      return res.status(500).json({ message: "Failed to fetch materials" });
    }
  });

  app.post("/api/master-data/material", async (req: Request, res: Response) => {
    try {
      const { code, name, type, baseUom, status } = req.body;
      const result = await pool.query(`
        INSERT INTO materials (code, name, type, base_uom, created_at, updated_at, is_active)
        VALUES ($1, $2, $3, $4, NOW(), NOW(), true)
        RETURNING *
      `, [code, name, type || 'Raw Material', baseUom || 'PC']);
      
      return res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error("Error creating material:", error);
      return res.status(500).json({ message: "Failed to create material", error: error.message });
    }
  });

  // Customers routes
  app.get("/api/master-data/customers", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM customers");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching customers:", error);
      return res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.get("/api/master-data/customer", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM customers");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching customers:", error);
      return res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.post("/api/master-data/customer", async (req: Request, res: Response) => {
    try {
      const { code, name, email, type } = req.body;
      const result = await pool.query(`
        INSERT INTO customers (code, name, email, type, created_at, updated_at, is_active)
        VALUES ($1, $2, $3, $4, NOW(), NOW(), true)
        RETURNING *
      `, [code, name, email, type || 'Regular']);
      
      return res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error("Error creating customer:", error);
      return res.status(500).json({ message: "Failed to create customer", error: error.message });
    }
  });

  // Vendors routes
  app.get("/api/master-data/vendors", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM vendors");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching vendors:", error);
      return res.status(500).json({ message: "Failed to fetch vendors" });
    }
  });

  app.get("/api/master-data/vendor", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM vendors");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching vendors:", error);
      return res.status(500).json({ message: "Failed to fetch vendors" });
    }
  });

  app.post("/api/master-data/vendor", async (req: Request, res: Response) => {
    try {
      const { code, name, email, type } = req.body;
      const result = await pool.query(`
        INSERT INTO vendors (code, name, email, type, created_at, updated_at, is_active)
        VALUES ($1, $2, $3, $4, NOW(), NOW(), true)
        RETURNING *
      `, [code, name, email, type || 'Supplier']);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating vendor:", error);
      return res.status(500).json({ message: "Failed to create vendor", error: error.message });
    }
  });

  // Units of Measure routes
  app.get("/api/master-data/units-of-measure", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM units_of_measure");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching units of measure:", error);
      return res.status(500).json({ message: "Failed to fetch units of measure" });
    }
  });

  // Currencies routes
  app.get("/api/master-data/currencies", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM currencies");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching currencies:", error);
      return res.status(500).json({ message: "Failed to fetch currencies" });
    }
  });

  // Cost Centers routes
  app.get("/api/master-data/cost-centers", async (req: Request, res: Response) => {
    try {
      res.setHeader('Content-Type', 'application/json');
      const result = await pool.query("SELECT * FROM cost_centers");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching cost centers:", error);
      return res.status(500).json({ message: "Failed to fetch cost centers" });
    }
  });

  // Purchase Groups
  app.get("/api/master-data/purchase-group", purchaseReferences.getPurchaseGroups);
  app.get("/api/master-data/purchase-group/:id", purchaseReferences.getPurchaseGroupById);
  app.post("/api/master-data/purchase-group", purchaseReferences.createPurchaseGroup);
  app.put("/api/master-data/purchase-group/:id", purchaseReferences.updatePurchaseGroup);
  app.delete("/api/master-data/purchase-group/:id", purchaseReferences.deletePurchaseGroup);
  
  // Supply Types
  app.get("/api/master-data/supply-type", purchaseReferences.getSupplyTypes);
  app.get("/api/master-data/supply-type/:id", purchaseReferences.getSupplyTypeById);
  app.post("/api/master-data/supply-type", purchaseReferences.createSupplyType);
  app.put("/api/master-data/supply-type/:id", purchaseReferences.updateSupplyType);
  app.delete("/api/master-data/supply-type/:id", purchaseReferences.deleteSupplyType);
  
  // Credit Control Areas
  app.get("/api/master-data/credit-control", creditControl.getCreditControlAreas);
  app.get("/api/master-data/credit-control/:id", creditControl.getCreditControlAreaById);
  app.post("/api/master-data/credit-control", creditControl.createCreditControlArea);
  app.put("/api/master-data/credit-control/:id", creditControl.updateCreditControlArea);
  app.delete("/api/master-data/credit-control/:id", creditControl.deleteCreditControlArea);
  
  // Approval Levels
  app.get("/api/master-data/approval-level", approvalLevel.getApprovalLevels);
  app.get("/api/master-data/approval-level/:id", approvalLevel.getApprovalLevelById);
  app.post("/api/master-data/approval-level", approvalLevel.createApprovalLevel);
  app.put("/api/master-data/approval-level/:id", approvalLevel.updateApprovalLevel);
  app.delete("/api/master-data/approval-level/:id", approvalLevel.deleteApprovalLevel);
  
  // Register routes for master data tables
  app.get("/api/master-data/sales-organization", getSalesOrganization);
  app.get("/api/master-data/purchase-organization", getPurchaseOrganization);
  app.get("/api/master-data/storage-location", getStorageLocation);
  app.get("/api/master-data/currency", getCurrency);
  app.get("/api/master-data/uom", getUom);
  app.get("/api/master-data/region", getRegion);
  app.get("/api/master-data/fiscal-period", getFiscalPeriod);
  app.get("/api/master-data/material", getMaterial);
  app.get("/api/master-data/bom", getBillOfMaterials);
  app.get("/api/master-data/bom/:id", getBillOfMaterialsById);
  app.get("/api/master-data/bom-items", getBOMItems);

  // POST routes that were missing - adding them here to be properly registered
  
  // Sales Organization POST route
  app.post("/api/master-data/sales-organization", async (req: Request, res: Response) => {
    try {
      const { code, name, description, company_code_id, companyCodeId, active } = req.body;
      
      // Handle both field name formats
      const companyCode = company_code_id || companyCodeId;
      
      const result = await pool.query(`
        INSERT INTO sales_organizations (code, name, description, company_code_id, active, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
        RETURNING *
      `, [code, name, description, companyCode, active !== false]);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating sales organization:", error);
      return res.status(500).json({ message: "Failed to create sales organization", error: error.message });
    }
  });

  // Purchase Organization POST route
  app.post("/api/master-data/purchase-organization", async (req: Request, res: Response) => {
    try {
      const { code, name, description, notes, companyCodeId, company_code_id, active } = req.body;
      
      // Handle both field name formats
      const companyCode = company_code_id || companyCodeId;
      
      // Create unique code within 10 character limit
      const baseCode = code ? code.substring(0, 6) : 'PO';
      const uniqueSuffix = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      const truncatedCode = baseCode + uniqueSuffix;
      
      const result = await pool.query(`
        INSERT INTO purchase_organizations (code, name, description, notes, company_code_id, active, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
        RETURNING *
      `, [truncatedCode, name, description, notes, companyCode, active !== false]);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating purchase organization:", error);
      return res.status(500).json({ message: "Failed to create purchase organization", error: error.message });
    }
  });

  // Cost Center POST route
  app.post("/api/master-data/cost-center", async (req: Request, res: Response) => {
    try {
      const { code, name, description, company_code_id, companyCodeId, cost_center_group, active } = req.body;
      
      // Handle both field name formats
      const companyCode = company_code_id || companyCodeId;
      
      // Truncate cost center code to 10 characters to match database constraint
      const truncatedCode = code ? code.substring(0, 10) : null;
      
      // Get company code from company_codes table for the required company_code field
      const companyResult = await pool.query(`SELECT code FROM company_codes WHERE id = $1`, [companyCode]);
      const companyCodeValue = companyResult.rows[0]?.code || 'DEFAULT';
      
      // Use correct database field names for cost centers table
      const result = await pool.query(`
        INSERT INTO cost_centers (cost_center, description, cost_center_category, company_code_id, company_code, active, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
        RETURNING *
      `, [truncatedCode, description, cost_center_group, companyCode, companyCodeValue, active !== false]);
      
      return res.status(201).json(result.rows[0]);
    } catch (error: any) {
      console.error("Error creating cost center:", error);
      return res.status(500).json({ message: "Failed to create cost center", error: error.message });
    }
  });
}