import { Router } from "express";
import { salesDistributionService } from "../services/sales-distribution-service";
import { Request, Response } from "express";

const router = Router();

// Enterprise Structure Routes

// Sales Organizations
router.get("/sales-organizations", async (req: Request, res: Response) => {
  try {
    const salesOrgs = await salesDistributionService.getAllSalesOrganizations();
    res.json(salesOrgs);
  } catch (error) {
    console.error("Error fetching sales organizations:", error);
    res.status(500).json({ message: "Failed to fetch sales organizations" });
  }
});

router.post("/sales-organizations", async (req: Request, res: Response) => {
  try {
    const { code, name, companyCode, currency, address } = req.body;
    const salesOrg = await salesDistributionService.createSalesOrganization({
      code,
      name,
      companyCode,
      currency,
      address
    });
    res.status(201).json(salesOrg);
  } catch (error) {
    console.error("Error creating sales organization:", error);
    res.status(500).json({ message: "Failed to create sales organization" });
  }
});

// Distribution Channels
router.get("/distribution-channels", async (req: Request, res: Response) => {
  try {
    const channels = await salesDistributionService.getAllDistributionChannels();
    res.json(channels);
  } catch (error) {
    console.error("Error fetching distribution channels:", error);
    res.status(500).json({ message: "Failed to fetch distribution channels" });
  }
});

router.post("/distribution-channels", async (req: Request, res: Response) => {
  try {
    const { code, name, description } = req.body;
    const channel = await salesDistributionService.createDistributionChannel({
      code,
      name,
      description
    });
    res.status(201).json(channel);
  } catch (error) {
    console.error("Error creating distribution channel:", error);
    res.status(500).json({ message: "Failed to create distribution channel" });
  }
});

// Divisions
router.get("/divisions", async (req: Request, res: Response) => {
  try {
    const divisions = await salesDistributionService.getAllDivisions();
    res.json(divisions);
  } catch (error) {
    console.error("Error fetching divisions:", error);
    res.status(500).json({ message: "Failed to fetch divisions" });
  }
});

router.post("/divisions", async (req: Request, res: Response) => {
  try {
    const { code, name, description } = req.body;
    const division = await salesDistributionService.createDivision({
      code,
      name,
      description
    });
    res.status(201).json(division);
  } catch (error) {
    console.error("Error creating division:", error);
    res.status(500).json({ message: "Failed to create division" });
  }
});

// Sales Offices
router.post("/sales-offices", async (req: Request, res: Response) => {
  try {
    const { code, name, description } = req.body;
    const office = await salesDistributionService.createSalesOffice({
      code,
      name,
      description
    });
    res.status(201).json(office);
  } catch (error) {
    console.error("Error creating sales office:", error);
    res.status(500).json({ message: "Failed to create sales office" });
  }
});

// Shipping Points
router.post("/shipping-points", async (req: Request, res: Response) => {
  try {
    const { code, name, plantCode, factoryCalendar } = req.body;
    const shippingPoint = await salesDistributionService.createShippingPoint({
      code,
      name,
      plantCode,
      factoryCalendar
    });
    res.status(201).json(shippingPoint);
  } catch (error) {
    console.error("Error creating shipping point:", error);
    res.status(500).json({ message: "Failed to create shipping point" });
  }
});

// Sales Areas
router.get("/sales-areas", async (req: Request, res: Response) => {
  try {
    const salesAreas = await salesDistributionService.getAllSalesAreas();
    res.json(salesAreas);
  } catch (error) {
    console.error("Error fetching sales areas:", error);
    res.status(500).json({ message: "Failed to fetch sales areas" });
  }
});

router.post("/sales-areas", async (req: Request, res: Response) => {
  try {
    const { salesOrgCode, distributionChannelCode, divisionCode, name } = req.body;
    
    // Validate configuration first
    const validation = await salesDistributionService.validateSalesAreaConfiguration(
      salesOrgCode,
      distributionChannelCode,
      divisionCode
    );
    
    if (!validation.isValid) {
      return res.status(400).json({
        message: "Invalid sales area configuration",
        errors: validation.errors
      });
    }
    
    const salesArea = await salesDistributionService.createSalesArea({
      salesOrgCode,
      distributionChannelCode,
      divisionCode,
      name
    });
    res.status(201).json(salesArea);
  } catch (error) {
    console.error("Error creating sales area:", error);
    res.status(500).json({ message: "Failed to create sales area" });
  }
});

router.get("/sales-areas/validate", async (req: Request, res: Response) => {
  try {
    const { salesOrgCode, distributionChannelCode, divisionCode } = req.query;
    
    if (!salesOrgCode || !distributionChannelCode || !divisionCode) {
      return res.status(400).json({
        message: "Missing required parameters: salesOrgCode, distributionChannelCode, divisionCode"
      });
    }
    
    const validation = await salesDistributionService.validateSalesAreaConfiguration(
      salesOrgCode as string,
      distributionChannelCode as string,
      divisionCode as string
    );
    
    res.json(validation);
  } catch (error) {
    console.error("Error validating sales area:", error);
    res.status(500).json({ message: "Failed to validate sales area" });
  }
});

// Sales Office Assignments
router.post("/sales-office-assignments", async (req: Request, res: Response) => {
  try {
    const { salesOfficeCode, salesAreaId } = req.body;
    const assignment = await salesDistributionService.assignSalesOfficeToSalesArea(
      salesOfficeCode,
      salesAreaId
    );
    res.status(201).json(assignment);
  } catch (error) {
    console.error("Error creating sales office assignment:", error);
    res.status(500).json({ message: "Failed to create sales office assignment" });
  }
});

// Document Configuration Routes

// Document Types
router.get("/document-types", async (req: Request, res: Response) => {
  try {
    const { category } = req.query;
    const docTypes = await salesDistributionService.getAllDocumentTypes(category as string);
    res.json(docTypes);
  } catch (error) {
    console.error("Error fetching document types:", error);
    res.status(500).json({ message: "Failed to fetch document types" });
  }
});

router.post("/document-types", async (req: Request, res: Response) => {
  try {
    const { code, name, category, numberRange, documentFlow } = req.body;
    const docType = await salesDistributionService.createDocumentType({
      code,
      name,
      category,
      numberRange,
      documentFlow
    });
    res.status(201).json(docType);
  } catch (error) {
    console.error("Error creating document type:", error);
    res.status(500).json({ message: "Failed to create document type" });
  }
});

// Item Categories
router.post("/item-categories", async (req: Request, res: Response) => {
  try {
    const {
      code,
      name,
      documentCategory,
      itemType,
      deliveryRelevant,
      billingRelevant,
      pricingRelevant
    } = req.body;
    
    const itemCategory = await salesDistributionService.createItemCategory({
      code,
      name,
      documentCategory,
      itemType,
      deliveryRelevant,
      billingRelevant,
      pricingRelevant
    });
    res.status(201).json(itemCategory);
  } catch (error) {
    console.error("Error creating item category:", error);
    res.status(500).json({ message: "Failed to create item category" });
  }
});

// Pricing Configuration Routes

// Condition Types
router.get("/condition-types", async (req: Request, res: Response) => {
  try {
    const conditionTypes = await salesDistributionService.getAllConditionTypes();
    res.json(conditionTypes);
  } catch (error) {
    console.error("Error fetching condition types:", error);
    res.status(500).json({ message: "Failed to fetch condition types" });
  }
});

router.post("/condition-types", async (req: Request, res: Response) => {
  try {
    const { code, name, conditionClass, calculationType, accessSequence } = req.body;
    const conditionType = await salesDistributionService.createConditionType({
      code,
      name,
      conditionClass,
      calculationType,
      accessSequence
    });
    res.status(201).json(conditionType);
  } catch (error) {
    console.error("Error creating condition type:", error);
    res.status(500).json({ message: "Failed to create condition type" });
  }
});

// Pricing Procedures
router.get("/pricing-procedures", async (req: Request, res: Response) => {
  try {
    const procedures = await salesDistributionService.getAllPricingProcedures();
    res.json(procedures);
  } catch (error) {
    console.error("Error fetching pricing procedures:", error);
    res.status(500).json({ message: "Failed to fetch pricing procedures" });
  }
});

router.post("/pricing-procedures", async (req: Request, res: Response) => {
  try {
    const { code, name, steps } = req.body;
    const procedure = await salesDistributionService.createPricingProcedure({
      code,
      name,
      steps
    });
    res.status(201).json(procedure);
  } catch (error) {
    console.error("Error creating pricing procedure:", error);
    res.status(500).json({ message: "Failed to create pricing procedure" });
  }
});

// Number Range Management Routes

router.post("/number-range-objects", async (req: Request, res: Response) => {
  try {
    const { objectCode, name, description } = req.body;
    const object = await salesDistributionService.createNumberRangeObject({
      objectCode,
      name,
      description
    });
    res.status(201).json(object);
  } catch (error) {
    console.error("Error creating number range object:", error);
    res.status(500).json({ message: "Failed to create number range object" });
  }
});

router.post("/number-ranges", async (req: Request, res: Response) => {
  try {
    const { rangeNumber, objectCode, fromNumber, toNumber, currentNumber, external } = req.body;
    const range = await salesDistributionService.createNumberRange({
      rangeNumber,
      objectCode,
      fromNumber,
      toNumber,
      currentNumber,
      external
    });
    res.status(201).json(range);
  } catch (error) {
    console.error("Error creating number range:", error);
    res.status(500).json({ message: "Failed to create number range" });
  }
});

router.get("/number-ranges/:objectCode/:rangeNumber/next", async (req: Request, res: Response) => {
  try {
    const { objectCode, rangeNumber } = req.params;
    const nextNumber = await salesDistributionService.getNextNumber(objectCode, rangeNumber);
    res.json({ nextNumber });
  } catch (error) {
    console.error("Error getting next number:", error);
    res.status(500).json({ message: "Failed to get next number" });
  }
});

// Copy Control Routes

router.post("/copy-control-headers", async (req: Request, res: Response) => {
  try {
    const { sourceDocType, targetDocType, copyRequirements, dataTransfer } = req.body;
    const control = await salesDistributionService.createCopyControlHeader({
      sourceDocType,
      targetDocType,
      copyRequirements,
      dataTransfer
    });
    res.status(201).json(control);
  } catch (error) {
    console.error("Error creating copy control header:", error);
    res.status(500).json({ message: "Failed to create copy control header" });
  }
});

router.post("/copy-control-items", async (req: Request, res: Response) => {
  try {
    const {
      sourceDocType,
      sourceItemCategory,
      targetDocType,
      targetItemCategory,
      copyRequirements,
      dataTransfer
    } = req.body;
    
    const control = await salesDistributionService.createCopyControlItem({
      sourceDocType,
      sourceItemCategory,
      targetDocType,
      targetItemCategory,
      copyRequirements,
      dataTransfer
    });
    res.status(201).json(control);
  } catch (error) {
    console.error("Error creating copy control item:", error);
    res.status(500).json({ message: "Failed to create copy control item" });
  }
});

// System Configuration Routes

router.post("/initialize-basic-config", async (req: Request, res: Response) => {
  try {
    const result = await salesDistributionService.initializeBasicConfiguration();
    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error("Error initializing basic configuration:", error);
    res.status(500).json({ 
      success: false, 
      message: "Failed to initialize basic configuration",
      error: error.message 
    });
  }
});

// Configuration Status and Health Check
router.get("/config-status", async (req: Request, res: Response) => {
  try {
    const salesOrgs = await salesDistributionService.getAllSalesOrganizations();
    const channels = await salesDistributionService.getAllDistributionChannels();
    const divisions = await salesDistributionService.getAllDivisions();
    const salesAreas = await salesDistributionService.getAllSalesAreas();
    const docTypes = await salesDistributionService.getAllDocumentTypes();
    const conditionTypes = await salesDistributionService.getAllConditionTypes();
    const procedures = await salesDistributionService.getAllPricingProcedures();

    const status = {
      salesOrganizations: salesOrgs.length,
      distributionChannels: channels.length,
      divisions: divisions.length,
      salesAreas: salesAreas.length,
      documentTypes: docTypes.length,
      conditionTypes: conditionTypes.length,
      pricingProcedures: procedures.length,
      configurationHealth: {
        enterpriseStructure: salesOrgs.length > 0 && channels.length > 0 && divisions.length > 0,
        salesAreas: salesAreas.length > 0,
        documentConfig: docTypes.length > 0,
        pricingConfig: conditionTypes.length > 0 && procedures.length > 0
      }
    };

    res.json(status);
  } catch (error) {
    console.error("Error fetching configuration status:", error);
    res.status(500).json({ message: "Failed to fetch configuration status" });
  }
});

export default router;