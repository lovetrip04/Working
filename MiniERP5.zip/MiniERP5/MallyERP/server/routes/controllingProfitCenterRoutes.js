/**
 * Controlling Profit Center Routes
 * Handles profit center operations for controlling module
 */

import express from 'express';
import pkg from 'pg';
const { Pool } = pkg;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const router = express.Router();

// Get all profit centers
router.get('/api/controlling/profit-centers', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        pc.*,
        cc.name as company_code_name
      FROM profit_centers pc
      LEFT JOIN company_codes cc ON pc.company_code_id = cc.id
      WHERE pc.active = true
      ORDER BY pc.id
    `);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching profit centers:', error);
    res.status(500).json({ message: 'Error fetching profit centers', error: error.message });
  }
});

// Create new profit center
router.post('/api/controlling/profit-centers', async (req, res) => {
  try {
    const { code, name, description, company_code_id, person_responsible, cost_center_id } = req.body;
    
    const result = await pool.query(`
      INSERT INTO profit_centers (code, name, description, company_code_id, person_responsible, cost_center_id, active, created_at, updated_at, created_by)
      VALUES ($1, $2, $3, $4, $5, $6, true, NOW(), NOW(), 1)
      RETURNING *
    `, [code, name, description, company_code_id, person_responsible, cost_center_id]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating profit center:', error);
    res.status(500).json({ message: 'Error creating profit center', error: error.message });
  }
});

export default router;