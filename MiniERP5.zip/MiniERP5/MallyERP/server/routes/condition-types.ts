import { Router } from 'express';
import { db } from '../db';
import { eq, and } from 'drizzle-orm';

const router = Router();

// Get all condition types for a company
router.get('/', async (req, res) => {
  try {
    const { company_code } = req.query;
    
    if (!company_code) {
      return res.status(400).json({ error: 'Company code is required' });
    }

    const result = await db.execute(`
      SELECT ct.*, cc.code as company_code, cc.name as company_name
      FROM condition_types ct
      JOIN company_codes cc ON ct.company_code_id = cc.id
      WHERE cc.code = $1
      ORDER BY ct.sequence_number, ct.condition_code
    `, [company_code]);

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching condition types:', error);
    res.status(500).json({ error: 'Failed to fetch condition types' });
  }
});

// Get companies for dropdown - moved to separate endpoint

// Create new condition type
router.post('/', async (req, res) => {
  try {
    const {
      condition_code,
      condition_name,
      condition_category,
      calculation_type,
      description,
      default_value,
      min_value,
      max_value,
      sequence_number,
      is_mandatory,
      is_active,
      company_code
    } = req.body;

    // Get company_code_id
    const companyResult = await db.execute(`
      SELECT id FROM company_codes WHERE code = $1
    `, [company_code]);

    if (companyResult.rows.length === 0) {
      return res.status(404).json({ error: 'Company not found' });
    }

    const company_code_id = companyResult.rows[0].id;

    // Check if condition code already exists for this company
    const existingResult = await db.execute(`
      SELECT id FROM condition_types 
      WHERE condition_code = $1 AND company_code_id = $2
    `, [condition_code, company_code_id]);

    if (existingResult.rows.length > 0) {
      return res.status(400).json({ error: 'Condition code already exists for this company' });
    }

    // Insert new condition type
    const insertResult = await db.execute(`
      INSERT INTO condition_types (
        condition_code, condition_name, condition_category, calculation_type,
        description, default_value, min_value, max_value, sequence_number,
        is_mandatory, is_active, company_code_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `, [
      condition_code, condition_name, condition_category, calculation_type,
      description, default_value, min_value, max_value, sequence_number,
      is_mandatory, is_active, company_code_id
    ]);

    res.status(201).json(insertResult.rows[0]);
  } catch (error) {
    console.error('Error creating condition type:', error);
    res.status(500).json({ error: 'Failed to create condition type' });
  }
});

// Update condition type
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const {
      condition_code,
      condition_name,
      condition_category,
      calculation_type,
      description,
      default_value,
      min_value,
      max_value,
      sequence_number,
      is_mandatory,
      is_active
    } = req.body;

    const updateResult = await db.execute(`
      UPDATE condition_types SET
        condition_code = $1,
        condition_name = $2,
        condition_category = $3,
        calculation_type = $4,
        description = $5,
        default_value = $6,
        min_value = $7,
        max_value = $8,
        sequence_number = $9,
        is_mandatory = $10,
        is_active = $11,
        updated_at = now()
      WHERE id = $12
      RETURNING *
    `, [
      condition_code, condition_name, condition_category, calculation_type,
      description, default_value, min_value, max_value, sequence_number,
      is_mandatory, is_active, id
    ]);

    if (updateResult.rows.length === 0) {
      return res.status(404).json({ error: 'Condition type not found' });
    }

    res.json(updateResult.rows[0]);
  } catch (error) {
    console.error('Error updating condition type:', error);
    res.status(500).json({ error: 'Failed to update condition type' });
  }
});

// Delete condition type
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Check if condition type is used in any sales orders
    const usageResult = await db.execute(`
      SELECT COUNT(*) as count
      FROM sales_order_conditions soc
      JOIN condition_types ct ON soc.condition_type_id = ct.id
      WHERE ct.id = $1
    `, [id]);

    const usageCount = parseInt(usageResult.rows[0].count);
    if (usageCount > 0) {
      return res.status(400).json({ 
        error: `Cannot delete condition type. It is used in ${usageCount} sales order(s)` 
      });
    }

    const deleteResult = await db.execute(`
      DELETE FROM condition_types WHERE id = $1 RETURNING *
    `, [id]);

    if (deleteResult.rows.length === 0) {
      return res.status(404).json({ error: 'Condition type not found' });
    }

    res.json({ message: 'Condition type deleted successfully' });
  } catch (error) {
    console.error('Error deleting condition type:', error);
    res.status(500).json({ error: 'Failed to delete condition type' });
  }
});

// Apply business template
router.post('/apply-template', async (req, res) => {
  try {
    const { template_type, company_code } = req.body;

    // Get company_code_id
    const companyResult = await db.execute(`
      SELECT id FROM company_codes WHERE code = $1
    `, [company_code]);

    if (companyResult.rows.length === 0) {
      return res.status(404).json({ error: 'Company not found' });
    }

    const company_code_id = companyResult.rows[0].id;

    let templateConditions = [];

    switch (template_type) {
      case 'restaurant':
        templateConditions = [
          { code: 'FOOD_BASE', name: 'Base Food Price', category: 'Revenue', type: 'fixed_amount', seq: 1 },
          { code: 'EXTRAS', name: 'Extra Toppings/Sides', category: 'Revenue', type: 'quantity_based', seq: 2 },
          { code: 'DELIVERY_FEE', name: 'Delivery Charge', category: 'Fee', type: 'fixed_amount', seq: 3 },
          { code: 'BULK_DISC', name: 'Volume Discount', category: 'Discount', type: 'percentage', seq: 4 },
          { code: 'LOCAL_TAX', name: 'Sales Tax', category: 'Tax', type: 'percentage', seq: 5 },
          { code: 'FOOD_COST', name: 'Cost of Ingredients', category: 'Cost', type: 'percentage', seq: 6 },
          { code: 'LABOR_COST', name: 'Labor & Operations', category: 'Cost', type: 'percentage', seq: 7 }
        ];
        break;
      case 'retail':
        templateConditions = [
          { code: 'PROD_PRICE', name: 'Product Price', category: 'Revenue', type: 'fixed_amount', seq: 1 },
          { code: 'SHIPPING', name: 'Shipping Cost', category: 'Fee', type: 'tiered', seq: 2 },
          { code: 'LOYALTY_DISC', name: 'Loyalty Discount', category: 'Discount', type: 'percentage', seq: 3 },
          { code: 'SALES_TAX', name: 'Sales Tax', category: 'Tax', type: 'percentage', seq: 4 },
          { code: 'PRODUCT_COST', name: 'Cost of Goods Sold', category: 'Cost', type: 'percentage', seq: 5 },
          { code: 'FULFILLMENT', name: 'Fulfillment Cost', category: 'Cost', type: 'fixed_amount', seq: 6 }
        ];
        break;
      case 'manufacturing':
        templateConditions = [
          { code: 'MAT_COST', name: 'Material Cost', category: 'Cost', type: 'fixed_amount', seq: 1 },
          { code: 'LABOR_RATE', name: 'Labor Cost', category: 'Cost', type: 'fixed_amount', seq: 2 },
          { code: 'OVERHEAD', name: 'Manufacturing Overhead', category: 'Cost', type: 'percentage', seq: 3 },
          { code: 'FREIGHT', name: 'Freight Charges', category: 'Fee', type: 'fixed_amount', seq: 4 },
          { code: 'MARGIN', name: 'Profit Margin', category: 'Revenue', type: 'percentage', seq: 5 }
        ];
        break;
      default:
        return res.status(400).json({ error: 'Invalid template type' });
    }

    // Insert template conditions
    const insertPromises = templateConditions.map(async (condition) => {
      return db.execute(`
        INSERT INTO condition_types (
          condition_code, condition_name, condition_category, calculation_type,
          sequence_number, company_code_id, is_active
        ) VALUES ($1, $2, $3, $4, $5, $6, true)
        ON CONFLICT (condition_code, company_code_id) DO NOTHING
      `, [
        condition.code, condition.name, condition.category, 
        condition.type, condition.seq, company_code_id
      ]);
    });

    await Promise.all(insertPromises);

    res.json({ 
      message: `${template_type} template applied successfully`,
      conditions_added: templateConditions.length
    });
  } catch (error) {
    console.error('Error applying template:', error);
    res.status(500).json({ error: 'Failed to apply template' });
  }
});

export default router;