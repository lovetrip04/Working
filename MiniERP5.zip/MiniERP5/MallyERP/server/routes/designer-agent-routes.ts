import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import { DesignerAgentService } from '../services/designer-agent-service';
import { db } from '../db';
import { designerDocuments, designerAnalysis, designerReviews } from '@shared/designer-agent-schema';
import { eq, desc } from 'drizzle-orm';

const router = Router();
const designerService = new DesignerAgentService();

// Configure multer for document uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/designer-documents/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `${uniqueSuffix}-${file.originalname}`);
  }
});

const upload = multer({ 
  storage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.pdf', '.docx', '.doc', '.png', '.jpg', '.jpeg'];
    const fileExt = path.extname(file.originalname).toLowerCase();
    
    if (allowedTypes.includes(fileExt)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOCX, and image files are allowed.'));
    }
  },
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

// Upload document for analysis
router.post('/upload-document', upload.single('document'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No document uploaded' });
    }

    const { documentType, uploadedBy } = req.body;

    const [document] = await db.insert(designerDocuments).values({
      fileName: req.file.originalname,
      fileType: path.extname(req.file.originalname).toLowerCase(),
      fileSize: req.file.size,
      uploadPath: req.file.path,
      documentType,
      uploadedBy,
      status: 'uploaded'
    }).returning();

    res.json({
      documentId: document.id,
      message: 'Document uploaded successfully',
      document
    });
  } catch (error) {
    console.error('Document upload error:', error);
    res.status(500).json({ error: 'Failed to upload document' });
  }
});

// Start document analysis
router.post('/analyze-document/:documentId', async (req, res) => {
  try {
    const documentId = parseInt(req.params.documentId);
    const { analysisOptions } = req.body;

    // Get document details
    const [document] = await db.select()
      .from(designerDocuments)
      .where(eq(designerDocuments.id, documentId))
      .limit(1);

    if (!document) {
      return res.status(404).json({ error: 'Document not found' });
    }

    // Read document content (placeholder - would implement actual file reading)
    const documentContent = `Document content from ${document.fileName}`;

    const analysisId = await designerService.analyzeDocument({
      documentId,
      documentContent,
      documentType: document.documentType as any,
      analysisOptions: analysisOptions || {
        prioritizeExistingTables: true,
        maintainDataIntegrity: true,
        generateMockData: true
      }
    });

    // Update document status
    await db.update(designerDocuments)
      .set({ 
        status: 'analyzed',
        processedAt: new Date()
      })
      .where(eq(designerDocuments.id, documentId));

    res.json({
      analysisId,
      message: 'Document analysis completed',
      status: 'completed'
    });
  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({ error: 'Failed to analyze document' });
  }
});

// Get analysis results
router.get('/analysis/:analysisId', async (req, res) => {
  try {
    const analysisId = parseInt(req.params.analysisId);
    const analysis = await designerService.getAnalysisResults(analysisId);

    if (!analysis) {
      return res.status(404).json({ error: 'Analysis not found' });
    }

    res.json(analysis);
  } catch (error) {
    console.error('Get analysis error:', error);
    res.status(500).json({ error: 'Failed to retrieve analysis' });
  }
});

// Submit analysis for review
router.post('/submit-for-review/:analysisId', async (req, res) => {
  try {
    const analysisId = parseInt(req.params.analysisId);
    const { reviewedBy } = req.body;

    const reviewId = await designerService.submitForReview(analysisId, reviewedBy);

    res.json({
      reviewId,
      message: 'Analysis submitted for review',
      status: 'pending_review'
    });
  } catch (error) {
    console.error('Submit review error:', error);
    res.status(500).json({ error: 'Failed to submit for review' });
  }
});

// Process review feedback
router.post('/review-feedback/:reviewId', async (req, res) => {
  try {
    const reviewId = parseInt(req.params.reviewId);
    const { status, comments, screenFeedback, changeRequests } = req.body;

    const result = await designerService.processReviewFeedback(
      reviewId,
      status,
      comments,
      screenFeedback,
      changeRequests
    );

    res.json({
      result,
      message: `Review ${status} successfully`,
      status
    });
  } catch (error) {
    console.error('Review feedback error:', error);
    res.status(500).json({ error: 'Failed to process review feedback' });
  }
});

// Get all documents
router.get('/documents', async (req, res) => {
  try {
    // Check if tables exist first
    const tableExists = await checkDesignerTablesExist();
    
    if (!tableExists) {
      await initializeDesignerTables();
    }
    
    // Use raw SQL query to avoid drizzle schema dependency
    const result = await db.execute('SELECT * FROM designer_documents ORDER BY uploaded_at DESC');
    
    res.json(result.rows || []);
  } catch (error) {
    console.error('Get documents error:', error);
    // Return empty array for initialization
    res.json([]);
  }
});

// Check if Designer Agent tables exist
async function checkDesignerTablesExist(): Promise<boolean> {
  try {
    const result = await db.execute(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name = 'designer_documents'
    `);
    return result.rows.length > 0;
  } catch (error) {
    return false;
  }
}

// Initialize Designer Agent tables
async function initializeDesignerTables() {
  try {
    await db.execute(`
      CREATE TABLE IF NOT EXISTS designer_documents (
        id SERIAL PRIMARY KEY,
        file_name VARCHAR(255) NOT NULL,
        file_type VARCHAR(50) NOT NULL,
        file_size INTEGER NOT NULL,
        upload_path TEXT NOT NULL,
        document_type VARCHAR(100) NOT NULL,
        status VARCHAR(50) DEFAULT 'uploaded',
        uploaded_by VARCHAR(255) NOT NULL,
        uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        processed_at TIMESTAMP WITH TIME ZONE
      )
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS designer_analysis (
        id SERIAL PRIMARY KEY,
        document_id INTEGER REFERENCES designer_documents(id),
        analysis_status VARCHAR(50) DEFAULT 'pending',
        existing_tables_analyzed JSONB,
        proposed_table_changes JSONB,
        new_tables_required JSONB,
        relationship_mappings JSONB,
        data_integrity_checks JSONB,
        existing_ui_components JSONB,
        proposed_ui_changes JSONB,
        new_ui_components JSONB,
        mock_data_examples JSONB,
        agent_notifications JSONB,
        implementation_plan JSONB,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS designer_reviews (
        id SERIAL PRIMARY KEY,
        analysis_id INTEGER REFERENCES designer_analysis(id),
        review_status VARCHAR(50) DEFAULT 'pending',
        reviewed_by VARCHAR(255) NOT NULL,
        review_comments TEXT,
        screen_specific_feedback JSONB,
        approval_timestamp TIMESTAMP WITH TIME ZONE,
        change_requests JSONB,
        change_request_status VARCHAR(50),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS designer_implementations (
        id SERIAL PRIMARY KEY,
        analysis_id INTEGER REFERENCES designer_analysis(id),
        implementation_status VARCHAR(50) DEFAULT 'pending',
        database_changes_applied JSONB,
        ui_changes_applied JSONB,
        agent_updates_completed JSONB,
        testing_results JSONB,
        validation_checks JSONB,
        rollback_plan JSONB,
        implemented_by VARCHAR(255) NOT NULL,
        started_at TIMESTAMP WITH TIME ZONE,
        completed_at TIMESTAMP WITH TIME ZONE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS designer_agent_communications (
        id SERIAL PRIMARY KEY,
        analysis_id INTEGER REFERENCES designer_analysis(id),
        target_agent VARCHAR(50) NOT NULL,
        communication_type VARCHAR(50) NOT NULL,
        message TEXT NOT NULL,
        payload JSONB,
        status VARCHAR(50) DEFAULT 'sent',
        sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        acknowledged_at TIMESTAMP WITH TIME ZONE
      )
    `);

    console.log('Designer Agent tables initialized successfully');
  } catch (error) {
    console.error('Designer Agent table initialization error:', error);
  }
}

// Get reviews for analysis
router.get('/reviews/:analysisId', async (req, res) => {
  try {
    const analysisId = parseInt(req.params.analysisId);
    const reviews = await designerService.getReviewStatus(analysisId);

    res.json(reviews);
  } catch (error) {
    console.error('Get reviews error:', error);
    res.status(500).json({ error: 'Failed to retrieve reviews' });
  }
});

// Get current system architecture
router.get('/system-architecture', async (req, res) => {
  try {
    // Query current table structures
    const tablesQuery = `
      SELECT 
        t.table_name,
        json_agg(
          json_build_object(
            'column_name', c.column_name,
            'data_type', c.data_type,
            'is_nullable', c.is_nullable,
            'column_default', c.column_default
          ) ORDER BY c.ordinal_position
        ) as columns
      FROM information_schema.tables t
      LEFT JOIN information_schema.columns c ON t.table_name = c.table_name
      WHERE t.table_schema = 'public' 
        AND t.table_type = 'BASE TABLE'
        AND t.table_name NOT LIKE 'drizzle_%'
      GROUP BY t.table_name
      ORDER BY t.table_name
    `;

    const result = await db.execute(tablesQuery);

    res.json({
      tables: result.rows,
      totalTables: result.rows.length,
      uiComponents: {
        existing: [
          { name: 'Finance Dashboard', domain: 'Finance', route: '/finance', status: 'active' },
          { name: 'Sales Management', domain: 'Sales', route: '/sales', status: 'active' },
          { name: 'Inventory Control', domain: 'Inventory', route: '/inventory', status: 'active' },
          { name: 'HR Management', domain: 'HR', route: '/hr', status: 'active' },
          { name: 'Production Planning', domain: 'Production', route: '/production', status: 'active' },
          { name: 'Purchase Management', domain: 'Purchasing', route: '/purchase', status: 'active' },
          { name: 'AI Agents System', domain: 'AI', route: '/ai-agents', status: 'active' },
          { name: 'Designer Agent', domain: 'AI', route: '/designer-agent', status: 'active' },
          { name: 'Transport System', domain: 'Logistics', route: '/transport', status: 'active' },
          { name: 'Controlling Module', domain: 'Finance', route: '/controlling', status: 'active' }
        ]
      }
    });
  } catch (error) {
    console.error('System architecture error:', error);
    res.status(500).json({ error: 'Failed to retrieve system architecture' });
  }
});

// Get current UI components
router.get('/ui-components', async (req, res) => {
  try {
    // Return current UI component structure
    const uiStructure = {
      pages: [
        { name: 'Finance', route: '/finance', description: 'Financial management and reporting' },
        { name: 'Sales', route: '/sales', description: 'Sales order and customer management' },
        { name: 'Inventory', route: '/inventory', description: 'Material and stock management' },
        { name: 'HR', route: '/hr', description: 'Human resources and payroll' },
        { name: 'Production', route: '/production', description: 'Manufacturing and work orders' },
        { name: 'Purchasing', route: '/purchase', description: 'Procurement and vendor management' }
      ],
      agentPages: [
        { name: 'Chief Agent', route: '/chief-agent', description: 'Executive oversight and approvals' },
        { name: 'Coach Agent', route: '/coach-agent', description: 'Strategic coordination' },
        { name: 'Agent Player', route: '/agent-player', description: 'Operational execution' },
        { name: 'Rookie Agent', route: '/rookie-agent', description: 'Learning and data entry' }
      ],
      components: [
        { name: 'JrChatbot', description: 'Business domain assistance chatbot' },
        { name: 'ResizableDashboard', description: 'Customizable dashboard widgets' },
        { name: 'EnhancedSalesOrder', description: 'Advanced sales order processing' }
      ]
    };

    res.json(uiStructure);
  } catch (error) {
    console.error('UI components error:', error);
    res.status(500).json({ error: 'Failed to retrieve UI components' });
  }
});

// Initialize tables endpoint
router.post('/init-tables', async (req, res) => {
  try {
    await initializeDesignerTables();
    res.json({ message: 'Designer Agent tables initialized successfully' });
  } catch (error) {
    console.error('Table initialization error:', error);
    res.status(500).json({ error: 'Failed to initialize tables' });
  }
});

export { router as designerAgentRoutes };