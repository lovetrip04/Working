import { Router } from "express";
import { bankIntegrationService } from "../../services/bankIntegrationService";
import multer from "multer";

const router = Router();
const upload = multer({ dest: 'uploads/' });

/**
 * Configure real bank account connection
 */
router.post("/configure-bank", async (req, res) => {
  try {
    const config = req.body;
    
    // Validate required fields
    if (!config.bankName || !config.routingNumber || !config.accountNumber) {
      return res.status(400).json({ error: "Missing required bank configuration" });
    }

    const result = await bankIntegrationService.configureBankAccount(config);
    res.json(result);
  } catch (error) {
    console.error("Bank configuration error:", error);
    res.status(500).json({ error: "Failed to configure bank account" });
  }
});

/**
 * Configure EDI trading partner
 */
router.post("/configure-edi", async (req, res) => {
  try {
    const config = req.body;
    
    // Validate required fields
    if (!config.partnerName || !config.partnerISA || !config.ourISA) {
      return res.status(400).json({ error: "Missing required EDI configuration" });
    }

    const result = await bankIntegrationService.configureEDIPartner(config);
    res.json(result);
  } catch (error) {
    console.error("EDI configuration error:", error);
    res.status(500).json({ error: "Failed to configure EDI partner" });
  }
});

/**
 * Upload and process bank statement file
 */
router.post("/upload-statement/:bankAccountId", upload.single('statement'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No statement file uploaded" });
    }

    const fs = require('fs');
    const fileContent = fs.readFileSync(req.file.path, 'utf8');
    
    const result = await bankIntegrationService.processBankStatement({
      bankAccountId: parseInt(req.params.bankAccountId),
      fileName: req.file.originalname,
      fileContent: fileContent,
      statementDate: req.body.statementDate || new Date().toISOString().split('T')[0]
    });

    // Clean up uploaded file
    fs.unlinkSync(req.file.path);
    
    res.json(result);
  } catch (error) {
    console.error("Bank statement processing error:", error);
    res.status(500).json({ error: "Failed to process bank statement" });
  }
});

/**
 * Send EDI document to trading partner
 */
router.post("/send-edi", async (req, res) => {
  try {
    const document = req.body;
    
    if (!document.tradingPartnerId || !document.documentType) {
      return res.status(400).json({ error: "Missing required EDI document fields" });
    }

    const result = await bankIntegrationService.sendEDIDocument(document);
    res.json(result);
  } catch (error) {
    console.error("EDI transmission error:", error);
    res.status(500).json({ error: "Failed to send EDI document" });
  }
});

/**
 * Get real-time bank balance
 */
router.get("/balance/:bankAccountId", async (req, res) => {
  try {
    const bankAccountId = parseInt(req.params.bankAccountId);
    const result = await bankIntegrationService.getBankBalance(bankAccountId);
    res.json(result);
  } catch (error) {
    console.error("Bank balance inquiry error:", error);
    res.status(500).json({ error: "Failed to retrieve bank balance" });
  }
});

/**
 * Test bank API connection
 */
router.post("/test-connection/:bankAccountId", async (req, res) => {
  try {
    const bankAccountId = parseInt(req.params.bankAccountId);
    
    // Test the connection without updating balances
    const result = await bankIntegrationService.getBankBalance(bankAccountId);
    
    res.json({
      success: true,
      message: "Bank API connection successful",
      connectionTest: true,
      timestamp: new Date()
    });
  } catch (error) {
    console.error("Bank connection test error:", error);
    res.status(500).json({ 
      success: false,
      error: "Bank API connection failed",
      details: error.message 
    });
  }
});

export default router;