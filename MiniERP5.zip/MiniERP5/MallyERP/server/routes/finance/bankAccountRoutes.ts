import { Router } from "express";
import { pool } from "../../db";

const router = Router();

/**
 * Get all bank accounts with balances and configurations
 */
router.get("/", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        ba.id,
        ba.account_number,
        ba.account_name,
        ba.bank_name,
        ba.account_type,
        ba.current_balance,
        ba.available_balance,
        ba.currency,
        ba.company_code_id,
        cc.name as company_name,
        ba.gl_account_id,
        gl.account_name as gl_account_name,
        ba.is_active,
        ba.created_at
      FROM bank_accounts ba
      LEFT JOIN company_codes cc ON ba.company_code_id = cc.id
      LEFT JOIN gl_accounts gl ON ba.gl_account_id = gl.id
      WHERE ba.is_active = true
      ORDER BY ba.account_type, ba.account_name
    `);
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching bank accounts:", error);
    res.status(500).json({ error: "Failed to fetch bank accounts" });
  }
});

/**
 * Get lockbox processing data
 */
router.get("/lockbox", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        lp.id,
        lp.lockbox_number,
        lp.processing_date,
        lp.deposit_amount,
        lp.check_count,
        lp.ach_count,
        lp.wire_count,
        lp.deposit_slip_number,
        lp.bank_file_name,
        lp.processing_status,
        ba.account_name,
        ba.bank_name
      FROM lockbox_processing lp
      JOIN bank_accounts ba ON lp.bank_account_id = ba.id
      ORDER BY lp.processing_date DESC
      LIMIT 50
    `);
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching lockbox data:", error);
    res.status(500).json({ error: "Failed to fetch lockbox processing data" });
  }
});

/**
 * Get lockbox transactions with cash application status
 */
router.get("/lockbox/transactions", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        lt.id,
        lt.check_number,
        lt.customer_account,
        lt.payment_amount,
        lt.payment_date,
        lt.deposit_date,
        lt.remittance_data,
        lt.invoice_references,
        lt.cash_application_status,
        lt.exception_reason,
        lt.manual_review_required,
        lp.lockbox_number,
        lp.processing_date,
        ba.account_name,
        ba.bank_name
      FROM lockbox_transactions lt
      JOIN lockbox_processing lp ON lt.lockbox_id = lp.id
      JOIN bank_accounts ba ON lp.bank_account_id = ba.id
      ORDER BY lt.deposit_date DESC, lt.payment_amount DESC
      LIMIT 100
    `);
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching lockbox transactions:", error);
    res.status(500).json({ error: "Failed to fetch lockbox transactions" });
  }
});

/**
 * Get EDI transactions
 */
router.get("/edi", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        id,
        edi_transaction_set,
        sender_id,
        receiver_id,
        control_number,
        transaction_date,
        document_type,
        reference_number,
        total_amount,
        currency_code,
        processing_status,
        error_messages,
        parsed_data,
        related_ar_id,
        related_ap_id,
        created_at,
        processed_at
      FROM edi_transactions
      ORDER BY transaction_date DESC
      LIMIT 50
    `);
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching EDI transactions:", error);
    res.status(500).json({ error: "Failed to fetch EDI transactions" });
  }
});

/**
 * Process cash application for lockbox transactions
 */
router.post("/lockbox/apply-cash", async (req, res) => {
  const { transactionId, invoiceNumbers, applicationAmount, notes } = req.body;
  
  try {
    await pool.query('BEGIN');
    
    // Update lockbox transaction
    await pool.query(`
      UPDATE lockbox_transactions 
      SET cash_application_status = 'applied',
          applied_at = CURRENT_TIMESTAMP,
          ar_application_id = $2
      WHERE id = $1
    `, [transactionId, Math.floor(Math.random() * 1000000)]);
    
    // Apply to AR invoices
    for (const invoiceNum of invoiceNumbers) {
      await pool.query(`
        UPDATE accounts_receivable 
        SET status = 'Paid',
            payment_date = CURRENT_DATE,
            payment_amount = payment_amount + $2
        WHERE invoice_number = $1
      `, [invoiceNum, applicationAmount / invoiceNumbers.length]);
    }
    
    await pool.query('COMMIT');
    res.json({ success: true, message: 'Cash application processed successfully' });
  } catch (error) {
    await pool.query('ROLLBACK');
    console.error("Error processing cash application:", error);
    res.status(500).json({ error: "Failed to process cash application" });
  }
});

export default router;