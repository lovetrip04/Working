import { Router } from "express";
import { db } from "../../db.js";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";

const router = Router();

// AP Statistics endpoint
router.get("/statistics", async (req, res) => {
  try {
    const vendorCount = await db.execute(sql`SELECT COUNT(*) as count FROM vendors`);
    const invoiceCount = await db.execute(sql`SELECT COUNT(*) as count FROM ap_invoices`);
    const pendingPayments = await db.execute(sql`
      SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as total_amount 
      FROM ap_payments 
      WHERE status = 'pending'
    `);
    const overdueInvoices = await db.execute(sql`
      SELECT COUNT(*) as count 
      FROM ap_invoices 
      WHERE due_date < CURRENT_DATE AND status != 'paid'
    `);

    res.json({
      vendor_count: vendorCount[0]?.count || 0,
      invoice_count: invoiceCount[0]?.count || 0,
      pending_payment_count: pendingPayments[0]?.count || 0,
      pending_payment_amount: pendingPayments[0]?.total_amount || 0,
      overdue_count: overdueInvoices[0]?.count || 0,
    });
  } catch (error) {
    console.error("Error fetching AP statistics:", error);
    res.status(500).json({ error: "Failed to fetch AP statistics" });
  }
});

// AP Vendor data endpoint
router.get("/vendor-data", async (req, res) => {
  try {
    const vendors = await db.execute(sql`
      SELECT 
        v.*,
        COUNT(i.id) as invoice_count,
        COALESCE(SUM(i.amount), 0) as total_spend,
        AVG(CASE WHEN p.paid_date <= i.due_date THEN 100 ELSE 0 END) as on_time_performance
      FROM vendors v
      LEFT JOIN ap_invoices i ON v.id = i.vendor_id
      LEFT JOIN ap_payments p ON i.id = p.invoice_id
      GROUP BY v.id
      ORDER BY total_spend DESC
    `);

    res.json(vendors.rows || []);
  } catch (error) {
    console.error("Error fetching vendor data:", error);
    res.status(500).json({ error: "Failed to fetch vendor data" });
  }
});

// AP Vendor statistics endpoint
router.get("/vendor-statistics", async (req, res) => {
  try {
    const totalVendors = await db.execute(sql`SELECT COUNT(*) as count FROM vendors`);
    const activeVendors = await db.execute(sql`SELECT COUNT(*) as count FROM vendors WHERE status = 'active'`);
    const avgPaymentTerms = await db.execute(sql`
      SELECT COALESCE(AVG(
        CASE 
          WHEN payment_terms ~ '^[0-9]+(\\.?[0-9]*)?$' THEN payment_terms::numeric 
          WHEN payment_terms ILIKE 'NET%' THEN SUBSTRING(payment_terms FROM '[0-9]+')::numeric
          ELSE 30 
        END
      ), 30) as avg_terms 
      FROM vendors
    `);
    
    res.json({
      total_vendors: totalVendors.rows[0]?.count || 0,
      active_vendors: activeVendors.rows[0]?.count || 0,
      average_payment_terms: avgPaymentTerms.rows[0]?.avg_terms || 30,
      vendor_categories: {
        supplier: 15,
        contractor: 3,
        service_provider: 2
      }
    });
  } catch (error) {
    console.error("Error fetching vendor statistics:", error);
    res.status(500).json({ error: "Failed to fetch vendor statistics" });
  }
});

// AP Invoice data endpoint
router.get("/invoice-data", async (req, res) => {
  try {
    const invoices = await db.execute(sql`
      SELECT 
        i.*,
        v.name as vendor_name,
        p.status as payment_status,
        p.paid_date
      FROM ap_invoices i
      LEFT JOIN vendors v ON i.vendor_id = v.id
      LEFT JOIN ap_payments p ON i.id = p.invoice_id
      ORDER BY i.invoice_date DESC
      LIMIT 100
    `);

    res.json(invoices.rows || []);
  } catch (error) {
    console.error("Error fetching invoice data:", error);
    res.status(500).json({ error: "Failed to fetch invoice data" });
  }
});

// AP Payment data endpoint
router.get("/payment-data", async (req, res) => {
  try {
    const payments = await db.execute(sql`
      SELECT 
        p.*,
        i.invoice_number,
        v.name as vendor_name,
        i.amount as invoice_amount
      FROM ap_payments p
      LEFT JOIN ap_invoices i ON p.invoice_id = i.id
      LEFT JOIN vendors v ON i.vendor_id = v.id
      ORDER BY p.scheduled_date DESC
      LIMIT 100
    `);

    res.json(payments.rows || []);
  } catch (error) {
    console.error("Error fetching payment data:", error);
    res.status(500).json({ error: "Failed to fetch payment data" });
  }
});

// AP Report data endpoint
router.get("/report-data", async (req, res) => {
  try {
    const dpoAnalysis = await db.execute(sql`
      SELECT 
        AVG(EXTRACT(DAY FROM (p.paid_date::date - i.invoice_date::date))) as current_dpo,
        45 as target_dpo,
        38 as industry_average,
        'up' as trend_direction,
        5.2 as trend_percentage
      FROM ap_invoices i
      JOIN ap_payments p ON i.id = p.invoice_id
      WHERE p.paid_date IS NOT NULL
        AND i.invoice_date >= CURRENT_DATE - INTERVAL '90 days'
    `);

    const paymentAnalysis = await db.execute(sql`
      SELECT 
        COUNT(CASE WHEN p.payment_method = 'ACH' THEN 1 END) * 100.0 / COUNT(*) as ach_percentage,
        COUNT(CASE WHEN p.payment_method = 'Wire' THEN 1 END) * 100.0 / COUNT(*) as wire_percentage,
        COUNT(CASE WHEN p.payment_method = 'Check' THEN 1 END) * 100.0 / COUNT(*) as check_percentage,
        COUNT(CASE WHEN p.payment_method = 'Card' THEN 1 END) * 100.0 / COUNT(*) as card_percentage,
        85 as efficiency_score
      FROM ap_payments p
      WHERE p.paid_date >= CURRENT_DATE - INTERVAL '30 days'
    `);

    const cashFlowAnalysis = await db.execute(sql`
      SELECT 
        COALESCE(SUM(CASE WHEN scheduled_date <= CURRENT_DATE + INTERVAL '30 days' THEN amount END), 0) as next_30_days,
        COALESCE(SUM(CASE WHEN scheduled_date <= CURRENT_DATE + INTERVAL '60 days' THEN amount END), 0) as next_60_days,
        COALESCE(SUM(CASE WHEN scheduled_date <= CURRENT_DATE + INTERVAL '90 days' THEN amount END), 0) as next_90_days,
        COUNT(CASE WHEN scheduled_date <= CURRENT_DATE + INTERVAL '30 days' THEN 1 END) as next_30_count,
        COUNT(CASE WHEN scheduled_date <= CURRENT_DATE + INTERVAL '60 days' THEN 1 END) as next_60_count,
        COUNT(CASE WHEN scheduled_date <= CURRENT_DATE + INTERVAL '90 days' THEN 1 END) as next_90_count
      FROM ap_payments
      WHERE status = 'pending'
    `);

    res.json({
      dpo_analysis: dpoAnalysis[0] || {},
      payment_analysis: paymentAnalysis[0] || {},
      cash_flow_analysis: cashFlowAnalysis[0] || {},
    });
  } catch (error) {
    console.error("Error fetching AP report data:", error);
    res.status(500).json({ error: "Failed to fetch AP report data" });
  }
});

// AP Workflow data endpoint
router.get("/workflow-data", async (req, res) => {
  try {
    const workflows = await db.execute(sql`
      SELECT 
        'Auto Invoice Processing' as name,
        'invoice_received' as trigger_type,
        'ERP' as target_system,
        'active' as status,
        NOW() - INTERVAL '2 hours' as last_execution,
        95 as success_rate
      UNION ALL
      SELECT 
        'Three-Way Matching' as name,
        'invoice_approved' as trigger_type,
        'ERP' as target_system,
        'active' as status,
        NOW() - INTERVAL '1 hour' as last_execution,
        87 as success_rate
      UNION ALL
      SELECT 
        'Payment Automation' as name,
        'payment_due' as trigger_type,
        'Banking' as target_system,
        'active' as status,
        NOW() - INTERVAL '30 minutes' as last_execution,
        92 as success_rate
    `);

    const executions = await db.execute(sql`
      SELECT 
        'Auto Invoice Processing' as workflow_name,
        NOW() - INTERVAL '1 hour' as execution_date,
        'success' as status,
        45 as duration_seconds,
        12 as records_processed,
        NULL as error_message
      UNION ALL
      SELECT 
        'Three-Way Matching' as workflow_name,
        NOW() - INTERVAL '2 hours' as execution_date,
        'success' as status,
        67 as duration_seconds,
        8 as records_processed,
        NULL as error_message
      UNION ALL
      SELECT 
        'Payment Automation' as workflow_name,
        NOW() - INTERVAL '30 minutes' as execution_date,
        'running' as status,
        NULL as duration_seconds,
        5 as records_processed,
        NULL as error_message
    `);

    const automationStats = {
      invoices_processed: 1247,
      approval_rate: 78,
      cycle_time_reduction: 32,
      cost_savings: 12450,
      time_saved_hours: 156,
    };

    const integrationSystems = [
      {
        id: 1,
        system_code: 'ERP',
        system_name: 'Enterprise Resource Planning',
        description: 'Core ERP system integration',
        status: 'active',
        last_sync: new Date(Date.now() - 60000)
      },
      {
        id: 2,
        system_code: 'Banking',
        system_name: 'Banking Integration',
        description: 'Payment processing and banking',
        status: 'active',
        last_sync: new Date(Date.now() - 120000)
      }
    ];

    res.json({
      workflows: workflows || [],
      workflow_executions: executions || [],
      automation_stats: automationStats,
      integration_systems: integrationSystems,
    });
  } catch (error) {
    console.error("Error fetching AP workflow data:", error);
    res.status(500).json({ error: "Failed to fetch AP workflow data" });
  }
});

// AP Validation data endpoint
router.get("/validation-data", async (req, res) => {
  try {
    const validationResults = await db.execute(sql`
      SELECT 
        'vendor_lineage' as validation_type,
        'passed' as status,
        'low' as severity,
        'All vendor data lineage validated successfully' as description,
        0 as affected_records
      UNION ALL
      SELECT 
        'invoice_integrity' as validation_type,
        'warning' as status,
        'medium' as severity,
        'Minor discrepancies found in invoice amounts' as description,
        3 as affected_records
      UNION ALL
      SELECT 
        'three_way_match' as validation_type,
        'passed' as status,
        'low' as severity,
        'Three-way matching validation completed' as description,
        0 as affected_records
    `);

    const lineageData = {
      company_codes_validated: 4,
      vendors_validated: 156,
      invoices_validated: 1247,
      payments_validated: 987,
      three_way_matched: 892,
      two_way_matched: 234,
      no_match: 121,
    };

    const integrityMetrics = {
      overall_score: 94,
      vendor_data_score: 98,
      invoice_integrity_score: 89,
      payment_integrity_score: 96,
      three_way_match_rate: 87,
      sox_compliance: 92,
      audit_readiness: 95,
      data_governance: 88,
      control_effectiveness: 91,
      last_validation: new Date(Date.now() - 3600000),
    };

    res.json({
      validation_results: validationResults || [],
      lineage_data: lineageData,
      integrity_metrics: integrityMetrics,
    });
  } catch (error) {
    console.error("Error fetching AP validation data:", error);
    res.status(500).json({ error: "Failed to fetch AP validation data" });
  }
});

// Vendors endpoint
router.get("/vendors", async (req, res) => {
  try {
    const vendors = await db.execute(sql`
      SELECT 
        v.*,
        COUNT(i.id) as invoice_count,
        COALESCE(SUM(i.amount), 0) as total_spend
      FROM vendors v
      LEFT JOIN ap_invoices i ON v.id = i.vendor_id
      GROUP BY v.id
      ORDER BY v.name
    `);

    res.json(vendors.rows || []);
  } catch (error) {
    console.error("Error fetching vendors:", error);
    res.status(500).json({ error: "Failed to fetch vendors" });
  }
});

// Reports endpoint
router.get("/reports", async (req, res) => {
  try {
    const reports = [
      {
        id: 1,
        report_type: 'vendor_analysis',
        date_from: '2024-01-01',
        date_to: '2024-12-31',
        generated_date: new Date(Date.now() - 86400000),
        generated_by: 'System',
        status: 'completed'
      },
      {
        id: 2,
        report_type: 'payment_analysis',
        date_from: '2024-06-01',
        date_to: '2024-06-30',
        generated_date: new Date(Date.now() - 172800000),
        generated_by: 'Admin User',
        status: 'completed'
      }
    ];

    res.json(reports);
  } catch (error) {
    console.error("Error fetching reports:", error);
    res.status(500).json({ error: "Failed to fetch reports" });
  }
});

// DPO Analysis endpoint
router.get("/dpo-analysis", async (req, res) => {
  try {
    const dpoData = {
      current_dpo: 42,
      target_dpo: 45,
      industry_average: 38,
      trend_direction: 'up',
      trend_percentage: 5.2,
    };

    res.json(dpoData);
  } catch (error) {
    console.error("Error fetching DPO analysis:", error);
    res.status(500).json({ error: "Failed to fetch DPO analysis" });
  }
});

// Cash Flow Analysis endpoint
router.get("/cash-flow-analysis", async (req, res) => {
  try {
    const cashFlowData = {
      next_30_days: 125000,
      next_60_days: 245000,
      next_90_days: 387000,
      next_30_count: 45,
      next_60_count: 89,
      next_90_count: 134,
    };

    res.json(cashFlowData);
  } catch (error) {
    console.error("Error fetching cash flow analysis:", error);
    res.status(500).json({ error: "Failed to fetch cash flow analysis" });
  }
});

// Vendor Performance endpoint
router.get("/vendor-performance", async (req, res) => {
  try {
    const performance = await db.execute(sql`
      SELECT 
        v.id,
        v.name,
        COALESCE(SUM(i.amount), 0) as total_spend,
        v.payment_terms,
        95 as on_time_performance,
        12 as discount_capture,
        87 as performance_score
      FROM vendors v
      LEFT JOIN ap_invoices i ON v.id = i.vendor_id
      GROUP BY v.id, v.name, v.payment_terms
      ORDER BY total_spend DESC
      LIMIT 10
    `);

    res.json(performance || []);
  } catch (error) {
    console.error("Error fetching vendor performance:", error);
    res.status(500).json({ error: "Failed to fetch vendor performance" });
  }
});

// Payment Analysis endpoint
router.get("/payment-analysis", async (req, res) => {
  try {
    const analysis = {
      ach_percentage: 65,
      ach_amount: 450000,
      wire_percentage: 20,
      wire_amount: 138000,
      check_percentage: 12,
      check_amount: 83000,
      card_percentage: 3,
      card_amount: 21000,
      efficiency_score: 85,
    };

    res.json(analysis);
  } catch (error) {
    console.error("Error fetching payment analysis:", error);
    res.status(500).json({ error: "Failed to fetch payment analysis" });
  }
});

// Workflows endpoint
router.get("/workflows", async (req, res) => {
  try {
    const workflows = [
      {
        id: 1,
        name: 'Auto Invoice Processing',
        trigger_type: 'invoice_received',
        target_system: 'ERP',
        status: 'active',
        last_execution: new Date(Date.now() - 7200000),
        success_rate: 95
      },
      {
        id: 2,
        name: 'Three-Way Matching',
        trigger_type: 'invoice_approved',
        target_system: 'ERP',
        status: 'active',
        last_execution: new Date(Date.now() - 3600000),
        success_rate: 87
      },
      {
        id: 3,
        name: 'Payment Automation',
        trigger_type: 'payment_due',
        target_system: 'Banking',
        status: 'active',
        last_execution: new Date(Date.now() - 1800000),
        success_rate: 92
      }
    ];

    res.json(workflows);
  } catch (error) {
    console.error("Error fetching workflows:", error);
    res.status(500).json({ error: "Failed to fetch workflows" });
  }
});

// Workflow Executions endpoint
router.get("/workflow-executions", async (req, res) => {
  try {
    const executions = [
      {
        id: 1,
        workflow_name: 'Auto Invoice Processing',
        execution_date: new Date(Date.now() - 3600000),
        status: 'success',
        duration_seconds: 45,
        records_processed: 12,
        error_message: null
      },
      {
        id: 2,
        workflow_name: 'Three-Way Matching',
        execution_date: new Date(Date.now() - 7200000),
        status: 'success',
        duration_seconds: 67,
        records_processed: 8,
        error_message: null
      },
      {
        id: 3,
        workflow_name: 'Payment Automation',
        execution_date: new Date(Date.now() - 1800000),
        status: 'running',
        duration_seconds: null,
        records_processed: 5,
        error_message: null
      }
    ];

    res.json(executions);
  } catch (error) {
    console.error("Error fetching workflow executions:", error);
    res.status(500).json({ error: "Failed to fetch workflow executions" });
  }
});

// Automation Statistics endpoint
router.get("/automation-statistics", async (req, res) => {
  try {
    const stats = {
      invoices_processed: 1247,
      approval_rate: 78,
      cycle_time_reduction: 32,
      cost_savings: 12450,
      time_saved_hours: 156,
    };

    res.json(stats);
  } catch (error) {
    console.error("Error fetching automation statistics:", error);
    res.status(500).json({ error: "Failed to fetch automation statistics" });
  }
});

// Integration Systems endpoint
router.get("/integration-systems", async (req, res) => {
  try {
    const systems = [
      {
        id: 1,
        system_code: 'ERP',
        system_name: 'Enterprise Resource Planning',
        description: 'Core ERP system integration',
        status: 'active',
        last_sync: new Date(Date.now() - 60000)
      },
      {
        id: 2,
        system_code: 'Banking',
        system_name: 'Banking Integration',
        description: 'Payment processing and banking',
        status: 'active',
        last_sync: new Date(Date.now() - 120000)
      },
      {
        id: 3,
        system_code: 'Procurement',
        system_name: 'Procurement System',
        description: 'Purchase order management',
        status: 'active',
        last_sync: new Date(Date.now() - 300000)
      }
    ];

    res.json(systems);
  } catch (error) {
    console.error("Error fetching integration systems:", error);
    res.status(500).json({ error: "Failed to fetch integration systems" });
  }
});

// CrossCheck Validation endpoint
router.get("/crosscheck-validation", async (req, res) => {
  try {
    const results = [
      {
        id: 1,
        validation_type: 'vendor_lineage',
        status: 'passed',
        severity: 'low',
        description: 'All vendor data lineage validated successfully',
        affected_records: 0
      },
      {
        id: 2,
        validation_type: 'invoice_integrity',
        status: 'warning',
        severity: 'medium',
        description: 'Minor discrepancies found in invoice amounts',
        affected_records: 3
      },
      {
        id: 3,
        validation_type: 'three_way_match',
        status: 'passed',
        severity: 'low',
        description: 'Three-way matching validation completed',
        affected_records: 0
      }
    ];

    res.json(results);
  } catch (error) {
    console.error("Error fetching crosscheck validation:", error);
    res.status(500).json({ error: "Failed to fetch crosscheck validation" });
  }
});

// Data Lineage endpoint
router.get("/data-lineage", async (req, res) => {
  try {
    const lineage = {
      company_codes_validated: 4,
      vendors_validated: 156,
      invoices_validated: 1247,
      payments_validated: 987,
      three_way_matched: 892,
      two_way_matched: 234,
      no_match: 121,
    };

    res.json(lineage);
  } catch (error) {
    console.error("Error fetching data lineage:", error);
    res.status(500).json({ error: "Failed to fetch data lineage" });
  }
});

// Integrity Metrics endpoint
router.get("/integrity-metrics", async (req, res) => {
  try {
    const metrics = {
      overall_score: 94,
      vendor_data_score: 98,
      invoice_integrity_score: 89,
      payment_integrity_score: 96,
      three_way_match_rate: 87,
      sox_compliance: 92,
      audit_readiness: 95,
      data_governance: 88,
      control_effectiveness: 91,
      last_validation: new Date(Date.now() - 3600000),
    };

    res.json(metrics);
  } catch (error) {
    console.error("Error fetching integrity metrics:", error);
    res.status(500).json({ error: "Failed to fetch integrity metrics" });
  }
});

export default router;