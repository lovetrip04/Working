/**
 * Comprehensive Accounts Receivable Routes
 * Implements payment processing, collection management, credit management, 
 * reporting, integration workflows, and document management
 */

import express from 'express';
import pkg from 'pg';
const { Pool } = pkg;
const router = express.Router();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// 1. PAYMENT PROCESSING & RECORDING

// Record manual payment
router.post('/payments', async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    
    const {
      customer_id,
      payment_amount,
      payment_date,
      payment_method_code,
      reference_number,
      notes,
      invoice_applications = [] // Array of {invoice_id, amount}
    } = req.body;

    // Validate customer exists and credit management
    const customerCheck = await client.query(
      'SELECT id, name FROM customers WHERE id = $1',
      [customer_id]
    );
    
    if (customerCheck.rows.length === 0) {
      throw new Error('Customer not found');
    }

    // Get payment method
    const paymentMethod = await client.query(
      'SELECT id, name FROM payment_methods WHERE code = $1 AND is_active = true',
      [payment_method_code]
    );

    if (paymentMethod.rows.length === 0) {
      throw new Error('Invalid payment method');
    }

    // Create payment record
    const paymentResult = await client.query(`
      INSERT INTO customer_payments (
        customer_id, payment_amount, payment_date, payment_method,
        payment_reference, notes, status
      ) VALUES ($1, $2, $3, $4, $5, $6, 'completed')
      RETURNING id
    `, [customer_id, payment_amount, payment_date, paymentMethod.rows[0].name, reference_number, notes]);

    const payment_id = paymentResult.rows[0].id;

    // Apply payments to specific invoices
    let totalApplied = 0;
    for (const application of invoice_applications) {
      await client.query(`
        INSERT INTO ar_payment_applications (
          payment_id, invoice_id, applied_amount, application_date
        ) VALUES ($1, $2, $3, $4)
      `, [payment_id, application.invoice_id, application.amount, payment_date]);
      
      // Update invoice status if fully paid
      await client.query(`
        UPDATE invoices 
        SET status = CASE 
          WHEN amount <= (
            SELECT COALESCE(SUM(applied_amount), 0) 
            FROM ar_payment_applications 
            WHERE invoice_id = $1
          ) THEN 'paid'
          ELSE 'partial'
        END,
        updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
      `, [application.invoice_id]);
      
      totalApplied += parseFloat(application.amount);
    }

    // Update customer balance
    await client.query(`
      UPDATE customer_credit_management 
      SET current_balance = current_balance - $1,
          updated_at = CURRENT_TIMESTAMP
      WHERE customer_id = $2
    `, [totalApplied, customer_id]);

    await client.query('COMMIT');
    
    res.json({
      success: true,
      payment_id,
      message: 'Payment recorded successfully'
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Payment recording error:', error);
    res.status(400).json({
      success: false,
      error: error.message
    });
  } finally {
    client.release();
  }
});

// Get payment applications for an invoice
router.get('/invoices/:invoice_id/payments', async (req, res) => {
  try {
    const { invoice_id } = req.params;
    
    const result = await pool.query(`
      SELECT 
        pa.applied_amount,
        pa.application_date,
        cp.payment_date,
        cp.payment_method,
        cp.payment_reference,
        cp.notes
      FROM ar_payment_applications pa
      JOIN customer_payments cp ON pa.payment_id = cp.id
      WHERE pa.invoice_id = $1
      ORDER BY pa.application_date DESC
    `, [invoice_id]);

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching payment applications:', error);
    res.status(500).json({ error: 'Failed to fetch payment applications' });
  }
});

// 2. COLLECTION MANAGEMENT

// Create collection activity
router.post('/collection-activities', async (req, res) => {
  try {
    const {
      customer_id,
      invoice_id,
      activity_type,
      description,
      outcome,
      next_action_date,
      assigned_to_user_id
    } = req.body;

    const result = await pool.query(`
      INSERT INTO collection_activities (
        customer_id, invoice_id, activity_type, activity_date,
        description, outcome, next_action_date, assigned_to_user_id
      ) VALUES ($1, $2, $3, CURRENT_TIMESTAMP, $4, $5, $6, $7)
      RETURNING *
    `, [customer_id, invoice_id, activity_type, description, outcome, next_action_date, assigned_to_user_id]);

    res.json({
      success: true,
      activity: result.rows[0]
    });
  } catch (error) {
    console.error('Error creating collection activity:', error);
    res.status(500).json({ error: 'Failed to create collection activity' });
  }
});

// Get collection activities for customer
router.get('/customers/:customer_id/collection-activities', async (req, res) => {
  try {
    const { customer_id } = req.params;
    
    const result = await pool.query(`
      SELECT 
        ca.*,
        i.invoice_number
      FROM collection_activities ca
      LEFT JOIN invoices i ON ca.invoice_id = i.id
      WHERE ca.customer_id = $1
      ORDER BY ca.activity_date DESC
    `, [customer_id]);

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching collection activities:', error);
    res.status(500).json({ error: 'Failed to fetch collection activities' });
  }
});

// Generate dunning letters
router.post('/customers/:customer_id/dunning-letter', async (req, res) => {
  const client = await pool.connect();
  try {
    const { customer_id } = req.params;
    const { level = 1 } = req.body;

    // Get customer info and overdue invoices
    const customerResult = await client.query(`
      SELECT c.*, ccm.current_balance, ccm.credit_rating
      FROM customers c
      LEFT JOIN customer_credit_management ccm ON c.id = ccm.customer_id
      WHERE c.id = $1
    `, [customer_id]);

    if (customerResult.rows.length === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const customer = customerResult.rows[0];

    // Get overdue invoices
    const overdueInvoices = await client.query(`
      SELECT 
        invoice_number,
        amount,
        due_date,
        (CURRENT_DATE - due_date) as days_overdue
      FROM invoices
      WHERE customer_id = $1 
        AND status != 'paid'
        AND due_date < CURRENT_DATE
      ORDER BY due_date ASC
    `, [customer_id]);

    // Get dunning template
    const templateResult = await client.query(`
      SELECT template_content, escalation_action
      FROM dunning_configurations
      WHERE level_number = $1 AND is_active = true
    `, [level]);

    if (templateResult.rows.length === 0) {
      return res.status(404).json({ error: 'Dunning template not found' });
    }

    const template = templateResult.rows[0];
    const totalOverdue = overdueInvoices.rows.reduce((sum, inv) => sum + parseFloat(inv.amount), 0);

    // Generate letter content
    let letterContent = template.template_content
      .replace('[Customer Name]', customer.name)
      .replace('[Amount]', `$${totalOverdue.toLocaleString()}`);

    // Execute escalation action
    if (template.escalation_action === 'credit_hold') {
      await client.query(`
        UPDATE customer_credit_management 
        SET is_on_credit_hold = true,
            credit_hold_reason = 'Overdue payments - Dunning Level ${level}',
            updated_at = CURRENT_TIMESTAMP
        WHERE customer_id = $1
      `, [customer_id]);
    }

    // Record collection activity
    await client.query(`
      INSERT INTO collection_activities (
        customer_id, activity_type, activity_date, description, outcome
      ) VALUES ($1, 'letter', CURRENT_TIMESTAMP, $2, 'Dunning letter sent - Level ${level}')
    `, [customer_id, letterContent]);

    res.json({
      success: true,
      letter_content: letterContent,
      total_overdue: totalOverdue,
      invoices: overdueInvoices.rows,
      escalation_applied: template.escalation_action
    });

  } catch (error) {
    console.error('Error generating dunning letter:', error);
    res.status(500).json({ error: 'Failed to generate dunning letter' });
  } finally {
    client.release();
  }
});

// 3. CREDIT MANAGEMENT

// Update customer credit limit
router.put('/customers/:customer_id/credit-limit', async (req, res) => {
  try {
    const { customer_id } = req.params;
    const { credit_limit, credit_rating, notes } = req.body;

    const result = await pool.query(`
      UPDATE customer_credit_management 
      SET credit_limit = $1,
          credit_rating = $2,
          last_review_date = CURRENT_TIMESTAMP,
          next_review_date = CURRENT_TIMESTAMP + INTERVAL '90 days',
          updated_at = CURRENT_TIMESTAMP
      WHERE customer_id = $3
      RETURNING *
    `, [credit_limit, credit_rating, customer_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Customer credit record not found' });
    }

    // Log credit review activity
    await pool.query(`
      INSERT INTO collection_activities (
        customer_id, activity_type, activity_date, description
      ) VALUES ($1, 'credit_review', CURRENT_TIMESTAMP, $2)
    `, [customer_id, `Credit limit updated to $${credit_limit}. Rating: ${credit_rating}. ${notes || ''}`]);

    res.json({
      success: true,
      credit_management: result.rows[0]
    });
  } catch (error) {
    console.error('Error updating credit limit:', error);
    res.status(500).json({ error: 'Failed to update credit limit' });
  }
});

// Check credit availability for new orders
router.post('/customers/:customer_id/credit-check', async (req, res) => {
  try {
    const { customer_id } = req.params;
    const { order_amount } = req.body;

    const result = await pool.query(`
      SELECT 
        ccm.*,
        c.name as customer_name,
        (ccm.credit_limit - ccm.current_balance) as available_credit,
        CASE 
          WHEN ccm.is_on_credit_hold THEN 'HOLD'
          WHEN (ccm.current_balance + $1) > ccm.credit_limit THEN 'EXCEEDED'
          WHEN ccm.credit_rating IN ('D') THEN 'RISK'
          ELSE 'APPROVED'
        END as credit_status
      FROM customer_credit_management ccm
      JOIN customers c ON ccm.customer_id = c.id
      WHERE ccm.customer_id = $2
    `, [order_amount, customer_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Customer credit record not found' });
    }

    const creditInfo = result.rows[0];

    res.json({
      customer_name: creditInfo.customer_name,
      credit_limit: creditInfo.credit_limit,
      current_balance: creditInfo.current_balance,
      available_credit: creditInfo.available_credit,
      order_amount: order_amount,
      credit_status: creditInfo.credit_status,
      is_on_hold: creditInfo.is_on_credit_hold,
      credit_rating: creditInfo.credit_rating,
      risk_score: creditInfo.risk_score
    });
  } catch (error) {
    console.error('Error performing credit check:', error);
    res.status(500).json({ error: 'Failed to perform credit check' });
  }
});

export default router;