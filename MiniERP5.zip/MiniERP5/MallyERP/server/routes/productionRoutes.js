import express from 'express';
import { pool } from '../db';

const router = express.Router();

// Production Activity Feed
router.get('/activity', async (req, res) => {
  try {
    // Check if production_activities table exists
    const tableCheckResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'production_activities'
      );
    `);
    
    if (tableCheckResult.rows[0].exists) {
      const result = await pool.query(`
        SELECT id, type, message, created_at
        FROM production_activities
        ORDER BY created_at DESC
        LIMIT 20
      `);
      
      res.json(result.rows);
    } else {
      // Return sample data if table doesn't exist
      res.json([
        { id: 1, type: 'order', message: 'New order received from Jane Doe', user: 'Jane Doe' },
        { id: 2, type: 'payment', message: 'Payment received for order #ORD-5430', orderNumber: 'ORD-5430' },
        { id: 3, type: 'inventory', message: 'Inventory alert: Wireless Earbuds stock is below threshold', product: 'Wireless Earbuds' },
        { id: 4, type: 'customer', message: 'Robert Johnson updated customer information', user: 'Robert Johnson' },
        { id: 5, type: 'product', message: 'Emma Brown added 3 new products', user: 'Emma Brown', count: 3 }
      ]);
    }
  } catch (error) {
    console.error('Error fetching production activities:', error);
    res.status(500).json({ message: 'Failed to fetch production activities' });
  }
});

// Get production orders
router.get('/orders', async (req, res) => {
  try {
    // Use the actual production_orders table if it exists
    const tableCheckResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'production_orders'
      );
    `);
    
    if (tableCheckResult.rows[0].exists) {
      const result = await pool.query(`
        SELECT po.*, m.name as material_name
        FROM production_orders po
        LEFT JOIN materials m ON po.material_id = m.id
        ORDER BY po.planned_start_date DESC
      `);
      
      res.json(result.rows);
    } else {
      // Return sample data if table doesn't exist
      res.json([
        {
          id: 1,
          order_number: "PRD-2025-1001",
          material_id: 3,
          material_name: "Smartphone Case",
          quantity: 500,
          status: "Planned",
          planned_start_date: new Date(2025, 2, 15).toISOString(),
          planned_end_date: new Date(2025, 2, 20).toISOString(),
          actual_start_date: null,
          actual_end_date: null
        },
        {
          id: 2,
          order_number: "PRD-2025-1002",
          material_id: 7,
          material_name: "Wireless Earbuds",
          quantity: 200,
          status: "In Progress",
          planned_start_date: new Date(2025, 2, 10).toISOString(),
          planned_end_date: new Date(2025, 2, 18).toISOString(),
          actual_start_date: new Date(2025, 2, 10).toISOString(),
          actual_end_date: null
        },
        {
          id: 3,
          order_number: "PRD-2025-1003",
          material_id: 12,
          material_name: "Bluetooth Speaker",
          quantity: 350,
          status: "Completed",
          planned_start_date: new Date(2025, 2, 5).toISOString(),
          planned_end_date: new Date(2025, 2, 12).toISOString(),
          actual_start_date: new Date(2025, 2, 5).toISOString(),
          actual_end_date: new Date(2025, 2, 11).toISOString()
        },
        {
          id: 4,
          order_number: "PRD-2025-1004",
          material_id: 5,
          material_name: "Smart Watch",
          quantity: 150,
          status: "Delayed",
          planned_start_date: new Date(2025, 2, 8).toISOString(),
          planned_end_date: new Date(2025, 2, 16).toISOString(),
          actual_start_date: new Date(2025, 2, 10).toISOString(),
          actual_end_date: null
        }
      ]);
    }
  } catch (error) {
    console.error('Error fetching production orders:', error);
    res.status(500).json({ message: 'Failed to fetch production orders' });
  }
});

export default router;