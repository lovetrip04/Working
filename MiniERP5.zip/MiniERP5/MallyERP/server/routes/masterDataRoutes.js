/**
 * Master Data API Routes
 * Handles all Master Data endpoints for the new applications
 */

const express = require('express');
const { db } = require('../db');
const router = express.Router();

// Purchasing Groups Routes
router.get('/purchasing-groups', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT * FROM purchasing_groups 
      ORDER BY group_code ASC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching purchasing groups:', error);
    res.status(500).json({ error: 'Failed to fetch purchasing groups' });
  }
});

router.post('/purchasing-groups', async (req, res) => {
  try {
    const { group_code, group_name, description, phone, email, responsible_person } = req.body;
    
    const result = await db.query(`
      INSERT INTO purchasing_groups (group_code, group_name, description, phone, email, responsible_person, active)
      VALUES ($1, $2, $3, $4, $5, $6, true)
      RETURNING *
    `, [group_code, group_name, description, phone, email, responsible_person]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating purchasing group:', error);
    res.status(500).json({ error: 'Failed to create purchasing group' });
  }
});

router.patch('/purchasing-groups/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { group_code, group_name, description, phone, email, responsible_person, active } = req.body;
    
    const result = await db.query(`
      UPDATE purchasing_groups 
      SET group_code = $1, group_name = $2, description = $3, phone = $4, email = $5, 
          responsible_person = $6, active = $7, updated_at = CURRENT_TIMESTAMP
      WHERE id = $8
      RETURNING *
    `, [group_code, group_name, description, phone, email, responsible_person, active, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Purchasing group not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating purchasing group:', error);
    res.status(500).json({ error: 'Failed to update purchasing group' });
  }
});

router.delete('/purchasing-groups/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await db.query('DELETE FROM purchasing_groups WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Purchasing group not found' });
    }
    
    res.json({ message: 'Purchasing group deleted successfully' });
  } catch (error) {
    console.error('Error deleting purchasing group:', error);
    res.status(500).json({ error: 'Failed to delete purchasing group' });
  }
});

// Purchasing Organizations Routes
router.get('/purchasing-organizations', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT * FROM purchasing_organizations 
      ORDER BY org_code ASC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching purchasing organizations:', error);
    res.status(500).json({ error: 'Failed to fetch purchasing organizations' });
  }
});

router.post('/purchasing-organizations', async (req, res) => {
  try {
    const { org_code, org_name, description, company_code, plant_code, currency, address, phone, email } = req.body;
    
    const result = await db.query(`
      INSERT INTO purchasing_organizations 
      (org_code, org_name, description, company_code, plant_code, currency, address, phone, email, active)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, true)
      RETURNING *
    `, [org_code, org_name, description, company_code, plant_code, currency, address, phone, email]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating purchasing organization:', error);
    res.status(500).json({ error: 'Failed to create purchasing organization' });
  }
});

router.patch('/purchasing-organizations/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { org_code, org_name, description, company_code, plant_code, currency, address, phone, email, active } = req.body;
    
    const result = await db.query(`
      UPDATE purchasing_organizations 
      SET org_code = $1, org_name = $2, description = $3, company_code = $4, plant_code = $5,
          currency = $6, address = $7, phone = $8, email = $9, active = $10, updated_at = CURRENT_TIMESTAMP
      WHERE id = $11
      RETURNING *
    `, [org_code, org_name, description, company_code, plant_code, currency, address, phone, email, active, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Purchasing organization not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating purchasing organization:', error);
    res.status(500).json({ error: 'Failed to update purchasing organization' });
  }
});

router.delete('/purchasing-organizations/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await db.query('DELETE FROM purchasing_organizations WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Purchasing organization not found' });
    }
    
    res.json({ message: 'Purchasing organization deleted successfully' });
  } catch (error) {
    console.error('Error deleting purchasing organization:', error);
    res.status(500).json({ error: 'Failed to delete purchasing organization' });
  }
});

// Valuation Classes Routes
router.get('/valuation-classes', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT * FROM valuation_classes 
      ORDER BY class_code ASC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching valuation classes:', error);
    res.status(500).json({ error: 'Failed to fetch valuation classes' });
  }
});

router.post('/valuation-classes', async (req, res) => {
  try {
    const { class_code, class_name, description, valuation_method, price_control, moving_price, standard_price } = req.body;
    
    const result = await db.query(`
      INSERT INTO valuation_classes 
      (class_code, class_name, description, valuation_method, price_control, moving_price, standard_price, active)
      VALUES ($1, $2, $3, $4, $5, $6, $7, true)
      RETURNING *
    `, [class_code, class_name, description, valuation_method, price_control, moving_price, standard_price]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating valuation class:', error);
    res.status(500).json({ error: 'Failed to create valuation class' });
  }
});

router.patch('/valuation-classes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { class_code, class_name, description, valuation_method, price_control, moving_price, standard_price, active } = req.body;
    
    const result = await db.query(`
      UPDATE valuation_classes 
      SET class_code = $1, class_name = $2, description = $3, valuation_method = $4, 
          price_control = $5, moving_price = $6, standard_price = $7, active = $8, updated_at = CURRENT_TIMESTAMP
      WHERE id = $9
      RETURNING *
    `, [class_code, class_name, description, valuation_method, price_control, moving_price, standard_price, active, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Valuation class not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating valuation class:', error);
    res.status(500).json({ error: 'Failed to update valuation class' });
  }
});

router.delete('/valuation-classes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await db.query('DELETE FROM valuation_classes WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Valuation class not found' });
    }
    
    res.json({ message: 'Valuation class deleted successfully' });
  } catch (error) {
    console.error('Error deleting valuation class:', error);
    res.status(500).json({ error: 'Failed to delete valuation class' });
  }
});

// Movement Types Routes
router.get('/movement-types', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT * FROM movement_types 
      ORDER BY movement_code ASC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching movement types:', error);
    res.status(500).json({ error: 'Failed to fetch movement types' });
  }
});

router.post('/movement-types', async (req, res) => {
  try {
    const { movement_code, movement_name, description, movement_category, debit_credit_indicator, quantity_update, value_update, reversal_allowed } = req.body;
    
    const result = await db.query(`
      INSERT INTO movement_types 
      (movement_code, movement_name, description, movement_category, debit_credit_indicator, 
       quantity_update, value_update, reversal_allowed, active)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)
      RETURNING *
    `, [movement_code, movement_name, description, movement_category, debit_credit_indicator, quantity_update, value_update, reversal_allowed]);
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating movement type:', error);
    res.status(500).json({ error: 'Failed to create movement type' });
  }
});

router.patch('/movement-types/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { movement_code, movement_name, description, movement_category, debit_credit_indicator, quantity_update, value_update, reversal_allowed, active } = req.body;
    
    const result = await db.query(`
      UPDATE movement_types 
      SET movement_code = $1, movement_name = $2, description = $3, movement_category = $4, 
          debit_credit_indicator = $5, quantity_update = $6, value_update = $7, reversal_allowed = $8, 
          active = $9, updated_at = CURRENT_TIMESTAMP
      WHERE id = $10
      RETURNING *
    `, [movement_code, movement_name, description, movement_category, debit_credit_indicator, quantity_update, value_update, reversal_allowed, active, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Movement type not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating movement type:', error);
    res.status(500).json({ error: 'Failed to update movement type' });
  }
});

router.delete('/movement-types/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await db.query('DELETE FROM movement_types WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Movement type not found' });
    }
    
    res.json({ message: 'Movement type deleted successfully' });
  } catch (error) {
    console.error('Error deleting movement type:', error);
    res.status(500).json({ error: 'Failed to delete movement type' });
  }
});

module.exports = router;