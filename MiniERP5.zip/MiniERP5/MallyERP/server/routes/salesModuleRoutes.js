import express from 'express';
import { pool } from '../db';

const router = express.Router();

// ========= SALES ORDERS ROUTES =========

// Get all orders
router.get('/api/sales/orders', async (req, res) => {
  try {
    // Check if orders table exists, create if it doesn't
    const checkTableResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'sales_orders'
      );
    `);
    
    if (!checkTableResult.rows[0].exists) {
      // Create orders table
      await pool.query(`
        CREATE TABLE sales_orders (
          id SERIAL PRIMARY KEY,
          order_number VARCHAR(50) UNIQUE NOT NULL,
          customer_id INT,
          customer_name VARCHAR(255) NOT NULL,
          order_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          delivery_date TIMESTAMP WITH TIME ZONE,
          status VARCHAR(50) DEFAULT 'Pending',
          total_amount DECIMAL(15, 2) DEFAULT 0,
          payment_status VARCHAR(50) DEFAULT 'Unpaid',
          shipping_address TEXT,
          billing_address TEXT,
          notes TEXT,
          created_by INT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample data
        INSERT INTO sales_orders (
          order_number, customer_name, order_date, delivery_date, 
          status, total_amount, payment_status, shipping_address, billing_address
        ) VALUES
        ('SO-2025-1001', 'TechNova Inc', NOW() - INTERVAL '13 DAYS', NOW() + INTERVAL '7 DAYS', 
          'Confirmed', 5649.75, 'Paid', '123 Tech Park, San Francisco, CA', '123 Tech Park, San Francisco, CA'),
        ('SO-2025-1002', 'Elevate Solutions', NOW() - INTERVAL '11 DAYS', NOW() + INTERVAL '5 DAYS', 
          'Processing', 2375.50, 'Paid', '456 Business Ave, Seattle, WA', '456 Business Ave, Seattle, WA'),
        ('SO-2025-1003', 'DataWave Analytics', NOW() - INTERVAL '8 DAYS', NOW() + INTERVAL '10 DAYS', 
          'Processing', 8925.33, 'Partial', '789 Data Drive, Boston, MA', '789 Data Drive, Boston, MA'),
        ('SO-2025-1004', 'Quantum Systems', NOW() - INTERVAL '5 DAYS', NOW() + INTERVAL '14 DAYS', 
          'Pending', 3450.20, 'Unpaid', '101 Quantum Blvd, Austin, TX', '101 Quantum Blvd, Austin, TX'),
        ('SO-2025-1005', 'Arctic Innovations', NOW() - INTERVAL '3 DAYS', NOW() + INTERVAL '7 DAYS', 
          'Confirmed', 1875.60, 'Paid', '202 Ice Street, Chicago, IL', '202 Ice Street, Chicago, IL');
      `);
      
      // Create order_items table
      await pool.query(`
        CREATE TABLE sales_order_items (
          id SERIAL PRIMARY KEY,
          order_id INT REFERENCES sales_orders(id) ON DELETE CASCADE,
          product_id INT,
          product_name VARCHAR(255) NOT NULL,
          quantity INT NOT NULL,
          unit_price DECIMAL(15, 2) NOT NULL,
          discount_percent DECIMAL(5, 2) DEFAULT 0,
          tax_percent DECIMAL(5, 2) DEFAULT 0,
          subtotal DECIMAL(15, 2) NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample order items (will be added after getting order IDs)
      `);
      
      // Add sample order items
      const ordersResult = await pool.query('SELECT id FROM sales_orders');
      const orderIds = ordersResult.rows;
      
      for (const order of orderIds) {
        // Generate 1-3 items per order
        const itemCount = Math.floor(Math.random() * 3) + 1;
        
        for (let i = 0; i < itemCount; i++) {
          // Sample product data
          const products = [
            { name: 'Enterprise SaaS License', price: 1299.99 },
            { name: 'Cloud Security Package', price: 899.50 },
            { name: 'Data Analytics Platform', price: 1499.75 },
            { name: 'Mobile Device Management', price: 699.99 },
            { name: 'Network Infrastructure', price: 2499.50 }
          ];
          
          const product = products[Math.floor(Math.random() * products.length)];
          const quantity = Math.floor(Math.random() * 5) + 1;
          const unitPrice = product.price;
          const subtotal = quantity * unitPrice;
          
          await pool.query(`
            INSERT INTO sales_order_items (
              order_id, product_name, quantity, unit_price, subtotal
            ) VALUES ($1, $2, $3, $4, $5)
          `, [order.id, product.name, quantity, unitPrice, subtotal]);
        }
      }
    }
    
    // Fetch orders
    const result = await pool.query(`
      SELECT 
        id, order_number, customer_name, order_date, 
        delivery_date, status, total_amount, payment_status
      FROM sales_orders
      ORDER BY order_date DESC
    `);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ message: 'Error fetching orders', error: error.message });
  }
});

// Get order details by ID
router.get('/api/sales/orders/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Get order details
    const orderResult = await pool.query(`
      SELECT * FROM sales_orders WHERE id = $1
    `, [id]);
    
    if (orderResult.rows.length === 0) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    // Get order items
    const itemsResult = await pool.query(`
      SELECT * FROM sales_order_items WHERE order_id = $1
    `, [id]);
    
    const order = {
      ...orderResult.rows[0],
      items: itemsResult.rows
    };
    
    res.json(order);
  } catch (error) {
    console.error('Error fetching order details:', error);
    res.status(500).json({ message: 'Error fetching order details', error: error.message });
  }
});

// Create a new order
router.post('/api/sales/orders', async (req, res) => {
  try {
    const {
      customer_name,
      customerCode,
      orderDate,
      delivery_date,
      status,
      total_amount,
      payment_status,
      shipping_address,
      billing_address,
      notes,
      items
    } = req.body;

    // Handle both customer_name and customerCode parameters
    let finalCustomerName = customer_name;
    if (customerCode && !customer_name) {
      // Look up customer name from customerCode
      try {
        const customerResult = await pool.query('SELECT name FROM customers WHERE code = $1', [customerCode]);
        if (customerResult.rows.length > 0) {
          finalCustomerName = customerResult.rows[0].name;
        } else {
          finalCustomerName = customerCode; // Use code as fallback
        }
      } catch (lookupError) {
        finalCustomerName = customerCode; // Use code as fallback
      }
    }
    
    // Generate order number (format: SO-YYYY-XXXX)
    const year = new Date().getFullYear();
    const countResult = await pool.query('SELECT COUNT(*) FROM sales_orders');
    const count = parseInt(countResult.rows[0].count) + 1;
    const orderNumber = `SO-${year}-${count.toString().padStart(4, '0')}`;
    
    // Create order
    const orderResult = await pool.query(`
      INSERT INTO sales_orders (
        order_number, customer_name, delivery_date, status,
        total_amount, payment_status, shipping_address, billing_address, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *
    `, [
      orderNumber, 
      finalCustomerName, 
      delivery_date, 
      status || 'Pending', 
      total_amount || 0, 
      payment_status || 'Unpaid', 
      shipping_address, 
      billing_address, 
      notes
    ]);
    
    const orderId = orderResult.rows[0].id;
    
    // Create order items if provided
    if (items && items.length > 0) {
      for (const item of items) {
        await pool.query(`
          INSERT INTO sales_order_items (
            order_id, product_name, quantity, unit_price, discount_percent, tax_percent, subtotal
          ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        `, [
          orderId,
          item.product_name,
          item.quantity,
          item.unit_price,
          item.discount_percent || 0,
          item.tax_percent || 0,
          item.subtotal
        ]);
      }
    }
    
    // Return order with items
    const fullOrderResult = await pool.query(`
      SELECT * FROM sales_orders WHERE id = $1
    `, [orderId]);
    
    const itemsResult = await pool.query(`
      SELECT * FROM sales_order_items WHERE order_id = $1
    `, [orderId]);
    
    const order = {
      ...fullOrderResult.rows[0],
      items: itemsResult.rows
    };
    
    res.status(201).json(order);
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ message: 'Error creating order', error: error.message });
  }
});

// ========= QUOTES/ESTIMATES ROUTES =========

// Get all quotes
router.get('/api/sales/quotes', async (req, res) => {
  try {
    // Check if quotes table exists, create if it doesn't
    const checkTableResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'sales_quotes'
      );
    `);
    
    if (!checkTableResult.rows[0].exists) {
      // Create quotes table
      await pool.query(`
        CREATE TABLE sales_quotes (
          id SERIAL PRIMARY KEY,
          quote_number VARCHAR(50) UNIQUE NOT NULL,
          opportunity_id INT,
          customer_name VARCHAR(255) NOT NULL,
          quote_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          valid_until TIMESTAMP WITH TIME ZONE,
          status VARCHAR(50) DEFAULT 'Draft',
          total_amount DECIMAL(15, 2) DEFAULT 0,
          discount_amount DECIMAL(15, 2) DEFAULT 0,
          tax_amount DECIMAL(15, 2) DEFAULT 0,
          grand_total DECIMAL(15, 2) DEFAULT 0,
          notes TEXT,
          terms_conditions TEXT,
          created_by INT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample data
        INSERT INTO sales_quotes (
          quote_number, customer_name, quote_date, valid_until, 
          status, total_amount, grand_total, terms_conditions
        ) VALUES
        ('QT-2025-1001', 'TechNova Inc', NOW() - INTERVAL '15 DAYS', NOW() + INTERVAL '45 DAYS', 
          'Sent', 6200.00, 6510.00, 'Net 30 payment terms. Quoted prices valid for 60 days.'),
        ('QT-2025-1002', 'Elevate Solutions', NOW() - INTERVAL '12 DAYS', NOW() + INTERVAL '48 DAYS', 
          'Draft', 3750.50, 3938.03, 'Net 30 payment terms. Quoted prices valid for 60 days.'),
        ('QT-2025-1003', 'DataWave Analytics', NOW() - INTERVAL '10 DAYS', NOW() + INTERVAL '50 DAYS', 
          'Approved', 9200.00, 9660.00, 'Net 30 payment terms. Quoted prices valid for 60 days.'),
        ('QT-2025-1004', 'Quantum Systems', NOW() - INTERVAL '7 DAYS', NOW() + INTERVAL '53 DAYS', 
          'Rejected', 4800.75, 5040.79, 'Net 30 payment terms. Quoted prices valid for 60 days.'),
        ('QT-2025-1005', 'Arctic Innovations', NOW() - INTERVAL '5 DAYS', NOW() + INTERVAL '55 DAYS', 
          'Sent', 2350.25, 2467.76, 'Net 30 payment terms. Quoted prices valid for 60 days.');
      `);
      
      // Create quote_items table
      await pool.query(`
        CREATE TABLE sales_quote_items (
          id SERIAL PRIMARY KEY,
          quote_id INT REFERENCES sales_quotes(id) ON DELETE CASCADE,
          product_name VARCHAR(255) NOT NULL,
          description TEXT,
          quantity INT NOT NULL,
          unit_price DECIMAL(15, 2) NOT NULL,
          discount_percent DECIMAL(5, 2) DEFAULT 0,
          tax_percent DECIMAL(5, 2) DEFAULT 0,
          subtotal DECIMAL(15, 2) NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample quote items (will be added after getting quote IDs)
      `);
      
      // Add sample quote items
      const quotesResult = await pool.query('SELECT id FROM sales_quotes');
      const quoteIds = quotesResult.rows;
      
      for (const quote of quoteIds) {
        // Generate 1-4 items per quote
        const itemCount = Math.floor(Math.random() * 4) + 1;
        
        for (let i = 0; i < itemCount; i++) {
          // Sample product data
          const products = [
            { name: 'Enterprise SaaS License', desc: 'Annual subscription', price: 1299.99 },
            { name: 'Cloud Security Package', desc: 'Advanced security suite', price: 899.50 },
            { name: 'Data Analytics Platform', desc: 'Business intelligence tools', price: 1499.75 },
            { name: 'Mobile Device Management', desc: 'Enterprise mobility solution', price: 699.99 },
            { name: 'Network Infrastructure', desc: 'Network hardware and setup', price: 2499.50 },
            { name: 'Custom Development', desc: 'Custom software development (hourly)', price: 150.00 },
            { name: 'Technical Support Plan', desc: '24/7 technical support', price: 499.99 }
          ];
          
          const product = products[Math.floor(Math.random() * products.length)];
          const quantity = Math.floor(Math.random() * 5) + 1;
          const unitPrice = product.price;
          const subtotal = quantity * unitPrice;
          
          await pool.query(`
            INSERT INTO sales_quote_items (
              quote_id, product_name, description, quantity, unit_price, subtotal
            ) VALUES ($1, $2, $3, $4, $5, $6)
          `, [quote.id, product.name, product.desc, quantity, unitPrice, subtotal]);
        }
      }
    }
    
    // Get status filter from query params
    const { status } = req.query;
    console.log('Quote filter - status:', status);
    
    // Create query with optional filtering
    let query = `
      SELECT 
        id, quote_number, customer_name, quote_date, 
        valid_until, status, total_amount, grand_total
      FROM sales_quotes
    `;
    
    const queryParams = [];
    
    // Add status filter if provided
    if (status && status !== 'all') {
      // Convert status to match database format (first letter uppercase)
      const formattedStatus = status.charAt(0).toUpperCase() + status.slice(1).toLowerCase();
      query += ` WHERE status = $1`;
      queryParams.push(formattedStatus);
      console.log(`Filtering quotes by status: ${formattedStatus}`);
    }
    
    // Add order by
    query += ` ORDER BY quote_date DESC`;
    
    // Execute query with parameters
    const result = await pool.query(query, queryParams);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching quotes:', error);
    res.status(500).json({ message: 'Error fetching quotes', error: error.message });
  }
});

// ========= INVOICES ROUTES =========

// Get all invoices
router.get('/api/sales/invoices', async (req, res) => {
  try {
    // Check if invoices table exists, create if it doesn't
    const checkTableResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'sales_invoices'
      );
    `);
    
    if (!checkTableResult.rows[0].exists) {
      // Create invoices table
      await pool.query(`
        CREATE TABLE sales_invoices (
          id SERIAL PRIMARY KEY,
          invoice_number VARCHAR(50) UNIQUE NOT NULL,
          order_id INT,
          customer_name VARCHAR(255) NOT NULL,
          invoice_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          due_date TIMESTAMP WITH TIME ZONE,
          status VARCHAR(50) DEFAULT 'Pending',
          total_amount DECIMAL(15, 2) DEFAULT 0,
          discount_amount DECIMAL(15, 2) DEFAULT 0,
          tax_amount DECIMAL(15, 2) DEFAULT 0,
          grand_total DECIMAL(15, 2) DEFAULT 0,
          paid_amount DECIMAL(15, 2) DEFAULT 0,
          payment_method VARCHAR(50),
          payment_date TIMESTAMP WITH TIME ZONE,
          notes TEXT,
          created_by INT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample data
        INSERT INTO sales_invoices (
          invoice_number, customer_name, invoice_date, due_date, 
          status, total_amount, grand_total, paid_amount, payment_method, payment_date
        ) VALUES
        ('INV-2025-1001', 'TechNova Inc', NOW() - INTERVAL '20 DAYS', NOW() - INTERVAL '5 DAYS', 
          'Paid', 5649.75, 5932.24, 5932.24, 'Credit Card', NOW() - INTERVAL '7 DAYS'),
        ('INV-2025-1002', 'Elevate Solutions', NOW() - INTERVAL '18 DAYS', NOW() - INTERVAL '3 DAYS', 
          'Paid', 2375.50, 2494.28, 2494.28, 'Bank Transfer', NOW() - INTERVAL '6 DAYS'),
        ('INV-2025-1003', 'DataWave Analytics', NOW() - INTERVAL '15 DAYS', NOW() + INTERVAL '15 DAYS', 
          'Partially Paid', 8925.33, 9371.60, 4000.00, 'Bank Transfer', NOW() - INTERVAL '10 DAYS'),
        ('INV-2025-1004', 'Quantum Systems', NOW() - INTERVAL '10 DAYS', NOW() + INTERVAL '20 DAYS', 
          'Unpaid', 3450.20, 3622.71, 0.00, null, null),
        ('INV-2025-1005', 'Arctic Innovations', NOW() - INTERVAL '7 DAYS', NOW() + INTERVAL '23 DAYS', 
          'Unpaid', 1875.60, 1969.38, 0.00, null, null);
      `);
      
      // Create invoice_items table
      await pool.query(`
        CREATE TABLE sales_invoice_items (
          id SERIAL PRIMARY KEY,
          invoice_id INT REFERENCES sales_invoices(id) ON DELETE CASCADE,
          product_name VARCHAR(255) NOT NULL,
          description TEXT,
          quantity INT NOT NULL,
          unit_price DECIMAL(15, 2) NOT NULL,
          discount_percent DECIMAL(5, 2) DEFAULT 0,
          tax_percent DECIMAL(5, 2) DEFAULT 0,
          subtotal DECIMAL(15, 2) NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample invoice items (will be added after getting invoice IDs)
      `);
      
      // Add sample invoice items
      const invoicesResult = await pool.query('SELECT id FROM sales_invoices');
      const invoiceIds = invoicesResult.rows;
      
      for (const invoice of invoiceIds) {
        // Generate 1-3 items per invoice
        const itemCount = Math.floor(Math.random() * 3) + 1;
        
        for (let i = 0; i < itemCount; i++) {
          // Sample product data
          const products = [
            { name: 'Enterprise SaaS License', desc: 'Annual subscription', price: 1299.99 },
            { name: 'Cloud Security Package', desc: 'Advanced security suite', price: 899.50 },
            { name: 'Data Analytics Platform', desc: 'Business intelligence tools', price: 1499.75 },
            { name: 'Mobile Device Management', desc: 'Enterprise mobility solution', price: 699.99 },
            { name: 'Network Infrastructure', desc: 'Network hardware and setup', price: 2499.50 }
          ];
          
          const product = products[Math.floor(Math.random() * products.length)];
          const quantity = Math.floor(Math.random() * 5) + 1;
          const unitPrice = product.price;
          const subtotal = quantity * unitPrice;
          
          await pool.query(`
            INSERT INTO sales_invoice_items (
              invoice_id, product_name, description, quantity, unit_price, subtotal
            ) VALUES ($1, $2, $3, $4, $5, $6)
          `, [invoice.id, product.name, product.desc, quantity, unitPrice, subtotal]);
        }
      }
    }
    
    // Get status filter from query params
    const { status } = req.query;
    console.log('Invoice filter - status:', status);
    
    // Create query with optional filtering
    let query = `
      SELECT 
        id, invoice_number, customer_name, invoice_date, 
        due_date, status, grand_total, paid_amount
      FROM sales_invoices
    `;
    
    const queryParams = [];
    
    // Add status filter if provided
    if (status && status !== 'all') {
      // Filter only invoices with matching status
      if (status === 'Unpaid') {
        // Only show records with status 'Unpaid'
        query += ` WHERE status = 'Unpaid'`;
        console.log(`Filtering invoices for Unpaid status only`);
      } 
      else if (status === 'Paid') {
        // Only show records with status 'Paid'
        query += ` WHERE status = 'Paid'`;
        console.log(`Filtering invoices for Paid status only`);
      }
      else if (status === 'Partially Paid') {
        // Only show records with status 'Partially Paid'
        query += ` WHERE status = 'Partially Paid'`;
        console.log(`Filtering invoices for Partially Paid status only`);
      }
      else if (status === 'Overdue') {
        // Only show records with status 'Overdue' 
        query += ` WHERE status = 'Overdue' OR (status = 'Unpaid' AND due_date < NOW())`;
        console.log(`Filtering invoices for Overdue status`);
      }
    }
    
    // Add order by
    query += ` ORDER BY invoice_date DESC`;
    
    // Execute query with parameters
    const result = await pool.query(query, queryParams);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching invoices:', error);
    res.status(500).json({ message: 'Error fetching invoices', error: error.message });
  }
});

// ========= RETURNS ROUTES =========

// Get all returns
router.get('/api/sales/returns', async (req, res) => {
  try {
    // Check if returns table exists, create if it doesn't
    const checkTableResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'sales_returns'
      );
    `);
    
    if (!checkTableResult.rows[0].exists) {
      // Create returns table
      await pool.query(`
        CREATE TABLE sales_returns (
          id SERIAL PRIMARY KEY,
          return_number VARCHAR(50) UNIQUE NOT NULL,
          order_id INT,
          invoice_id INT,
          customer_name VARCHAR(255) NOT NULL,
          return_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          status VARCHAR(50) DEFAULT 'Pending',
          total_amount DECIMAL(15, 2) DEFAULT 0,
          return_reason TEXT,
          notes TEXT,
          created_by INT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample data
        INSERT INTO sales_returns (
          return_number, customer_name, return_date, 
          status, total_amount, return_reason
        ) VALUES
        ('RET-2025-1001', 'TechNova Inc', NOW() - INTERVAL '10 DAYS', 
          'Completed', 1299.99, 'Product not needed anymore'),
        ('RET-2025-1002', 'Elevate Solutions', NOW() - INTERVAL '7 DAYS', 
          'Processing', 899.50, 'Incompatible with current systems'),
        ('RET-2025-1003', 'DataWave Analytics', NOW() - INTERVAL '5 DAYS', 
          'Approved', 699.99, 'Duplicate order'),
        ('RET-2025-1004', 'Quantum Systems', NOW() - INTERVAL '3 DAYS', 
          'Pending', 1499.75, 'Wrong product received');
      `);
      
      // Create return_items table
      await pool.query(`
        CREATE TABLE sales_return_items (
          id SERIAL PRIMARY KEY,
          return_id INT REFERENCES sales_returns(id) ON DELETE CASCADE,
          product_name VARCHAR(255) NOT NULL,
          quantity INT NOT NULL,
          unit_price DECIMAL(15, 2) NOT NULL,
          subtotal DECIMAL(15, 2) NOT NULL,
          return_reason TEXT,
          condition VARCHAR(50),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample return items (will be added after getting return IDs)
      `);
      
      // Add sample return items
      const returnsResult = await pool.query('SELECT id FROM sales_returns');
      const returnIds = returnsResult.rows;
      
      for (const returnRecord of returnIds) {
        // Generate 1-2 items per return
        const itemCount = Math.floor(Math.random() * 2) + 1;
        
        for (let i = 0; i < itemCount; i++) {
          // Sample product data
          const products = [
            { name: 'Enterprise SaaS License', price: 1299.99 },
            { name: 'Cloud Security Package', price: 899.50 },
            { name: 'Data Analytics Platform', price: 1499.75 },
            { name: 'Mobile Device Management', price: 699.99 },
            { name: 'Network Infrastructure', price: 2499.50 }
          ];
          
          const conditions = ['New', 'Like New', 'Used', 'Damaged'];
          
          const product = products[Math.floor(Math.random() * products.length)];
          const quantity = Math.floor(Math.random() * 2) + 1;
          const unitPrice = product.price;
          const subtotal = quantity * unitPrice;
          const condition = conditions[Math.floor(Math.random() * conditions.length)];
          
          await pool.query(`
            INSERT INTO sales_return_items (
              return_id, product_name, quantity, unit_price, subtotal, condition
            ) VALUES ($1, $2, $3, $4, $5, $6)
          `, [returnRecord.id, product.name, quantity, unitPrice, subtotal, condition]);
        }
      }
    }
    
    // Fetch returns
    // Get status filter from query params
    const { status } = req.query;
    console.log('Return filter - status:', status);
    
    // Create query with optional filtering
    let query = `
      SELECT 
        id, return_number, customer_name, return_date, 
        status, total_amount, return_reason
      FROM sales_returns
    `;
    
    const queryParams = [];
    
    // Add status filter if provided
    if (status && status !== 'all') {
      // Filter returns based on specific status values
      if (status === 'Pending') {
        query += ` WHERE status = 'Pending'`;
        console.log(`Filtering returns for Pending status only`);
      } 
      else if (status === 'Approved') {
        query += ` WHERE status = 'Approved'`;
        console.log(`Filtering returns for Approved status only`);
      }
      else if (status === 'Processing') {
        query += ` WHERE status = 'Processing'`;
        console.log(`Filtering returns for Processing status only`);
      }
      else if (status === 'Completed') {
        query += ` WHERE status = 'Completed'`;
        console.log(`Filtering returns for Completed status only`);
      }
      else if (status === 'Rejected') {
        query += ` WHERE status = 'Rejected'`;
        console.log(`Filtering returns for Rejected status only`);
      }
    }
    
    // Add order by
    query += ` ORDER BY return_date DESC`;
    
    // Execute query with parameters
    const result = await pool.query(query, queryParams);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching returns:', error);
    res.status(500).json({ message: 'Error fetching returns', error: error.message });
  }
});

// ========= CUSTOMERS ROUTES =========

// Get all customers
router.get('/api/sales/customers', async (req, res) => {
  try {
    // Check if customers table exists, create if it doesn't
    const checkTableResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'sales_customers'
      );
    `);
    
    if (!checkTableResult.rows[0].exists) {
      // Create customers table
      await pool.query(`
        CREATE TABLE sales_customers (
          id SERIAL PRIMARY KEY,
          customer_number VARCHAR(50) UNIQUE NOT NULL,
          company_name VARCHAR(255) NOT NULL,
          contact_person VARCHAR(255),
          email VARCHAR(255),
          phone VARCHAR(50),
          website VARCHAR(255),
          industry VARCHAR(100),
          customer_type VARCHAR(50) DEFAULT 'Business',
          billing_address TEXT,
          shipping_address TEXT,
          tax_id VARCHAR(100),
          payment_terms VARCHAR(100),
          credit_limit DECIMAL(15, 2),
          status VARCHAR(50) DEFAULT 'Active',
          notes TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample data
        INSERT INTO sales_customers (
          customer_number, company_name, contact_person, email, phone,
          website, industry, customer_type, status, credit_limit
        ) VALUES
        ('CUST-1001', 'TechNova Inc', 'John Smith', 'john.smith@technova.com', '(555) 123-4567',
          'www.technova.com', 'Technology', 'Business', 'Active', 50000.00),
        ('CUST-1002', 'Elevate Solutions', 'Sarah Johnson', 'sarah@elevatesolutions.com', '(555) 234-5678',
          'www.elevatesolutions.com', 'Consulting', 'Business', 'Active', 35000.00),
        ('CUST-1003', 'DataWave Analytics', 'Michael Chen', 'michael@datawave.com', '(555) 345-6789',
          'www.datawave.com', 'Data Services', 'Business', 'Active', 75000.00),
        ('CUST-1004', 'Quantum Systems', 'Emily Rodriguez', 'emily@quantumsystems.com', '(555) 456-7890',
          'www.quantumsystems.com', 'Manufacturing', 'Business', 'Active', 100000.00),
        ('CUST-1005', 'Arctic Innovations', 'David Wilson', 'david@arcticinnovations.com', '(555) 567-8901',
          'www.arcticinnovations.com', 'Research', 'Business', 'Active', 25000.00),
        ('CUST-1006', 'Sunrise Healthcare', 'Lisa Morgan', 'lisa@sunrisehealthcare.com', '(555) 678-9012',
          'www.sunrisehealthcare.com', 'Healthcare', 'Business', 'Inactive', 40000.00),
        ('CUST-1007', 'Velocity Logistics', 'Robert Brown', 'robert@velocitylogistics.com', '(555) 789-0123',
          'www.velocitylogistics.com', 'Transportation', 'Business', 'Active', 60000.00);
      `);
      
      // Create customer_contacts table
      await pool.query(`
        CREATE TABLE sales_customer_contacts (
          id SERIAL PRIMARY KEY,
          customer_id INT REFERENCES sales_customers(id) ON DELETE CASCADE,
          name VARCHAR(255) NOT NULL,
          position VARCHAR(100),
          email VARCHAR(255),
          phone VARCHAR(50),
          is_primary BOOLEAN DEFAULT FALSE,
          notes TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Sample customer contacts (will be added after getting customer IDs)
      `);
      
      // Add sample customer contacts
      const customersResult = await pool.query('SELECT id, contact_person, email, phone FROM sales_customers');
      const customers = customersResult.rows;
      
      for (const customer of customers) {
        // Add primary contact based on customer data
        await pool.query(`
          INSERT INTO sales_customer_contacts (
            customer_id, name, position, email, phone, is_primary
          ) VALUES ($1, $2, $3, $4, $5, $6)
        `, [customer.id, customer.contact_person, 'Primary Contact', customer.email, customer.phone, true]);
        
        // Add additional contact for some customers
        if (Math.random() > 0.5) {
          const positions = ['Sales Manager', 'Finance Director', 'Technical Lead', 'Operations Manager'];
          const position = positions[Math.floor(Math.random() * positions.length)];
          const name = ['Alex Wong', 'Maria Garcia', 'Tom Baker', 'Jessica Lee'][Math.floor(Math.random() * 4)];
          const email = `${name.split(' ')[0].toLowerCase()}@${customer.email.split('@')[1]}`;
          const phone = '(555) ' + Math.floor(Math.random() * 900 + 100) + '-' + Math.floor(Math.random() * 9000 + 1000);
          
          await pool.query(`
            INSERT INTO sales_customer_contacts (
              customer_id, name, position, email, phone, is_primary
            ) VALUES ($1, $2, $3, $4, $5, $6)
          `, [customer.id, name, position, email, phone, false]);
        }
      }
    }
    
    // Get status filter from query params
    const { status } = req.query;
    console.log('Customer filter - status:', status);
    
    // Create query with optional filtering
    let query = `
      SELECT 
        id, customer_number, company_name, contact_person, 
        email, phone, industry, status
      FROM sales_customers
    `;
    
    const queryParams = [];
    
    // Add status filter if provided
    if (status && status !== 'all') {
      // Filter customers based on specific status values
      if (status === 'Active') {
        query += ` WHERE status = 'Active'`;
        console.log(`Filtering customers for Active status only`);
      } 
      else if (status === 'Inactive') {
        query += ` WHERE status = 'Inactive'`;
        console.log(`Filtering customers for Inactive status only`);
      }
      else if (status === 'On Hold') {
        query += ` WHERE status = 'On Hold'`;
        console.log(`Filtering customers for On Hold status only`);
      }
      else if (status === 'Blocked') {
        query += ` WHERE status = 'Blocked'`;
        console.log(`Filtering customers for Blocked status only`);
      }
      else if (status === 'VIP') {
        query += ` WHERE status = 'VIP'`;
        console.log(`Filtering customers for VIP status only`);
      }
    }
    
    // Add order by
    query += ` ORDER BY company_name`;
    
    // Execute query with parameters
    const result = await pool.query(query, queryParams);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching customers:', error);
    res.status(500).json({ message: 'Error fetching customers', error: error.message });
  }
});

export default router;