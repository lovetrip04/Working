import express from 'express';
import { pool } from '../db';

const router = express.Router();

// Get all purchase orders
router.get('/orders', async (req, res) => {
  try {
    // Check if purchase_orders table exists
    const tableCheckResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'purchase_orders'
      );
    `);
    
    if (tableCheckResult.rows[0].exists) {
      const result = await pool.query(`
        SELECT po.*, v.name as vendor_name
        FROM purchase_orders po
        LEFT JOIN vendors v ON po.vendor_id = v.id
        ORDER BY po.order_date DESC
      `);
      res.json(result.rows);
    } else {
      // Return sample data if table doesn't exist
      res.json([
        {
          id: 1,
          order_number: "PO-2025-1001",
          vendor_id: 1,
          vendor_name: "Tech Supplies Inc.",
          order_date: new Date(2025, 0, 15).toISOString(),
          delivery_date: new Date(2025, 1, 15).toISOString(),
          status: "Pending",
          total_amount: 5600.00,
          currency: "USD"
        },
        {
          id: 2,
          order_number: "PO-2025-1002",
          vendor_id: 2,
          vendor_name: "Global Manufacturing Ltd.",
          order_date: new Date(2025, 0, 18).toISOString(),
          delivery_date: new Date(2025, 1, 18).toISOString(),
          status: "Approved",
          total_amount: 12450.00,
          currency: "USD"
        },
        {
          id: 3,
          order_number: "PO-2025-1003",
          vendor_id: 3,
          vendor_name: "Industrial Components Co.",
          order_date: new Date(2025, 0, 22).toISOString(),
          delivery_date: new Date(2025, 1, 22).toISOString(),
          status: "Received",
          total_amount: 7820.00,
          currency: "USD"
        }
      ]);
    }
  } catch (error) {
    console.error('Error fetching purchase orders:', error);
    res.status(500).json({ message: 'Failed to fetch purchase orders' });
  }
});

// Get all vendors
router.get('/vendors', async (req, res) => {
  try {
    // Check if vendors table exists
    const tableCheckResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'vendors'
      );
    `);
    
    if (tableCheckResult.rows[0].exists) {
      const result = await pool.query(`
        SELECT * FROM vendors ORDER BY name
      `);
      res.json(result.rows);
    } else {
      // Return sample data if table doesn't exist
      res.json([
        {
          id: 1,
          vendor_number: "V0001",
          name: "Tech Supplies Inc.",
          contact_person: "John Smith",
          email: "jsmith@techsupplies.com",
          phone: "+1-123-456-7890"
        },
        {
          id: 2,
          vendor_number: "V0002",
          name: "Global Manufacturing Ltd.",
          contact_person: "Sarah Johnson",
          email: "sarah@globalmanufacturing.com",
          phone: "+1-234-567-8901"
        },
        {
          id: 3,
          vendor_number: "V0003",
          name: "Industrial Components Co.",
          contact_person: "Robert Brown",
          email: "rbrown@industrialcomp.com",
          phone: "+1-345-678-9012"
        }
      ]);
    }
  } catch (error) {
    console.error('Error fetching vendors:', error);
    res.status(500).json({ message: 'Failed to fetch vendors' });
  }
});

// Create new purchase order
router.post('/orders', async (req, res) => {
  try {
    const {
      vendor_id,
      order_date,
      delivery_date,
      status,
      total_amount,
      currency,
      notes
    } = req.body;

    // Generate order number
    const year = new Date().getFullYear();
    const nextOrderQuery = await pool.query(`
      SELECT COUNT(*) FROM purchase_orders WHERE order_number LIKE $1
    `, [`PO-${year}-%`]);
    
    const nextOrderNumber = parseInt(nextOrderQuery.rows[0].count) + 1;
    const orderNumber = `PO-${year}-${nextOrderNumber.toString().padStart(4, '0')}`;
    
    const result = await pool.query(`
      INSERT INTO purchase_orders (
        order_number, vendor_id, order_date, delivery_date, 
        status, total_amount, currency, notes, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
      RETURNING *
    `, [
      orderNumber, 
      vendor_id, 
      order_date, 
      delivery_date, 
      status || 'Draft', 
      total_amount, 
      currency || 'USD',
      notes
    ]);
    
    // Get vendor name to include in response
    const vendorResult = await pool.query(`
      SELECT name FROM vendors WHERE id = $1
    `, [vendor_id]);
    
    const responseData = {
      ...result.rows[0],
      vendor_name: vendorResult.rows[0]?.name || ''
    };
    
    res.status(201).json(responseData);
  } catch (error) {
    console.error('Error creating purchase order:', error);
    res.status(500).json({ message: 'Failed to create purchase order' });
  }
});

export default router;