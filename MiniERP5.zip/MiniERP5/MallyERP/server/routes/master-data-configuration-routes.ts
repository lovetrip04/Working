import { Request, Response, Router } from "express";
import { masterDataConfigurationService } from "../services/master-data-configuration-service";
import { z } from "zod";

const router = Router();

// Initialize Complete Master Data Configuration
router.post("/initialize-complete", async (req: Request, res: Response) => {
  try {
    const result = await masterDataConfigurationService.initializeCompleteConfiguration();
    
    res.json({
      success: result.success,
      message: result.success ? "Complete master data configuration initialized successfully" : "Configuration initialization had errors",
      componentsInitialized: result.componentsInitialized,
      errors: result.errors,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Master data configuration error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Master data configuration initialization failed",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
});

// Get Configuration Status
router.get("/status", async (req: Request, res: Response) => {
  try {
    const status = await masterDataConfigurationService.getConfigurationStatus();
    
    res.json({
      success: true,
      status,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Configuration status error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Failed to get configuration status",
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
});

export default router;