import express from 'express';
import { pool } from '../db';

const router = express.Router();

// Get all products
router.get('/products', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      ORDER BY p.id DESC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ message: 'Failed to fetch products' });
  }
});

// Get stock levels
router.get('/stock-levels', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT p.id, p.name, p.sku, p.stock as current_stock, p.min_stock, 
             p.min_stock + 20 as max_stock, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      ORDER BY p.stock ASC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching stock levels:', error);
    res.status(500).json({ message: 'Failed to fetch stock levels' });
  }
});

// Get stock movements
router.get('/movements', async (req, res) => {
  try {
    // First check if the table exists
    const tableExists = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'stock_movements'
      );
    `);
    
    if (tableExists.rows[0].exists) {
      const result = await pool.query(`
        SELECT sm.id, sm.product_id, sm.type as movement_type, sm.quantity, 
               sm.reason as reference, sm.date as movement_date, 
               p.name as product_name, p.sku, 
               COALESCE(u.username, 'System') as user_name
        FROM stock_movements sm
        LEFT JOIN products p ON sm.product_id = p.id
        LEFT JOIN users u ON sm.user_id = u.id
        ORDER BY sm.date DESC
      `);
      res.json(result.rows);
    } else {
      // Provide sample data if table doesn't exist
      res.json([
        {
          id: 1,
          product_id: 1,
          movement_type: 'IN',
          quantity: 50,
          reference: 'Initial Stock',
          movement_date: new Date().toISOString(),
          product_name: 'Sample Product',
          sku: 'SKU-001',
          user_name: 'Admin'
        }
      ]);
    }
  } catch (error) {
    console.error('Error fetching stock movements:', error);
    res.status(500).json({ message: 'Failed to fetch stock movements' });
  }
});

// Get warehouses (storage locations)
router.get('/warehouses', async (req, res) => {
  try {
    // Check if storage_locations table exists
    const tableCheckResult = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'storage_locations'
      );
    `);
    
    if (tableCheckResult.rows[0].exists) {
      const result = await pool.query(`
        SELECT sl.*, pl.name as plant_name, pl.code as plant_code,
               cc.name as company_code_name
        FROM storage_locations sl
        LEFT JOIN plants pl ON sl.plant_id = pl.id
        LEFT JOIN company_codes cc ON pl.company_code_id = cc.id
        ORDER BY sl.id ASC
      `);
      res.json(result.rows);
    } else {
      // Return sample data if the table doesn't exist
      res.json([
        { 
          id: 1, 
          code: "WH-001", 
          name: "Main Warehouse", 
          plant_name: "Manufacturing Plant 1",
          is_active: true 
        },
        { 
          id: 2, 
          code: "WH-002", 
          name: "Assembly Area", 
          plant_name: "Manufacturing Plant 1",
          is_active: true 
        },
        { 
          id: 3, 
          code: "WH-003", 
          name: "Shipping Dock", 
          plant_name: "Distribution Center",
          is_active: true 
        }
      ]);
    }
  } catch (error) {
    console.error('Error fetching warehouses:', error);
    res.status(500).json({ message: 'Failed to fetch warehouses' });
  }
});

// Create a new product
router.post('/products', async (req, res) => {
  try {
    const {
      name, sku, description, category_id, unit_of_measure_id,
      price, current_stock, min_stock, max_stock, storage_location_id
    } = req.body;

    const result = await pool.query(
      `INSERT INTO products (
         name, sku, description, category_id, unit_of_measure_id,
         price, current_stock, min_stock, max_stock, storage_location_id, created_at
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
       RETURNING *`,
      [name, sku, description, category_id, unit_of_measure_id, price, current_stock, min_stock, max_stock, storage_location_id]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ message: 'Failed to create product' });
  }
});

// Create a stock movement
router.post('/movements', async (req, res) => {
  try {
    const { product_id, quantity, type, reason, user_id } = req.body;

    const result = await pool.query(
      `INSERT INTO stock_movements (
         product_id, quantity, type, reason, user_id, date, created_at
       ) VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
       RETURNING *`,
      [product_id, quantity, type, reason, user_id || 1]
    );

    // Update product stock level
    if (type === 'IN') {
      await pool.query(
        `UPDATE products SET stock = stock + $1 WHERE id = $2`,
        [quantity, product_id]
      );
    } else if (type === 'OUT') {
      await pool.query(
        `UPDATE products SET stock = stock - $1 WHERE id = $2`,
        [quantity, product_id]
      );
    }

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating stock movement:', error);
    res.status(500).json({ message: 'Failed to create stock movement' });
  }
});

// Create a warehouse (storage location)
router.post('/warehouses', async (req, res) => {
  try {
    const { code, name, description, plant_id, is_active } = req.body;

    const result = await pool.query(
      `INSERT INTO storage_locations (
         code, name, description, plant_id, is_active
       ) VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [code, name, description, plant_id, is_active || true]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating warehouse:', error);
    res.status(500).json({ message: 'Failed to create warehouse' });
  }
});

export default router;