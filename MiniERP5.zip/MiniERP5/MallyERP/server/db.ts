
import * as schema from "@shared/schema";
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';


import * as financialSchema from "@shared/financial-schema";
import * as purchaseReferencesSchema from "@shared/purchase-references-schema";
import * as organizationalSchema from "@shared/organizational-schema";



if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Configure pool with connection retry and timeout settings
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL,
  max: 10, // Reduced max connections to prevent overload
  idleTimeoutMillis: 60000, // Increased idle timeout
  connectionTimeoutMillis: 10000, // Increased connection timeout
});

// Add robust error handling for connection issues
pool.on('error', (err: any) => {
  console.error('Database pool error:', err.message || err);
  // Don't throw here - let individual queries handle errors
});

pool.on('connect', () => {
  console.log('Database connection established');
});

export const db = drizzle(pool, { schema });