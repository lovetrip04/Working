import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import path from "path";
import express from "express";
import { storage } from "./storage";
import { pool } from "./db";
import { db } from "./db";
import { z } from "zod";
import { errorLogger } from "./utils/errorLogger";
import DataIntegrityMiddleware from "./middleware/dataIntegrityMiddleware";
import ZeroErrorDataHandler from "./utils/zeroErrorDataHandler";
import {
  insertCustomerSchema,
  insertCategorySchema,
  insertProductSchema,
  insertExpenseSchema,
  insertUserSchema,
  fiscalYearVariants,
  glAccounts,
  chartOfAccounts
} from "@shared/schema";
import { eq } from "drizzle-orm";
// Initialize master data routes
import initializeMasterDataRoutes from "./routes/master-data";
import adminRoutes from "./routes/admin";
import salesOppRoutes from "./routes/salesOppRoutes.js";
import salesModuleRoutes from "./routes/salesModuleRoutes.js";
import leadsRoutes from "./routes/leads";
import exportsRoutes from "./routes/exports";
import diagnosticsRoutes from "./routes/tools/diagnostics";
import productsRoutes from "./routes/products";
import inventoryRoutes from "./routes/inventoryRoutes.js";
import purchaseRoutes from "./routes/purchaseRoutes.js";
import productionRoutes from "./routes/productionRoutes.js";
import financeRoutes from "./routes/financeRoutes.js";
import controllingRoutes from "./routes/controllingRoutes.js";
import dashboardRoutes from "./routes/dashboardRoutes.js";
import transportRoutes from "./routes/transportRoutes.js";
import transportDirectRoutes from "./routes/transportDirectRoutes.js";
import githubIntegrationRoutes from "./routes/githubIntegrationRoutes.js";
import aiAgentRoutes from "./routes/aiAgentRoutes.js";
import apiKeyRoutes from "./routes/apiKeyRoutes.js";
import chiefAgentRoutes from "./routes/chief-agent-routes";
import chiefAgentPermissionsRoutes from "./routes/chief-agent-permissions-routes";
import reportsRoutes from "./routes/reportsRoutes.js";
import uploadRoutes from "./routes/uploadRoutes.js";
import workspaceRoutes from "./routes/workspaceRoutes.js";
import workspaceAgentRoutes from "./routes/workspaceAgentRoutes.js";
import salesFinanceIntegrationRoutes from "./routes/sales-finance-integration-routes";
import salesDistributionRoutes from "./routes/sales-distribution-routes";
import sdCustomizationRoutes from "./routes/sd-customization-routes";
import cashManagementRoutes from "./routes/transactions/cash-management";
import errorLogRoutes from "./routes/errorLogRoutes";
import changeLogRoutes from "./routes/changeLogRoutes";
import intelligentTestingRoutes from "./routes/intelligent-testing-routes";
import { manualE2ETestingService } from "./services/manual-e2e-testing";
import issuesRoutes from "./routes/issuesRoutes";
import agentPlayerRoutes from "./routes/agent-player-routes";
import coachAgentRoutes from "./routes/coach-agent-routes";
import rookieAgentRoutes from "./routes/rookie-agent-routes";
import agentStatusRoutes from "./routes/agent-status-routes";
import healthMonitoringRoutes from "./routes/health-monitoring-routes";
import { designerAgentRoutes } from "./routes/designer-agent-routes";
import purchaseRequestRoutes from "./routes/purchaseRequestRoutes.js";
import productionWorkOrderRoutes from "./routes/productionWorkOrderRoutes.js";
import controllingProfitCenterRoutes from "./routes/controllingProfitCenterRoutes.js";
import transactionAPIRoutes from "./routes/transactionAPIRoutes.js";
import jrIntegrationRoutes from "./routes/jr-integration";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize master data routes FIRST to avoid conflicts
  initializeMasterDataRoutes(app);
  
  // Add admin routes for data protection
  app.use("/api/admin", adminRoutes);
  
  // Register sales opportunity routes
  app.use(salesOppRoutes);
  
  // Register sales module routes (orders, quotes, invoices, returns, customers)
  app.use(salesModuleRoutes);
  
  // Register leads routes for opportunity form
  app.use(leadsRoutes);
  
  // Register exports routes
  app.use(exportsRoutes);
  
  // Register API diagnostics and testing routes
  app.use(diagnosticsRoutes);
  
  // Register products routes
  app.use(productsRoutes);
  
  // Register inventory routes
  app.use("/api/inventory", inventoryRoutes);
  
  // Register purchase routes
  app.use("/api/purchase", purchaseRoutes);
  
  // Register production routes
  app.use("/api/production", productionRoutes);
  
  // Register finance routes
  app.use("/api/finance", financeRoutes);
  
  // Register financial configuration routes
  app.use("/api/financial-config", (await import('./routes/financial-configuration-routes')).default);
  
  // Register Sales Distribution configuration routes
  app.use("/api/sales-distribution", salesDistributionRoutes);
  
  // Register Sales Distribution customization routes
  app.use("/api/sd-customization", sdCustomizationRoutes);
  
  // Register enhanced dashboard routes
  app.use("/api/dashboard", dashboardRoutes);
  
  // Register transport system routes
  app.use("/api/transport", transportRoutes);
  
  // Register direct transport routes with fixed SQL
  app.use("/api/transport-direct", transportDirectRoutes);
  
  // Register GitHub integration routes
  app.use("/api/github", githubIntegrationRoutes);
  
  // Register AI Agent routes
  app.use("/api/ai", aiAgentRoutes);
  
  // Register API key management routes
  app.use("/api/keys", apiKeyRoutes);
  
  // Register Reports routes
  app.use("/api/reports", reportsRoutes);
  
  // Register Upload routes for external data import
  app.use("/api/upload", uploadRoutes);
  
  // Register Workspace management routes
  app.use("/api/workspace", workspaceRoutes);
  
  // Register error logging routes
  app.use("/api/logs", errorLogRoutes);
  
  // Register change log routes for audit trail
  app.use("/api/change-log", changeLogRoutes);
  
  // Register Intelligent Testing Agent routes
  app.use("/api/intelligent-testing", intelligentTestingRoutes);
  
  // Register Cash Management transaction routes
  app.use("/api/transactions/cash-management", cashManagementRoutes);
  
  // Register ProjectTest routes for screenshot organization
  app.use("/api/projecttest", (await import('./routes/projecttest-routes')).default);

  // Register Condition Types Management routes
  app.use("/api/condition-types", (await import('./routes/condition-types')).default);

  // Dominos Cost Analysis Testing
  app.get('/api/dominos-cost-testing/run', async (req, res) => {
    try {
      const { DominosCostTestingService } = await import('./services/dominos-cost-testing');
      const testingService = new DominosCostTestingService();
      const results = await testingService.runComprehensiveTests();
      
      res.json({
        timestamp: new Date().toISOString(),
        testSuite: 'Dominos Pizza ERP Cost Analysis',
        totalTests: results.length,
        passedTests: results.filter(r => r.status === 'PASSED').length,
        failedTests: results.filter(r => r.status === 'FAILED').length,
        warningTests: results.filter(r => r.status === 'WARNING').length,
        results: results
      });
    } catch (error) {
      console.error('Error running Dominos cost tests:', error);
      res.status(500).json({ error: 'Failed to run cost analysis tests' });
    }
  });

  // Manual E2E Testing API endpoint
  app.post("/api/manual-e2e-testing/run", async (req: Request, res: Response) => {
    try {
      console.log('Starting Manual E2E Testing workflow...');
      const results = await manualE2ETestingService.runCompleteBusinessWorkflow();
      res.json(results);
    } catch (error) {
      console.error('Manual E2E Testing error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message,
        message: 'Failed to run manual E2E testing workflow'
      });
    }
  });

  // Comprehensive ERP Testing Routes
  app.post('/api/comprehensive-erp-testing/run', async (req, res) => {
    try {
      const { ComprehensiveERPTesting } = await import('./services/comprehensive-erp-testing.js');
      const erpTesting = new ComprehensiveERPTesting();
      const results = await erpTesting.runComprehensiveERPTesting();
      res.json(results);
    } catch (error) {
      console.error('Comprehensive ERP Testing failed:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message,
        details: 'Failed to execute comprehensive ERP testing'
      });
    }
  });

  // Single Company ERP Testing Routes
  app.post('/api/single-company-testing/run/:companyType', async (req, res) => {
    try {
      const { SingleCompanyERPTesting } = await import('./services/single-company-erp-testing.js');
      const singleCompanyTesting = new SingleCompanyERPTesting();
      const results = await singleCompanyTesting.testSingleCompany(req.params.companyType);
      res.json(results);
    } catch (error) {
      console.error('Single Company ERP Testing failed:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message,
        details: 'Failed to execute single company ERP testing'
      });
    }
  });
  
  // Import and register transport status routes
  const transportStatusRoutes = (await import("./routes/transportStatusRoutes.js")).default;
  app.use("/api/transport-status", transportStatusRoutes);
  
  // Import and register number range routes
  const numberRangeRoutes = (await import("./routes/numberRangeRoutes.js")).default;
  app.use("/api/number-ranges", numberRangeRoutes);
  
  // Import and register controlling routes
  const controllingRoutes = (await import("./routes/controllingRoutes.js")).default;
  app.use("/api/controlling", controllingRoutes);
  
  // Register missing API routes
  app.use(purchaseRequestRoutes);
  app.use(productionWorkOrderRoutes);
  app.use(controllingProfitCenterRoutes);
  
  // Register transaction API routes
  app.use("/api/transactions", transactionAPIRoutes);
  app.use("/api/master-data", transactionAPIRoutes);
  
  // Register enhanced sales order routes
  const salesOrderRoutes = (await import("./routes/sales/salesOrderRoutes.js")).default;
  app.use("/api/sales-orders", salesOrderRoutes);
  
  // Register enhanced finance invoice routes
  const invoiceRoutes = (await import("./routes/finance/invoiceRoutes.js")).default;
  app.use("/api/invoices", invoiceRoutes);
  
  // Register enhanced inventory stock movement routes
  const stockMovementRoutes = (await import("./routes/inventory/stockMovementRoutes.js")).default;
  app.use("/api/stock-movements", stockMovementRoutes);
  
  // Register comprehensive AR routes
  const arRoutes = (await import("./routes/finance/arRoutes.js")).default;
  const arReportingRoutes = (await import("./routes/finance/arReporting.js")).default;
  const arIntegrationRoutes = (await import("./routes/finance/arIntegration.js")).default;
  app.use("/api/ar", arRoutes);
  app.use("/api/ar/reports", arReportingRoutes);
  app.use("/api/ar/integration", arIntegrationRoutes);

  // Register comprehensive AP routes
  const apRoutes = (await import("./routes/finance/apRoutes.js")).default;
  app.use("/api/ap", apRoutes);

  // Register bank account management routes
  const bankAccountRoutes = (await import("./routes/finance/bankAccountRoutes.js")).default;
  app.use("/api/finance/bank-accounts", bankAccountRoutes);

  // Register bank integration routes for real banking
  const bankIntegrationRoutes = (await import("./routes/finance/bankIntegrationRoutes.js")).default;
  app.use("/api/finance/bank-integration", bankIntegrationRoutes);

  // AR CrossCheck Agent endpoint
  app.post("/api/ar/crosscheck-validation", async (req, res) => {
    try {
      const ARCrossCheckAgent = (await import("./agents/ARCrossCheckAgent.js")).default;
      const agent = new ARCrossCheckAgent();
      const validationReport = await agent.performComprehensiveARValidation();
      res.json(validationReport);
    } catch (error) {
      console.error("AR CrossCheck validation error:", error);
      res.status(500).json({ error: "Failed to perform AR validation" });
    }
  });
  
  // Register Agent Player routes
  app.use("/api/agent-players", agentPlayerRoutes);
  
  // Register Coach Agent routes
  app.use("/api/coach-agents", coachAgentRoutes);
  
  // Register Agent Status Monitoring routes
  app.use("/api/agent-status", agentStatusRoutes);
  
  // Register Chief Agent Permissions routes
  const chiefAgentPermissionsRoutes = (await import("./routes/chief-agent-permissions-routes")).default;
  app.use("/api/chief-agent-permissions", chiefAgentPermissionsRoutes);
  
  // Register Health Monitoring routes
  app.use("/api/health", healthMonitoringRoutes);
  
  // Register Chief Agent routes
  app.use("/api/chief-agent", chiefAgentRoutes);
  
  // Register Rookie Agent routes
  app.use("/api/rookie-agent", rookieAgentRoutes);
  
  // Register Designer Agent routes
  app.use("/api/designer-agent", designerAgentRoutes);
  
  // Register Jr. Assistant Integration routes
  app.use("/api/jr", jrIntegrationRoutes);
  
  // Register Jr. Domain Intelligence routes
  const jrDomainIntelligenceRoutes = (await import("./routes/jr-domain-intelligence")).default;
  app.use("/api/jr/domain", jrDomainIntelligenceRoutes);
  
  // Implement approval levels routes directly
  app.get("/api/master-data/approval-level", async (req: Request, res: Response) => {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS approval_levels (
          id SERIAL PRIMARY KEY,
          level INTEGER NOT NULL,
          name VARCHAR(255) NOT NULL,
          description TEXT,
          value_limit NUMERIC NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `);
      
      const result = await pool.query(`
        SELECT id, level, name, description, value_limit, created_at, updated_at
        FROM approval_levels
        ORDER BY level ASC
      `);
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching approval levels:", error);
      return res.status(500).json({ message: "Failed to fetch approval levels" });
    }
  });
  
  app.post("/api/master-data/approval-level", async (req: Request, res: Response) => {
    try {
      const { level, name, description, value_limit } = req.body;
      
      if (!level || !name) {
        return res.status(400).json({ message: "Level and name are required fields" });
      }
      
      const result = await pool.query(`
        INSERT INTO approval_levels (level, name, description, value_limit)
        VALUES ($1, $2, $3, $4)
        RETURNING id, level, name, description, value_limit, created_at, updated_at
      `, [level, name, description || null, value_limit || null]);
      
      return res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error("Error creating approval level:", error);
      return res.status(500).json({ message: "Failed to create approval level" });
    }
  });

  // Company Code routes - adding directly to ensure availability
  app.get("/api/master-data/company-code", async (req: Request, res: Response) => {
    try {
      // Execute SQL query to get company codes without parameters to avoid syntax errors
      const result = await pool.query("SELECT * FROM company_codes");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching company codes:", error);
      return res.status(500).json({ message: "Failed to fetch company codes" });
    }
  });

  // Individual company code route
  app.get("/api/master-data/company-code/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid ID format" });
      }
      const result = await pool.query("SELECT * FROM company_codes WHERE id = $1", [id]);
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Company code not found" });
      }
      return res.status(200).json(result.rows[0]);
    } catch (error) {
      console.error("Error fetching company code:", error);
      return res.status(500).json({ message: "Failed to fetch company code" });
    }
  });

  app.put("/api/master-data/company-code/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { code, name, currency, country, city, language, isActive, active } = req.body;
      
      // Handle both isActive (frontend) and active (backend) field names
      const activeStatus = isActive !== undefined ? isActive : active;
      
      const result = await pool.query(`
        UPDATE company_codes 
        SET code = $1, name = $2, currency = $3, country = $4, 
            city = $5, language = $6, active = $7, updated_at = NOW()
        WHERE id = $8
        RETURNING *
      `, [code, name, currency, country, city, language, activeStatus, id]);
      
      if (result.rows.length === 0) {
        return res.status(404).json({ message: "Company code not found" });
      }
      
      return res.status(200).json(result.rows[0]);
    } catch (error) {
      console.error("Error updating company code:", error);
      return res.status(500).json({ message: "Failed to update company code" });
    }
  });

  app.post("/api/master-data/company-code", async (req: Request, res: Response) => {
    try {
      const { code, name, currency, country, city, language, isActive } = req.body;
      
      errorLogger.info('CompanyCode', 'Creating new company code', { code, name, country, currency });
      
      if (!code || !name || !currency || !country) {
        errorLogger.warn('CompanyCode', 'Missing required fields for company code creation', { received: req.body });
        return res.status(400).json({ message: "Code, name, currency, and country are required fields" });
      }
      
      // Check if company code already exists
      const existingResult = await pool.query("SELECT id FROM company_codes WHERE code = $1", [code]);
      if (existingResult.rows.length > 0) {
        errorLogger.warn('CompanyCode', 'Attempted to create duplicate company code', { code });
        return res.status(409).json({ message: "Company code already exists" });
      }
      
      // Use Zero-Error Data Handler to ensure data is saved successfully
      const saveResult = await ZeroErrorDataHandler.saveWithAutoFix('company_codes', {
        code,
        name,
        city: city || null,
        country,
        currency,
        language: language || null,
        active: isActive !== false
      });

      if (saveResult.success) {
        errorLogger.info('CompanyCode', 'Company code created successfully', { 
          id: saveResult.data.id, 
          code: saveResult.data.code,
          name: saveResult.data.name,
          fixesApplied: saveResult.fixesApplied
        });
        
        return res.status(201).json(saveResult.data);
      } else {
        errorLogger.error('CompanyCode', 'Failed to create company code after auto-fixes', new Error(saveResult.message), { 
          requestBody: req.body,
          fixesApplied: saveResult.fixesApplied,
          originalError: saveResult.originalError
        });
        
        return res.status(500).json({ 
          message: "Failed to create company code", 
          error: saveResult.message,
          fixesAttempted: saveResult.fixesApplied
        });
      }
    } catch (error: any) {
      errorLogger.error('CompanyCode', 'Unexpected error in company code creation', error, { requestBody: req.body });
      
      return res.status(500).json({ 
        message: "Unexpected error occurred", 
        error: error.message 
      });
    }
  });

  // Zero-Error Data Integrity System Endpoints
  app.get("/api/system/health", async (req: Request, res: Response) => {
    try {
      const health = await ZeroErrorDataHandler.getSystemHealth();
      return res.json(health);
    } catch (error: any) {
      errorLogger.error('SystemHealth', 'Health check failed', error);
      return res.status(500).json({ 
        status: 'critical', 
        message: 'Health check failed',
        error: error.message 
      });
    }
  });

  app.post("/api/system/validate-data", async (req: Request, res: Response) => {
    try {
      const { tableName, data } = req.body;
      
      if (!tableName || !data) {
        return res.status(400).json({ 
          message: "tableName and data are required" 
        });
      }

      const result = await ZeroErrorDataHandler.saveWithAutoFix(tableName, data);
      return res.json(result);
    } catch (error: any) {
      errorLogger.error('SystemValidation', 'Data validation failed', error, { 
        requestBody: req.body 
      });
      return res.status(500).json({ 
        message: "Validation failed", 
        error: error.message 
      });
    }
  });
  
  // Add plant routes directly here for compatibility
  app.get("/api/master-data/plant", async (req: Request, res: Response) => {
    try {
      const result = await pool.query("SELECT * FROM plants");
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching plants:", error);
      return res.status(500).json({ message: "Failed to fetch plants" });
    }
  });
  // User routes
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json({ id: user.id, username: user.username, name: user.name });
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      res.json({ id: user.id, username: user.username, name: user.name });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Dashboard routes
  app.get("/api/dashboard/stats", async (req: Request, res: Response) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get("/api/dashboard/sales-chart", async (req: Request, res: Response) => {
    try {
      // Generate sample data for the timeframe
      const timeframe = req.query.timeframe || "day";
      let salesData;
      
      if (timeframe === "day") {
        salesData = [
          { date: "8AM", revenue: 1200, orders: 8 },
          { date: "10AM", revenue: 1800, orders: 12 },
          { date: "12PM", revenue: 2400, orders: 18 },
          { date: "2PM", revenue: 1900, orders: 15 },
          { date: "4PM", revenue: 2800, orders: 20 },
          { date: "6PM", revenue: 3200, orders: 25 },
          { date: "8PM", revenue: 2700, orders: 22 }
        ];
      } else if (timeframe === "week") {
        salesData = [
          { date: "Mon", revenue: 5200, orders: 42 },
          { date: "Tue", revenue: 4800, orders: 38 },
          { date: "Wed", revenue: 6400, orders: 51 },
          { date: "Thu", revenue: 5900, orders: 47 },
          { date: "Fri", revenue: 7200, orders: 58 },
          { date: "Sat", revenue: 8500, orders: 68 },
          { date: "Sun", revenue: 6900, orders: 55 }
        ];
      } else if (timeframe === "month") {
        salesData = [
          { date: "Week 1", revenue: 32500, orders: 260 },
          { date: "Week 2", revenue: 38700, orders: 310 },
          { date: "Week 3", revenue: 35600, orders: 285 },
          { date: "Week 4", revenue: 42300, orders: 338 }
        ];
      } else {
        salesData = [
          { date: "Jan", revenue: 152000, orders: 1216 },
          { date: "Feb", revenue: 142800, orders: 1142 },
          { date: "Mar", revenue: 163400, orders: 1307 },
          { date: "Apr", revenue: 157900, orders: 1263 },
          { date: "May", revenue: 172200, orders: 1378 },
          { date: "Jun", revenue: 185500, orders: 1484 },
          { date: "Jul", revenue: 176900, orders: 1415 },
          { date: "Aug", revenue: 182300, orders: 1458 },
          { date: "Sep", revenue: 178600, orders: 1429 },
          { date: "Oct", revenue: 195400, orders: 1563 },
          { date: "Nov", revenue: 210300, orders: 1682 },
          { date: "Dec", revenue: 231500, orders: 1852 }
        ];
      }
      
      res.json(salesData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales chart data" });
    }
  });

  app.get("/api/dashboard/revenue-by-category", async (req: Request, res: Response) => {
    try {
      const revenueData = [
        { name: "Electronics", value: 35000 },
        { name: "Clothing", value: 24000 },
        { name: "Home & Kitchen", value: 18500 },
        { name: "Beauty", value: 12000 },
        { name: "Books", value: 9500 }
      ];
      
      res.json(revenueData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch revenue data" });
    }
  });

  // Customer routes
  app.get("/api/customers", async (req: Request, res: Response) => {
    try {
      const customers = await storage.getCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.get("/api/customers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  app.post("/api/customers", async (req: Request, res: Response) => {
    try {
      const customerData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer({
        ...customerData,
        userId: 1 // Default user ID
      });
      
      res.status(201).json(customer);
    } catch (error) {
      res.status(400).json({ message: "Invalid customer data" });
    }
  });

  app.put("/api/customers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const customerData = insertCustomerSchema.partial().parse(req.body);
      
      const updatedCustomer = await storage.updateCustomer(id, customerData);
      res.json(updatedCustomer);
    } catch (error) {
      res.status(400).json({ message: "Invalid customer data" });
    }
  });

  app.delete("/api/customers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCustomer(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Category routes
  app.get("/api/categories", async (req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const category = await storage.getCategory(id);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  app.post("/api/categories", async (req: Request, res: Response) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory({
        ...categoryData,
        userId: 1 // Default user ID
      });
      
      res.status(201).json(category);
    } catch (error) {
      res.status(400).json({ message: "Invalid category data" });
    }
  });

  app.put("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const categoryData = insertCategorySchema.partial().parse(req.body);
      
      const updatedCategory = await storage.updateCategory(id, categoryData);
      res.json(updatedCategory);
    } catch (error) {
      res.status(400).json({ message: "Invalid category data" });
    }
  });

  app.delete("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCategory(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // Product routes
  app.get("/api/products", async (req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", async (req: Request, res: Response) => {
    try {
      const productData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct({
        ...productData,
        categoryId: parseInt(productData.categoryId.toString()),
        userId: 1 // Default user ID
      });
      
      res.status(201).json(product);
    } catch (error) {
      res.status(400).json({ message: "Invalid product data" });
    }
  });

  app.put("/api/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const productData = insertProductSchema.partial().parse(req.body);
      
      // Convert categoryId to number if provided
      const dataToUpdate = productData.categoryId 
        ? { ...productData, categoryId: parseInt(productData.categoryId.toString()) }
        : productData;
      
      const updatedProduct = await storage.updateProduct(id, dataToUpdate);
      res.json(updatedProduct);
    } catch (error) {
      res.status(400).json({ message: "Invalid product data" });
    }
  });

  app.delete("/api/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteProduct(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  app.get("/api/products/top-selling", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit.toString()) : 5;
      const topProducts = await storage.getTopSellingProducts(limit);
      res.json(topProducts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch top selling products" });
    }
  });

  // Order routes
  app.get("/api/orders", async (req: Request, res: Response) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/recent", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit.toString()) : 5;
      const orders = await storage.getRecentOrders(limit);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent orders" });
    }
  });

  app.get("/api/orders/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const order = await storage.getOrder(id);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.post("/api/orders", async (req: Request, res: Response) => {
    try {
      // Order data validation would typically be more complex
      const order = await storage.createOrder(req.body);
      res.status(201).json(order);
    } catch (error) {
      res.status(400).json({ message: "Invalid order data" });
    }
  });

  app.put("/api/orders/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const order = await storage.updateOrder(id, req.body);
      res.json(order);
    } catch (error) {
      res.status(400).json({ message: "Invalid order data" });
    }
  });

  app.delete("/api/orders/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteOrder(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete order" });
    }
  });

  // Invoice routes
  app.get("/api/invoices", async (req: Request, res: Response) => {
    try {
      const invoices = await storage.getInvoices();
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Expense routes
  app.get("/api/expenses", async (req: Request, res: Response) => {
    try {
      const expenses = await storage.getExpenses();
      res.json(expenses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  app.post("/api/expenses", async (req: Request, res: Response) => {
    try {
      const expenseData = insertExpenseSchema.parse(req.body);
      const expense = await storage.createExpense({
        ...expenseData,
        date: new Date(expenseData.date),
        userId: 1 // Default user ID
      });
      
      res.status(201).json(expense);
    } catch (error) {
      res.status(400).json({ message: "Invalid expense data" });
    }
  });

  app.put("/api/expenses/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const expenseData = insertExpenseSchema.partial().parse(req.body);
      
      // Convert date to Date object if provided
      const dataToUpdate = expenseData.date 
        ? { ...expenseData, date: new Date(expenseData.date) }
        : expenseData;
      
      const updatedExpense = await storage.updateExpense(id, dataToUpdate);
      res.json(updatedExpense);
    } catch (error) {
      res.status(400).json({ message: "Invalid expense data" });
    }
  });

  app.delete("/api/expenses/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteExpense(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete expense" });
    }
  });

  // Inventory management routes
  app.get("/api/inventory/low-stock", async (req: Request, res: Response) => {
    try {
      const products = await storage.getLowStockProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch low stock products" });
    }
  });

  app.post("/api/inventory/adjust-stock", async (req: Request, res: Response) => {
    try {
      const { productId, quantity, type, reason } = req.body;
      
      const movement = await storage.adjustStock({
        productId: parseInt(productId),
        quantity: parseInt(quantity),
        type,
        reason,
        userId: 1, // Default user ID
        date: new Date()
      });
      
      res.status(201).json(movement);
    } catch (error) {
      res.status(400).json({ message: "Invalid stock adjustment data" });
    }
  });

  // Module-specific dashboard stats
  app.get("/api/sales/stats", async (req: Request, res: Response) => {
    try {
      const stats = await storage.getSalesStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales stats" });
    }
  });

  app.get("/api/inventory/stats", async (req: Request, res: Response) => {
    try {
      const stats = await storage.getInventoryStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory stats" });
    }
  });

  app.get("/api/finance/stats", async (req: Request, res: Response) => {
    try {
      const stats = await storage.getFinanceStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch finance stats" });
    }
  });

  // Additional data for module dashboards
  app.get("/api/sales/trends", async (req: Request, res: Response) => {
    try {
      const timeframe = req.query.timeframe || "monthly";
      
      // Generate sample data for the sales trends
      const monthlySales = [
        { month: "Jan", value: 45000 },
        { month: "Feb", value: 52000 },
        { month: "Mar", value: 48000 },
        { month: "Apr", value: 61000 },
        { month: "May", value: 55000 },
        { month: "Jun", value: 67000 }
      ];
      
      const categoryTrends = [
        { month: "Jan", Electronics: 25000, Clothing: 12000, "Home & Kitchen": 8000 },
        { month: "Feb", Electronics: 30000, Clothing: 14000, "Home & Kitchen": 8000 },
        { month: "Mar", Electronics: 27000, Clothing: 13000, "Home & Kitchen": 8000 },
        { month: "Apr", Electronics: 35000, Clothing: 16000, "Home & Kitchen": 10000 },
        { month: "May", Electronics: 31000, Clothing: 15000, "Home & Kitchen": 9000 },
        { month: "Jun", Electronics: 38000, Clothing: 18000, "Home & Kitchen": 11000 }
      ];
      
      const categories = ["Electronics", "Clothing", "Home & Kitchen"];
      
      res.json({
        monthlySales,
        categoryTrends,
        categories
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales trends" });
    }
  });

  app.get("/api/inventory/distribution", async (req: Request, res: Response) => {
    try {
      const distribution = [
        { name: "Electronics", value: 45 },
        { name: "Clothing", value: 25 },
        { name: "Home & Kitchen", value: 15 },
        { name: "Beauty", value: 10 },
        { name: "Books", value: 5 }
      ];
      
      res.json(distribution);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory distribution" });
    }
  });

  app.get("/api/inventory/product-movement", async (req: Request, res: Response) => {
    try {
      const movement = [
        { name: "Jan", incoming: 120, outgoing: 85 },
        { name: "Feb", incoming: 140, outgoing: 95 },
        { name: "Mar", incoming: 130, outgoing: 110 },
        { name: "Apr", incoming: 170, outgoing: 145 },
        { name: "May", incoming: 150, outgoing: 130 },
        { name: "Jun", incoming: 180, outgoing: 155 }
      ];
      
      res.json(movement);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product movement data" });
    }
  });

  app.get("/api/inventory/dashboard-stats", async (req: Request, res: Response) => {
    try {
      const stats = await storage.getInventoryStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory dashboard stats" });
    }
  });

  app.get("/api/finance/overview", async (req: Request, res: Response) => {
    try {
      const timeframe = req.query.timeframe || "last30";
      
      // Sample finance overview data
      const financeData = {
        revenue: {
          value: 52489.23,
          percentage: 8.2
        },
        expenses: {
          value: 18249.87,
          percentage: 3.5
        },
        profit: {
          value: 34239.36,
          percentage: 12.5
        },
        chart: [
          { date: "Jan", revenue: 45000, expenses: 16000, profit: 29000 },
          { date: "Feb", revenue: 48000, expenses: 17500, profit: 30500 },
          { date: "Mar", revenue: 52000, expenses: 18000, profit: 34000 },
          { date: "Apr", revenue: 49000, expenses: 18500, profit: 30500 },
          { date: "May", revenue: 53000, expenses: 19000, profit: 34000 },
          { date: "Jun", revenue: 58000, expenses: 19500, profit: 38500 }
        ]
      };
      
      res.json(financeData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch finance overview data" });
    }
  });

  app.get("/api/finance/expense-breakdown", async (req: Request, res: Response) => {
    try {
      const breakdown = [
        { name: "Utilities", value: 1200 },
        { name: "Rent", value: 3500 },
        { name: "Salaries", value: 8500 },
        { name: "Inventory", value: 5200 },
        { name: "Marketing", value: 1800 },
        { name: "Other", value: 1300 }
      ];
      
      res.json(breakdown);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expense breakdown data" });
    }
  });

  app.get("/api/finance/upcoming-expenses", async (req: Request, res: Response) => {
    try {
      const upcoming = [
        { id: 1, description: "Quarterly Rent Payment", category: "Rent", dueDate: "2023-07-15", amount: 10500, status: "Pending" },
        { id: 2, description: "Utility Bills", category: "Utilities", dueDate: "2023-07-20", amount: 1250, status: "Pending" },
        { id: 3, description: "Employee Salaries", category: "Salaries", dueDate: "2023-07-31", amount: 8500, status: "Scheduled" },
        { id: 4, description: "Marketing Campaign", category: "Marketing", dueDate: "2023-08-05", amount: 3500, status: "Pending" },
        { id: 5, description: "Inventory Restock", category: "Inventory", dueDate: "2023-08-10", amount: 5800, status: "Pending" }
      ];
      
      res.json(upcoming);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch upcoming expenses" });
    }
  });

  app.get("/api/finance/trends", async (req: Request, res: Response) => {
    try {
      const timeframe = req.query.timeframe || "monthly";
      
      // Sample revenue vs expenses data
      const revenueVsExpenses = [
        { period: "Jan", revenue: 45000, expenses: 16000, profit: 29000 },
        { period: "Feb", revenue: 48000, expenses: 17500, profit: 30500 },
        { period: "Mar", revenue: 52000, expenses: 18000, profit: 34000 },
        { period: "Apr", revenue: 49000, expenses: 18500, profit: 30500 },
        { period: "May", revenue: 53000, expenses: 19000, profit: 34000 },
        { period: "Jun", revenue: 58000, expenses: 19500, profit: 38500 }
      ];
      
      // Sample monthly revenue data
      const monthlyRevenue = [
        { month: "Jan", value: 45000 },
        { month: "Feb", value: 48000 },
        { month: "Mar", value: 52000 },
        { month: "Apr", value: 49000 },
        { month: "May", value: 53000 },
        { month: "Jun", value: 58000 }
      ];
      
      res.json({
        revenueVsExpenses,
        monthlyRevenue
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch finance trends" });
    }
  });

  app.get("/api/activities/recent", async (req: Request, res: Response) => {
    try {
      const activities = [
        { 
          id: 1, 
          type: "order", 
          message: "New order received from Jane Doe", 
          timeAgo: "2 minutes ago",
          user: "Jane Doe",
          highlight: "New order"
        },
        { 
          id: 2, 
          type: "payment", 
          message: "Payment received for order #ORD-5420", 
          timeAgo: "15 minutes ago",
          orderNumber: "ORD-5420",
          highlight: "Payment received"
        },
        { 
          id: 3, 
          type: "inventory", 
          message: "Inventory alert: Wireless Earbuds stock is below threshold", 
          timeAgo: "38 minutes ago",
          product: "Wireless Earbuds",
          highlight: "Inventory alert" 
        },
        { 
          id: 4, 
          type: "customer", 
          message: "Robert Johnson updated customer information", 
          timeAgo: "1 hour ago",
          user: "Robert Johnson" 
        },
        { 
          id: 5, 
          type: "product", 
          message: "Emma Brown added 3 new products", 
          timeAgo: "2 hours ago",
          user: "Emma Brown",
          count: 3
        }
      ];
      
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent activities" });
    }
  });
  
  // Financial Master Data Routes
  app.get("/api/master-data/fiscal-year-variants", async (req: Request, res: Response) => {
    try {
      const variants = await db.select().from(fiscalYearVariants);
      res.json(variants);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fiscal year variants" });
    }
  });

  app.post("/api/master-data/fiscal-year-variants", async (req: Request, res: Response) => {
    try {
      const [variant] = await db.insert(fiscalYearVariants).values(req.body).returning();
      res.status(201).json(variant);
    } catch (error) {
      res.status(500).json({ message: "Failed to create fiscal year variant" });
    }
  });

  app.patch("/api/master-data/fiscal-year-variants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const [variant] = await db.update(fiscalYearVariants).set(req.body).where(eq(fiscalYearVariants.id, id)).returning();
      res.json(variant);
    } catch (error) {
      res.status(500).json({ message: "Failed to update fiscal year variant" });
    }
  });

  app.delete("/api/master-data/fiscal-year-variants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await db.delete(fiscalYearVariants).where(eq(fiscalYearVariants.id, id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete fiscal year variant" });
    }
  });

  app.get("/api/master-data/gl-accounts", async (req: Request, res: Response) => {
    try {
      const accounts = await db.select().from(glAccounts);
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch GL accounts" });
    }
  });

  app.post("/api/master-data/gl-accounts", async (req: Request, res: Response) => {
    try {
      const [account] = await db.insert(glAccounts).values(req.body).returning();
      res.status(201).json(account);
    } catch (error) {
      res.status(500).json({ message: "Failed to create GL account" });
    }
  });

  app.patch("/api/master-data/gl-accounts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const [account] = await db.update(glAccounts).set(req.body).where(eq(glAccounts.id, id)).returning();
      res.json(account);
    } catch (error) {
      res.status(500).json({ message: "Failed to update GL account" });
    }
  });

  app.delete("/api/master-data/gl-accounts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await db.delete(glAccounts).where(eq(glAccounts.id, id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete GL account" });
    }
  });

  // Master Data Routes are already initialized at the top of this function
  
  // Add error log routes
  app.use("/api/error-log", errorLogRoutes);
  
  // Add change log routes
  app.use("/api/change-log", changeLogRoutes);
  
  // Add comprehensive issues routes
  app.use("/api/issues", issuesRoutes);

  // Integration API endpoints for MM-FI Integration Enhancement
  app.get("/api/integration/mm-fi/mappings", async (req: Request, res: Response) => {
    try {
      const mappings = [
        {
          id: 1,
          mapping_name: "Material Posting to GL",
          source_module: "MM",
          target_module: "FI",
          source_transaction: "MIGO",
          target_transaction: "FB01",
          mapping_rules: [],
          is_active: true,
          auto_posting: true,
          validation_required: true,
          approval_required: false,
          created_by: 1,
          created_at: new Date(),
          updated_at: new Date()
        }
      ];
      res.json(mappings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch MM-FI mappings" });
    }
  });

  app.get("/api/integration/mm-fi/transactions", async (req: Request, res: Response) => {
    try {
      const transactions = [
        {
          id: 1,
          transaction_id: "TXN001",
          mapping_id: 1,
          source_document_id: 1001,
          target_document_id: 2001,
          source_data: { material: "MAT001", quantity: 100 },
          target_data: { account: "400000", amount: 1000 },
          status: "completed",
          error_message: null,
          retry_count: 0,
          max_retries: 3,
          processing_started_at: new Date(),
          processing_completed_at: new Date(),
          created_at: new Date(),
          updated_at: new Date()
        }
      ];
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch MM-FI transactions" });
    }
  });

  app.get("/api/integration/mm-fi/logs", async (req: Request, res: Response) => {
    try {
      const logs = [
        {
          id: 1,
          transaction_id: 1,
          log_level: "info",
          log_message: "Integration completed successfully",
          log_details: { duration: "2.5s", records_processed: 1 },
          timestamp: new Date()
        }
      ];
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch MM-FI logs" });
    }
  });

  // Integration API endpoints for SD-FI Integration Enhancement
  app.get("/api/integration/sd-fi/mappings", async (req: Request, res: Response) => {
    try {
      const mappings = [
        {
          id: 1,
          mapping_name: "Sales Order to Invoice",
          source_module: "SD",
          target_module: "FI",
          source_document_type: "Sales Order",
          target_document_type: "Customer Invoice",
          pricing_procedure: "RVAA01",
          revenue_recognition_rule: "immediate",
          tax_calculation_method: "standard",
          is_active: true,
          real_time_posting: true,
          automatic_clearing: false,
          billing_integration: true,
          credit_management_check: true,
          created_by: 1,
          created_at: new Date(),
          updated_at: new Date()
        }
      ];
      res.json(mappings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch SD-FI mappings" });
    }
  });

  app.get("/api/integration/sd-fi/transactions", async (req: Request, res: Response) => {
    try {
      const transactions = [
        {
          id: 1,
          transaction_id: "SDFI001",
          mapping_id: 1,
          sales_document_id: 3001,
          billing_document_id: 4001,
          source_data: { order_value: 5000, customer: "CUST001" },
          target_data: { invoice_number: "INV001", amount: 5000 },
          status: "posted",
          revenue_recognized: true,
          credit_check_passed: true,
          billing_status: "completed",
          created_at: new Date(),
          updated_at: new Date()
        }
      ];
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch SD-FI transactions" });
    }
  });

  app.get("/api/integration/sd-fi/revenue-recognition", async (req: Request, res: Response) => {
    try {
      const revenueRecognition = [
        {
          id: 1,
          transaction_id: 1,
          recognition_rule: "immediate",
          total_revenue: 5000,
          recognized_amount: 5000,
          deferred_amount: 0,
          recognition_date: new Date(),
          accounting_period: "2025-06",
          created_at: new Date()
        }
      ];
      res.json(revenueRecognition);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch revenue recognition data" });
    }
  });

  app.get("/api/integration/sd-fi/credit-management", async (req: Request, res: Response) => {
    try {
      const creditManagement = [
        {
          id: 1,
          customer_id: "CUST001",
          credit_limit: 50000,
          current_exposure: 15000,
          available_credit: 35000,
          credit_status: "approved",
          last_check_date: new Date(),
          risk_category: "low"
        }
      ];
      res.json(creditManagement);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch credit management data" });
    }
  });

  app.get("/api/integration/sd-fi/pricing-components", async (req: Request, res: Response) => {
    try {
      const pricingComponents = [
        {
          id: 1,
          transaction_id: 1,
          component_type: "base_price",
          component_name: "Net Price",
          calculation_method: "fixed",
          rate_value: 100,
          amount: 5000,
          currency_code: "USD",
          account_assignment: "400000",
          created_at: new Date()
        }
      ];
      res.json(pricingComponents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch pricing components" });
    }
  });

  // Shop Floor Control API endpoints
  app.get("/api/shop-floor/work-orders", async (req: Request, res: Response) => {
    try {
      const workOrders = [
        {
          id: 1,
          order_number: "WO001",
          product_id: 1,
          planned_quantity: 100,
          actual_quantity: 95,
          status: "in_progress",
          start_date: new Date(),
          planned_end_date: new Date(),
          actual_end_date: null,
          created_at: new Date(),
          updated_at: new Date()
        }
      ];
      res.json(workOrders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch work orders" });
    }
  });

  app.get("/api/shop-floor/operations", async (req: Request, res: Response) => {
    try {
      const operations = [
        {
          id: 1,
          work_order_id: 1,
          operation_number: "010",
          work_center: "WC001",
          description: "Assembly Operation",
          planned_duration: 120,
          actual_duration: 110,
          status: "completed",
          created_at: new Date()
        }
      ];
      res.json(operations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch operations" });
    }
  });

  app.get("/api/shop-floor/confirmations", async (req: Request, res: Response) => {
    try {
      const confirmations = [
        {
          id: 1,
          operation_id: 1,
          confirmed_quantity: 95,
          actual_time: 110,
          confirmation_type: "final",
          confirmed_by: 1,
          confirmation_date: new Date(),
          created_at: new Date()
        }
      ];
      res.json(confirmations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch confirmations" });
    }
  });

  // Authorization Management API endpoints
  app.get("/api/authorization/roles", async (req: Request, res: Response) => {
    try {
      const roles = [
        {
          id: 1,
          role_name: "Administrator",
          description: "Full system access",
          is_active: true,
          created_at: new Date(),
          updated_at: new Date()
        }
      ];
      res.json(roles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch roles" });
    }
  });

  app.get("/api/authorization/permissions", async (req: Request, res: Response) => {
    try {
      const permissions = [
        {
          id: 1,
          permission_name: "CREATE_TRANSACTION",
          module_name: "Finance",
          description: "Create financial transactions",
          is_active: true,
          created_at: new Date()
        }
      ];
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch permissions" });
    }
  });

  app.get("/api/authorization/user-assignments", async (req: Request, res: Response) => {
    try {
      const assignments = [
        {
          id: 1,
          user_id: 1,
          role_id: 1,
          assigned_by: 1,
          assignment_date: new Date(),
          expiry_date: null,
          is_active: true
        }
      ];
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user assignments" });
    }
  });

  // Management Reporting API endpoints
  app.get("/api/reporting/kpis", async (req: Request, res: Response) => {
    try {
      const kpis = [
        {
          id: 1,
          kpi_name: "Revenue Growth",
          current_value: 15.5,
          target_value: 20.0,
          unit: "percentage",
          category: "Financial",
          last_updated: new Date()
        }
      ];
      res.json(kpis);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch KPIs" });
    }
  });

  app.get("/api/reporting/dashboards", async (req: Request, res: Response) => {
    try {
      const dashboards = [
        {
          id: 1,
          dashboard_name: "Executive Summary",
          description: "High-level business metrics",
          owner_id: 1,
          is_public: false,
          created_at: new Date(),
          updated_at: new Date()
        }
      ];
      res.json(dashboards);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboards" });
    }
  });

  app.get("/api/reporting/reports", async (req: Request, res: Response) => {
    try {
      const reports = [
        {
          id: 1,
          report_name: "Financial Summary",
          report_type: "financial",
          schedule: "monthly",
          last_run: new Date(),
          status: "completed",
          created_at: new Date()
        }
      ];
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });

  // Additional Shop Floor Control API endpoints
  app.get("/api/shop-floor-operations", async (req: Request, res: Response) => {
    try {
      const operations = [
        {
          id: 1,
          operation_number: "010",
          work_center: "WC001",
          description: "Assembly Operation",
          status: "active",
          created_at: new Date()
        }
      ];
      res.json(operations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch shop floor operations" });
    }
  });

  app.post("/api/shop-floor-operations", async (req: Request, res: Response) => {
    try {
      const { 
        operation_number, 
        production_order_id, 
        work_center_id, 
        operation_description,
        planned_start_date,
        planned_end_date,
        planned_duration,
        planned_quantity,
        setup_time,
        processing_time,
        teardown_time,
        status,
        notes
      } = req.body;

      // Validate required fields
      const requiredFields = [];
      if (!operation_number) requiredFields.push('Operation Number');
      if (!production_order_id) requiredFields.push('Production Order ID');
      if (!work_center_id) requiredFields.push('Work Center');
      if (!operation_description) requiredFields.push('Operation Description');
      if (!planned_quantity || planned_quantity <= 0) requiredFields.push('Planned Quantity (must be greater than 0)');

      if (requiredFields.length > 0) {
        return res.status(400).json({ 
          message: `Missing required fields: ${requiredFields.join(', ')}`,
          requiredFields: requiredFields
        });
      }

      // Create new operation with auto-generated ID
      const newOperation = {
        id: Date.now(), // Simple ID generation for demo
        operation_number,
        production_order_id: Number(production_order_id),
        work_center_id: Number(work_center_id),
        operation_description,
        planned_start_date: planned_start_date ? new Date(planned_start_date) : new Date(),
        planned_end_date: planned_end_date ? new Date(planned_end_date) : new Date(),
        planned_duration: Number(planned_duration) || 0,
        planned_quantity: Number(planned_quantity),
        completed_quantity: 0,
        rejected_quantity: 0,
        setup_time: Number(setup_time) || 0,
        processing_time: Number(processing_time) || 0,
        teardown_time: Number(teardown_time) || 0,
        status: status || 'planned',
        quality_check_status: 'pending',
        yield_percentage: 0,
        efficiency_percentage: 0,
        notes: notes || '',
        created_at: new Date(),
        updated_at: new Date(),
        active: true
      };

      res.status(201).json(newOperation);
    } catch (error) {
      console.error('Error creating shop floor operation:', error);
      res.status(500).json({ 
        message: "Failed to create shop floor operation",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/quality-checks", async (req: Request, res: Response) => {
    try {
      const qualityChecks = [
        {
          id: 1,
          check_name: "Dimension Check",
          status: "passed",
          inspector: "Inspector A",
          checked_at: new Date()
        }
      ];
      res.json(qualityChecks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quality checks" });
    }
  });

  app.get("/api/resource-allocations", async (req: Request, res: Response) => {
    try {
      const allocations = [
        {
          id: 1,
          resource_type: "Machine",
          resource_name: "CNC-001",
          allocated_to: "WO001",
          allocation_date: new Date()
        }
      ];
      res.json(allocations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch resource allocations" });
    }
  });

  app.get("/api/work-centers", async (req: Request, res: Response) => {
    try {
      const workCenters = [
        {
          id: 1,
          work_center_code: "WC001",
          description: "Assembly Line 1",
          capacity: 100,
          status: "active"
        }
      ];
      res.json(workCenters);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch work centers" });
    }
  });

  app.get("/api/production-orders", async (req: Request, res: Response) => {
    try {
      const productionOrders = [
        {
          id: 1,
          order_number: "PO001",
          product: "Product A",
          quantity: 100,
          status: "in_progress",
          start_date: new Date()
        }
      ];
      res.json(productionOrders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch production orders" });
    }
  });

  // Finance API Routes
  app.get("/api/finance/accounts-receivable", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          ar.id,
          ar.invoice_number,
          ar.customer_id,
          c.name as customer_name,
          ar.invoice_date,
          ar.due_date,
          ar.amount,
          ar.tax_amount,
          ar.net_amount,
          ar.status,
          ar.company_code_id,
          cc.name as company_name,
          CASE 
            WHEN ar.status = 'paid' THEN 0
            ELSE (CURRENT_DATE - ar.due_date)
          END as days_overdue,
          CASE 
            WHEN ar.status = 'paid' THEN ar.amount
            ELSE 0
          END as paid_amount,
          CASE 
            WHEN ar.status = 'paid' THEN 0
            ELSE ar.amount
          END as outstanding_amount
        FROM accounts_receivable ar
        LEFT JOIN customers c ON ar.customer_id = c.id
        LEFT JOIN company_codes cc ON ar.company_code_id = cc.id
        ORDER BY ar.invoice_date DESC
        LIMIT 50
      `);
      res.json(result.rows);
    } catch (error) {
      console.error("Error fetching accounts receivable:", error);
      res.status(500).json({ error: "Failed to fetch accounts receivable data" });
    }
  });

  // Invoice Details API - Fixed version
  app.get("/api/finance/accounts-receivable/:id/details", async (req: Request, res: Response) => {
    try {
      const invoiceId = req.params.id;
      
      // Get invoice details with proper field names
      const result = await pool.query(`
        SELECT 
          ar.id,
          ar.invoice_number,
          ar.customer_id,
          c.name as customer_name,
          c.email as customer_email,
          c.phone as customer_phone,
          ar.invoice_date,
          ar.due_date,
          ar.amount,
          ar.payment_amount,
          ar.status,
          ar.payment_terms,
          ar.notes,
          c.credit_limit,
          CASE 
            WHEN ar.due_date IS NOT NULL THEN (CURRENT_DATE - ar.due_date)
            ELSE 0
          END as days_overdue
        FROM accounts_receivable ar
        LEFT JOIN customers c ON ar.customer_id = c.id
        WHERE ar.id = $1
      `, [invoiceId]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Invoice not found" });
      }

      const invoice = result.rows[0];
      const amount = parseFloat(invoice.amount) || 0;
      const totalPaid = parseFloat(invoice.payment_amount) || 0;
      const outstandingAmount = Math.max(0, amount - totalPaid);
      const daysOverdue = Math.max(0, invoice.days_overdue || 0);
      
      // Determine aging bucket
      let agingBucket = 'Current';
      if (daysOverdue > 0 && daysOverdue <= 30) {
        agingBucket = '1-30 days';
      } else if (daysOverdue > 30 && daysOverdue <= 60) {
        agingBucket = '31-60 days';
      } else if (daysOverdue > 60 && daysOverdue <= 90) {
        agingBucket = '61-90 days';
      } else if (daysOverdue > 90) {
        agingBucket = '90+ days';
      }

      // Generate line items
      const lineItems = [
        {
          id: 1,
          description: 'Professional Services',
          quantity: 1,
          unit_price: amount * 0.6,
          line_amount: amount * 0.6
        },
        {
          id: 2,
          description: 'Materials & Supplies',
          quantity: 2,
          unit_price: amount * 0.2,
          line_amount: amount * 0.4
        }
      ];

      // Generate payment history
      const payments = [];
      if (totalPaid > 0) {
        payments.push({
          id: 1,
          payment_date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          payment_amount: totalPaid,
          payment_method: 'Bank Transfer',
          payment_reference: `PAY-${invoice.invoice_number}`,
          payment_status: 'confirmed'
        });
      }

      // Return structured response
      res.json({
        invoice: {
          ...invoice,
          outstanding_amount: outstandingAmount,
          total_paid: totalPaid,
          is_overdue: daysOverdue > 0 && invoice.status !== 'paid'
        },
        line_items: lineItems,
        payments: payments,
        aging_analysis: {
          days_overdue: daysOverdue,
          aging_bucket: agingBucket,
          is_overdue: daysOverdue > 0 && invoice.status !== 'paid'
        }
      });
    } catch (error) {
      console.error("Error fetching invoice details:", error);
      res.status(500).json({ error: "Failed to fetch invoice details", details: error.message });
    }
  });

  app.get("/api/finance/accounts-payable", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          ap.id,
          ap.invoice_number,
          ap.vendor_id,
          v.name as vendor_name,
          ap.invoice_date,
          ap.due_date,
          ap.amount,
          ap.tax_amount,
          ap.net_amount,
          ap.status,
          ap.company_code_id,
          cc.name as company_name
        FROM accounts_payable ap
        LEFT JOIN vendors v ON ap.vendor_id = v.id
        LEFT JOIN company_codes cc ON ap.company_code_id = cc.id
        ORDER BY ap.invoice_date DESC
        LIMIT 50
      `);
      res.json(result.rows);
    } catch (error) {
      console.error("Error fetching accounts payable:", error);
      res.status(500).json({ error: "Failed to fetch accounts payable data" });
    }
  });

  app.get("/api/finance/general-ledger", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          gl.id,
          gl.document_number,
          gl.gl_account_id,
          gla.account_number,
          gla.account_name,
          gl.amount,
          gl.debit_credit_indicator,
          gl.posting_date,
          gl.posting_status,
          gl.reference_document
        FROM gl_entries gl
        LEFT JOIN gl_accounts gla ON gl.gl_account_id = gla.id
        ORDER BY gl.posting_date DESC
        LIMIT 100
      `);
      res.json(result.rows);
    } catch (error) {
      console.error("Error fetching general ledger:", error);
      res.status(500).json({ error: "Failed to fetch general ledger data" });
    }
  });

  app.get("/api/finance/expenses", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          e.id,
          e.expense_number,
          e.description,
          e.amount,
          e.expense_date,
          e.category_id,
          ec.name as category_name,
          e.status,
          e.employee_id,
          emp.first_name || ' ' || emp.last_name as employee_name
        FROM expenses e
        LEFT JOIN expense_categories ec ON e.category_id = ec.id
        LEFT JOIN employees emp ON e.employee_id = emp.id
        ORDER BY e.expense_date DESC
        LIMIT 50
      `);
      res.json(result.rows);
    } catch (error) {
      console.error("Error fetching expenses:", error);
      res.status(500).json({ error: "Failed to fetch expenses data" });
    }
  });

  app.get("/api/finance/journal-entries", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          je.id,
          je.entry_number,
          je.description,
          je.posting_date,
          je.total_debit,
          je.total_credit,
          je.status,
          je.reference_document
        FROM journal_entries je
        ORDER BY je.posting_date DESC
        LIMIT 50
      `);
      res.json(result.rows);
    } catch (error) {
      console.error("Error fetching journal entries:", error);
      res.status(500).json({ error: "Failed to fetch journal entries data" });
    }
  });

  app.get("/api/finance/financial-reports", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          'Balance Sheet' as report_name,
          'Shows assets, liabilities, and equity' as description,
          'monthly' as frequency,
          CURRENT_DATE as last_generated
        UNION ALL
        SELECT 
          'Income Statement' as report_name,
          'Revenue and expense summary' as description,
          'monthly' as frequency,
          CURRENT_DATE - INTERVAL '5 days' as last_generated
        UNION ALL
        SELECT 
          'Cash Flow Statement' as report_name,
          'Cash inflows and outflows' as description,
          'monthly' as frequency,
          CURRENT_DATE - INTERVAL '2 days' as last_generated
      `);
      res.json(result.rows);
    } catch (error) {
      console.error("Error fetching financial reports:", error);
      res.status(500).json({ error: "Failed to fetch financial reports data" });
    }
  });

  // Management Reporting API Routes
  app.get("/api/management-reporting/kpi-metrics", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          'revenue_growth' as metric_name,
          15.2 as value,
          'percentage' as unit,
          'positive' as trend
        UNION ALL
        SELECT 
          'profit_margin' as metric_name,
          23.7 as value,
          'percentage' as unit,
          'positive' as trend
        UNION ALL
        SELECT 
          'customer_satisfaction' as metric_name,
          4.2 as value,
          'rating' as unit,
          'stable' as trend
      `);
      return res.json(result.rows);
    } catch (error) {
      console.error("Error fetching KPI metrics:", error);
      return res.status(500).json({ message: "Failed to fetch KPI metrics" });
    }
  });

  app.get("/api/management-reporting/reports", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          1 as id,
          'Monthly Financial Report' as name,
          'Financial summary for the current month' as description,
          'monthly' as frequency,
          CURRENT_DATE - INTERVAL '1 day' as last_generated
        UNION ALL
        SELECT 
          2 as id,
          'Sales Performance Report' as name,
          'Sales team performance analysis' as description,
          'weekly' as frequency,
          CURRENT_DATE - INTERVAL '3 days' as last_generated
      `);
      return res.json(result.rows);
    } catch (error) {
      console.error("Error fetching reports:", error);
      return res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.get("/api/management-reporting/alert-rules", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          1 as id,
          'Low Stock Alert' as name,
          'Inventory below minimum threshold' as description,
          true as is_active,
          'inventory_level < 10' as condition_text
        UNION ALL
        SELECT 
          2 as id,
          'High Value Transaction' as name,
          'Transaction exceeds approval limit' as description,
          true as is_active,
          'transaction_amount > 50000' as condition_text
      `);
      return res.json(result.rows);
    } catch (error) {
      console.error("Error fetching alert rules:", error);
      return res.status(500).json({ message: "Failed to fetch alert rules" });
    }
  });

  app.get("/api/management-reporting/widgets", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          'sales-overview' as widget_id,
          'Sales Overview' as title,
          'chart' as type,
          true as is_visible,
          1 as position_order
        UNION ALL
        SELECT 
          'inventory-status' as widget_id,
          'Inventory Status' as title,
          'table' as type,
          true as is_visible,
          2 as position_order
      `);
      return res.json(result.rows);
    } catch (error) {
      console.error("Error fetching widgets:", error);
      return res.status(500).json({ message: "Failed to fetch widgets" });
    }
  });

  app.get("/api/management-reporting/dashboards", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          1 as id,
          'Executive Dashboard' as name,
          'High-level business metrics' as description,
          true as is_default
        UNION ALL
        SELECT 
          2 as id,
          'Operations Dashboard' as name,
          'Operational performance metrics' as description,
          false as is_default
      `);
      return res.json(result.rows);
    } catch (error) {
      console.error("Error fetching dashboards:", error);
      return res.status(500).json({ message: "Failed to fetch dashboards" });
    }
  });

  // Balance Sheet API Routes
  app.get("/api/balance-sheet-reports", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          1 as id,
          'Current Assets' as account_category,
          'Cash and Cash Equivalents' as account_name,
          150000.00 as current_balance,
          140000.00 as previous_balance,
          CURRENT_DATE as as_of_date
        UNION ALL
        SELECT 
          2 as id,
          'Current Assets' as account_category,
          'Accounts Receivable' as account_name,
          85000.00 as current_balance,
          92000.00 as previous_balance,
          CURRENT_DATE as as_of_date
        UNION ALL
        SELECT 
          3 as id,
          'Current Liabilities' as account_category,
          'Accounts Payable' as account_name,
          65000.00 as current_balance,
          58000.00 as previous_balance,
          CURRENT_DATE as as_of_date
      `);
      return res.json(result.rows);
    } catch (error) {
      console.error("Error fetching balance sheet reports:", error);
      return res.status(500).json({ message: "Failed to fetch balance sheet reports" });
    }
  });

  app.get("/api/company-codes", async (req: Request, res: Response) => {
    try {
      const result = await pool.query("SELECT * FROM company_codes ORDER BY code");
      return res.json(result.rows);
    } catch (error) {
      console.error("Error fetching company codes:", error);
      return res.status(500).json({ message: "Failed to fetch company codes" });
    }
  });

  app.get("/api/balance-sheet-items", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT 
          1 as id,
          'ASSETS' as category,
          'Current Assets' as subcategory,
          'Cash' as item_name,
          '1000' as account_code,
          150000.00 as amount
        UNION ALL
        SELECT 
          2 as id,
          'ASSETS' as category,
          'Current Assets' as subcategory,
          'Inventory' as item_name,
          '1400' as account_code,
          85000.00 as amount
        UNION ALL
        SELECT 
          3 as id,
          'LIABILITIES' as category,
          'Current Liabilities' as subcategory,
          'Accounts Payable' as item_name,
          '2000' as account_code,
          45000.00 as amount
      `);
      return res.json(result.rows);
    } catch (error) {
      console.error("Error fetching balance sheet items:", error);
      return res.status(500).json({ message: "Failed to fetch balance sheet items" });
    }
  });

  // Workspace Agent Routes
  app.use("/api/workspace-agent", workspaceAgentRoutes);

  // SD-FI Integration Routes
  app.use("/api/sales-finance", salesFinanceIntegrationRoutes);

  // Complete Gap Implementation Routes
  const completeGapRoutes = (await import("./routes/complete-gap-implementation-routes")).default;
  app.use("/api/complete-implementation", completeGapRoutes);

  // Master Data Configuration Routes  
  const masterDataRoutes = (await import("./routes/master-data-configuration-routes")).default;
  app.use("/api/master-data", masterDataRoutes);

  // Transactional Applications Routes
  const transactionalRoutes = (await import("./routes/transactional-applications-routes")).default;
  app.use("/api/transactions", transactionalRoutes);

  // Pizza E2E Testing endpoint with real screenshots and timestamps
  app.post('/api/intelligent-testing/run-pizza-e2e', async (req: Request, res: Response) => {
    try {
      const { pizzaE2ETestingService } = await import('./services/pizza-e2e-testing');
      const result = await pizzaE2ETestingService.runComprehensiveE2ETesting();
      res.json(result);
    } catch (error) {
      console.error('Pizza E2E Testing failed:', error);
      res.status(500).json({ error: 'Failed to run Pizza E2E testing' });
    }
  });

  // Pizza E2E testing routes
  app.post('/api/pizza-e2e/run-tests', async (req: Request, res: Response) => {
    try {
      const { pizzaE2ETestingService } = await import('./services/pizza-e2e-testing');
      const results = await pizzaE2ETestingService.runComprehensiveE2ETesting();
      res.json(results);
    } catch (error) {
      console.error('Pizza E2E testing error:', error);
      res.status(500).json({ error: 'Failed to run Pizza E2E tests', details: error.message });
    }
  });

  // Application Interface Screenshot Routes
  app.post('/api/pizza-e2e/capture-interfaces', async (req: Request, res: Response) => {
    try {
      const { simpleInterfaceCaptureService } = await import('./services/simple-interface-capture');
      const results = await simpleInterfaceCaptureService.captureApplicationInterfaces();
      res.json(results);
    } catch (error) {
      console.error('Interface screenshot error:', error);
      res.status(500).json({ error: 'Failed to capture interface screenshots', details: error.message });
    }
  });

  // Static file serving for screenshots
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Agent session management
  app.post("/api/agent-session/role", async (req: Request, res: Response) => {
    try {
      const { role } = req.body;
      console.log(`Agent role changed to: ${role}`);
      res.json({ success: true, role });
    } catch (error) {
      console.error("Error updating agent role:", error);
      res.status(500).json({ message: "Failed to update agent role" });
    }
  });

  // Inventory API routes
  app.get("/api/inventory", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        ORDER BY p.name
      `);
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching inventory:", error);
      return res.status(500).json({ message: "Failed to fetch inventory" });
    }
  });

  // Finance API routes
  app.get("/api/finance/gl-account", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT * FROM gl_accounts ORDER BY account_number
      `);
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching GL accounts:", error);
      return res.status(500).json({ message: "Failed to fetch GL accounts" });
    }
  });

  // Sales API routes
  app.get("/api/sales/sales-order", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT o.*, c.name as customer_name 
        FROM orders o 
        LEFT JOIN customers c ON o.customer_id = c.id 
        ORDER BY o.order_number DESC
      `);
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching sales orders:", error);
      return res.status(500).json({ message: "Failed to fetch sales orders" });
    }
  });

  // HR API routes
  app.get("/api/hr/employees", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT * FROM employees ORDER BY last_name, first_name
      `);
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching employees:", error);
      return res.status(500).json({ message: "Failed to fetch employees" });
    }
  });

  // Production API routes
  app.get("/api/production/work-orders", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT * FROM work_orders ORDER BY created_at DESC
      `);
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching work orders:", error);
      return res.status(500).json({ message: "Failed to fetch work orders" });
    }
  });

  // Purchasing API routes
  app.get("/api/purchasing/purchase-orders", async (req: Request, res: Response) => {
    try {
      const result = await pool.query(`
        SELECT po.*, v.name as vendor_name 
        FROM purchase_orders po 
        LEFT JOIN vendors v ON po.vendor_id = v.id 
        ORDER BY po.created_at DESC
      `);
      return res.status(200).json(result.rows);
    } catch (error) {
      console.error("Error fetching purchase orders:", error);
      return res.status(500).json({ message: "Failed to fetch purchase orders" });
    }
  });

  // Rock Agent - System Protection Routes
  app.get("/api/rock-agent/health-check", async (req: Request, res: Response) => {
    try {
      const { rockAgent } = await import('./agents/RockAgent.js');
      const healthReport = await rockAgent.performSystemHealthCheck();
      return res.status(200).json(healthReport);
    } catch (error) {
      console.error("Error in Rock Agent health check:", error);
      return res.status(500).json({ message: "Health check failed" });
    }
  });

  app.post("/api/rock-agent/auto-heal", async (req: Request, res: Response) => {
    try {
      const { rockAgent } = await import('./agents/RockAgent.js');
      const healingResult = await rockAgent.autoHealSystem();
      return res.status(200).json(healingResult);
    } catch (error) {
      console.error("Error in Rock Agent auto-healing:", error);
      return res.status(500).json({ message: "Auto-healing failed" });
    }
  });

  app.get("/api/rock-agent/status", async (req: Request, res: Response) => {
    try {
      const { rockAgent } = await import('./agents/RockAgent.js');
      const statusReport = await rockAgent.generateStatusReport();
      return res.status(200).json(statusReport);
    } catch (error) {
      console.error("Error generating Rock Agent status:", error);
      return res.status(500).json({ message: "Status report failed" });
    }
  });

  app.post("/api/rock-agent/start-monitoring", async (req: Request, res: Response) => {
    try {
      const { intervalMinutes = 5 } = req.body;
      const { rockAgent } = await import('./agents/RockAgent.js');
      rockAgent.startMonitoring(intervalMinutes);
      return res.status(200).json({ 
        message: "Rock Agent monitoring started",
        interval: intervalMinutes,
        timestamp: new Date()
      });
    } catch (error) {
      console.error("Error starting Rock Agent monitoring:", error);
      return res.status(500).json({ message: "Failed to start monitoring" });
    }
  });

  // Rock Agent Protection Rules and Validation
  app.get("/api/rock-agent/protection-rules", async (req: Request, res: Response) => {
    try {
      const { rockAgent } = await import('./agents/RockAgent.js');
      const rules = rockAgent.getDatabaseChangeProtectionRules();
      return res.status(200).json(rules);
    } catch (error) {
      console.error("Error getting protection rules:", error);
      return res.status(500).json({ message: "Failed to get protection rules" });
    }
  });

  app.post("/api/rock-agent/validate-changes", async (req: Request, res: Response) => {
    try {
      const { changeType, details } = req.body;
      const { rockAgent } = await import('./agents/RockAgent.js');
      const validation = await rockAgent.validateNewChanges(changeType, details);
      return res.status(200).json(validation);
    } catch (error) {
      console.error("Error validating changes:", error);
      return res.status(500).json({ message: "Failed to validate changes" });
    }
  });

  app.post("/api/rock-agent/pre-change-check", async (req: Request, res: Response) => {
    try {
      const { rockAgent } = await import('./agents/RockAgent.js');
      const baseline = await rockAgent.preChangeValidation();
      return res.status(200).json(baseline);
    } catch (error) {
      console.error("Error in pre-change check:", error);
      return res.status(500).json({ message: "Pre-change check failed" });
    }
  });

  app.post("/api/rock-agent/post-change-verify", async (req: Request, res: Response) => {
    try {
      const { baseline } = req.body;
      const { rockAgent } = await import('./agents/RockAgent.js');
      const verification = await rockAgent.postChangeVerification(baseline);
      return res.status(200).json(verification);
    } catch (error) {
      console.error("Error in post-change verification:", error);
      return res.status(500).json({ message: "Post-change verification failed" });
    }
  });

  // Payment Integration Routes
  const paymentRoutes = await import('./routes/payment-integration');
  app.use('/api/payments', paymentRoutes.default);

  // CrossCheck Validation Routes
  const crossCheckRoutes = await import('./routes/crosscheck-validation');
  app.use('/api/crosscheck', crossCheckRoutes.default);

  // End-to-End Process Routes
  const endToEndRoutes = await import('./routes/end-to-end-processes');
  app.use('/api/end-to-end', endToEndRoutes.default);

  // Add 404 handler for unmatched API routes only (MUST BE LAST)
  app.use('/api/*', (req: Request, res: Response) => {
    res.status(404).json({ 
      message: `API route ${req.originalUrl} not found`,
      method: req.method,
      timestamp: new Date().toISOString()
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
