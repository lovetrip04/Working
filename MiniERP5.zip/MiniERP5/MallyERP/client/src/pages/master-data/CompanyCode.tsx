import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Plus, Search, Edit, Trash2, X, FileUp, Download, Globe, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { useAgentPermissions } from "@/hooks/useAgentPermissions";
// Import the company code excel import component
import CompanyCodeExcelImport from "../../components/master-data/CompanyCodeExcelImport";

// Define the Company Code type (matches database schema)
type CompanyCode = {
  id: number;
  code: string;
  name: string;
  city: string | null;
  country: string;
  currency: string;
  language: string | null;
  active: boolean; // Database field name
  created_at: string;
  updated_at: string;
};

// List of currencies
const CURRENCIES = [
  "USD", "EUR", "JPY", "GBP", "AUD", "CAD", "CHF", "CNY", 
  "HKD", "NZD", "SEK", "KRW", "SGD", "NOK", "MXN", "INR"
];

// List of countries
const COUNTRIES = [
  "United States", "Canada", "United Kingdom", "Germany", "France", "Italy", "Spain", 
  "Japan", "China", "Australia", "India", "Brazil", "Mexico", "South Africa", "Russia"
];

// List of fiscal year options
const FISCAL_YEARS = [
  "Calendar Year (Jan-Dec)", 
  "Apr-Mar", 
  "Jul-Jun", 
  "Oct-Sep"
];

// Company Code Form Schema
const companyCodeSchema = z.object({
  code: z.string().min(2, "Code is required").max(10, "Code must be at most 10 characters"),
  name: z.string().min(1, "Name is required").max(100, "Name must be at most 100 characters"),
  description: z.string().optional(),
  currency: z.string().min(1, "Currency is required"),
  country: z.string().min(1, "Country is required"),
  taxId: z.string().optional(),
  fiscalYear: z.string().min(1, "Fiscal Year is required"),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  postalCode: z.string().optional(),
  phone: z.string().optional(),
  email: z.union([z.string().email("Invalid email format"), z.literal("")]).optional(),
  website: z.union([z.string().url("Invalid website URL"), z.literal("")]).optional(),
  logoUrl: z.string().optional(),
  isActive: z.boolean().default(true),
});

// Company Code Management Page
export default function CompanyCodePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [editingCompanyCode, setEditingCompanyCode] = useState<CompanyCode | null>(null);
  const [activeTab, setActiveTab] = useState("basic");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const permissions = useAgentPermissions();

  // Fetch company codes directly to avoid JSON parsing issues
  const [companyCodes, setCompanyCodes] = useState<CompanyCode[]>([]);
  const [filteredCompanyCodes, setFilteredCompanyCodes] = useState<CompanyCode[]>([]);
  const [companyCodesLoading, setCompanyCodesLoading] = useState(true);
  const [companyCodesError, setCompanyCodesError] = useState<Error | null>(null);
  
  // Fetch data on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch company codes
        setCompanyCodesLoading(true);
        const response = await fetch("/api/master-data/company-code", {
          headers: {
            'Accept': 'application/json'
          }
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          if (errorText.includes('<!DOCTYPE')) {
            throw new Error('Server returned HTML instead of JSON');
          }
          throw new Error(`API Error: ${response.status} ${response.statusText}`);
        }
        
        const data = await response.json();
        setCompanyCodes(data);
        setFilteredCompanyCodes(data);
        setCompanyCodesLoading(false);
      } catch (error) {
        console.error("Error fetching company codes:", error);
        setCompanyCodesError(error instanceof Error ? error : new Error('Failed to fetch company codes'));
        setCompanyCodesLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  // Filter company codes based on search query
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredCompanyCodes(companyCodes);
    } else {
      setFilteredCompanyCodes(
        companyCodes.filter(
          (companyCode) =>
            companyCode.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
            companyCode.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            companyCode.country.toLowerCase().includes(searchQuery.toLowerCase())
        )
      );
    }
  }, [searchQuery, companyCodes]);

  // Company code form setup
  const form = useForm<z.infer<typeof companyCodeSchema>>({
    resolver: zodResolver(companyCodeSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      currency: "USD",
      country: "United States",
      taxId: "",
      fiscalYear: "Calendar Year (Jan-Dec)",
      address: "",
      city: "",
      state: "",
      postalCode: "",
      phone: "",
      email: "",
      website: "",
      logoUrl: "",
      isActive: true,
    },
  });

  // Set form values when editing
  useEffect(() => {
    if (editingCompanyCode) {
      form.reset({
        code: editingCompanyCode.code,
        name: editingCompanyCode.name,
        description: "",
        currency: editingCompanyCode.currency,
        country: editingCompanyCode.country,
        taxId: "",
        fiscalYear: "Calendar Year (Jan-Dec)",
        address: "",
        city: editingCompanyCode.city || "",
        state: "",
        postalCode: "",
        phone: "",
        email: "",
        website: "",
        logoUrl: "",
        isActive: editingCompanyCode.active, // Map database 'active' field to form 'isActive' field
      });
    } else {
      form.reset({
        code: "",
        name: "",
        description: "",
        currency: "USD",
        country: "United States",
        taxId: "",
        fiscalYear: "Calendar Year (Jan-Dec)",
        address: "",
        city: "",
        state: "",
        postalCode: "",
        phone: "",
        email: "",
        website: "",
        logoUrl: "",
        isActive: true,
      });
    }
  }, [editingCompanyCode, form]);

  // Create company code mutation
  const createCompanyCodeMutation = useMutation({
    mutationFn: (companyCode: z.infer<typeof companyCodeSchema>) => {
      console.log("Sending to API:", JSON.stringify(companyCode));
      return apiRequest(`/api/master-data/company-code`, {
        method: "POST",
        body: JSON.stringify(companyCode)
      }).then(res => {
        if (!res.ok) {
          return res.json().then(err => {
            throw new Error(err.message || "Failed to create company code");
          });
        }
        return res.json();
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Company Code created successfully",
      });
      // Refresh the company codes list
      fetch("/api/master-data/company-code", {
        headers: { 'Accept': 'application/json' }
      })
        .then(res => res.json())
        .then(data => {
          setCompanyCodes(data);
          setFilteredCompanyCodes(data);
        });
      setShowDialog(false);
      setActiveTab("basic");
      form.reset();
    },
    onError: (error: any) => {
      console.error("Create error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to create Company Code",
        variant: "destructive",
      });
    },
  });

  // Update company code mutation
  const updateCompanyCodeMutation = useMutation({
    mutationFn: (data: { id: number; companyCode: z.infer<typeof companyCodeSchema> }) => {
      return apiRequest(`/api/master-data/company-code/${data.id}`, {
        method: "PUT",
        body: JSON.stringify(data.companyCode),
      }).then(res => res.json());
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Company Code updated successfully",
      });
      // Refresh the company codes list
      fetch("/api/master-data/company-code", {
        headers: { 'Accept': 'application/json' }
      })
        .then(res => res.json())
        .then(data => {
          setCompanyCodes(data);
          setFilteredCompanyCodes(data);
        });
      setShowDialog(false);
      setEditingCompanyCode(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update Company Code",
        variant: "destructive",
      });
    },
  });

  // Delete company code mutation
  const deleteCompanyCodeMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest(`/api/master-data/company-code/${id}`, {
        method: "DELETE",
      }).then(res => res.json());
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Company Code deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/company-code"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete Company Code",
        variant: "destructive",
      });
    },
  });

  // Form submission
  const onSubmit = (values: z.infer<typeof companyCodeSchema>) => {
    console.log("Form submitted with values:", values);
    
    // Convert code to uppercase and send active field directly
    const updatedValues: any = {
      ...values,
      code: values.code.toUpperCase(),
      active: values.isActive, // Map isActive to active for backend
    };
    
    // Remove isActive since backend expects active
    delete updatedValues.isActive;
    
    if (editingCompanyCode) {
      updateCompanyCodeMutation.mutate({ id: editingCompanyCode.id, companyCode: updatedValues });
    } else {
      createCompanyCodeMutation.mutate(updatedValues);
    }
  };

  // Function to close the dialog and reset state
  const closeDialog = () => {
    setShowDialog(false);
    setEditingCompanyCode(null);
    form.reset();
  };

  // Function to handle editing a company code
  const handleEdit = (companyCode: CompanyCode) => {
    setEditingCompanyCode(companyCode);
    
    // Map database fields to form fields with proper type conversion
    const formData = {
      code: companyCode.code,
      name: companyCode.name,
      currency: companyCode.currency,
      country: companyCode.country,
      city: companyCode.city || "",
      language: companyCode.language || "",
      isActive: companyCode.active, // Map active to isActive for the form
      fiscalYear: "Calendar Year (Jan-Dec)", // Default fiscal year
      description: "",
      taxId: "",
      address: "",
      state: "",
      postalCode: "",
      phone: "",
      email: "",
      website: "",
      logoUrl: ""
    };
    
    form.reset(formData);
    setShowDialog(true);
  };

  // Function to handle deleting a company code
  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this Company Code?")) {
      deleteCompanyCodeMutation.mutate(id);
    }
  };

  // Check for errors
  if (companyCodesError) {
    return (
      <div className="p-4">
        <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded-md">
          <h3 className="text-lg font-medium">Error</h3>
          <p>{(companyCodesError as Error).message || "An error occurred"}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center">
          <Link href="/master-data" className="mr-4 p-2 rounded-md hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Company Codes</h1>
            <p className="text-sm text-muted-foreground">
              Manage the legal entities in your organization
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {permissions.hasDataModificationRights ? (
            <>
              <Button variant="outline" onClick={() => setShowImportDialog(true)}>
                <FileUp className="mr-2 h-4 w-4" />
                Import from Excel
              </Button>
              <Button onClick={() => setShowDialog(true)}>
                <Plus className="mr-2 h-4 w-4" />
                New Company Code
              </Button>
            </>
          ) : (
            <div className="text-sm text-gray-500 px-3 py-2 bg-gray-50 rounded">
              {permissions.getRestrictedMessage()}
            </div>
          )}
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search company codes..."
          className="pl-8"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Company Codes Table */}
      <Card>
        <CardHeader>
          <CardTitle>Company Codes</CardTitle>
          <CardDescription>
            All registered legal entities in your organization
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="max-h-[500px] overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-white z-10">
                  <TableRow>
                    <TableHead className="w-[100px]">Code</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden sm:table-cell">Country</TableHead>
                    <TableHead className="hidden md:table-cell">Currency</TableHead>
                    <TableHead className="hidden md:table-cell">Fiscal Year</TableHead>
                    <TableHead className="w-[100px] text-center">Status</TableHead>
                    <TableHead className="w-[100px] text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {companyCodesLoading ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24">
                        Loading...
                      </TableCell>
                    </TableRow>
                  ) : filteredCompanyCodes.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24">
                        No company codes found. {searchQuery ? "Try a different search." : "Create your first company code."}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredCompanyCodes.map((companyCode) => (
                      <TableRow key={companyCode.id}>
                        <TableCell className="font-medium">{companyCode.code}</TableCell>
                        <TableCell>{companyCode.name}</TableCell>
                        <TableCell className="hidden sm:table-cell">{companyCode.country}</TableCell>
                        <TableCell className="hidden md:table-cell">{companyCode.currency}</TableCell>
                        <TableCell className="hidden md:table-cell">Calendar Year</TableCell>
                        <TableCell className="text-center">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                              companyCode.active
                                ? "bg-green-100 text-green-800"
                                : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {companyCode.active ? "Active" : "Inactive"}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {permissions.hasDataModificationRights && (
                              <>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEdit(companyCode)}
                                  title="Edit Company Code"
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleDelete(companyCode.id)}
                                  className="text-red-500 hover:text-red-700"
                                  title="Delete Company Code"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                            {!permissions.hasDataModificationRights && (
                              <span className="text-xs text-gray-500 px-2 py-1">
                                {permissions.label}
                              </span>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Company Code Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>
              {editingCompanyCode ? "Edit Company Code" : "Create Company Code"}
            </DialogTitle>
            <DialogDescription>
              {editingCompanyCode
                ? "Update the company code details below"
                : "Add a new legal entity to your organization"}
            </DialogDescription>
          </DialogHeader>

          <div className="overflow-y-auto max-h-[calc(90vh-200px)] pr-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="basic">Basic Information</TabsTrigger>
                    <TabsTrigger value="contact">Contact & Address</TabsTrigger>
                    <TabsTrigger value="additional">Additional Information</TabsTrigger>
                  </TabsList>
                  
                  {/* Basic Information Tab */}
                  <TabsContent value="basic" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="code"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Code*</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="E.g., US01" 
                                {...field} 
                                disabled={!!editingCompanyCode}
                              />
                            </FormControl>
                            <FormDescription>
                              Unique code for this legal entity (max 10 characters)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name*</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="E.g., ACME Corporation USA" 
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription>
                              Official legal name of the entity
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Brief description of this legal entity" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select country" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {COUNTRIES.map((country) => (
                                  <SelectItem key={country} value={country}>
                                    {country}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="currency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Currency*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select currency" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {CURRENCIES.map((currency) => (
                                  <SelectItem key={currency} value={currency}>
                                    {currency}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="fiscalYear"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Fiscal Year*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select fiscal year" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {FISCAL_YEARS.map((fiscalYear) => (
                                  <SelectItem key={fiscalYear} value={fiscalYear}>
                                    {fiscalYear}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="taxId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tax ID</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Tax identification number" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="isActive"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 p-4 border rounded-md">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Active</FormLabel>
                            <FormDescription>
                              Is this company code active and available for use?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </TabsContent>

                  {/* Contact & Address Tab */}
                  <TabsContent value="contact" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Street address" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="City" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>State/Province</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="State or province" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="postalCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Postal Code</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Postal or ZIP code" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Phone number" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Email address" 
                                {...field} 
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormDescription>
                              Leave blank if no email address is available
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </TabsContent>

                  {/* Additional Information Tab */}
                  <TabsContent value="additional" className="space-y-4">
                    <FormField
                      control={form.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Website</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://www.example.com" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormDescription>
                            Company website URL (must include http:// or https://). Leave blank if no website is available.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="logoUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Logo URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="URL to company logo" 
                              {...field} 
                              value={field.value || ""}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                </Tabs>

                <DialogFooter className="pt-4">
                  <div className="flex w-full justify-between">
                    <div>
                      {activeTab !== "basic" && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            if (activeTab === "contact") setActiveTab("basic");
                            if (activeTab === "additional") setActiveTab("contact");
                          }}
                        >
                          Back
                        </Button>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={closeDialog}
                      >
                        Cancel
                      </Button>
                      
                      <div className="flex gap-2">
                        {/* Next button (visible on first two tabs) */}
                        {activeTab !== "additional" && (
                          <Button 
                            type="button"
                            onClick={() => {
                              if (activeTab === "basic") setActiveTab("contact");
                              if (activeTab === "contact") setActiveTab("additional");
                            }}
                          >
                            Next
                          </Button>
                        )}
                        
                        {/* Save button (visible on all tabs) */}
                        <Button 
                          type="button"
                          variant={activeTab !== "additional" ? "outline" : "default"}
                          onClick={() => {
                            // Get form values
                            const values = form.getValues();
                            
                            // Pre-process values to handle empty email and website
                            const processedValues = {
                              ...values,
                              email: values.email === "" ? undefined : values.email,
                              website: values.website === "" ? undefined : values.website,
                              logoUrl: values.logoUrl === "" ? undefined : values.logoUrl
                            };
                            
                            // Submit the form
                            if (editingCompanyCode) {
                              updateCompanyCodeMutation.mutate({ id: editingCompanyCode.id, companyCode: processedValues });
                            } else {
                              createCompanyCodeMutation.mutate(processedValues);
                            }
                          }}
                          disabled={createCompanyCodeMutation.isPending || updateCompanyCodeMutation.isPending}
                        >
                          {createCompanyCodeMutation.isPending || updateCompanyCodeMutation.isPending ? (
                            "Saving..."
                          ) : (
                            editingCompanyCode ? "Save Changes" : "Save"
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </DialogFooter>
              </form>
            </Form>
          </div>
        </DialogContent>
      </Dialog>

      {/* Excel Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Import Company Codes from Excel</DialogTitle>
            <DialogDescription>
              Upload an Excel file with company code data to import in bulk
            </DialogDescription>
          </DialogHeader>
          {/* Import component will need to be properly implemented */}
          <div className="py-4">
            <p>Excel import functionality will be implemented here.</p>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowImportDialog(false)}
            >
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}