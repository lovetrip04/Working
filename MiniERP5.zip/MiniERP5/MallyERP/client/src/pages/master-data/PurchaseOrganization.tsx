import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/apiClient";
import { Link } from "wouter";

// UI Components
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialog } from "@/components/ui/alert-dialog";
import { PlusCircle, Edit, Trash2, ShoppingCart, TruckIcon, Search, RefreshCw, ArrowLeft } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { SearchRefreshBar } from "@/components/ui/search-refresh-bar";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
// Types for the data
interface CompanyCode {
  id: number;
  code: string;
  name: string;
}

interface PurchaseOrganization {
  id: number;
  code: string;
  name: string;
  description?: string;
  companyCodeId: number;
  purchasingGroup?: string;
  supplyType?: string;
  notes?: string;
  approvalLevel?: string;
  currency: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
  phone?: string;
  email?: string;
  manager?: string;
  status: string;
  isActive: boolean;
  companyCode?: CompanyCode;
}

// Validation schema for the form
const purchaseOrgFormSchema = z.object({
  code: z.string().min(2, "Code must be at least 2 characters").max(10, "Code must be at most 10 characters"),
  name: z.string().min(3, "Name must be at least 3 characters"),
  description: z.string().optional(),
  companyCodeId: z.coerce.number().min(1, "Company code is required"),
  purchasingGroup: z.string().optional(),
  supplyType: z.string().optional(),
  approvalLevel: z.string().optional(),
  currency: z.string().default("USD"),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  country: z.string().optional(),
  postalCode: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().optional(),
  manager: z.string().optional(),
  status: z.string().default("active"),
  isActive: z.boolean().default(true),
  notes: z.string().optional(),
});

export default function PurchaseOrganization() {
  const permissions = useAgentPermissions();

  // State management
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingPurchaseOrg, setEditingPurchaseOrg] = useState<PurchaseOrganization | null>(null);
  const [deletingPurchaseOrg, setDeletingPurchaseOrg] = useState<PurchaseOrganization | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Forms
  const addForm = useForm<z.infer<typeof purchaseOrgFormSchema>>({
    resolver: zodResolver(purchaseOrgFormSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      purchasingGroup: "",
      supplyType: "",
      approvalLevel: "",
      currency: "USD",
      address: "",
      city: "",
      state: "",
      country: "",
      postalCode: "",
      phone: "",
      email: "",
      manager: "",
      status: "active",
      isActive: true,
    },
  });

  const editForm = useForm<z.infer<typeof purchaseOrgFormSchema>>({
    resolver: zodResolver(purchaseOrgFormSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      purchasingGroup: "",
      supplyType: "",
      approvalLevel: "",
      currency: "USD",
      address: "",
      city: "",
      state: "",
      country: "",
      postalCode: "",
      phone: "",
      email: "",
      manager: "",
      status: "active",
      isActive: true,
    },
  });

  // Fetch data
  const { data: purchaseOrgs = [] as PurchaseOrganization[], isLoading, error } = useQuery({
    queryKey: ['/api/master-data/purchase-organization'],
    retry: 1,
  });

  const { data: companyCodes = [] as CompanyCode[] } = useQuery({
    queryKey: ['/api/master-data/company-code'],
    retry: 1,
  });
  
  // Fetch purchase groups and supply types for dropdown options
  const { data: purchaseGroups = [] as Array<{id: number, code: string, name: string}> } = useQuery({
    queryKey: ['/api/master-data/purchase-group'],
    retry: 1,
  });
  
  const { data: supplyTypes = [] as Array<{id: number, code: string, name: string}> } = useQuery({
    queryKey: ['/api/master-data/supply-type'],
    retry: 1,
  });

  // Mutations
  const addPurchaseOrgMutation = useMutation({
    mutationFn: (data: z.infer<typeof purchaseOrgFormSchema>) => 
      apiRequest('/api/master-data/purchase-organization', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchase-organization'] });
      setIsAddDialogOpen(false);
      addForm.reset();
      toast({
        title: "Purchase Organization Added",
        description: "Purchase organization has been successfully added.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add purchase organization. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updatePurchaseOrgMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: z.infer<typeof purchaseOrgFormSchema> }) => 
      apiRequest(`/api/master-data/purchase-organization/${id}`, 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchase-organization'] });
      setIsEditDialogOpen(false);
      setEditingPurchaseOrg(null);
      toast({
        title: "Purchase Organization Updated",
        description: "Purchase organization has been successfully updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update purchase organization. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deletePurchaseOrgMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/master-data/purchase-organization/${id}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchase-organization'] });
      setIsDeleteDialogOpen(false);
      setDeletingPurchaseOrg(null);
      toast({
        title: "Purchase Organization Deleted",
        description: "Purchase organization has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete purchase organization. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Form submit handlers
  const handleAddSubmit = (data: z.infer<typeof purchaseOrgFormSchema>) => {
    addPurchaseOrgMutation.mutate(data);
  };

  const handleEditSubmit = (data: z.infer<typeof purchaseOrgFormSchema>) => {
    if (!editingPurchaseOrg) return;
    updatePurchaseOrgMutation.mutate({ id: editingPurchaseOrg.id, data });
  };

  const openEditDialog = (purchaseOrg: PurchaseOrganization) => {
    setEditingPurchaseOrg(purchaseOrg);
    editForm.reset({
      code: purchaseOrg.code,
      name: purchaseOrg.name,
      description: purchaseOrg.description || "",
      companyCodeId: purchaseOrg.companyCodeId,
      purchasingGroup: purchaseOrg.purchasingGroup || "",
      supplyType: purchaseOrg.supplyType || "",
      approvalLevel: purchaseOrg.approvalLevel || "",
      currency: purchaseOrg.currency || "USD",
      address: purchaseOrg.address || "",
      city: purchaseOrg.city || "",
      state: purchaseOrg.state || "",
      country: purchaseOrg.country || "",
      postalCode: purchaseOrg.postalCode || "",
      phone: purchaseOrg.phone || "",
      email: purchaseOrg.email || "",
      manager: purchaseOrg.manager || "",
      status: purchaseOrg.status,
      isActive: purchaseOrg.isActive,
      notes: purchaseOrg.notes || ""
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (purchaseOrg: PurchaseOrganization) => {
    setDeletingPurchaseOrg(purchaseOrg);
    setIsDeleteDialogOpen(true);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center mb-6">
          <Link href="/master-data" className="mr-4 p-2 rounded-md hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Purchase Organization Management</h1>
            <p className="text-gray-600 mt-1">
              Manage purchase organizations for procurement activities
            </p>
          </div>
        </div>
        <Button 
          variant="default" 
          onClick={() => setIsAddDialogOpen(true)}
          className="space-x-2"
        >
          <PlusCircle className="h-4 w-4" />
          <span>Add Purchase Organization</span>
        </Button>
      </div>

      <SearchRefreshBar 
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        resourceName="purchase organization"
        queryKey="/api/master-data/purchase-organization"
      />

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Organizations</TabsTrigger>
          <TabsTrigger value="direct">Direct Materials</TabsTrigger>
          <TabsTrigger value="indirect">Indirect Materials</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <PurchaseOrgTable 
            purchaseOrgs={(purchaseOrgs as PurchaseOrganization[]).filter(org => 
              searchQuery ? (
                org.code.toUpperCase().includes(searchQuery.toUpperCase()) ||
                org.name.toUpperCase().includes(searchQuery.toUpperCase()) ||
                (org.description && org.description.toUpperCase().includes(searchQuery.toUpperCase())) ||
                (org.companyCode && org.companyCode.name.toUpperCase().includes(searchQuery.toUpperCase()))
              ) : true
            )}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="direct">
          <PurchaseOrgTable 
            purchaseOrgs={(purchaseOrgs as PurchaseOrganization[]).filter(org => 
              org.supplyType === 'direct' && (
                searchQuery ? (
                  org.code.toUpperCase().includes(searchQuery.toUpperCase()) ||
                  org.name.toUpperCase().includes(searchQuery.toUpperCase()) ||
                  (org.description && org.description.toUpperCase().includes(searchQuery.toUpperCase())) ||
                  (org.companyCode && org.companyCode.name.toUpperCase().includes(searchQuery.toUpperCase()))
                ) : true
              )
            )}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
        
        <TabsContent value="indirect">
          <PurchaseOrgTable 
            purchaseOrgs={(purchaseOrgs as PurchaseOrganization[]).filter(org => 
              org.supplyType === 'indirect' && (
                searchQuery ? (
                  org.code.toUpperCase().includes(searchQuery.toUpperCase()) ||
                  org.name.toUpperCase().includes(searchQuery.toUpperCase()) ||
                  (org.description && org.description.toUpperCase().includes(searchQuery.toUpperCase())) ||
                  (org.companyCode && org.companyCode.name.toUpperCase().includes(searchQuery.toUpperCase()))
                ) : true
              )
            )}
            isLoading={isLoading}
            onEdit={openEditDialog}
            onDelete={openDeleteDialog}
          />
        </TabsContent>
      </Tabs>

      {/* Add Purchase Organization Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Add New Purchase Organization</DialogTitle>
            <DialogDescription>
              Enter purchase organization details to manage procurement activities.
            </DialogDescription>
          </DialogHeader>
          <Form {...addForm}>
            <form onSubmit={addForm.handleSubmit(handleAddSubmit)} className="space-y-6 overflow-y-auto max-h-[calc(90vh-200px)] pr-2">
              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={addForm.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Purchase Org. Code</FormLabel>
                      <FormControl>
                        <Input placeholder="P001" {...field} />
                      </FormControl>
                      <FormDescription>
                        Unique identifier for this purchase organization
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Global Procurement" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="companyCodeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company Code</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value?.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Company Code" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(companyCodes as CompanyCode[]).map((companyCode) => (
                            <SelectItem key={companyCode.id} value={companyCode.id.toString()}>
                              {companyCode.code} - {companyCode.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={addForm.control}
                  name="purchasingGroup"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Purchasing Group</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Group" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Array.isArray(purchaseGroups) && purchaseGroups.length > 0 ? (
                            purchaseGroups.map((group) => (
                              <SelectItem key={group.id} value={group.code}>
                                {group.name}
                              </SelectItem>
                            ))
                          ) : (
                            <SelectItem value="loading" disabled>
                              Loading purchase groups...
                            </SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="supplyType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Supply Type</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Array.isArray(supplyTypes) && supplyTypes.length > 0 ? (
                            supplyTypes.map((type) => (
                              <SelectItem key={type.id} value={type.code}>
                                {type.name}
                              </SelectItem>
                            ))
                          ) : (
                            <SelectItem value="loading" disabled>
                              Loading supply types...
                            </SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="approvalLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Approval Level</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low (under $10,000)</SelectItem>
                          <SelectItem value="medium">Medium ($10,000 - $50,000)</SelectItem>
                          <SelectItem value="high">High ($50,000 - $250,000)</SelectItem>
                          <SelectItem value="executive">Executive (over $250,000)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={addForm.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="USD">USD - US Dollar</SelectItem>
                          <SelectItem value="EUR">EUR - Euro</SelectItem>
                          <SelectItem value="GBP">GBP - British Pound</SelectItem>
                          <SelectItem value="JPY">JPY - Japanese Yen</SelectItem>
                          <SelectItem value="CNY">CNY - Chinese Yuan</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="country"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Country</FormLabel>
                      <FormControl>
                        <Input placeholder="United States" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="planning">Planning</SelectItem>
                          <SelectItem value="restructuring">Restructuring</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-3">Contact Information</h3>
                  <div className="space-y-3">
                    <FormField
                      control={addForm.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address</FormLabel>
                          <FormControl>
                            <Input placeholder="123 Business Ave." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <FormField
                        control={addForm.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input placeholder="Chicago" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addForm.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>State/Province</FormLabel>
                            <FormControl>
                              <Input placeholder="IL" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-3">Management Information</h3>
                  <div className="space-y-3">
                    <FormField
                      control={addForm.control}
                      name="manager"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Manager</FormLabel>
                          <FormControl>
                            <Input placeholder="John Smith" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <FormField
                        control={addForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone</FormLabel>
                            <FormControl>
                              <Input placeholder="+1 (555) 123-4567" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="procurement@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <FormField
                control={addForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Detailed description of the purchase organization" 
                        className="resize-none" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Additional information about this purchase organization" 
                        className="resize-none" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addForm.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Enable for use in transactions
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={addPurchaseOrgMutation.isPending}>
                  {addPurchaseOrgMutation.isPending ? "Creating..." : "Create Purchase Organization"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Purchase Organization Dialog - Similar to Add with prefilled values */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>Edit Purchase Organization</DialogTitle>
            <DialogDescription>
              Update purchase organization details.
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-6">
              {/* Same form fields as Add dialog */}
              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={editForm.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Purchase Org. Code</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="companyCodeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company Code</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value?.toString()}
                        value={field.value?.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Company Code" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(companyCodes as CompanyCode[]).map((companyCode) => (
                            <SelectItem key={companyCode.id} value={companyCode.id.toString()}>
                              {companyCode.code} - {companyCode.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Rest of the form fields omitted for brevity but would be the same as the Add dialog */}
              {/* ... */}
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={updatePurchaseOrgMutation.isPending}>
                  {updatePurchaseOrgMutation.isPending ? "Updating..." : "Update Purchase Organization"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the purchase organization "{deletingPurchaseOrg?.name}" ({deletingPurchaseOrg?.code}).
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingPurchaseOrg && deletePurchaseOrgMutation.mutate(deletingPurchaseOrg.id)}
              disabled={deletePurchaseOrgMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deletePurchaseOrgMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// Purchase Organization Table Component
function PurchaseOrgTable({
  purchaseOrgs,
  isLoading,
  onEdit,
  onDelete
}: {
  purchaseOrgs: PurchaseOrganization[];
  isLoading: boolean;
  onEdit: (purchaseOrg: PurchaseOrganization) => void;
  onDelete: (purchaseOrg: PurchaseOrganization) => void;
}) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center items-center h-40">
            <div className="flex flex-col items-center">
              <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
              <p className="mt-2 text-gray-500">Loading purchase organizations...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!purchaseOrgs || purchaseOrgs.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center items-center h-40">
            <div className="flex flex-col items-center">
              <ShoppingCart className="h-8 w-8 text-gray-400" />
              <p className="mt-2 text-gray-500">No purchase organizations found</p>
              <p className="text-sm text-gray-400">Add a purchase organization to get started</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Company Code</TableHead>
              <TableHead>Supply Type</TableHead>
              <TableHead>Purchasing Group</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {purchaseOrgs.map((purchaseOrg) => (
              <TableRow key={purchaseOrg.id}>
                <TableCell className="font-medium">{purchaseOrg.code}</TableCell>
                <TableCell>{purchaseOrg.name}</TableCell>
                <TableCell>{purchaseOrg.companyCode?.code} - {purchaseOrg.companyCode?.name}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="capitalize">
                    {purchaseOrg.supplyType?.replace(/_/g, ' ') || 'N/A'}
                  </Badge>
                </TableCell>
                <TableCell className="capitalize">
                  {purchaseOrg.purchasingGroup?.replace(/_/g, ' ') || 'N/A'}
                </TableCell>
                <TableCell>
                  {purchaseOrg.isActive ? (
                    <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                      Inactive
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onEdit(purchaseOrg)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDelete(purchaseOrg)}
                      className="text-red-500 hover:text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}