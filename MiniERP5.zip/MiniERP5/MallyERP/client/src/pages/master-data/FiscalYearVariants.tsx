import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, RefreshCw, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
const fiscalYearVariantSchema = z.object({
  code: z.string().min(1, "Code is required").max(10, "Code must be 10 characters or less"),
  name: z.string().min(1, "Name is required").max(100, "Name must be 100 characters or less"),
  description: z.string().optional(),
  calendar_type: z.enum(["gregorian", "fiscal", "company_specific"]),
  fiscal_year_start_month: z.number().min(1).max(12),
  fiscal_year_start_day: z.number().min(1).max(31),
  number_of_periods: z.number().min(1).max(16),
  special_periods: z.number().min(0).max(4),
  shift_periods: z.boolean().default(false),
  year_dependent: z.boolean().default(false),
  year_shift: z.number().min(-1).max(1).default(0),
  leap_year_rule: z.enum(["standard", "ignore", "special_handling"]).default("standard"),
  posting_periods: z.number().min(1).max(16),
  active: z.boolean().default(true)
});

type FiscalYearVariant = z.infer<typeof fiscalYearVariantSchema> & { id: number };

export default function FiscalYearVariants() {
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [editingVariant, setEditingVariant] = useState<FiscalYearVariant | null>(null);
  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  const { data: variants = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/fiscal-year-variants"],
  });

  const form = useForm<z.infer<typeof fiscalYearVariantSchema>>({
    resolver: zodResolver(fiscalYearVariantSchema),
    defaultValues: {
      code: "",
      name: "",
      description: "",
      calendar_type: "gregorian",
      fiscal_year_start_month: 1,
      fiscal_year_start_day: 1,
      number_of_periods: 12,
      special_periods: 0,
      shift_periods: false,
      year_dependent: false,
      year_shift: 0,
      leap_year_rule: "standard",
      posting_periods: 12,
      active: true
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: z.infer<typeof fiscalYearVariantSchema>) =>
      apiRequest("/api/fiscal-year-variants", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fiscal-year-variants"] });
      setOpen(false);
      setEditingVariant(null);
      form.reset();
      toast({ title: "Success", description: "Fiscal year variant created successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to create fiscal year variant", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }: { id: number } & z.infer<typeof fiscalYearVariantSchema>) =>
      apiRequest(`/api/fiscal-year-variants/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fiscal-year-variants"] });
      setOpen(false);
      setEditingVariant(null);
      form.reset();
      toast({ title: "Success", description: "Fiscal year variant updated successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to update fiscal year variant", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/fiscal-year-variants/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fiscal-year-variants"] });
      toast({ title: "Success", description: "Fiscal year variant deleted successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: "Failed to delete fiscal year variant", variant: "destructive" });
    },
  });

  const onSubmit = (data: z.infer<typeof fiscalYearVariantSchema>) => {
    if (editingVariant) {
      updateMutation.mutate({ id: editingVariant.id, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (variant: FiscalYearVariant) => {
    setEditingVariant(variant);
    form.reset(variant);
    setOpen(true);
  };

  const handleCreate = () => {
    setEditingVariant(null);
    form.reset();
    setOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/master-data")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Master Data
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Fiscal Year Variants</h1>
            <p className="text-muted-foreground">Configure fiscal year structures and calendar definitions</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={handleCreate}>
                <Plus className="h-4 w-4 mr-2" />
                Create Fiscal Year Variant
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingVariant ? "Edit Fiscal Year Variant" : "Create Fiscal Year Variant"}
                </DialogTitle>
                <DialogDescription>
                  Configure fiscal year calendar structure and posting periods
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Variant Code</FormLabel>
                          <FormControl>
                            <Input placeholder="K4" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Variant Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Calendar Year Variant" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Input placeholder="Standard calendar year with 12 periods" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="calendar_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Calendar Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select calendar type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="gregorian">Gregorian Calendar</SelectItem>
                              <SelectItem value="fiscal">Fiscal Calendar</SelectItem>
                              <SelectItem value="company_specific">Company Specific</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="fiscal_year_start_month"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Fiscal Year Start Month</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="1" 
                              max="12" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="number_of_periods"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Number of Periods</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="1" 
                              max="16" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="special_periods"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Special Periods</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="0" 
                              max="4" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingVariant ? "Update" : "Create"} Fiscal Year Variant
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Fiscal Year Variants</CardTitle>
          <CardDescription>
            Manage fiscal year calendar structures and posting period definitions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">Loading fiscal year variants...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Calendar Type</TableHead>
                  <TableHead>Periods</TableHead>
                  <TableHead>Start Month</TableHead>
                  <TableHead>Special Periods</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {variants.map((variant: FiscalYearVariant) => (
                  <TableRow key={variant.id}>
                    <TableCell className="font-medium">{variant.code}</TableCell>
                    <TableCell>{variant.name}</TableCell>
                    <TableCell className="capitalize">{variant.calendar_type}</TableCell>
                    <TableCell>{variant.number_of_periods}</TableCell>
                    <TableCell>{variant.fiscal_year_start_month}</TableCell>
                    <TableCell>{variant.special_periods}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        variant.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {variant.active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(variant)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteMutation.mutate(variant.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}