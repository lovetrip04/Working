import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit2, Trash2, Save, X, ArrowLeft, RefreshCw } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
interface DistributionChannel {
  id: number;
  code: string;
  name: string;
  description: string;
  salesOrganization: string;
  active: boolean;
  createdAt: string;
}

export default function DistributionChannels() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingChannel, setEditingChannel] = useState<DistributionChannel | null>(null);
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    description: "",
    salesOrganization: "1000",
    active: true
  });

  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  const { data: channels = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/master-data/distribution-channels"],
  });

  const createMutation = useMutation({
    mutationFn: (data: Omit<DistributionChannel, "id" | "createdAt">) =>
      apiRequest("/api/master-data/distribution-channels", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/distribution-channels"] });
      setIsDialogOpen(false);
      resetForm();
      toast({ title: "Success", description: "Distribution channel created successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, ...data }: { id: number } & Partial<DistributionChannel>) =>
      apiRequest(`/api/master-data/distribution-channels/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/distribution-channels"] });
      setEditingChannel(null);
      resetForm();
      toast({ title: "Success", description: "Distribution channel updated successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      apiRequest(`/api/master-data/distribution-channels/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-data/distribution-channels"] });
      toast({ title: "Success", description: "Distribution channel deleted successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      code: "",
      name: "",
      description: "",
      salesOrganization: "1000",
      active: true
    });
    setEditingChannel(null);
    setIsDialogOpen(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingChannel) {
      updateMutation.mutate({ id: editingChannel.id, ...formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (channel: DistributionChannel) => {
    setEditingChannel(channel);
    setFormData({
      code: channel.code,
      name: channel.name,
      description: channel.description,
      salesOrganization: channel.salesOrganization,
      active: channel.active
    });
    setIsDialogOpen(true);
  };

  const handleRefresh = () => {
    refetch();
    toast({ title: "Refreshed", description: "Distribution channels data refreshed" });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/master-data">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Distribution Channels</h1>
            <p className="text-muted-foreground">
              Manage sales distribution channels for different delivery methods
            </p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button onClick={handleRefresh} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => { resetForm(); setIsDialogOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" />
                Add Channel
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingChannel ? "Edit Distribution Channel" : "Create Distribution Channel"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="code">Channel Code</Label>
                    <Input
                      id="code"
                      value={formData.code}
                      onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                      placeholder="e.g., 10, 20, 30"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="salesOrganization">Sales Organization</Label>
                    <Input
                      id="salesOrganization"
                      value={formData.salesOrganization}
                      onChange={(e) => setFormData({ ...formData, salesOrganization: e.target.value })}
                      placeholder="1000"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Channel Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Store Pickup, Home Delivery"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Detailed description of the distribution channel"
                    rows={3}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={formData.active}
                    onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                  />
                  <Label htmlFor="active">Active</Label>
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createMutation.isPending || updateMutation.isPending}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {editingChannel ? "Update" : "Create"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-8">
          <RefreshCw className="h-6 w-6 animate-spin mr-2" />
          Loading distribution channels...
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {channels.map((channel: DistributionChannel) => (
            <Card key={channel.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{channel.code}</CardTitle>
                  <Badge variant={channel.active ? "default" : "secondary"}>
                    {channel.active ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <CardDescription className="font-medium">
                  {channel.name}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="font-medium">Sales Org:</span> {channel.salesOrganization}
                  </div>
                  {channel.description && (
                    <div className="text-sm text-muted-foreground">
                      {channel.description}
                    </div>
                  )}
                  <div className="flex justify-end space-x-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(channel)}
                    >
                      <Edit2 className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deleteMutation.mutate(channel.id)}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="h-3 w-3 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {channels.length === 0 && !isLoading && (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground mb-4">No distribution channels found</p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Distribution Channel
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}