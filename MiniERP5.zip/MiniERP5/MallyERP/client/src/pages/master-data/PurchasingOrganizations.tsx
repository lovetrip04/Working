import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Filter, Download, Edit, Trash2, ArrowLeft, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

import { useAgentPermissions } from "@/hooks/useAgentPermissions";
interface PurchasingOrganization {
  id: number;
  org_code: string;
  org_name: string;
  description: string;
  company_code: string;
  plant_code: string;
  currency: string;
  address: string;
  phone: string;
  email: string;
  active: boolean;
  created_at: string;
  updated_at: string;
}

interface NewPurchasingOrganization {
  org_code: string;
  org_name: string;
  description: string;
  company_code: string;
  plant_code: string;
  currency: string;
  address: string;
  phone: string;
  email: string;
}

export default function PurchasingOrganizations() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [companyFilter, setCompanyFilter] = useState("all");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<PurchasingOrganization | null>(null);
  const [newItem, setNewItem] = useState<NewPurchasingOrganization>({
    org_code: "",
    org_name: "",
    description: "",
    company_code: "",
    plant_code: "",
    currency: "",
    address: "",
    phone: "",
    email: ""
  });

  const { toast } = useToast();
  const permissions = useAgentPermissions();
  const queryClient = useQueryClient();

  useEffect(() => {
    document.title = "Purchasing Organizations | MallyERP";
  }, []);

  // Fetch purchasing organizations
  const { data: purchasingOrgs, isLoading, refetch } = useQuery({
    queryKey: ['/api/master-data/purchasing-organizations'],
  });

  // Fetch company codes for dropdown
  const { data: companyCodes } = useQuery({
    queryKey: ['/api/master-data/company-codes'],
  });

  // Fetch plants for dropdown
  const { data: plants } = useQuery({
    queryKey: ['/api/master-data/plants'],
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: (data: NewPurchasingOrganization) => 
      apiRequest('/api/master-data/purchasing-organizations', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchasing-organizations'] });
      setShowCreateDialog(false);
      setNewItem({
        org_code: "",
        org_name: "",
        description: "",
        company_code: "",
        plant_code: "",
        currency: "",
        address: "",
        phone: "",
        email: ""
      });
      toast({
        title: "Success",
        description: "Purchasing organization created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create purchasing organization",
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<PurchasingOrganization> }) =>
      apiRequest(`/api/master-data/purchasing-organizations/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchasing-organizations'] });
      setShowEditDialog(false);
      setEditingItem(null);
      toast({
        title: "Success",
        description: "Purchasing organization updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update purchasing organization",
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      apiRequest(`/api/master-data/purchasing-organizations/${id}`, {
        method: 'DELETE',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/master-data/purchasing-organizations'] });
      toast({
        title: "Success",
        description: "Purchasing organization deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete purchasing organization",
        variant: "destructive",
      });
    },
  });

  const handleCreate = () => {
    if (!newItem.org_code || !newItem.org_name || !newItem.company_code) {
      toast({
        title: "Validation Error",
        description: "Organization code, name, and company code are required",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate(newItem);
  };

  const handleEdit = (item: PurchasingOrganization) => {
    setEditingItem(item);
    setShowEditDialog(true);
  };

  const handleUpdate = () => {
    if (!editingItem) return;
    updateMutation.mutate({
      id: editingItem.id,
      data: editingItem
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this purchasing organization?")) {
      deleteMutation.mutate(id);
    }
  };

  const filteredItems = (purchasingOrgs as PurchasingOrganization[])?.filter(item => {
    const matchesSearch = 
      item.org_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.org_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.company_code?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "active" && item.active) || 
      (statusFilter === "inactive" && !item.active);

    const matchesCompany = companyFilter === "all" || item.company_code === companyFilter;
    
    return matchesSearch && matchesStatus && matchesCompany;
  }) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link href="/master-data">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Master Data
              </Button>
            </Link>
          </div>
          <h1 className="text-3xl font-bold">Purchasing Organizations</h1>
          <p className="text-muted-foreground">Manage procurement organizational structure</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Organization
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Purchasing Organization</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="org_code">Organization Code *</Label>
                  <Input
                    id="org_code"
                    value={newItem.org_code}
                    onChange={(e) => setNewItem({...newItem, org_code: e.target.value})}
                    placeholder="e.g., PO01"
                  />
                </div>
                <div>
                  <Label htmlFor="org_name">Organization Name *</Label>
                  <Input
                    id="org_name"
                    value={newItem.org_name}
                    onChange={(e) => setNewItem({...newItem, org_name: e.target.value})}
                    placeholder="e.g., Main Purchasing Organization"
                  />
                </div>
                <div>
                  <Label htmlFor="company_code">Company Code *</Label>
                  <Select value={newItem.company_code} onValueChange={(value) => setNewItem({...newItem, company_code: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select company" />
                    </SelectTrigger>
                    <SelectContent>
                      {(companyCodes as any[])?.map((company: any) => (
                        <SelectItem key={company.company_code} value={company.company_code}>
                          {company.company_code} - {company.company_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="plant_code">Plant</Label>
                  <Select value={newItem.plant_code} onValueChange={(value) => setNewItem({...newItem, plant_code: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select plant" />
                    </SelectTrigger>
                    <SelectContent>
                      {(plants as any[])?.map((plant: any) => (
                        <SelectItem key={plant.plant_code} value={plant.plant_code}>
                          {plant.plant_code} - {plant.plant_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="currency">Currency</Label>
                  <Select value={newItem.currency} onValueChange={(value) => setNewItem({...newItem, currency: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD - US Dollar</SelectItem>
                      <SelectItem value="EUR">EUR - Euro</SelectItem>
                      <SelectItem value="GBP">GBP - British Pound</SelectItem>
                      <SelectItem value="JPY">JPY - Japanese Yen</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={newItem.description}
                    onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                    placeholder="Enter description"
                  />
                </div>
                <div>
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    value={newItem.address}
                    onChange={(e) => setNewItem({...newItem, address: e.target.value})}
                    placeholder="Enter address"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={newItem.phone}
                    onChange={(e) => setNewItem({...newItem, phone: e.target.value})}
                    placeholder="Enter phone number"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newItem.email}
                    onChange={(e) => setNewItem({...newItem, email: e.target.value})}
                    placeholder="Enter email address"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreate} disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Creating..." : "Create"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-2 flex-1">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by code, name, or company..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={showFilters ? "default" : "outline"}
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="mr-2 h-4 w-4" />
                Filters
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
          
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 pt-4 border-t">
              <div>
                <Label>Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Company</Label>
                <Select value={companyFilter} onValueChange={setCompanyFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Companies</SelectItem>
                    {(companyCodes as any[])?.map((company: any) => (
                      <SelectItem key={company.company_code} value={company.company_code}>
                        {company.company_code}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Purchasing Organizations ({filteredItems.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading purchasing organizations...</div>
          ) : filteredItems.length > 0 ? (
            <div className="overflow-auto max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Organization Code</TableHead>
                    <TableHead>Organization Name</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Plant</TableHead>
                    <TableHead>Currency</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.org_code}</TableCell>
                      <TableCell>{item.org_name}</TableCell>
                      <TableCell>{item.company_code}</TableCell>
                      <TableCell>{item.plant_code}</TableCell>
                      <TableCell>{item.currency}</TableCell>
                      <TableCell>
                        <Badge variant={item.active ? "default" : "secondary"}>
                          {item.active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(item)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No purchasing organizations match your search.' : 'No purchasing organizations found.'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      {showEditDialog && editingItem && (
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Purchasing Organization</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit_org_code">Organization Code</Label>
                <Input
                  id="edit_org_code"
                  value={editingItem.org_code}
                  onChange={(e) => setEditingItem({...editingItem, org_code: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_org_name">Organization Name</Label>
                <Input
                  id="edit_org_name"
                  value={editingItem.org_name}
                  onChange={(e) => setEditingItem({...editingItem, org_name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit_company_code">Company Code</Label>
                <Select value={editingItem.company_code} onValueChange={(value) => setEditingItem({...editingItem, company_code: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {(companyCodes as any[])?.map((company: any) => (
                      <SelectItem key={company.company_code} value={company.company_code}>
                        {company.company_code} - {company.company_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit_description">Description</Label>
                <Input
                  id="edit_description"
                  value={editingItem.description}
                  onChange={(e) => setEditingItem({...editingItem, description: e.target.value})}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Updating..." : "Update"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}