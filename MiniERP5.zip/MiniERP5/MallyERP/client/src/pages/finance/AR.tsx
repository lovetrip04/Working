import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  PieChart,
  LineChart,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Download,
  Filter,
  Clock,
  DollarSign,
  Eye,
  Calendar,
  User,
  CreditCard,
  ChevronRight,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function AccountsReceivable() {
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<number | null>(null);
  const [showInvoiceDetails, setShowInvoiceDetails] = useState(false);

  const { data: arData = [], isLoading } = useQuery({
    queryKey: ["/api/finance/accounts-receivable"],
  });

  const { data: invoiceDetails } = useQuery({
    queryKey: [`/api/finance/accounts-receivable/${selectedInvoiceId}/details`],
    enabled: !!selectedInvoiceId,
  });

  const { data: customers } = useQuery({
    queryKey: ["/api/customers"],
  });

  if (isLoading) {
    return <div className="p-6">Loading accounts receivable data...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Accounts Receivable (AR)</h1>
          <p className="text-sm text-muted-foreground">Manage customer invoices and payment collections</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            New Invoice
          </Button>
        </div>
      </div>

      {/* AR Navigation Tabs */}
      <Card>
        <Tabs defaultValue="overview" className="w-full">
          <div className="border-b px-4">
            <TabsList className="bg-transparent h-12 p-0 rounded-none">
              <TabsTrigger 
                value="overview" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="invoices" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Invoices
              </TabsTrigger>
              <TabsTrigger 
                value="aging" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Aging Analysis
              </TabsTrigger>
              <TabsTrigger 
                value="payments" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Payments
              </TabsTrigger>
              <TabsTrigger 
                value="collections" 
                className="data-[state=active]:border-b-2 border-primary data-[state=active]:text-primary data-[state=active]:shadow-none rounded-none h-12 px-4"
              >
                Collections
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Overview Tab Content */}
          <TabsContent value="overview" className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Summary KPI Cards */}
              <ARCard 
                title="Total Receivables" 
                value="$482,917.32" 
                change={4.2} 
                isPositive={true}
                period="vs last month"
                icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
              />
              <ARCard 
                title="Average Collection Period" 
                value="32 days" 
                change={-2.5} 
                isPositive={true}
                period="vs last month"
                icon={<Clock className="h-4 w-4 text-muted-foreground" />}
              />
              <ARCard 
                title="Overdue Receivables" 
                value="$87,432.15" 
                change={1.7} 
                isPositive={false}
                period="vs last month"
                icon={<BarChart className="h-4 w-4 text-amber-500" />}
              />
            </div>
            
            {/* Aging Summary */}
            <div className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Aging Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                    Receivables Aging Chart
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Additional AR Widgets */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Top Customers by Outstanding Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <ARCustomer 
                      name="Acme Corporation"
                      balance="$78,500.00"
                      aging="15-30 days"
                      creditLimit="$100,000.00"
                    />
                    <ARCustomer 
                      name="TechNova Inc"
                      balance="$54,250.75"
                      aging="Current"
                      creditLimit="$150,000.00"
                    />
                    <ARCustomer 
                      name="Global Enterprises"
                      balance="$42,890.50"
                      aging="30-60 days"
                      creditLimit="$75,000.00"
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Collections Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <CollectionActivity 
                      customer="Acme Corporation"
                      activity="Payment reminder sent"
                      date="May 12, 2025"
                      status="Pending"
                    />
                    <CollectionActivity 
                      customer="Global Enterprises"
                      activity="Follow-up call scheduled"
                      date="May 15, 2025"
                      status="Scheduled"
                    />
                    <CollectionActivity 
                      customer="TechNova Inc"
                      activity="Partial payment received"
                      date="May 10, 2025"
                      status="Completed"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Invoices Tab Content */}
          <TabsContent value="invoices" className="p-4">
            {arData && arData.length > 0 ? (
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground">
                  Showing {arData.length} accounts receivable records
                </div>
                <div className="rounded-md border overflow-x-auto">
                  <table className="w-full min-w-max">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="text-left p-3 font-medium">Invoice Number</th>
                        <th className="text-left p-3 font-medium">Customer</th>
                        <th className="text-left p-3 font-medium">Invoice Date</th>
                        <th className="text-left p-3 font-medium">Due Date</th>
                        <th className="text-right p-3 font-medium">Amount</th>
                        <th className="text-center p-3 font-medium">Status</th>
                        <th className="text-center p-3 font-medium w-24 bg-blue-100 border-2 border-blue-300">🔍 Details</th>
                      </tr>
                    </thead>
                    <tbody>
                      {arData.map((invoice: any) => (
                        <tr key={invoice.id} className="border-b hover:bg-muted/50">
                          <td className="p-3">
                            <span
                              className="text-blue-600 hover:text-blue-800 cursor-pointer hover:underline font-medium underline"
                              style={{ cursor: 'pointer', textDecoration: 'underline', color: '#2563eb' }}
                              onClick={() => {
                                setSelectedInvoiceId(invoice.id);
                                setShowInvoiceDetails(true);
                              }}
                            >
                              {invoice.invoice_number}
                            </span>
                          </td>
                          <td className="p-3">{invoice.customer_name || `Customer ${invoice.customer_id}`}</td>
                          <td className="p-3">{new Date(invoice.invoice_date).toLocaleDateString()}</td>
                          <td className="p-3">
                            <div className="flex flex-col">
                              <span>{new Date(invoice.due_date).toLocaleDateString()}</span>
                              {invoice.days_overdue > 0 && (
                                <span className="text-sm text-red-600 font-medium">
                                  {invoice.days_overdue} days overdue
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-3 text-right">
                            <div className="flex flex-col items-end">
                              <span className="font-medium">${parseFloat(invoice.amount || 0).toLocaleString()}</span>
                              {invoice.outstanding_amount > 0 && (
                                <span className="text-sm text-orange-600">
                                  ${parseFloat(invoice.outstanding_amount || 0).toLocaleString()} outstanding
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-3 text-center">
                            <Badge 
                              variant={invoice.status === 'paid' ? 'default' : invoice.status === 'open' ? 'secondary' : 'destructive'}
                              className={invoice.status === 'paid' ? 'bg-green-500' : invoice.days_overdue > 0 ? 'bg-red-500' : ''}
                            >
                              {invoice.status}
                            </Badge>
                          </td>
                          <td className="p-3 text-center bg-blue-50">
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-10 w-16 bg-blue-500 hover:bg-blue-600 text-white border-blue-500"
                              onClick={() => {
                                setSelectedInvoiceId(invoice.id);
                                setShowInvoiceDetails(true);
                              }}
                            >
                              ➡️
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No accounts receivable data available
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="aging" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Detailed aging analysis would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="payments" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Payment management interface would appear here
            </div>
          </TabsContent>
          
          <TabsContent value="collections" className="p-4">
            <div className="text-center py-8 text-muted-foreground">
              Collections management interface would appear here
            </div>
          </TabsContent>
        </Tabs>
      </Card>

      {/* Invoice Details Dialog */}
      <Dialog open={showInvoiceDetails} onOpenChange={setShowInvoiceDetails}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Invoice Details - {invoiceDetails?.invoice_number || `Invoice ${selectedInvoiceId}`}
            </DialogTitle>
          </DialogHeader>
          
          {invoiceDetails ? (
            <div className="space-y-6">
              {/* Invoice Summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium">Total Amount</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      ${parseFloat(invoiceDetails.invoice?.amount || invoiceDetails.amount || 0).toLocaleString()}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="h-4 w-4 text-orange-600" />
                      <span className="text-sm font-medium">Outstanding</span>
                    </div>
                    <div className="text-2xl font-bold text-orange-600">
                      ${parseFloat(invoiceDetails.invoice?.outstanding_amount || invoiceDetails.outstanding_amount || 0).toLocaleString()}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-medium">Days Outstanding</span>
                    </div>
                    <div className="text-2xl font-bold text-blue-600">
                      {invoiceDetails.aging_analysis?.days_overdue || invoiceDetails.invoice?.days_overdue || 0}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Customer & Invoice Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Customer Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Customer Name:</span>
                      <div className="font-medium">{invoiceDetails.invoice?.customer_name || 'N/A'}</div>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Customer ID:</span>
                      <div className="font-medium">{invoiceDetails.invoice?.customer_id || 'N/A'}</div>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Credit Limit:</span>
                      <div className="font-medium">${parseFloat(invoiceDetails.invoice?.credit_limit || 0).toLocaleString()}</div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Invoice Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Invoice Date:</span>
                      <div className="font-medium">{invoiceDetails.invoice?.invoice_date ? new Date(invoiceDetails.invoice.invoice_date).toLocaleDateString() : 'N/A'}</div>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Due Date:</span>
                      <div className="font-medium">{invoiceDetails.invoice?.due_date ? new Date(invoiceDetails.invoice.due_date).toLocaleDateString() : 'N/A'}</div>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Status:</span>
                      <div>
                        <Badge 
                          variant={invoiceDetails.invoice?.status === 'paid' ? 'default' : invoiceDetails.invoice?.status === 'open' ? 'secondary' : 'destructive'}
                          className={invoiceDetails.invoice?.status === 'paid' ? 'bg-green-500' : invoiceDetails.aging_analysis?.days_overdue > 30 ? 'bg-red-500' : ''}
                        >
                          {invoiceDetails.invoice?.status || 'Unknown'}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Payment History */}
              {invoiceDetails.payments && invoiceDetails.payments.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      Payment History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th className="text-left p-3 font-medium">Payment Date</th>
                            <th className="text-left p-3 font-medium">Payment Method</th>
                            <th className="text-right p-3 font-medium">Amount</th>
                            <th className="text-left p-3 font-medium">Reference</th>
                          </tr>
                        </thead>
                        <tbody>
                          {invoiceDetails.payments.map((payment: any, index: number) => (
                            <tr key={index} className="border-b hover:bg-muted/50">
                              <td className="p-3">{new Date(payment.payment_date).toLocaleDateString()}</td>
                              <td className="p-3">{payment.payment_method || 'Bank Transfer'}</td>
                              <td className="p-3 text-right font-medium">${parseFloat(payment.payment_amount || payment.amount || 0).toLocaleString()}</td>
                              <td className="p-3">{payment.payment_reference || payment.reference || '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Invoice Line Items */}
              {invoiceDetails.line_items && invoiceDetails.line_items.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Invoice Line Items</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th className="text-left p-3 font-medium">Description</th>
                            <th className="text-right p-3 font-medium">Quantity</th>
                            <th className="text-right p-3 font-medium">Unit Price</th>
                            <th className="text-right p-3 font-medium">Total</th>
                          </tr>
                        </thead>
                        <tbody>
                          {invoiceDetails.line_items.map((item: any, index: number) => (
                            <tr key={index} className="border-b hover:bg-muted/50">
                              <td className="p-3">{item.description}</td>
                              <td className="p-3 text-right">{item.quantity}</td>
                              <td className="p-3 text-right">${parseFloat(item.unit_price).toLocaleString()}</td>
                              <td className="p-3 text-right font-medium">${parseFloat(item.line_amount || item.total_amount || (item.quantity * item.unit_price)).toLocaleString()}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Aging Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Aging Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-sm text-green-600 font-medium">Current (0-30 days)</div>
                      <div className="text-lg font-bold text-green-700">
                        ${invoiceDetails.aging_analysis?.aging_bucket === 'Current' ? parseFloat(invoiceDetails.invoice?.outstanding_amount || 0).toLocaleString() : '0'}
                      </div>
                    </div>
                    <div className="text-center p-4 bg-yellow-50 rounded-lg">
                      <div className="text-sm text-yellow-600 font-medium">31-60 days</div>
                      <div className="text-lg font-bold text-yellow-700">
                        ${invoiceDetails.aging_analysis?.aging_bucket === '31-60 days' ? parseFloat(invoiceDetails.invoice?.outstanding_amount || 0).toLocaleString() : '0'}
                      </div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <div className="text-sm text-orange-600 font-medium">61-90 days</div>
                      <div className="text-lg font-bold text-orange-700">
                        ${invoiceDetails.aging_analysis?.aging_bucket === '61-90 days' ? parseFloat(invoiceDetails.invoice?.outstanding_amount || 0).toLocaleString() : '0'}
                      </div>
                    </div>
                    <div className="text-center p-4 bg-red-50 rounded-lg">
                      <div className="text-sm text-red-600 font-medium">Over 90 days</div>
                      <div className="text-lg font-bold text-red-700">
                        ${invoiceDetails.aging_analysis?.aging_bucket === '90+ days' ? parseFloat(invoiceDetails.invoice?.outstanding_amount || 0).toLocaleString() : '0'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Aging Status:</span>
                      <Badge variant={invoiceDetails.aging_analysis?.is_overdue ? 'destructive' : 'secondary'}>
                        {invoiceDetails.aging_analysis?.aging_bucket || 'Current'}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <span className="font-medium">Days Overdue:</span>
                      <span className={invoiceDetails.aging_analysis?.days_overdue > 0 ? 'text-red-600 font-bold' : 'text-green-600'}>
                        {invoiceDetails.aging_analysis?.days_overdue || 0}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading invoice details...</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Supporting components
type ARCardProps = {
  title: string;
  value: string;
  change: number;
  isPositive: boolean;
  period: string;
  icon: React.ReactNode;
};

function ARCard({ title, value, change, isPositive, period, icon }: ARCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center space-x-1 text-xs mt-1">
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          </span>
          <span className={isPositive ? "text-green-500" : "text-red-500"}>
            {isPositive ? "+" : ""}{change}%
          </span>
          <span className="text-muted-foreground">{period}</span>
        </div>
      </CardContent>
    </Card>
  );
}

type ARCustomerProps = {
  name: string;
  balance: string;
  aging: string;
  creditLimit: string;
};

function ARCustomer({ name, balance, aging, creditLimit }: ARCustomerProps) {
  const isOverdue = aging !== "Current";
  
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{name}</div>
        <div className="text-xs text-muted-foreground">Credit limit: {creditLimit}</div>
      </div>
      <div className="text-right">
        <div className="font-medium">{balance}</div>
        <div className="text-xs">
          {isOverdue ? (
            <Badge variant="destructive" className="text-xs rounded-sm">{aging}</Badge>
          ) : (
            <Badge variant="outline" className="text-xs rounded-sm">{aging}</Badge>
          )}
        </div>
      </div>
    </div>
  );
}

type CollectionActivityProps = {
  customer: string;
  activity: string;
  date: string;
  status: string;
};

function CollectionActivity({ customer, activity, date, status }: CollectionActivityProps) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{customer}</div>
        <div className="text-xs text-muted-foreground">{activity}</div>
      </div>
      <div className="text-right">
        <div className="text-xs text-muted-foreground">{date}</div>
        <div className="text-xs">
          <Badge 
            variant={status === "Completed" ? "default" : status === "Pending" ? "secondary" : "outline"} 
            className={`text-xs rounded-sm ${status === "Completed" ? "bg-green-500" : status === "Pending" ? "bg-amber-500" : ""}`}
          >
            {status}
          </Badge>
        </div>
      </div>
    </div>
  );
}