import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, CreditCard, FileText, Users, DollarSign, Workflow, Shield, CheckCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

// Import tile components
import VendorManagementTile from "./ap-tiles/VendorManagementTile";
import InvoiceProcessingTile from "./ap-tiles/InvoiceProcessingTile";
import PaymentAuthorizationTile from "./ap-tiles/PaymentAuthorizationTile";
import APReportingTile from "./ap-tiles/APReportingTile";
import APWorkflowsTile from "./ap-tiles/APWorkflowsTile";
import APValidationTile from "./ap-tiles/APValidationTile";

export default function APTiles() {
  const [activeTile, setActiveTile] = useState<string | null>(null);

  // Fetch AP statistics for tile overview
  const { data: apStatistics } = useQuery({
    queryKey: ['/api/ap/statistics'],
  });

  const { data: vendorData } = useQuery({
    queryKey: ['/api/ap/vendor-data'],
  });

  const { data: invoiceData } = useQuery({
    queryKey: ['/api/ap/invoice-data'],
  });

  const { data: paymentData } = useQuery({
    queryKey: ['/api/ap/payment-data'],
  });

  const { data: workflowData } = useQuery({
    queryKey: ['/api/ap/workflow-data'],
  });

  const { data: reportData } = useQuery({
    queryKey: ['/api/ap/report-data'],
  });

  const { data: validationData } = useQuery({
    queryKey: ['/api/ap/validation-data'],
  });

  const handleBackToTiles = () => {
    setActiveTile(null);
  };

  // If a tile is active, show the tile component
  if (activeTile) {
    const TileComponent = {
      'vendor-management': VendorManagementTile,
      'invoice-processing': InvoiceProcessingTile,
      'payment-authorization': PaymentAuthorizationTile,
      'ap-reporting': APReportingTile,
      'ap-workflows': APWorkflowsTile,
      'ap-validation': APValidationTile,
    }[activeTile];

    if (TileComponent) {
      return (
        <div className="h-screen flex flex-col">
          {/* Tile Header */}
          <div className="flex items-center justify-between p-4 border-b bg-white">
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handleBackToTiles}
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to AP Tiles</span>
              </Button>
              <h1 className="text-xl font-bold">
                {activeTile.split('-').map(word => 
                  word.charAt(0).toUpperCase() + word.slice(1)
                ).join(' ')}
              </h1>
            </div>
          </div>
          
          {/* Tile Content */}
          <div className="flex-1 p-4 overflow-hidden">
            <TileComponent onBack={handleBackToTiles} />
          </div>
        </div>
      );
    }
  }

  // Main tiles overview
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Accounts Payable - Tile System</h1>
          <p className="text-gray-600 mt-2">Complete AP end-to-end process with vendor details, payments, and integrated workflows</p>
        </div>
        <Button
          variant="outline"
          onClick={() => window.location.href = '/finance'}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Finance</span>
        </Button>
      </div>

      {/* AP Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Vendors</p>
                <p className="text-2xl font-bold text-blue-600">
                  {vendorData?.total_vendors || 0}
                </p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Invoices</p>
                <p className="text-2xl font-bold text-orange-600">
                  {invoiceData?.pending_invoices || 0}
                </p>
              </div>
              <FileText className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Outstanding Amount</p>
                <p className="text-2xl font-bold text-red-600">
                  ${paymentData?.outstanding_amount?.toFixed(2) || '0.00'}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Data Integrity</p>
                <p className="text-2xl font-bold text-green-600">
                  {validationData?.integrity_score || 0}%
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AP Process Flow */}
      <Card className="border-green-200 bg-gradient-to-r from-green-50 to-emerald-100">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-green-900">AP End-to-End Process Flow</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <div className="text-center p-3 bg-white rounded-lg border border-green-200">
              <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <p className="text-sm font-medium">Vendor Setup</p>
              <p className="text-xs text-gray-600">Master data, terms, limits</p>
            </div>
            <div className="text-center p-3 bg-white rounded-lg border border-green-200">
              <FileText className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <p className="text-sm font-medium">Invoice Receipt</p>
              <p className="text-xs text-gray-600">Processing, validation</p>
            </div>
            <div className="text-center p-3 bg-white rounded-lg border border-green-200">
              <Shield className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <p className="text-sm font-medium">Approval</p>
              <p className="text-xs text-gray-600">Workflow, authorization</p>
            </div>
            <div className="text-center p-3 bg-white rounded-lg border border-green-200">
              <CreditCard className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <p className="text-sm font-medium">Payment</p>
              <p className="text-xs text-gray-600">Authorization, processing</p>
            </div>
            <div className="text-center p-3 bg-white rounded-lg border border-green-200">
              <FileText className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <p className="text-sm font-medium">Reporting</p>
              <p className="text-xs text-gray-600">Analytics, compliance</p>
            </div>
            <div className="text-center p-3 bg-white rounded-lg border border-green-200">
              <CheckCircle className="h-8 w-8 text-emerald-600 mx-auto mb-2" />
              <p className="text-sm font-medium">Validation</p>
              <p className="text-xs text-gray-600">Data integrity check</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AP Tiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Vendor Management Tile */}
        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-blue-200 hover:border-blue-400"
          onClick={() => setActiveTile('vendor-management')}
        >
          <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Users className="h-8 w-8 text-blue-600" />
                <div>
                  <CardTitle className="text-lg">Vendor Management</CardTitle>
                  <p className="text-sm text-blue-700">Complete vendor details & setup</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium text-blue-600">Active Vendors</p>
                <p className="text-xl font-bold">{vendorData?.active_vendors || 0}</p>
              </div>
              <div>
                <p className="font-medium text-green-600">Payment Terms</p>
                <p className="text-xl font-bold">{vendorData?.avg_payment_terms || 0} days</p>
              </div>
              <div>
                <p className="font-medium text-purple-600">Credit Limits</p>
                <p className="text-lg font-bold">${vendorData?.total_credit_limits?.toFixed(0) || '0'}</p>
              </div>
              <div>
                <p className="font-medium text-orange-600">New This Month</p>
                <p className="text-xl font-bold">{vendorData?.new_vendors || 0}</p>
              </div>
            </div>
            <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">
              Manage Vendors →
            </Button>
          </CardContent>
        </Card>

        {/* Invoice Processing Tile */}
        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-orange-200 hover:border-orange-400"
          onClick={() => setActiveTile('invoice-processing')}
        >
          <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <FileText className="h-8 w-8 text-orange-600" />
                <div>
                  <CardTitle className="text-lg">Invoice Processing</CardTitle>
                  <p className="text-sm text-orange-700">Receipt, validation & approval</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium text-orange-600">Pending</p>
                <p className="text-xl font-bold">{invoiceData?.pending || 0}</p>
              </div>
              <div>
                <p className="font-medium text-green-600">Approved</p>
                <p className="text-xl font-bold">{invoiceData?.approved || 0}</p>
              </div>
              <div>
                <p className="font-medium text-blue-600">Total Value</p>
                <p className="text-lg font-bold">${invoiceData?.total_value?.toFixed(0) || '0'}</p>
              </div>
              <div>
                <p className="font-medium text-red-600">Overdue</p>
                <p className="text-xl font-bold">{invoiceData?.overdue || 0}</p>
              </div>
            </div>
            <Button className="w-full mt-4 bg-orange-600 hover:bg-orange-700">
              Process Invoices →
            </Button>
          </CardContent>
        </Card>

        {/* Payment Authorization Tile */}
        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-green-200 hover:border-green-400"
          onClick={() => setActiveTile('payment-authorization')}
        >
          <CardHeader className="bg-gradient-to-r from-green-50 to-green-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <CreditCard className="h-8 w-8 text-green-600" />
                <div>
                  <CardTitle className="text-lg">Payment Authorization</CardTitle>
                  <p className="text-sm text-green-700">Approval limits & processing</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium text-green-600">Authorized</p>
                <p className="text-xl font-bold">{paymentData?.authorized || 0}</p>
              </div>
              <div>
                <p className="font-medium text-blue-600">Processing</p>
                <p className="text-xl font-bold">{paymentData?.processing || 0}</p>
              </div>
              <div>
                <p className="font-medium text-purple-600">Daily Limit</p>
                <p className="text-lg font-bold">${paymentData?.daily_limit?.toFixed(0) || '0'}</p>
              </div>
              <div>
                <p className="font-medium text-orange-600">Pending Auth</p>
                <p className="text-xl font-bold">{paymentData?.pending_auth || 0}</p>
              </div>
            </div>
            <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">
              Authorize Payments →
            </Button>
          </CardContent>
        </Card>

        {/* AP Reporting Tile */}
        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-purple-200 hover:border-purple-400"
          onClick={() => setActiveTile('ap-reporting')}
        >
          <CardHeader className="bg-gradient-to-r from-purple-50 to-purple-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <FileText className="h-8 w-8 text-purple-600" />
                <div>
                  <CardTitle className="text-lg">AP Reporting</CardTitle>
                  <p className="text-sm text-purple-700">Analytics & compliance reports</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium text-purple-600">Reports Generated</p>
                <p className="text-xl font-bold">{reportData?.generated || 0}</p>
              </div>
              <div>
                <p className="font-medium text-green-600">Compliance Score</p>
                <p className="text-xl font-bold">{reportData?.compliance_score || 0}%</p>
              </div>
              <div>
                <p className="font-medium text-blue-600">DPO</p>
                <p className="text-xl font-bold">{reportData?.dpo || 0} days</p>
              </div>
              <div>
                <p className="font-medium text-orange-600">Cost Savings</p>
                <p className="text-lg font-bold">${reportData?.cost_savings?.toFixed(0) || '0'}</p>
              </div>
            </div>
            <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700">
              View Reports →
            </Button>
          </CardContent>
        </Card>

        {/* AP Workflows Tile */}
        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-indigo-200 hover:border-indigo-400"
          onClick={() => setActiveTile('ap-workflows')}
        >
          <CardHeader className="bg-gradient-to-r from-indigo-50 to-indigo-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Workflow className="h-8 w-8 text-indigo-600" />
                <div>
                  <CardTitle className="text-lg">AP Workflows</CardTitle>
                  <p className="text-sm text-indigo-700">Automation & integration</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium text-indigo-600">Active Workflows</p>
                <p className="text-xl font-bold">{workflowData?.active || 0}</p>
              </div>
              <div>
                <p className="font-medium text-green-600">Success Rate</p>
                <p className="text-xl font-bold">{workflowData?.success_rate || 0}%</p>
              </div>
              <div>
                <p className="font-medium text-blue-600">Executions</p>
                <p className="text-xl font-bold">{workflowData?.executions || 0}</p>
              </div>
              <div>
                <p className="font-medium text-orange-600">Savings</p>
                <p className="text-lg font-bold">${workflowData?.savings?.toFixed(0) || '0'}</p>
              </div>
            </div>
            <Button className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700">
              Manage Workflows →
            </Button>
          </CardContent>
        </Card>

        {/* AP Validation Tile */}
        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-emerald-200 hover:border-emerald-400"
          onClick={() => setActiveTile('ap-validation')}
        >
          <CardHeader className="bg-gradient-to-r from-emerald-50 to-emerald-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Shield className="h-8 w-8 text-emerald-600" />
                <div>
                  <CardTitle className="text-lg">CrossCheck Validation</CardTitle>
                  <p className="text-sm text-emerald-700">Data integrity & lineage</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium text-emerald-600">Integrity Score</p>
                <p className="text-xl font-bold">{validationData?.integrity_score || 0}%</p>
              </div>
              <div>
                <p className="font-medium text-green-600">Validated Records</p>
                <p className="text-xl font-bold">{validationData?.validated || 0}</p>
              </div>
              <div>
                <p className="font-medium text-blue-600">Issues Found</p>
                <p className="text-xl font-bold">{validationData?.issues || 0}</p>
              </div>
              <div>
                <p className="font-medium text-purple-600">Last Check</p>
                <p className="text-sm font-bold">{validationData?.last_check || 'Never'}</p>
              </div>
            </div>
            <Button className="w-full mt-4 bg-emerald-600 hover:bg-emerald-700">
              Run Validation →
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}