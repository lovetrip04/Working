import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, AlertTriangle, RefreshCw, Database, FileCheck, GitBranch } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface APValidationTileProps {
  onBack: () => void;
}

export default function APValidationTile({ onBack }: APValidationTileProps) {
  const [validationType, setValidationType] = useState("");
  const [selectedVendor, setSelectedVendor] = useState("");
  const [dateRange, setDateRange] = useState("");
  const [showValidationForm, setShowValidationForm] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch AP validation results
  const { data: validationResults, isLoading } = useQuery({
    queryKey: ['/api/ap/crosscheck-validation'],
  });

  // Fetch AP lineage data
  const { data: lineageData } = useQuery({
    queryKey: ['/api/ap/data-lineage'],
  });

  // Fetch AP integrity metrics
  const { data: integrityMetrics } = useQuery({
    queryKey: ['/api/ap/integrity-metrics'],
  });

  // Fetch vendors for validation filtering
  const { data: vendors } = useQuery({
    queryKey: ['/api/ap/vendors'],
  });

  // Run AP validation mutation
  const runValidationMutation = useMutation({
    mutationFn: async (validationData: any) => {
      return await apiRequest('/api/ap/run-crosscheck-validation', {
        method: 'POST',
        body: JSON.stringify(validationData),
      });
    },
    onSuccess: () => {
      toast({
        title: "Validation Completed",
        description: "AP CrossCheck validation has been completed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ap/crosscheck-validation'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ap/integrity-metrics'] });
      setShowValidationForm(false);
    },
    onError: (error) => {
      toast({
        title: "Validation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Fix data integrity mutation
  const fixIntegrityMutation = useMutation({
    mutationFn: async (fixData: any) => {
      return await apiRequest('/api/ap/fix-data-integrity', {
        method: 'POST',
        body: JSON.stringify(fixData),
      });
    },
    onSuccess: () => {
      toast({
        title: "Data Fixed",
        description: "AP data integrity issues have been resolved.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ap/crosscheck-validation'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ap/integrity-metrics'] });
    },
    onError: (error) => {
      toast({
        title: "Fix Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleRunValidation = () => {
    if (!validationType) {
      toast({
        title: "Missing Information",
        description: "Please select validation type.",
        variant: "destructive",
      });
      return;
    }

    runValidationMutation.mutate({
      validation_type: validationType,
      vendor_id: selectedVendor || null,
      date_range: dateRange || null,
      triggered_by: 'Current User',
      triggered_date: new Date().toISOString(),
    });
  };

  const handleFixIntegrity = (issueId: string, fixType: string) => {
    fixIntegrityMutation.mutate({
      issue_id: issueId,
      fix_type: fixType,
      fixed_by: 'Current User',
      fixed_date: new Date().toISOString(),
    });
  };

  const getValidationStatusBadge = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'passed':
        return <Badge className="bg-green-500 text-white">Passed</Badge>;
      case 'failed':
        return <Badge className="bg-red-500 text-white">Failed</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-500 text-white">Warning</Badge>;
      case 'running':
        return <Badge className="bg-blue-500 text-white">Running</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical':
        return <Badge className="bg-red-800 text-white">Critical</Badge>;
      case 'high':
        return <Badge className="bg-red-500 text-white">High</Badge>;
      case 'medium':
        return <Badge className="bg-orange-500 text-white">Medium</Badge>;
      case 'low':
        return <Badge className="bg-yellow-500 text-white">Low</Badge>;
      default:
        return <Badge variant="outline">{severity}</Badge>;
    }
  };

  return (
    <div className="space-y-6 h-full overflow-y-auto">
      {/* AP CrossCheck Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Data Integrity Score</p>
                <p className="text-2xl font-bold text-green-600">
                  {(integrityMetrics?.overall_score ?? 0)}%
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Critical Issues</p>
                <p className="text-2xl font-bold text-red-600">
                  {Array.isArray(validationResults) ? validationResults.filter((r) => r.severity === 'critical').length || 0}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Vendors Validated</p>
                <p className="text-2xl font-bold text-blue-600">
                  {(lineageData?.vendors_validated ?? 0)}
                </p>
              </div>
              <GitBranch className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Last Validation</p>
                <p className="text-sm font-bold text-purple-600">
                  {integrityMetrics?.last_validation ? 
                    new Date((integrityMetrics?.last_validation ?? {)}).toLocaleDateString() : 'Never'}
                </p>
              </div>
              <RefreshCw className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Validation Form */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Run AP CrossCheck Validation</CardTitle>
            <Button
              onClick={() => setShowValidationForm(!showValidationForm)}
              variant={showValidationForm ? "outline" : "default"}
            >
              {showValidationForm ? 'Hide Form' : 'New Validation'}
            </Button>
          </div>
        </CardHeader>
        {showValidationForm && (
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Validation Type</Label>
                <Select value={validationType} onValueChange={setValidationType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select validation type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full_system">Full AP System Validation</SelectItem>
                    <SelectItem value="vendor_lineage">Vendor Data Lineage</SelectItem>
                    <SelectItem value="invoice_integrity">Invoice Integrity</SelectItem>
                    <SelectItem value="payment_validation">Payment Validation</SelectItem>
                    <SelectItem value="three_way_match">Three-Way Match Validation</SelectItem>
                    <SelectItem value="gl_reconciliation">GL Reconciliation</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Vendor (Optional)</Label>
                <Select value={selectedVendor} onValueChange={setSelectedVendor}>
                  <SelectTrigger>
                    <SelectValue placeholder="All vendors" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Vendors</SelectItem>
                    {Array.isArray(vendors) ? vendors.map((vendor) => (
                      <SelectItem key={vendor.id} value={vendor.id.toString()}>
                        {vendor.name}
                      </SelectItem>
                    )) : null}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Date Range</Label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select date range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last_7_days">Last 7 Days</SelectItem>
                    <SelectItem value="last_30_days">Last 30 Days</SelectItem>
                    <SelectItem value="last_90_days">Last 90 Days</SelectItem>
                    <SelectItem value="current_year">Current Year</SelectItem>
                    <SelectItem value="all_time">All Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-end mt-4">
              <Button 
                onClick={handleRunValidation}
                disabled={runValidationMutation.isPending}
              >
                {runValidationMutation.isPending ? 'Running Validation...' : 'Run Validation'}
              </Button>
            </div>
          </CardContent>
        )}
      </Card>

      {/* AP Data Lineage Overview */}
      <Card>
        <CardHeader>
          <CardTitle>AP Data Lineage Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Database className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">
                {(lineageData?.company_codes_validated ?? 0)}
              </p>
              <p className="text-sm text-blue-600">Company Codes</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <FileCheck className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">
                {(lineageData?.vendors_validated ?? 0)}
              </p>
              <p className="text-sm text-green-600">Vendors</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <GitBranch className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">
                {(lineageData?.invoices_validated ?? 0)}
              </p>
              <p className="text-sm text-purple-600">Invoices</p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <CheckCircle className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">
                {(lineageData?.payments_validated ?? 0)}
              </p>
              <p className="text-sm text-orange-600">Payments</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Three-Way Match Validation */}
      <Card>
        <CardHeader>
          <CardTitle>Three-Way Match Validation Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">
                {(lineageData?.three_way_matched ?? 0)}
              </p>
              <p className="text-sm text-green-600">Perfect Matches</p>
              <p className="text-xs text-gray-600">PO + Invoice + Receipt</p>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <p className="text-2xl font-bold text-yellow-600">
                {(lineageData?.two_way_matched ?? 0)}
              </p>
              <p className="text-sm text-yellow-600">Two-Way Matches</p>
              <p className="text-xs text-gray-600">Missing one component</p>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <p className="text-2xl font-bold text-red-600">
                {(lineageData?.no_match ?? 0)}
              </p>
              <p className="text-sm text-red-600">No Matches</p>
              <p className="text-xs text-gray-600">Requires investigation</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Validation Results */}
      <Card>
        <CardHeader>
          <CardTitle>AP Validation Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto max-h-96 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Validation Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Affected Records</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center">Loading...</TableCell>
                  </TableRow>
                ) : !validationResults || validationResults.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-green-600">
                      All validations passed - No issues found
                    </TableCell>
                  </TableRow>
                ) : (
                  Array.isArray(validationResults) ? validationResults.map((result) => (
                    <TableRow key={result.id}>
                      <TableCell className="font-medium">{result.validation_type.replace('_', ' ')}</TableCell>
                      <TableCell>{getValidationStatusBadge(result.status)}</TableCell>
                      <TableCell>{getSeverityBadge(result.severity)}</TableCell>
                      <TableCell className="max-w-xs">{result.description}</TableCell>
                      <TableCell>{result.affected_records || 0}</TableCell>
                      <TableCell>
                        {result.status === 'failed' && (
                          <Button
                            size="sm"
                            onClick={() => handleFixIntegrity(result.id, result.fix_type)}
                            disabled={fixIntegrityMutation.isPending}
                          >
                            Fix Issue
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* AP Data Integrity Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>AP Data Integrity Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Vendor Master Data</span>
                  <span className="text-sm font-bold text-green-600">
                    {(integrityMetrics?.vendor_data_score ?? 0)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full" 
                    style={{ width: `${(integrityMetrics?.vendor_data_score ?? 0)}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Invoice Integrity</span>
                  <span className="text-sm font-bold text-blue-600">
                    {(integrityMetrics?.invoice_integrity_score ?? 0)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full" 
                    style={{ width: `${(integrityMetrics?.invoice_integrity_score ?? 0)}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Payment Integrity</span>
                  <span className="text-sm font-bold text-purple-600">
                    {(integrityMetrics?.payment_integrity_score ?? 0)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-purple-600 h-2 rounded-full" 
                    style={{ width: `${(integrityMetrics?.payment_integrity_score ?? 0)}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Three-Way Match Rate</span>
                  <span className="text-sm font-bold text-orange-600">
                    {(integrityMetrics?.three_way_match_rate ?? 0)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-orange-600 h-2 rounded-full" 
                    style={{ width: `${(integrityMetrics?.three_way_match_rate ?? 0)}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Compliance Status */}
      <Card>
        <CardHeader>
          <CardTitle>AP Compliance Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
              <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <p className="text-lg font-bold text-green-600">
                {(integrityMetrics?.sox_compliance ?? 0)}%
              </p>
              <p className="text-sm text-green-600">SOX Compliance</p>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-200">
              <FileCheck className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <p className="text-lg font-bold text-blue-600">
                {(integrityMetrics?.audit_readiness ?? 0)}%
              </p>
              <p className="text-sm text-blue-600">Audit Readiness</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg border border-purple-200">
              <Database className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <p className="text-lg font-bold text-purple-600">
                {(integrityMetrics?.data_governance ?? 0)}%
              </p>
              <p className="text-sm text-purple-600">Data Governance</p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg border border-orange-200">
              <GitBranch className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <p className="text-lg font-bold text-orange-600">
                {(integrityMetrics?.control_effectiveness ?? 0)}%
              </p>
              <p className="text-sm text-orange-600">Control Effectiveness</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}