import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { FileText, Download, Calendar, TrendingUp, BarChart3, PieChart } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface APReportingTileProps {
  onBack: () => void;
}

export default function APReportingTile({ onBack }: APReportingTileProps) {
  const [reportType, setReportType] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [vendorFilter, setVendorFilter] = useState("");
  const [showReportForm, setShowReportForm] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch AP reports
  const { data: apReports, isLoading } = useQuery({
    queryKey: ['/api/ap/reports'],
  });

  // Fetch DPO analysis (Days Payable Outstanding)
  const { data: dpoAnalysis } = useQuery({
    queryKey: ['/api/ap/dpo-analysis'],
  });

  // Fetch cash flow analysis
  const { data: cashFlowAnalysis } = useQuery({
    queryKey: ['/api/ap/cash-flow-analysis'],
  });

  // Fetch vendor performance metrics
  const { data: vendorPerformance } = useQuery({
    queryKey: ['/api/ap/vendor-performance'],
  });

  // Fetch payment analysis
  const { data: paymentAnalysis } = useQuery({
    queryKey: ['/api/ap/payment-analysis'],
  });

  // Fetch vendors for report filtering
  const { data: vendors } = useQuery({
    queryKey: ['/api/ap/vendors'],
  });

  // Generate report mutation
  const generateReportMutation = useMutation({
    mutationFn: async (reportData: any) => {
      return await apiRequest('/api/ap/generate-report', {
        method: 'POST',
        body: JSON.stringify(reportData),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Report Generated",
        description: "AP report has been generated successfully and is ready for download.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ap/reports'] });
      if ((data?.download_url ?? "")) {
        window.open((data?.download_url ?? ""), '_blank');
      }
      setShowReportForm(false);
    },
    onError: (error) => {
      toast({
        title: "Report Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerateReport = () => {
    if (!reportType || !dateFrom || !dateTo) {
      toast({
        title: "Missing Information",
        description: "Please select report type and date range.",
        variant: "destructive",
      });
      return;
    }

    generateReportMutation.mutate({
      report_type: reportType,
      date_from: dateFrom,
      date_to: dateTo,
      vendor_filter: vendorFilter || null,
      generated_by: 'Current User',
      generated_date: new Date().toISOString(),
    });
  };

  const downloadReport = async (reportId: string) => {
    try {
      const response = await apiRequest(`/api/ap/download-report/${reportId}`);
      if ((response?.download_url ?? "")) {
        window.open((response?.download_url ?? ""), '_blank');
      }
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download report.",
        variant: "destructive",
      });
    }
  };

  const getReportTypeBadge = (type: string) => {
    const typeMap: { [key: string]: { color: string; label: string } } = {
      'vendor_analysis': { color: 'bg-blue-500', label: 'Vendor Analysis' },
      'payment_analysis': { color: 'bg-green-500', label: 'Payment Analysis' },
      'cash_flow_forecast': { color: 'bg-purple-500', label: 'Cash Flow' },
      'dpo_analysis': { color: 'bg-orange-500', label: 'DPO Analysis' },
      'compliance_report': { color: 'bg-red-500', label: 'Compliance' },
    };
    const config = typeMap[type] || { color: 'bg-gray-500', label: type };
    return <Badge className={`${config.color} text-white`}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-6 h-full overflow-y-auto">
      {/* AP Reporting Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Current DPO</p>
                <p className="text-2xl font-bold text-blue-600">
                  {(dpoAnalysis?.current_dpo ?? 0)} days
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Payment Efficiency</p>
                <p className="text-2xl font-bold text-green-600">
                  {(paymentAnalysis?.efficiency_score ?? 0)}%
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">30-Day Payables</p>
                <p className="text-2xl font-bold text-purple-600">
                  ${cashFlowAnalysis?.next_30_days?.toFixed(0) || '0'}
                </p>
              </div>
              <PieChart className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Reports Generated</p>
                <p className="text-2xl font-bold text-orange-600">
                  {Array.isArray(apReports) ? apReports.filter((report) => 
                    new Date(report.generated_date).getMonth() === new Date().getMonth()
                  ).length : 0}
                </p>
              </div>
              <FileText className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Generation Form */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Generate AP Report</CardTitle>
            <Button
              onClick={() => setShowReportForm(!showReportForm)}
              variant={showReportForm ? "outline" : "default"}
            >
              {showReportForm ? 'Hide Form' : 'New Report'}
            </Button>
          </div>
        </CardHeader>
        {showReportForm && (
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>Report Type</Label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select report type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vendor_analysis">Vendor Analysis</SelectItem>
                    <SelectItem value="payment_analysis">Payment Analysis</SelectItem>
                    <SelectItem value="cash_flow_forecast">Cash Flow Forecast</SelectItem>
                    <SelectItem value="dpo_analysis">DPO Analysis</SelectItem>
                    <SelectItem value="compliance_report">Compliance Report</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>From Date</Label>
                <Input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label>To Date</Label>
                <Input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Vendor (Optional)</Label>
                <Select value={vendorFilter} onValueChange={setVendorFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All vendors" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Vendors</SelectItem>
                    {Array.isArray(vendors) ? vendors.map((vendor) => (
                      <SelectItem key={vendor.id} value={vendor.id.toString()}>
                        {vendor.name}
                      </SelectItem>
                    )) : null}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-end mt-4">
              <Button 
                onClick={handleGenerateReport}
                disabled={generateReportMutation.isPending}
              >
                {generateReportMutation.isPending ? 'Generating...' : 'Generate Report'}
              </Button>
            </div>
          </CardContent>
        )}
      </Card>

      {/* DPO Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Days Payable Outstanding (DPO) Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-600">
                {(dpoAnalysis?.current_dpo ?? 0)}
              </p>
              <p className="text-sm text-blue-600">Current DPO</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">
                {(dpoAnalysis?.target_dpo ?? 0)}
              </p>
              <p className="text-sm text-green-600">Target DPO</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <p className="text-2xl font-bold text-purple-600">
                {(dpoAnalysis?.industry_average ?? 0)}
              </p>
              <p className="text-sm text-purple-600">Industry Average</p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">
                {dpoAnalysis?.trend_direction === 'up' ? '↑' : dpoAnalysis?.trend_direction === 'down' ? '↓' : '→'} {(dpoAnalysis?.trend_percentage ?? 0)}%
              </p>
              <p className="text-sm text-orange-600">Trend</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Vendor Performance Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Top Vendor Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Vendor Name</TableHead>
                  <TableHead>Total Spend</TableHead>
                  <TableHead>Payment Terms</TableHead>
                  <TableHead>On-Time Performance</TableHead>
                  <TableHead>Discount Capture</TableHead>
                  <TableHead>Performance Score</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(Array.isArray(vendorPerformance) ? vendorPerformance.slice() : []).map((vendor: any) => (
                  <TableRow key={vendor.id}>
                    <TableCell className="font-medium">{vendor.name}</TableCell>
                    <TableCell>${vendor?.total_spend?.toFixed(2) || '0.00'}</TableCell>
                    <TableCell>Net {vendor.payment_terms} days</TableCell>
                    <TableCell>
                      <Badge className={vendor.on_time_performance >= 90 ? 'bg-green-500' : vendor.on_time_performance >= 75 ? 'bg-yellow-500' : 'bg-red-500'}>
                        {vendor.on_time_performance || 0}%
                      </Badge>
                    </TableCell>
                    <TableCell>{vendor.discount_capture || 0}%</TableCell>
                    <TableCell>
                      <Badge className={vendor.performance_score >= 85 ? 'bg-green-500' : vendor.performance_score >= 70 ? 'bg-yellow-500' : 'bg-red-500'}>
                        {vendor.performance_score || 0}
                      </Badge>
                    </TableCell>
                  </TableRow>
                )) || (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-gray-500">
                      No vendor performance data available
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Cash Flow Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Cash Flow Analysis (Next 90 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <p className="text-2xl font-bold text-red-600">
                ${cashFlowAnalysis?.next_30_days?.toFixed(0) || '0'}
              </p>
              <p className="text-sm text-red-600">Next 30 Days</p>
              <p className="text-xs text-gray-600">
                {(cashFlowAnalysis?.next_30_count ?? 0)} payments
              </p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">
                ${cashFlowAnalysis?.next_60_days?.toFixed(0) || '0'}
              </p>
              <p className="text-sm text-orange-600">Next 60 Days</p>
              <p className="text-xs text-gray-600">
                {(cashFlowAnalysis?.next_60_count ?? 0)} payments
              </p>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <p className="text-2xl font-bold text-yellow-600">
                ${cashFlowAnalysis?.next_90_days?.toFixed(0) || '0'}
              </p>
              <p className="text-sm text-yellow-600">Next 90 Days</p>
              <p className="text-xs text-gray-600">
                {(cashFlowAnalysis?.next_90_count ?? 0)} payments
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Method Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Method Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-600">
                {(paymentAnalysis?.ach_percentage ?? 0)}%
              </p>
              <p className="text-sm text-blue-600">ACH Transfers</p>
              <p className="text-xs text-gray-600">
                ${paymentAnalysis?.ach_amount?.toFixed(0) || '0'}
              </p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <p className="text-2xl font-bold text-purple-600">
                {(paymentAnalysis?.wire_percentage ?? 0)}%
              </p>
              <p className="text-sm text-purple-600">Wire Transfers</p>
              <p className="text-xs text-gray-600">
                ${paymentAnalysis?.wire_amount?.toFixed(0) || '0'}
              </p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">
                {(paymentAnalysis?.check_percentage ?? 0)}%
              </p>
              <p className="text-sm text-green-600">Checks</p>
              <p className="text-xs text-gray-600">
                ${paymentAnalysis?.check_amount?.toFixed(0) || '0'}
              </p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">
                {(paymentAnalysis?.card_percentage ?? 0)}%
              </p>
              <p className="text-sm text-orange-600">Cards</p>
              <p className="text-xs text-gray-600">
                ${paymentAnalysis?.card_amount?.toFixed(0) || '0'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Recent AP Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto max-h-64 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Report Type</TableHead>
                  <TableHead>Date Range</TableHead>
                  <TableHead>Generated Date</TableHead>
                  <TableHead>Generated By</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center">Loading...</TableCell>
                  </TableRow>
                ) : !apReports || apReports.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-gray-500">
                      No reports found
                    </TableCell>
                  </TableRow>
                ) : (
                  (Array.isArray(apReports) ? apReports.slice() : []).map((report: any) => (
                    <TableRow key={report.id}>
                      <TableCell>{getReportTypeBadge(report.report_type)}</TableCell>
                      <TableCell>
                        {new Date(report.date_from).toLocaleDateString()} - {new Date(report.date_to).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{new Date(report.generated_date).toLocaleDateString()}</TableCell>
                      <TableCell>{report.generated_by}</TableCell>
                      <TableCell>
                        <Badge className={report.status === 'completed' ? 'bg-green-500 text-white' : 'bg-yellow-500 text-white'}>
                          {report.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => downloadReport(report.id)}
                          disabled={report.status !== 'completed'}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}