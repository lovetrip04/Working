import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, CreditCard, Check, X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface PaymentProcessingTileProps {
  onBack: () => void;
}

export default function PaymentProcessingTile({ onBack }: PaymentProcessingTileProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [paymentReference, setPaymentReference] = useState("");
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch outstanding invoices
  const { data: outstandingInvoices, isLoading } = useQuery({
    queryKey: ['/api/ar/outstanding-invoices'],
  });

  // Fetch payment methods
  const { data: paymentMethods } = useQuery({
    queryKey: ['/api/ar/payment-methods'],
  });

  // Fetch recent payments
  const { data: recentPayments } = useQuery({
    queryKey: ['/api/ar/recent-payments'],
  });

  // Process payment mutation
  const processPaymentMutation = useMutation({
    mutationFn: async (paymentData: any) => {
      return await apiRequest('/api/ar/process-payment', {
        method: 'POST',
        body: JSON.stringify(paymentData),
      });
    },
    onSuccess: () => {
      toast({
        title: "Payment Processed",
        description: "Payment has been successfully recorded and posted to GL.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ar/outstanding-invoices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ar/recent-payments'] });
      setShowPaymentForm(false);
      setSelectedInvoice(null);
      setPaymentAmount("");
      setPaymentReference("");
    },
    onError: (error) => {
      toast({
        title: "Payment Processing Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleProcessPayment = () => {
    if (!selectedInvoice || !paymentAmount || !paymentMethod) {
      toast({
        title: "Missing Information",
        description: "Please select an invoice, enter payment amount, and choose payment method.",
        variant: "destructive",
      });
      return;
    }

    processPaymentMutation.mutate({
      invoice_id: selectedInvoice.id,
      amount: parseFloat(paymentAmount),
      payment_method: paymentMethod,
      reference: paymentReference,
      payment_date: new Date().toISOString(),
    });
  };

  const filteredInvoices = Array.isArray(outstandingInvoices) 
    ? outstandingInvoices.filter((invoice: any) =>
        invoice.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoice.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'outstanding':
        return <Badge variant="destructive">Outstanding</Badge>;
      case 'partial':
        return <Badge className="bg-yellow-500 text-white">Partial</Badge>;
      case 'paid':
        return <Badge className="bg-green-500 text-white">Paid</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6 h-full overflow-y-auto">
      {/* Payment Processing Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Outstanding Amount</p>
                <p className="text-2xl font-bold text-red-600">
                  ${Array.isArray(outstandingInvoices) ? outstandingInvoices.reduce((sum, inv) => sum + parseFloat(inv.outstanding_amount || 0), 0).toFixed(2) : '0.00'}
                </p>
              </div>
              <CreditCard className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Processed Today</p>
                <p className="text-2xl font-bold text-green-600">
                  ${Array.isArray(recentPayments) ? recentPayments.filter((p) => new Date(p.payment_date).toDateString() === new Date().toDateString())
                    .reduce((sum: number, p: any) => sum + parseFloat(p.amount), 0).toFixed(2) : '0.00'}
                </p>
              </div>
              <Check className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Outstanding Invoices</p>
                <p className="text-2xl font-bold text-blue-600">
                  {(outstandingInvoices?.length ?? 0)}
                </p>
              </div>
              <X className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment Form */}
      {showPaymentForm && (
        <Card>
          <CardHeader>
            <CardTitle>Process Payment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Selected Invoice</Label>
                <Input
                  value={selectedInvoice ? `${selectedInvoice.invoice_number} - ${selectedInvoice.customer_name}` : ''}
                  disabled
                />
              </div>
              
              <div className="space-y-2">
                <Label>Outstanding Amount</Label>
                <Input
                  value={selectedInvoice ? `$${selectedInvoice.outstanding_amount}` : ''}
                  disabled
                />
              </div>
              
              <div className="space-y-2">
                <Label>Payment Amount</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  placeholder="Enter payment amount"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Payment Method</Label>
                <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.isArray(paymentMethods) ? paymentMethods.map((method) => (
                      <SelectItem key={method.id} value={method.method_code}>
                        {method.method_name}
                      </SelectItem>
                    )) : null}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2 md:col-span-2">
                <Label>Payment Reference</Label>
                <Input
                  value={paymentReference}
                  onChange={(e) => setPaymentReference(e.target.value)}
                  placeholder="Enter payment reference/check number"
                />
              </div>
            </div>
            
            <div className="flex justify-end space-x-2 mt-4">
              <Button variant="outline" onClick={() => setShowPaymentForm(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleProcessPayment}
                disabled={processPaymentMutation.isPending}
              >
                {processPaymentMutation.isPending ? 'Processing...' : 'Process Payment'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Outstanding Invoices */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Outstanding Invoices</CardTitle>
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search invoices..."
                  className="pl-8 w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto max-h-96 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice Number</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Outstanding Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center">Loading...</TableCell>
                  </TableRow>
                ) : filteredInvoices.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-gray-500">
                      No outstanding invoices found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInvoices.map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell className="font-medium">{invoice.invoice_number}</TableCell>
                      <TableCell>{invoice.customer_name}</TableCell>
                      <TableCell>{new Date(invoice.due_date).toLocaleDateString()}</TableCell>
                      <TableCell>${parseFloat(invoice.outstanding_amount).toFixed(2)}</TableCell>
                      <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          onClick={() => {
                            setSelectedInvoice(invoice);
                            setPaymentAmount(invoice.outstanding_amount);
                            setShowPaymentForm(true);
                          }}
                        >
                          Process Payment
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Recent Payments */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Payments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto max-h-64 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Payment Date</TableHead>
                  <TableHead>Invoice Number</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Reference</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(Array.isArray(recentPayments) ? recentPayments.slice() : []).map((payment: any) => (
                  <TableRow key={payment.id}>
                    <TableCell>{new Date(payment.payment_date).toLocaleDateString()}</TableCell>
                    <TableCell>{payment.invoice_number}</TableCell>
                    <TableCell>{payment.customer_name}</TableCell>
                    <TableCell>${parseFloat(payment.amount).toFixed(2)}</TableCell>
                    <TableCell>{payment.payment_method}</TableCell>
                    <TableCell>{payment.reference}</TableCell>
                  </TableRow>
                )) || (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-gray-500">
                      No recent payments found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}