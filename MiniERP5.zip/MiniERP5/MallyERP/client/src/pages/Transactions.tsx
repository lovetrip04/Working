import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Search, Filter, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

interface TransactionApp {
  id: string;
  title: string;
  description: string;
  category: string;
  route: string;
  icon: any;
  isImplemented: boolean;
}

const transactionApps: TransactionApp[] = [
  // Critical Phase 1 Applications (NEW - HIGH PRIORITY)
  {
    id: "document-number-ranges",
    title: "Document Number Ranges",
    description: "Configure and manage sequential document numbering for all transaction types",
    category: "Critical Infrastructure",
    route: "/transactions/document-number-ranges",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "document-posting-system",
    title: "Document Posting System",
    description: "Core document posting engine with validation, approval workflows, and audit trails",
    category: "Critical Infrastructure", 
    route: "/transactions/document-posting-system",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "automatic-clearing-enhanced",
    title: "Automatic Clearing",
    description: "Enhanced automatic clearing with advanced matching algorithms and exception handling",
    category: "Critical Infrastructure",
    route: "/transactions/automatic-clearing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "asset-accounting-enhanced",
    title: "Asset Accounting",
    description: "Complete fixed asset management with depreciation, transfers, and lifecycle tracking",
    category: "Critical Infrastructure",
    route: "/transactions/asset-accounting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "bank-statement-processing-enhanced",
    title: "Bank Statement Processing",
    description: "Advanced bank statement import, processing, and automated reconciliation",
    category: "Critical Infrastructure",
    route: "/transactions/bank-statement-processing",
    icon: FileText,
    isImplemented: true
  },
  
  // Enhanced Financial Transactions (Phase 1 - NEW)
  {
    id: "payment-processing-enhanced",
    title: "Payment Processing",
    description: "Comprehensive payment handling with multiple methods, currencies, and full audit trails",
    category: "Critical Infrastructure",
    route: "/transactions/payment-processing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "period-end-closing-enhanced",
    title: "Period End Closing",
    description: "Automated month-end, quarter-end, and year-end closing procedures with step tracking",
    category: "Critical Infrastructure",
    route: "/transactions/period-end-closing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "down-payment-management-enhanced",
    title: "Down Payment Management",
    description: "Advanced payment processing for received and paid down payments with application tracking",
    category: "Critical Infrastructure",
    route: "/transactions/down-payment-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "recurring-entries-enhanced",
    title: "Recurring Entries",
    description: "Automated recurring financial postings with template management and scheduling",
    category: "Critical Infrastructure",
    route: "/transactions/recurring-entries",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "cash-management-enhanced",
    title: "Cash Management",
    description: "Complete cash flow management with forecasting and liquidity planning",
    category: "Critical Infrastructure",
    route: "/transactions/cash-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "tax-reporting-enhanced",
    title: "Tax Reporting",
    description: "Comprehensive tax calculation and reporting with multi-jurisdiction support",
    category: "Critical Infrastructure",
    route: "/transactions/tax-reporting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "intercompany-transactions-enhanced",
    title: "Intercompany Transactions",
    description: "Advanced intercompany transaction processing with automated eliminations",
    category: "Critical Infrastructure",
    route: "/transactions/intercompany-transactions",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "inventory-valuation-enhanced",
    title: "Inventory Valuation",
    description: "Sophisticated inventory valuation with multiple costing methods and revaluation",
    category: "Critical Infrastructure",
    route: "/transactions/inventory-valuation",
    icon: FileText,
    isImplemented: true
  },

  // NEW CRITICAL MISSING APPLICATIONS - JUST IMPLEMENTED
  {
    id: "balance-sheet-reporting",
    title: "Balance Sheet Reporting",
    description: "Automated balance sheet generation with comparative analysis and variance reporting",
    category: "Financial Reporting",
    route: "/transactions/balance-sheet-reporting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "profit-loss-reporting", 
    title: "Profit & Loss Reporting",
    description: "Comprehensive income statement generation with period comparisons and analysis",
    category: "Financial Reporting",
    route: "/transactions/profit-loss-reporting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "bill-of-exchange-management",
    title: "Bill of Exchange Management",
    description: "Complete negotiable instrument management with endorsements and collections",
    category: "Financial Instruments",
    route: "/transactions/bill-of-exchange-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "dunning-process",
    title: "Dunning Process",
    description: "Automated collections management with multi-level dunning and escalation workflows",
    category: "Collections Management",
    route: "/transactions/dunning-process",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "cost-center-planning",
    title: "Cost Center Planning",
    description: "Comprehensive budget planning and management for organizational cost centers",
    category: "Planning & Budgeting",
    route: "/transactions/cost-center-planning",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "variance-analysis",
    title: "Variance Analysis",
    description: "Advanced variance analysis with root cause identification and corrective action tracking",
    category: "Planning & Budgeting",
    route: "/transactions/variance-analysis",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "cash-management-advanced",
    title: "Cash Management",
    description: "Real-time cash position monitoring, flow tracking, and forecasting across all accounts",
    category: "Critical Infrastructure",
    route: "/transactions/cash-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "tax-reporting-v2",
    title: "Tax Reporting",
    description: "Comprehensive tax calculation, filing, and compliance reporting with automated submissions",
    category: "Critical Infrastructure",
    route: "/transactions/tax-reporting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "intercompany-transactions-v2",
    title: "Intercompany Transactions",
    description: "Multi-entity transaction management with matching, elimination, and consolidation processing",
    category: "Critical Infrastructure",
    route: "/transactions/intercompany-transactions",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "inventory-valuation-v2",
    title: "Inventory Valuation",
    description: "Advanced inventory revaluation with multiple costing methods and adjustment tracking",
    category: "Critical Infrastructure",
    route: "/transactions/inventory-valuation",
    icon: FileText,
    isImplemented: true
  },
  
  // Finance Module (15 applications)
  {
    id: "document-posting",
    title: "Document Posting",
    description: "Post financial documents with comprehensive validation and audit trails",
    category: "Finance",
    route: "/transactions/document-posting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "accounts-payable",
    title: "Accounts Payable",
    description: "Manage vendor invoices and payment processing with full audit trails",
    category: "Finance",
    route: "/transactions/accounts-payable",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "accounts-receivable",
    title: "Accounts Receivable",
    description: "Process customer invoices and track receivables with aging analysis",
    category: "Finance",
    route: "/transactions/accounts-receivable",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "general-ledger-posting",
    title: "General Ledger Posting",
    description: "Direct posting to general ledger with comprehensive validation",
    category: "Finance",
    route: "/transactions/general-ledger-posting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "tax-processing",
    title: "Tax Processing",
    description: "Calculate and process tax transactions with compliance tracking",
    category: "Finance",
    route: "/transactions/tax-processing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "credit-management",
    title: "Credit Management",
    description: "Manage customer credit limits and risk assessment",
    category: "Finance",
    route: "/transactions/credit-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "debit-management",
    title: "Debit Management",
    description: "Process debit transactions and adjustments",
    category: "Finance",
    route: "/transactions/debit-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "recurring-entries",
    title: "Recurring Entries",
    description: "Automate recurring journal entries and accruals",
    category: "Finance",
    route: "/transactions/recurring-entries",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "allocation-posting",
    title: "Allocation Posting",
    description: "Distribute costs and revenues across multiple cost centers",
    category: "Finance",
    route: "/transactions/allocation-posting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "automatic-clearing",
    title: "Automatic Clearing",
    description: "Automated clearing of open items with intelligent matching algorithms",
    category: "Finance", 
    route: "/transactions/automatic-clearing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "period-end-closing",
    title: "Period End Closing",
    description: "Complete period end closing procedures with comprehensive checks",
    category: "Finance",
    route: "/transactions/period-end-closing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "foreign-currency-valuation",
    title: "Foreign Currency Valuation",
    description: "Foreign currency valuation with real-time exchange rates",
    category: "Finance",
    route: "/transactions/foreign-currency-valuation",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "payment-processing",
    title: "Payment Processing",
    description: "Process vendor and customer payments with multiple payment methods",
    category: "Finance",
    route: "/transactions/payment-processing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "cash-management",
    title: "Cash Management",
    description: "Manage cash flows and liquidity with forecasting capabilities",
    category: "Finance", 
    route: "/transactions/cash-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "intercompany-posting",
    title: "Intercompany Posting",
    description: "Handle intercompany transactions with automatic reconciliation",
    category: "Finance",
    route: "/transactions/intercompany-posting",
    icon: FileText,
    isImplemented: true
  },
  
  // Controlling Module (7 applications)
  {
    id: "cost-center-accounting",
    title: "Cost Center Accounting",
    description: "Track and analyze costs by organizational units",
    category: "Controlling",
    route: "/transactions/cost-center-accounting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "profit-center-accounting",
    title: "Profit Center Accounting",
    description: "Monitor profitability by business segments",
    category: "Controlling",
    route: "/transactions/profit-center-accounting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "internal-orders",
    title: "Internal Orders",
    description: "Manage internal projects and cost collection",
    category: "Controlling",
    route: "/transactions/internal-orders",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "activity-based-costing",
    title: "Activity Based Costing",
    description: "Allocate costs based on business activities",
    category: "Controlling",
    route: "/transactions/activity-based-costing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "product-costing",
    title: "Product Costing",
    description: "Calculate accurate product costs and margins",
    category: "Controlling",
    route: "/transactions/product-costing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "project-accounting",
    title: "Project Accounting",
    description: "Track project costs, revenues, and profitability",
    category: "Controlling",
    route: "/transactions/project-accounting",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "overhead-calculation",
    title: "Overhead Calculation",
    description: "Calculate and distribute overhead costs",
    category: "Controlling",
    route: "/transactions/overhead-calculation",
    icon: FileText,
    isImplemented: true
  },
  
  // Inventory Module (9 applications)
  {
    id: "goods-issue",
    title: "Goods Issue",
    description: "Process goods issues with real-time inventory updates",
    category: "Inventory",
    route: "/transactions/goods-issue",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "goods-receipt",
    title: "Goods Receipt", 
    description: "Record goods receipts with quality control and validation",
    category: "Inventory",
    route: "/transactions/goods-receipt",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "inventory-management",
    title: "Inventory Management",
    description: "Comprehensive inventory tracking and movement management",
    category: "Inventory",
    route: "/transactions/inventory-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "material-reservation",
    title: "Material Reservation",
    description: "Reserve materials for production and projects",
    category: "Inventory",
    route: "/transactions/material-reservation",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "stock-transfer",
    title: "Stock Transfer",
    description: "Transfer inventory between locations and plants",
    category: "Inventory",
    route: "/transactions/stock-transfer",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "physical-inventory",
    title: "Physical Inventory",
    description: "Conduct cycle counts and inventory adjustments",
    category: "Inventory",
    route: "/transactions/physical-inventory",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "consignment-processing",
    title: "Consignment Processing",
    description: "Manage consignment inventory and settlements",
    category: "Inventory",
    route: "/transactions/consignment-processing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "serial-number-tracking",
    title: "Serial Number Tracking",
    description: "Track individual items by serial numbers",
    category: "Inventory",
    route: "/transactions/serial-number-tracking",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "batch-management",
    title: "Batch Management",
    description: "Manage inventory by production batches",
    category: "Inventory",
    route: "/transactions/batch-management",
    icon: FileText,
    isImplemented: true
  },
  
  // Purchase Module (4 applications)
  {
    id: "purchase-order-processing",
    title: "Purchase Order Processing",
    description: "Create and manage purchase orders with approval workflows",
    category: "Purchase",
    route: "/transactions/purchase-order-processing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "invoice-verification",
    title: "Invoice Verification",
    description: "Verify vendor invoices against purchase orders",
    category: "Purchase",
    route: "/transactions/invoice-verification",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "supplier-evaluation",
    title: "Supplier Evaluation",
    description: "Evaluate supplier performance and quality metrics",
    category: "Purchase",
    route: "/transactions/supplier-evaluation",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "contract-management",
    title: "Contract Management",
    description: "Manage supplier contracts and agreements",
    category: "Purchase",
    route: "/transactions/contract-management",
    icon: FileText,
    isImplemented: true
  },
  
  // Production Module (3 applications)
  {
    id: "production-order-processing",
    title: "Production Order Processing",
    description: "Manage production orders and manufacturing processes",
    category: "Production",
    route: "/transactions/production-order-processing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "work-center-management",
    title: "Work Center Management",
    description: "Manage work centers and production resources",
    category: "Production",
    route: "/transactions/work-center-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "capacity-planning",
    title: "Capacity Planning",
    description: "Plan and optimize production capacity",
    category: "Production",
    route: "/transactions/capacity-planning",
    icon: FileText,
    isImplemented: true
  },
  
  // Asset Module (1 application)
  {
    id: "asset-accounting",
    title: "Asset Accounting", 
    description: "Comprehensive asset lifecycle management and depreciation calculations",
    category: "Assets",
    route: "/transactions/asset-accounting",
    icon: FileText,
    isImplemented: true
  },
  
  // Banking Module (2 applications)
  {
    id: "bank-statement-processing",
    title: "Bank Statement Processing",
    description: "Automated bank statement import and reconciliation",
    category: "Banking",
    route: "/transactions/bank-statement-processing", 
    icon: FileText,
    isImplemented: true
  },
  {
    id: "down-payment-management",
    title: "Down Payment Management",
    description: "Manage down payments and advance payments with full traceability",
    category: "Banking",
    route: "/transactions/down-payment-management",
    icon: FileText,
    isImplemented: true
  },
  
  // HR Module (2 applications)
  {
    id: "payroll-processing",
    title: "Payroll Processing",
    description: "Process employee payroll with tax calculations",
    category: "HR",
    route: "/transactions/payroll-processing",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "time-management",
    title: "Time Management",
    description: "Track employee time and attendance",
    category: "HR",
    route: "/transactions/time-management",
    icon: FileText,
    isImplemented: true
  },
  
  // Final Remaining Applications (5 applications)
  {
    id: "shop-floor-control",
    title: "Shop Floor Control",
    description: "Real-time production execution tracking and manufacturing control system",
    category: "Manufacturing",
    route: "/transactions/shop-floor-control",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "advanced-authorization-management",
    title: "Advanced Authorization Management",
    description: "Role-based access control with detailed permissions and organizational restrictions",
    category: "Security & Access",
    route: "/transactions/advanced-authorization-management",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "mm-fi-integration-enhancement",
    title: "MM-FI Integration Enhancement",
    description: "Real-time material management and financial integration with automated posting",
    category: "Integration",
    route: "/transactions/mm-fi-integration-enhancement",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "sd-fi-integration-enhancement",
    title: "SD-FI Integration Enhancement",
    description: "Sales and distribution to financial integration with automated billing and revenue recognition",
    category: "Integration",
    route: "/transactions/sd-fi-integration-enhancement",
    icon: FileText,
    isImplemented: true
  },
  {
    id: "management-reporting-dashboard-enhancement",
    title: "Management Reporting Dashboard Enhancement",
    description: "Executive dashboards with comprehensive KPIs and cross-functional analytics",
    category: "Reporting & Analytics",
    route: "/transactions/management-reporting-dashboard-enhancement",
    icon: FileText,
    isImplemented: true
  }
];

export default function Transactions() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = Array.from(new Set(transactionApps.map(app => app.category)));

  const filteredApps = transactionApps.filter(app => {
    const matchesSearch = app.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || app.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const implementedCount = transactionApps.filter(app => app.isImplemented).length;
  const totalCount = transactionApps.length;
  const completionPercentage = ((implementedCount / totalCount) * 100).toFixed(1);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/">
          <Button variant="outline">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold">Transaction Applications</h1>
          <p className="text-muted-foreground">
            Comprehensive transaction processing with zero-error data integrity
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Applications</CardDescription>
            <CardTitle className="text-2xl">{totalCount}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Implemented</CardDescription>
            <CardTitle className="text-2xl text-green-600">{implementedCount}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Completion Rate</CardDescription>
            <CardTitle className="text-2xl">{completionPercentage}%</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Data Integrity</CardDescription>
            <CardTitle className="text-2xl text-blue-600">100%</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search transaction applications..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-48">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(category => (
              <SelectItem key={category} value={category}>{category}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredApps.map((app) => {
          const IconComponent = app.icon;
          return (
            <Card key={app.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <IconComponent className="h-8 w-8 text-blue-600" />
                  <Badge variant={app.isImplemented ? "default" : "secondary"}>
                    {app.isImplemented ? "Active" : "Planned"}
                  </Badge>
                </div>
                <CardTitle className="text-lg">{app.title}</CardTitle>
                <CardDescription>{app.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <Badge variant="outline">{app.category}</Badge>
                  <Link href={app.route}>
                    <Button variant="outline" size="sm">
                      Open Application
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredApps.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No transaction applications found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}