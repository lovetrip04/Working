import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Building2, 
  Settings, 
  BookOpen, 
  CreditCard, 
  DollarSign, 
  FileText,
  Brain,
  TrendingUp,
  Calculator,
  PieChart, ArrowLeft } from "lucide-react";

export default function Finance() {
  const handleButtonClick = (path: string) => {
    window.location.href = path;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center mb-6">
          <Link href="/" className="mr-4 p-2 rounded-md hover:bg-gray-100">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Finance Module</h1>
            <p className="text-muted-foreground mt-2">
              Complete financial management with enterprise-standard configuration and AI guidance
            </p>
          </div>
        </div>
        <Badge variant="outline" className="px-3 py-1">
          AI-Enhanced
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Configuration Management */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-blue-600" />
              Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Set up enterprise structure, chart of accounts, and fiscal year settings
            </p>
            <div className="space-y-2">
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/configuration')}
              >
                <FileText className="h-4 w-4 mr-2" />
                Standard Configuration
              </Button>
              <Button 
                className="w-full justify-start"
                onClick={() => handleButtonClick('/finance/configuration-assistant')}
              >
                <Brain className="h-4 w-4 mr-2" />
                AI Configuration Assistant
              </Button>
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/end-to-end-guide')}
              >
                <BookOpen className="h-4 w-4 mr-2" />
                End-to-End Guide
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* General Ledger */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5 text-green-600" />
              General Ledger
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Manage chart of accounts, journal entries, and financial postings
            </p>
            <div className="space-y-2">
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/general-ledger')}
              >
                <Building2 className="h-4 w-4 mr-2" />
                GL Accounts
              </Button>
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/journal-entries')}
              >
                <FileText className="h-4 w-4 mr-2" />
                Journal Entries
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Accounts Receivable */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-purple-600" />
              Accounts Receivable
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Customer invoicing, payments, and receivables management
            </p>
            <div className="space-y-2">
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/accounts-receivable')}
              >
                <CreditCard className="h-4 w-4 mr-2" />
                Customer Invoices
              </Button>
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/payments-received')}
              >
                <DollarSign className="h-4 w-4 mr-2" />
                Payments Received
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Accounts Payable */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-orange-600" />
              Accounts Payable
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Vendor invoices, payments, and payables management
            </p>
            <div className="space-y-2">
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/accounts-payable')}
              >
                <FileText className="h-4 w-4 mr-2" />
                Vendor Invoices
              </Button>
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/payments-made')}
              >
                <DollarSign className="h-4 w-4 mr-2" />
                Payments Made
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Financial Reports */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5 text-indigo-600" />
              Financial Reports
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Balance sheet, P&L, trial balance, and financial analysis
            </p>
            <div className="space-y-2">
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/reports')}
              >
                <PieChart className="h-4 w-4 mr-2" />
                Financial Reports
              </Button>
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/trial-balance')}
              >
                <Calculator className="h-4 w-4 mr-2" />
                Trial Balance
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Finance Rookie */}
        <Card className="hover:shadow-lg transition-shadow border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-blue-600" />
              Finance Rookie
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Intelligent financial guidance and automated configuration
            </p>
            <div className="space-y-2">
              <Button 
                className="w-full justify-start bg-blue-600 hover:bg-blue-700 text-white"
                onClick={() => handleButtonClick('/ai-agents')}
              >
                <Brain className="h-4 w-4 mr-2" />
                Finance Rookie
              </Button>
              <Button 
                className="w-full justify-start" 
                variant="outline"
                onClick={() => handleButtonClick('/finance/configuration-assistant')}
              >
                <Settings className="h-4 w-4 mr-2" />
                Smart Configuration
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Financial Framework Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">GLOBL</div>
                <div className="text-sm text-green-700">Company Defined</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">1000</div>
                <div className="text-sm text-green-700">Company Code Active</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">INT</div>
                <div className="text-sm text-green-700">Chart of Accounts</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}