import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Eye, Package, Truck, FileText, ArrowLeft } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface SalesOrder {
  id: number;
  orderNumber: string;
  customerId: number;
  orderDate: string;
  requestedDeliveryDate?: string;
  totalAmount: string;
  currency: string;
  status: string;
  salesOrganization: string;
  distributionChannel: string;
  division: string;
}

interface SalesOrderItem {
  id: number;
  lineItem: number;
  materialId: number;
  quantity: string;
  unit: string;
  unitPrice: string;
  netAmount: string;
  taxAmount: string;
  plant: string;
  deliveryStatus: string;
  billingStatus: string;
}

interface Customer {
  id: number;
  name: string;
  email: string;
}

interface Product {
  id: number;
  name: string;
  price: number;
  unit: string;
}

export default function SalesOrderManagement() {
  const [selectedOrder, setSelectedOrder] = useState<SalesOrder | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newOrder, setNewOrder] = useState({
    customerId: '',
    requestedDeliveryDate: '',
    items: [{ materialId: '', quantity: '', plant: '1000' }]
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch sales orders
  const { data: salesOrders = [], isLoading: loadingOrders } = useQuery({
    queryKey: ['/api/sales-finance/sales-orders'],
  });

  // Fetch customers for dropdown
  const { data: customers = [] } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Fetch products for item selection
  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Create sales order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      return apiRequest('/api/sales-finance/sales-orders', {
        method: 'POST',
        body: JSON.stringify(orderData),
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/sales-finance/sales-orders'] });
      setIsCreateDialogOpen(false);
      setNewOrder({
        customerId: '',
        requestedDeliveryDate: '',
        items: [{ materialId: '', quantity: '', plant: '1000' }]
      });
      toast({
        title: "Sales Order Created",
        description: `Order ${data.data.salesOrder.orderNumber} created successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create sales order",
        variant: "destructive",
      });
    },
  });

  const handleCreateOrder = () => {
    const orderData = {
      customerId: parseInt(newOrder.customerId),
      requestedDeliveryDate: newOrder.requestedDeliveryDate || undefined,
      items: newOrder.items
        .filter(item => item.materialId && item.quantity)
        .map(item => ({
          materialId: parseInt(item.materialId),
          quantity: parseFloat(item.quantity),
          unit: 'EA', // Default unit
          plant: item.plant,
        })),
    };

    if (orderData.items.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one item to the order",
        variant: "destructive",
      });
      return;
    }

    createOrderMutation.mutate(orderData);
  };

  const addOrderItem = () => {
    setNewOrder(prev => ({
      ...prev,
      items: [...prev.items, { materialId: '', quantity: '', plant: '1000' }]
    }));
  };

  const updateOrderItem = (index: number, field: string, value: string) => {
    setNewOrder(prev => ({
      ...prev,
      items: prev.items.map((item, i) => 
        i === index ? { ...item, [field]: value } : item
      )
    }));
  };

  const removeOrderItem = (index: number) => {
    if (newOrder.items.length > 1) {
      setNewOrder(prev => ({
        ...prev,
        items: prev.items.filter((_, i) => i !== index)
      }));
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'CREATED': return 'secondary';
      case 'CONFIRMED': return 'default';
      case 'DELIVERED': return 'outline';
      case 'BILLED': return 'success';
      case 'CLOSED': return 'destructive';
      default: return 'secondary';
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Sales Order Management</h1>
            <p className="text-gray-600 mt-1">Create and manage customer sales orders - Tile S001</p>
          </div>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Sales Order
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Sales Order</DialogTitle>
              <DialogDescription>
                Enter the details for the new sales order
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              {/* Order Header */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="customer">Customer</Label>
                  <Select 
                    value={newOrder.customerId} 
                    onValueChange={(value) => setNewOrder(prev => ({ ...prev, customerId: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a customer" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id.toString()}>
                          {customer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="deliveryDate">Requested Delivery Date</Label>
                  <Input
                    id="deliveryDate"
                    type="date"
                    value={newOrder.requestedDeliveryDate}
                    onChange={(e) => setNewOrder(prev => ({ ...prev, requestedDeliveryDate: e.target.value }))}
                  />
                </div>
              </div>

              {/* Order Items */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-base font-semibold">Order Items</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addOrderItem}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                </div>
                {newOrder.items.map((item, index) => (
                  <div key={index} className="grid grid-cols-4 gap-4 p-4 border rounded-lg">
                    <div className="space-y-2">
                      <Label>Material</Label>
                      <Select 
                        value={item.materialId} 
                        onValueChange={(value) => updateOrderItem(index, 'materialId', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select material" />
                        </SelectTrigger>
                        <SelectContent>
                          {products.map((product) => (
                            <SelectItem key={product.id} value={product.id.toString()}>
                              {product.name} - ${product.price}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Quantity</Label>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateOrderItem(index, 'quantity', e.target.value)}
                        placeholder="Enter quantity"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Plant</Label>
                      <Input
                        value={item.plant}
                        onChange={(e) => updateOrderItem(index, 'plant', e.target.value)}
                        placeholder="Plant code"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeOrderItem(index)}
                        disabled={newOrder.items.length === 1}
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleCreateOrder}
                  disabled={createOrderMutation.isPending}
                >
                  {createOrderMutation.isPending ? 'Creating...' : 'Create Order'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Orders List */}
      <Card>
        <CardHeader>
          <CardTitle>Sales Orders</CardTitle>
          <CardDescription>
            Manage all customer sales orders and track their status
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loadingOrders ? (
            <div className="text-center py-8">Loading sales orders...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order Number</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Order Date</TableHead>
                  <TableHead>Delivery Date</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {salesOrders.data?.map((order: SalesOrder) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">{order.orderNumber}</TableCell>
                    <TableCell>
                      {customers.find(c => c.id === order.customerId)?.name || `Customer ${order.customerId}`}
                    </TableCell>
                    <TableCell>{new Date(order.orderDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      {order.requestedDeliveryDate ? new Date(order.requestedDeliveryDate).toLocaleDateString() : 'Not specified'}
                    </TableCell>
                    <TableCell>${parseFloat(order.totalAmount).toFixed(2)} {order.currency}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(order.status)}>
                        {order.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={() => setSelectedOrder(order)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Package className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <FileText className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Order Details Panel */}
      {selectedOrder && (
        <Card>
          <CardHeader>
            <CardTitle>Order Details - {selectedOrder.orderNumber}</CardTitle>
            <CardDescription>
              View detailed information about the selected sales order
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="overview" className="w-full">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="items">Items</TabsTrigger>
                <TabsTrigger value="delivery">Delivery</TabsTrigger>
                <TabsTrigger value="billing">Billing</TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-sm text-gray-500">Customer</Label>
                    <p className="font-medium">
                      {customers.find(c => c.id === selectedOrder.customerId)?.name || `Customer ${selectedOrder.customerId}`}
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm text-gray-500">Order Date</Label>
                    <p className="font-medium">{new Date(selectedOrder.orderDate).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <Label className="text-sm text-gray-500">Total Amount</Label>
                    <p className="font-medium">${parseFloat(selectedOrder.totalAmount).toFixed(2)} {selectedOrder.currency}</p>
                  </div>
                  <div>
                    <Label className="text-sm text-gray-500">Status</Label>
                    <Badge variant={getStatusBadgeVariant(selectedOrder.status)}>
                      {selectedOrder.status}
                    </Badge>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="items">
                <div className="text-center py-8 text-gray-500">
                  Order items will be displayed here when item details are loaded
                </div>
              </TabsContent>
              <TabsContent value="delivery">
                <div className="text-center py-8 text-gray-500">
                  Delivery information will be displayed here
                </div>
              </TabsContent>
              <TabsContent value="billing">
                <div className="text-center py-8 text-gray-500">
                  Billing information will be displayed here
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  );
}