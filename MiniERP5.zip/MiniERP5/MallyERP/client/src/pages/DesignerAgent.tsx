import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, FileText, Database, Monitor, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DesignerDocument {
  id: number;
  fileName: string;
  fileType: string;
  documentType: string;
  status: string;
  uploadedBy: string;
  uploadedAt: string;
}

interface AnalysisResult {
  id: number;
  analysisStatus: string;
  proposedTableChanges: any;
  newTablesRequired: any;
  proposedUIChanges: any;
  mockDataExamples: any;
  implementationPlan: any;
}

interface ReviewData {
  status: 'approved' | 'changes_requested' | 'rejected';
  comments: string;
  screenFeedback: Record<number, string>;
}

export default function DesignerAgent() {
  const [activeTab, setActiveTab] = useState('upload');
  const [documents, setDocuments] = useState<DesignerDocument[]>([]);
  const [selectedDocument, setSelectedDocument] = useState<DesignerDocument | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [reviewData, setReviewData] = useState<ReviewData>({
    status: 'approved',
    comments: '',
    screenFeedback: {}
  });
  const [systemArchitecture, setSystemArchitecture] = useState<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadDocuments();
    loadSystemArchitecture();
  }, []);

  const loadDocuments = async () => {
    try {
      const response = await fetch('/api/designer-agent/documents');
      if (response.ok) {
        const docs = await response.json();
        setDocuments(Array.isArray(docs) ? docs : []);
      } else {
        console.log('Designer Agent tables not yet created - starting with empty state');
        setDocuments([]);
      }
    } catch (error) {
      console.log('Designer Agent initializing - starting with empty document list');
      setDocuments([]);
    }
  };

  const loadSystemArchitecture = async () => {
    try {
      const response = await fetch('/api/designer-agent/system-architecture');
      const architecture = await response.json();
      setSystemArchitecture(architecture);
    } catch (error) {
      console.error('Failed to load system architecture:', error);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('document', file);
    formData.append('documentType', 'technical_spec');
    formData.append('uploadedBy', 'System Administrator');

    try {
      setUploadProgress(25);
      const response = await fetch('/api/designer-agent/upload-document', {
        method: 'POST',
        body: formData
      });

      setUploadProgress(75);
      const result = await response.json();
      
      if (response.ok) {
        setUploadProgress(100);
        toast({
          title: "Success",
          description: "Document uploaded successfully"
        });
        loadDocuments();
        setActiveTab('analyze');
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : "Failed to upload document",
        variant: "destructive"
      });
    } finally {
      setTimeout(() => setUploadProgress(0), 2000);
    }
  };

  const startAnalysis = async (documentId: number) => {
    try {
      const response = await fetch(`/api/designer-agent/analyze-document/${documentId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          analysisOptions: {
            prioritizeExistingTables: true,
            maintainDataIntegrity: true,
            generateMockData: true
          }
        })
      });

      const result = await response.json();
      
      if (response.ok) {
        toast({
          title: "Analysis Started",
          description: "Document analysis completed successfully"
        });
        loadAnalysisResults(result.analysisId);
        setActiveTab('review');
      }
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Failed to analyze document",
        variant: "destructive"
      });
    }
  };

  const loadAnalysisResults = async (analysisId: number) => {
    try {
      const response = await fetch(`/api/designer-agent/analysis/${analysisId}`);
      const analysisData = await response.json();
      setAnalysis(analysisData);
    } catch (error) {
      console.error('Failed to load analysis results:', error);
    }
  };

  const submitReview = async () => {
    if (!analysis) return;

    try {
      // First submit for review
      const reviewResponse = await fetch(`/api/designer-agent/submit-for-review/${analysis.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reviewedBy: 'System Administrator'
        })
      });

      const reviewResult = await reviewResponse.json();

      // Then process the feedback
      const feedbackResponse = await fetch(`/api/designer-agent/review-feedback/${reviewResult.reviewId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reviewData)
      });

      if (feedbackResponse.ok) {
        toast({
          title: "Review Submitted",
          description: `Analysis ${reviewData.status} successfully`
        });
        
        if (reviewData.status === 'approved') {
          setActiveTab('implementation');
        }
      }
    } catch (error) {
      toast({
        title: "Review Failed",
        description: "Failed to submit review",
        variant: "destructive"
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pending':
      case 'analyzing':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Designer Agent</h1>
        <p className="text-gray-600 mt-2">
          Intelligent document analysis and system architecture design
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="upload">Upload Document</TabsTrigger>
          <TabsTrigger value="analyze">Analyze & Design</TabsTrigger>
          <TabsTrigger value="review">Review & Approve</TabsTrigger>
          <TabsTrigger value="implementation">Implementation</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Document Upload
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <div className="space-y-2">
                  <label htmlFor="document-upload" className="cursor-pointer">
                    <span className="text-lg font-medium">Upload Technical Document</span>
                    <p className="text-gray-500">PDF, DOCX, or Image files up to 10MB</p>
                  </label>
                  <Input
                    id="document-upload"
                    type="file"
                    accept=".pdf,.docx,.doc,.png,.jpg,.jpeg"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <Button onClick={() => document.getElementById('document-upload')?.click()}>
                    Choose File
                  </Button>
                </div>
              </div>

              {uploadProgress > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Uploading...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} className="w-full" />
                </div>
              )}

              <div className="space-y-4">
                <h3 className="font-medium">Recent Documents</h3>
                <ScrollArea className="h-48">
                  {documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center justify-between p-3 border rounded-lg mb-2 cursor-pointer hover:bg-gray-50"
                      onClick={() => setSelectedDocument(doc)}
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="h-4 w-4" />
                        <div>
                          <p className="font-medium">{doc.fileName}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(doc.uploadedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(doc.status)}
                        <Badge variant="outline">{doc.status}</Badge>
                      </div>
                    </div>
                  ))}
                </ScrollArea>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analyze" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                System Analysis & Design
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedDocument ? (
                <div className="space-y-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h3 className="font-medium">Selected Document</h3>
                    <p className="text-sm text-gray-600">{selectedDocument.fileName}</p>
                    <Badge className="mt-2">{selectedDocument.documentType}</Badge>
                  </div>

                  <Button 
                    onClick={() => startAnalysis(selectedDocument.id)}
                    className="w-full"
                  >
                    Start Intelligent Analysis
                  </Button>

                  {systemArchitecture && (
                    <div className="space-y-4">
                      <h3 className="font-medium">Current System Architecture</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-sm">Database Tables</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-2xl font-bold">{systemArchitecture.totalTables}</p>
                            <p className="text-sm text-gray-500">Active tables</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-sm">UI Components</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-2xl font-bold">12</p>
                            <p className="text-sm text-gray-500">Business modules</p>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">Please select a document to analyze</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="review" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Monitor className="h-5 w-5" />
                Review & Approval
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {analysis ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <h3 className="font-medium">Table Changes</h3>
                        <p className="text-2xl font-bold">
                          {analysis.proposedTableChanges?.tableModifications?.length || 0}
                        </p>
                        <p className="text-sm text-gray-500">Modifications</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <h3 className="font-medium">New Tables</h3>
                        <p className="text-2xl font-bold">
                          {analysis.newTablesRequired?.length || 0}
                        </p>
                        <p className="text-sm text-gray-500">Required</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <h3 className="font-medium">UI Changes</h3>
                        <p className="text-2xl font-bold">
                          {analysis.proposedUIChanges?.length || 0}
                        </p>
                        <p className="text-sm text-gray-500">Components</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Side-by-Side UI Comparison */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Monitor className="h-5 w-5" />
                        UI Components Comparison
                      </CardTitle>
                      <p className="text-sm text-gray-600">
                        Review existing components vs proposed changes before proceeding
                      </p>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        
                        {/* Existing UI Components */}
                        <div className="space-y-4">
                          <h3 className="font-medium text-green-700 flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Existing UI Components
                          </h3>
                          <ScrollArea className="h-64 border rounded-lg p-4">
                            <div className="space-y-2">
                              {systemArchitecture?.uiComponents?.existing?.map((component: any, index: number) => (
                                <div key={index} className="flex items-center justify-between p-2 bg-green-50 rounded border-l-4 border-green-500">
                                  <span className="text-sm font-medium">{component.name}</span>
                                  <Badge variant="outline" className="text-green-700 border-green-700">
                                    {component.domain}
                                  </Badge>
                                </div>
                              )) || (
                                <div className="space-y-2">
                                  <div className="flex items-center justify-between p-2 bg-green-50 rounded border-l-4 border-green-500">
                                    <span className="text-sm font-medium">Finance Dashboard</span>
                                    <Badge variant="outline" className="text-green-700 border-green-700">Finance</Badge>
                                  </div>
                                  <div className="flex items-center justify-between p-2 bg-green-50 rounded border-l-4 border-green-500">
                                    <span className="text-sm font-medium">Sales Management</span>
                                    <Badge variant="outline" className="text-green-700 border-green-700">Sales</Badge>
                                  </div>
                                  <div className="flex items-center justify-between p-2 bg-green-50 rounded border-l-4 border-green-500">
                                    <span className="text-sm font-medium">Inventory Control</span>
                                    <Badge variant="outline" className="text-green-700 border-green-700">Inventory</Badge>
                                  </div>
                                  <div className="flex items-center justify-between p-2 bg-green-50 rounded border-l-4 border-green-500">
                                    <span className="text-sm font-medium">HR Management</span>
                                    <Badge variant="outline" className="text-green-700 border-green-700">HR</Badge>
                                  </div>
                                  <div className="flex items-center justify-between p-2 bg-green-50 rounded border-l-4 border-green-500">
                                    <span className="text-sm font-medium">Production Planning</span>
                                    <Badge variant="outline" className="text-green-700 border-green-700">Production</Badge>
                                  </div>
                                </div>
                              )}
                            </div>
                          </ScrollArea>
                        </div>

                        {/* Missing/New UI Components */}
                        <div className="space-y-4">
                          <h3 className="font-medium text-orange-700 flex items-center gap-2">
                            <AlertTriangle className="h-4 w-4" />
                            Missing & New Components
                          </h3>
                          <ScrollArea className="h-64 border rounded-lg p-4">
                            <div className="space-y-2">
                              {analysis.proposedUIChanges?.newComponents?.map((component: any, index: number) => (
                                <div key={index} className="flex items-center justify-between p-2 bg-orange-50 rounded border-l-4 border-orange-500">
                                  <span className="text-sm font-medium">{component.name}</span>
                                  <Badge variant="outline" className="text-orange-700 border-orange-700">
                                    {component.priority || 'New'}
                                  </Badge>
                                </div>
                              )) || (
                                <div className="space-y-2">
                                  <div className="flex items-center justify-between p-2 bg-orange-50 rounded border-l-4 border-orange-500">
                                    <span className="text-sm font-medium">Advanced Reporting</span>
                                    <Badge variant="outline" className="text-orange-700 border-orange-700">Missing</Badge>
                                  </div>
                                  <div className="flex items-center justify-between p-2 bg-blue-50 rounded border-l-4 border-blue-500">
                                    <span className="text-sm font-medium">Document Integration</span>
                                    <Badge variant="outline" className="text-blue-700 border-blue-700">New</Badge>
                                  </div>
                                  <div className="flex items-center justify-between p-2 bg-blue-50 rounded border-l-4 border-blue-500">
                                    <span className="text-sm font-medium">Workflow Automation</span>
                                    <Badge variant="outline" className="text-blue-700 border-blue-700">New</Badge>
                                  </div>
                                  <div className="flex items-center justify-between p-2 bg-orange-50 rounded border-l-4 border-orange-500">
                                    <span className="text-sm font-medium">Mobile Interface</span>
                                    <Badge variant="outline" className="text-orange-700 border-orange-700">Missing</Badge>
                                  </div>
                                </div>
                              )}
                            </div>
                          </ScrollArea>
                        </div>
                      </div>

                      {/* Impact Summary */}
                      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-medium text-blue-800 mb-2">Impact Summary</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-green-700">Existing Components:</span>
                            <p className="text-green-600">5 modules working properly</p>
                          </div>
                          <div>
                            <span className="font-medium text-orange-700">Missing Components:</span>
                            <p className="text-orange-600">2 components need to be added</p>
                          </div>
                          <div>
                            <span className="font-medium text-blue-700">New Features:</span>
                            <p className="text-blue-600">2 new capabilities proposed</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="space-y-4">
                    <h3 className="font-medium">Implementation Plan</h3>
                    {analysis.implementationPlan?.phases?.map((phase: any, index: number) => (
                      <Card key={index}>
                        <CardContent className="p-4">
                          <h4 className="font-medium">Phase {phase.phase}: {phase.name}</h4>
                          <ul className="mt-2 space-y-1">
                            {phase.tasks?.map((task: any, taskIndex: number) => (
                              <li key={taskIndex} className="text-sm text-gray-600">
                                • {task.task || task}
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-medium">Review Decision</h3>
                    <Select value={reviewData.status} onValueChange={(value: any) => 
                      setReviewData({...reviewData, status: value})
                    }>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="approved">Approve Implementation</SelectItem>
                        <SelectItem value="changes_requested">Request Changes</SelectItem>
                        <SelectItem value="rejected">Reject Proposal</SelectItem>
                      </SelectContent>
                    </Select>

                    <Textarea
                      placeholder="Review comments and feedback..."
                      value={reviewData.comments}
                      onChange={(e) => setReviewData({...reviewData, comments: e.target.value})}
                      rows={4}
                    />

                    <Button onClick={submitReview} className="w-full">
                      Submit Review Decision
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">No analysis results available</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="implementation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Implementation Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="font-medium text-green-800">Implementation Approved</h3>
                  <p className="text-green-600">
                    Changes will be automatically applied to the system and all agents will be notified.
                  </p>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Agent Notifications</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {['Chief Agent', 'Coach Agent', 'Player Agent', 'Rookie Agent'].map((agent) => (
                      <div key={agent} className="flex items-center justify-between p-2 border rounded">
                        <span className="text-sm">{agent}</span>
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}