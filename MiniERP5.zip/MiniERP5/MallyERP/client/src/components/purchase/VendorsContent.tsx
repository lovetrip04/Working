import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, Download, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function VendorsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  
  // Sample data for vendors
  const vendors = [
    {
      id: 1,
      vendor_number: "V0001",
      name: "Tech Supplies Inc.",
      contact_person: "John Smith",
      email: "jsmith@techsupplies.com",
      phone: "+1-123-456-7890",
      status: "Active",
      rating: "Preferred"
    },
    {
      id: 2,
      vendor_number: "V0002",
      name: "Global Manufacturing Ltd.",
      contact_person: "Sarah Johnson",
      email: "sarah@globalmanufacturing.com",
      phone: "+1-234-567-8901",
      status: "Active",
      rating: "Standard"
    },
    {
      id: 3,
      vendor_number: "V0003",
      name: "Industrial Components Co.",
      contact_person: "Robert Brown",
      email: "rbrown@industrialcomp.com",
      phone: "+1-345-678-9012",
      status: "Active",
      rating: "Standard"
    },
    {
      id: 4,
      vendor_number: "V0004",
      name: "Quality Parts Suppliers",
      contact_person: "Emily Davis",
      email: "emily@qualityparts.com",
      phone: "+1-456-789-0123",
      status: "Blocked",
      rating: "Standard"
    }
  ];

  const filteredVendors = vendors.filter(vendor => 
    vendor.vendor_number.toLowerCase().includes(searchTerm.toLowerCase()) || 
    vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vendor.contact_person.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vendor.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return <Badge className="bg-green-500 text-white">Active</Badge>;
      case 'blocked':
        return <Badge variant="destructive">Blocked</Badge>;
      case 'inactive':
        return <Badge variant="outline">Inactive</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getRatingBadge = (rating: string) => {
    switch (rating.toLowerCase()) {
      case 'preferred':
        return <Badge className="bg-blue-500 text-white">Preferred</Badge>;
      case 'standard':
        return <Badge className="bg-gray-500 text-white">Standard</Badge>;
      case 'probation':
        return <Badge className="bg-yellow-500 text-white">Probation</Badge>;
      default:
        return <Badge variant="outline">{rating}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search vendors..." 
            className="pl-8 rounded-md border border-input bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              console.log('Filter vendors clicked');
              // Add filter functionality
            }}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              console.log('Export vendors clicked');
              // Add export functionality
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button 
            size="sm"
            onClick={() => {
              console.log('New vendor clicked');
              // Add new vendor functionality
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            New Vendor
          </Button>
        </div>
      </div>
      
      {/* Vendors Table */}
      <Card>
        <CardHeader>
          <CardTitle>Vendors</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredVendors.length > 0 ? (
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vendor Number</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Contact Person</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Rating</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredVendors.map((vendor) => (
                    <TableRow key={vendor.id}>
                      <TableCell className="font-medium">{vendor.vendor_number}</TableCell>
                      <TableCell>{vendor.name}</TableCell>
                      <TableCell>{vendor.contact_person}</TableCell>
                      <TableCell>{vendor.email}</TableCell>
                      <TableCell>{vendor.phone}</TableCell>
                      <TableCell>{getStatusBadge(vendor.status)}</TableCell>
                      <TableCell>{getRatingBadge(vendor.rating)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm ? 'No vendors match your search.' : 'No vendors found.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}