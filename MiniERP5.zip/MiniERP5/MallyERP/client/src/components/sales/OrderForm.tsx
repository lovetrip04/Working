import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Trash2 } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const orderItemSchema = z.object({
  productId: z.string().min(1, "Please select a product"),
  quantity: z.string().transform((val) => parseInt(val, 10)).refine((val) => val > 0, "Quantity must be greater than 0"),
  unitPrice: z.number().optional(),
  total: z.number().optional(),
});

const orderSchema = z.object({
  customerId: z.string().min(1, "Please select a customer"),
  date: z.string().min(1, "Please enter a date"),
  status: z.string().min(1, "Please select a status"),
  items: z.array(orderItemSchema).min(1, "Please add at least one item"),
  notes: z.string().optional(),
  shippingAddress: z.string().optional(),
});

type OrderFormValues = z.infer<typeof orderSchema>;

interface OrderFormProps {
  defaultValues?: Partial<OrderFormValues>;
  orderId?: number;
  onSuccess?: () => void;
}

export default function OrderForm({ defaultValues, orderId, onSuccess }: OrderFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [items, setItems] = useState<any[]>(defaultValues?.items || [{ productId: "", quantity: "1" }]);

  const { data: customers } = useQuery({
    queryKey: ['/api/customers'],
  });

  const { data: products } = useQuery({
    queryKey: ['/api/products'],
  });

  const form = useForm<OrderFormValues>({
    resolver: zodResolver(orderSchema),
    defaultValues: defaultValues || {
      customerId: "",
      date: new Date().toISOString().split('T')[0],
      status: "Processing",
      items: [{ productId: "", quantity: "1" }],
      notes: "",
      shippingAddress: "",
    },
  });

  const addItem = () => {
    setItems([...items, { productId: "", quantity: "1" }]);
  };

  const removeItem = (index: number) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  };

  const updateItem = (index: number, field: string, value: string) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
    
    // Update form values
    const currentItems = form.getValues("items") || [];
    currentItems[index] = { ...currentItems[index], [field]: value };
    form.setValue("items", currentItems);
  };

  const getProductPrice = (productId: string): number => {
    if (!products) return 0;
    const product = products.find((p: any) => p.id.toString() === productId);
    return product ? product.price : 0;
  };

  const calculateTotal = (productId: string, quantity: string): number => {
    const price = getProductPrice(productId);
    const qty = parseInt(quantity, 10) || 0;
    return price * qty;
  };

  const { mutate, isPending } = useMutation({
    mutationFn: async (data: OrderFormValues) => {
      // Process items to include calculated unit price and total
      data.items = data.items.map(item => ({
        ...item,
        unitPrice: getProductPrice(item.productId),
        total: calculateTotal(item.productId, item.quantity.toString())
      }));

      if (orderId) {
        return apiRequest("PUT", `/api/orders/${orderId}`, data);
      } else {
        return apiRequest("POST", "/api/orders", data);
      }
    },
    onSuccess: () => {
      toast({
        title: orderId ? "Order updated" : "Order created",
        description: orderId
          ? "The order has been updated successfully."
          : "The new order has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: OrderFormValues) {
    mutate(data);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="customerId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Customer</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a customer" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {customers?.map((customer: any) => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="status"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Status</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="Processing">Processing</SelectItem>
                  <SelectItem value="Shipped">Shipped</SelectItem>
                  <SelectItem value="Delivered">Delivered</SelectItem>
                  <SelectItem value="Canceled">Canceled</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="shippingAddress"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Shipping Address</FormLabel>
              <FormControl>
                <Input placeholder="Shipping address" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div>
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium">Order Items</h3>
            <Button type="button" variant="outline" size="sm" onClick={addItem}>
              Add Item
            </Button>
          </div>

          <div className="space-y-2">
            {items.map((item, index) => (
              <div key={index} className="flex items-center gap-2 p-2 border rounded-md">
                <div className="flex-1">
                  <Select
                    value={item.productId}
                    onValueChange={(value) => updateItem(index, "productId", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select product" />
                    </SelectTrigger>
                    <SelectContent>
                      {products?.map((product: any) => (
                        <SelectItem key={product.id} value={product.id.toString()}>
                          {product.name} (${product.price.toFixed(2)})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-24">
                  <Input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, "quantity", e.target.value)}
                    min="1"
                    placeholder="Qty"
                  />
                </div>
                <div className="w-24 text-right">
                  ${calculateTotal(item.productId, item.quantity).toFixed(2)}
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeItem(index)}
                  disabled={items.length === 1}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
          <FormMessage>{form.formState.errors.items?.message}</FormMessage>
        </div>

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Input placeholder="Order notes" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="text-right font-medium">
          Total: $
          {items
            .reduce(
              (sum, item) => sum + calculateTotal(item.productId, item.quantity),
              0
            )
            .toFixed(2)}
        </div>

        <Button type="submit" className="w-full" disabled={isPending}>
          {isPending ? "Saving..." : orderId ? "Update Order" : "Create Order"}
        </Button>
      </form>
    </Form>
  );
}
